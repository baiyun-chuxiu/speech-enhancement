import type { AudioFormat } from './types';
import type { ProcessingRuntimeCapabilities } from './types';

import {
  APP_SETTINGS_STORAGE_KEY,
  DEFAULT_APP_SETTINGS,
  LEGACY_LOCALE_STORAGE_KEY,
  LOCALE_COOKIE_KEY,
  getRuntimeCapabilitiesFromSystemInfo,
  getStoredAppSettings,
  normalizeAppSettings,
  persistAppSettings,
  type AppSettings,
} from './app-settings';

function createStorage(
  initial: Record<string, string> = {}
): Pick<Storage, 'getItem' | 'setItem' | 'removeItem'> & { store: Record<string, string> } {
  const store = { ...initial };
  return {
    store,
    getItem: (key: string) => store[key] ?? null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
  };
}

describe('app-settings', () => {
  describe('getStoredAppSettings', () => {
    it('returns the default settings when nothing is persisted', () => {
      const storage = createStorage();

      expect(getStoredAppSettings({ storage })).toEqual(DEFAULT_APP_SETTINGS);
    });

    it('merges saved settings with the legacy locale key', () => {
      const storage = createStorage({
        [APP_SETTINGS_STORAGE_KEY]: JSON.stringify({
          apiUrl: 'http://custom:9000',
          theme: 'dark',
          notifications: false,
        }),
        [LEGACY_LOCALE_STORAGE_KEY]: 'en',
      });

      expect(getStoredAppSettings({ storage })).toEqual({
        ...DEFAULT_APP_SETTINGS,
        apiUrl: 'http://custom:9000',
        theme: 'dark',
        notifications: false,
        locale: 'en',
      });
    });
  });

  describe('normalizeAppSettings', () => {
    it('normalizes unsupported values against runtime capabilities', () => {
      const capabilities: ProcessingRuntimeCapabilities = {
        supportedDevices: ['cpu'],
        supportedQualities: ['balanced'],
        supportedOutputFormats: ['wav'],
        completionCapabilities: {
          autoSave: false,
          notifications: true,
        },
      };

      const normalized = normalizeAppSettings(
        {
          ...DEFAULT_APP_SETTINGS,
          device: 'cuda',
          quality: 'fast',
          outputFormat: 'mp3',
          autoSave: true,
          notifications: true,
        },
        capabilities,
      );

      expect(normalized.device).toBe('cpu');
      expect(normalized.quality).toBe('balanced');
      expect(normalized.outputFormat).toBe('wav' satisfies AudioFormat);
      expect(normalized.autoSave).toBe(false);
      expect(normalized.notifications).toBe(true);
    });
  });

  describe('getRuntimeCapabilitiesFromSystemInfo', () => {
    it('keeps auto device available when the backend reports concrete runtimes', () => {
      const capabilities = getRuntimeCapabilitiesFromSystemInfo({
        device: 'cpu',
        supported_devices: ['cpu', 'cuda'],
      });

      expect(capabilities.supportedDevices).toEqual(['auto', 'cpu', 'cuda']);
    });
  });

  describe('persistAppSettings', () => {
    it('writes the settings payload, legacy locale value, and locale cookie', () => {
      const storage = createStorage();
      const cookieState = { cookie: '' };
      const nextSettings: AppSettings = {
        ...DEFAULT_APP_SETTINGS,
        apiUrl: 'http://example.com:8000',
        locale: 'en',
      };

      persistAppSettings(nextSettings, { storage, cookieStore: cookieState });

      expect(storage.store[APP_SETTINGS_STORAGE_KEY]).toBe(JSON.stringify(nextSettings));
      expect(storage.store[LEGACY_LOCALE_STORAGE_KEY]).toBe('en');
      expect(cookieState.cookie).toContain(`${LOCALE_COOKIE_KEY}=en`);
      expect(cookieState.cookie).toContain('path=/');
    });
  });
});
