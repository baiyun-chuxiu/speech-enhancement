# Library Module

[根目录](../CLAUDE.md) > **lib/**

## Module Overview

Utility functions, type definitions, and API abstraction layer for the InfoCom application.

## Module Structure

```
lib/
├── types.ts                # Centralized TypeScript type definitions
├── utils.ts                # Tailwind class merging utility
├── utils.test.ts           # Utils tests
├── api/                    # Multi-backend API implementations
│   ├── index.ts            # API exports
│   ├── model-api.ts        # Unified model API interface
│   ├── model-api.test.ts   # API tests
│   └── infocom.ts          # INFOCOM REST API client
└── utils/
    └── data-parser.ts      # Sensor data parsing utilities
```

## Type Definitions (`types.ts`)

Centralized type definitions for all application state structures.

### File-Related Types

```typescript
interface FileInfo {
  id: string;
  name: string;
  size: number;
  type: string;
  lastModified: number;
  uploadedAt: Date;
  status: UploadStatus;
  progress: number;
  file?: File;
  path?: string;  // Tauri file path
}

type UploadStatus = 'idle' | 'uploading' | 'success' | 'error' | 'validating';

interface TextFileInfo extends FileInfo {
  content?: string;
  encoding?: string;
  lineCount?: number;
  wordCount?: number;
}

interface AudioFileInfo extends FileInfo {
  duration?: number;
  sampleRate?: number;
  channels?: number;
  bitRate?: number;
  format?: AudioFormat;
}

type AudioFormat = 'mp3' | 'wav' | 'm4a' | 'ogg' | 'flac' | 'aac';
```

### Audio Analysis Types

```typescript
interface AudioAnalysis {
  duration: number;
  sampleRate: number;
  channels: number;
  bitRate: number;
  format: AudioFormat;
  waveformData: number[];      // Normalized 0-1
  frequencyData?: number[];
  peakAmplitude: number;
  averageAmplitude: number;
  silenceRatio: number;
}

interface AudioPlaybackState {
  isPlaying: boolean;
  isPaused: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  playbackRate: number;
  isLoading: boolean;
  error?: string;
}
```

### Model Processing Types

```typescript
interface ModelProcessRequest {
  textFile: TextFileInfo;
  audioFile: AudioFileInfo;
  textContent?: string;
  audioData?: ArrayBuffer;
  options?: ModelProcessOptions;
}

interface ModelProcessOptions {
  model?: string;
  language?: string;
  quality?: 'fast' | 'balanced' | 'high';
  outputFormat?: AudioFormat;
  sampleRate?: number;
}

interface ModelProcessResponse {
  success: boolean;
  outputAudio?: ProcessedAudio;
  metadata?: ProcessMetadata;
  error?: string;
}

interface ProcessedAudio {
  id: string;
  data: ArrayBuffer;
  url?: string;        // Blob URL for playback
  path?: string;       // Local file path
  format: AudioFormat;
  duration: number;
  sampleRate: number;
  size: number;
  createdAt: Date;
}

interface ProcessMetadata {
  processingTime: number;
  modelUsed: string;
  inputTextLength: number;
  inputAudioDuration: number;
  outputAudioDuration: number;
  steps: ProcessStep[];
}

interface ProcessStep {
  name: string;
  status: ProcessStatus;
  progress: number;
  startTime?: Date;
  endTime?: Date;
  message?: string;
}

type ProcessStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'skipped';
```

### API Interface Types

```typescript
interface ModelApiInterface {
  process(request: ModelProcessRequest): Promise<ModelProcessResponse>;
  getProgress(taskId: string): Promise<ProcessStep[]>;
  cancelProcess(taskId: string): Promise<void>;
  checkModelStatus(): Promise<ModelStatus>;
}

interface ModelStatus {
  isAvailable: boolean;
  modelName: string;
  modelVersion: string;
  capabilities: string[];
  memoryUsage?: number;
  gpuAvailable?: boolean;
}
```

## Multi-Backend API (`api/model-api.ts`)

Unified interface supporting five backend implementations with automatic environment detection.

### Architecture

```mermaid
graph TB
    Client[Application Code]
    ModelApi[modelApi.getApi<br/>环境自动检测]

    Client -->|调用| ModelApi

    ModelApi -->|Tauri环境| TauriApi[TauriModelApi]
    ModelApi -->|Web模式| InfocomApi[InfocomModelApi]
    ModelApi -->|配置HTTP| HttpApi[HttpModelApi]
    ModelApi -->|实时通信| WsApi[WebSocketModelApi]
    ModelApi -->|开发模式| MockApi[MockModelApi<br/>默认]

    TauriApi --> Rust[Rust Commands<br/>invoke]
    HttpApi --> HTTP[HTTP Server<br/>localhost:8080]
    WsApi --> WS[WebSocket<br/>localhost:8080/ws]
    InfocomApi --> INFO[INFOCOM<br/>localhost:8000]
    MockApi --> Local[本地模拟]

    style MockApi fill:#ffcdd2
```

### API Implementations

| Implementation | Environment | Transport | Use Case |
|----------------|-------------|-----------|----------|
| **TauriModelApi** | Desktop app only | Tauri invoke commands | Production (desktop) |
| **InfocomModelApi** | Web/Desktop | HTTP REST (localhost:8000) | Production (web) |
| **HttpModelApi** | Web/Desktop | HTTP REST (localhost:8080) | Custom backend |
| **WebSocketModelApi** | Web/Desktop | WebSocket (ws://localhost:8080/ws) | Real-time updates |
| **MockModelApi** | Any | In-memory simulation | Development/testing |

### Usage

```typescript
import { modelApi } from '@/lib/api/model-api';

// Set backend mode (optional, defaults to 'mock')
modelApi.setMode('infocom');  // or 'tauri', 'http', 'mock'

// Process audio and text
const response = await modelApi.process({
  textFile,
  audioFile,
  textContent: '...',
  options: { quality: 'balanced', outputFormat: 'wav' },
});

// Check progress
const steps = await modelApi.getProgress(taskId);

// Cancel processing
await modelApi.cancelProcess(taskId);

// Check model status
const status = await modelApi.checkModelStatus();
```

### TauriModelApi

Uses `@tauri-apps/api/core` invoke commands for optimal desktop performance.

**Commands**:
- `process_audio_text` - Main processing command
- `get_process_progress` - Poll task progress
- `cancel_process` - Cancel running task
- `check_model_status` - Model availability check
- `save_audio_file` - Save output to disk
- `read_text_file` - Read file contents
- `read_audio_file` - Read audio bytes

### InfocomModelApi

Client for the INFOCOM REST API server.

**API Endpoints**:
- `GET /health` - Health check
- `GET /api/v1/system/info` - System information
- `POST /api/v1/files/upload` - Upload files
- `POST /api/v1/audiophase/enhance` - Enhance audio
- `POST /api/v1/sensor/process` - Process sensor data
- `GET /api/v1/tasks/:id` - Get task status
- `POST /api/v1/tasks/:id/cancel` - Cancel task
- `GET /api/v1/files/download/:id` - Download file
- `WS /ws/tasks/:id` - WebSocket for real-time updates

### MockModelApi

Development implementation that returns simulated data.

**Features**:
- Generates WAV file with sine wave
- Simulates 2-second processing delay
- Returns mock metadata with 4 processing steps
- Always reports model as available

## INFOCOM API Client (`api/infocom.ts`)

Specialized client for INFOCOM REST API with WebSocket support.

### Key Features

- **Configurable API URL** - Stored in localStorage
- **XHR-based uploads** - For progress tracking
- **WebSocket support** - Real-time task updates
- **Full pipeline helper** - `processAudioWithSensors()`

### Example Usage

```typescript
import * as infocomApi from '@/lib/api/infocom';

// Check health
const health = await infocomApi.checkHealth();

// Upload file with progress
const result = await infocomApi.uploadFile(file, (progress) => {
  console.log(`Upload: ${progress}%`);
});

// Enhance audio
const enhance = await infocomApi.enhanceAudio({
  file_id: result.file_id,
  model_type: 'phase_net_18',
  device: 'auto',
});

// Monitor progress
const ws = infocomApi.createTaskWebSocket(
  enhance.task_id,
  (status) => console.log('Status:', status.progress)
);
```

## Utilities (`utils.ts`)

### `cn()` Function

Tailwind class merging utility using `clsx` and `tailwind-merge`.

```typescript
import { cn } from '@/lib/utils';

// Merge classes with deduplication
cn('px-4 py-2', 'px-2');  // 'py-2 px-2'

// Conditional classes
cn('base-class', isActive && 'active-class', className);

// Common usage in components
<div className={cn(
  'flex items-center gap-2',
  disabled && 'opacity-50',
  className
)} />
```

## Data Parser (`utils/data-parser.ts`)

Utilities for parsing sensor data files.

### Features

- Parse accelerometer/gyroscope text files
- Extract X/Y/Z axis data
- Calculate statistics (min, max, mean, std)
- Downsample for visualization

## Testing

- **Test Files**: 2/8 (25%)
- **Coverage**:
  - `utils.test.ts` ✅
  - `model-api.test.ts` ✅
  - `infocom.test.ts` ✅

## Known Issues

1. **No request cancellation** - HTTP requests lack abort controller support
2. **Error handling inconsistency** - Different APIs throw different error formats
3. **Type safety gaps** - Some `any` types in INFOCOM client
4. **WebSocket reconnection** - No automatic reconnection logic

## Future Enhancements

1. **Request queueing** - Queue multiple requests with concurrency limits
2. **Response caching** - Cache GET requests with TTL
3. **Retry logic** - Automatic retry with exponential backoff
4. **Type safety** - Replace remaining `any` types with proper types
5. **WebSocket heartbeat** - Keep connection alive with ping/pong
