import { defaultLocale, isLocale, LOCALE_COOKIE_KEY, LOCALE_STORAGE_KEY, type Locale } from '@/i18n/config';
import type {
  AudioFormat,
  CompletionCapabilities,
  ComputeDevice,
  ProcessingQuality,
  ProcessingRuntimeCapabilities,
} from './types';

export { LOCALE_COOKIE_KEY };

export type AppTheme = 'light' | 'dark' | 'system';

export interface AppSettings {
  apiUrl: string;
  theme: AppTheme;
  device: ComputeDevice;
  quality: ProcessingQuality;
  outputFormat: AudioFormat;
  autoSave: boolean;
  notifications: boolean;
  locale: Locale;
}

interface StorageLike {
  getItem?: (key: string) => string | null;
  setItem?: (key: string, value: string) => void;
  removeItem?: (key: string) => void;
}

interface CookieStoreLike {
  cookie: string;
}

interface SettingsReadOptions {
  storage?: StorageLike;
  cookieHeader?: string | null;
}

interface SettingsWriteOptions {
  storage?: StorageLike;
  cookieStore?: CookieStoreLike;
}

export const APP_SETTINGS_STORAGE_KEY = 'infocom-settings';
export const LEGACY_LOCALE_STORAGE_KEY = LOCALE_STORAGE_KEY;
export const DEFAULT_APP_SETTINGS: AppSettings = {
  apiUrl: 'http://localhost:8000',
  theme: 'system',
  device: 'auto',
  quality: 'balanced',
  outputFormat: 'wav',
  autoSave: true,
  notifications: true,
  locale: defaultLocale,
};

export const DEFAULT_COMPLETION_CAPABILITIES: CompletionCapabilities = {
  autoSave: false,
  notifications: true,
};

export const DEFAULT_RUNTIME_CAPABILITIES: ProcessingRuntimeCapabilities = {
  supportedDevices: ['auto', 'cpu'],
  supportedQualities: ['balanced'],
  supportedOutputFormats: ['wav'],
  completionCapabilities: DEFAULT_COMPLETION_CAPABILITIES,
};

function getBrowserStorage(): StorageLike | undefined {
  if (typeof window === 'undefined') {
    return undefined;
  }

  return window.localStorage;
}

function safeParseSettings(raw: string | null | undefined): Partial<AppSettings> {
  if (!raw) {
    return {};
  }

  try {
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return typeof parsed === 'object' && parsed !== null ? parsed : {};
  } catch {
    return {};
  }
}

export function parseLocaleCookie(cookieHeader?: string | null): Locale | null {
  if (!cookieHeader) {
    return null;
  }

  const parts = cookieHeader.split(';').map((part) => part.trim());
  const match = parts.find((part) => part.startsWith(`${LOCALE_COOKIE_KEY}=`));
  if (!match) {
    return null;
  }

  const value = decodeURIComponent(match.split('=').slice(1).join('='));
  return isLocale(value) ? value : null;
}

function pickSupportedValue<T extends string>(
  current: T,
  supported: readonly T[],
  fallback: T,
): T {
  if (supported.includes(current)) {
    return current;
  }

  if (supported.includes(fallback)) {
    return fallback;
  }

  return supported[0] ?? fallback;
}

export function normalizeAppSettings(
  settings: Partial<AppSettings>,
  capabilities?: Partial<ProcessingRuntimeCapabilities>,
): AppSettings {
  const merged: AppSettings = {
    ...DEFAULT_APP_SETTINGS,
    ...settings,
    locale: isLocale(settings.locale) ? settings.locale : DEFAULT_APP_SETTINGS.locale,
  };

  if (!capabilities) {
    return merged;
  }

  return {
    ...merged,
    device: capabilities.supportedDevices?.length
      ? pickSupportedValue(merged.device, capabilities.supportedDevices, DEFAULT_APP_SETTINGS.device)
      : merged.device,
    quality: capabilities.supportedQualities?.length
      ? pickSupportedValue(merged.quality, capabilities.supportedQualities, DEFAULT_APP_SETTINGS.quality)
      : merged.quality,
    outputFormat: capabilities.supportedOutputFormats?.length
      ? pickSupportedValue(
          merged.outputFormat,
          capabilities.supportedOutputFormats,
          DEFAULT_APP_SETTINGS.outputFormat,
        )
      : merged.outputFormat,
    autoSave: capabilities.completionCapabilities
      ? capabilities.completionCapabilities.autoSave && merged.autoSave
      : merged.autoSave,
    notifications: capabilities.completionCapabilities
      ? capabilities.completionCapabilities.notifications && merged.notifications
      : merged.notifications,
  };
}

interface RuntimeSystemInfoShape {
  device?: string;
  supported_devices?: string[];
  supported_qualities?: string[];
  supported_output_formats?: string[];
}

export function getClientCompletionCapabilities(): CompletionCapabilities {
  const isTauriRuntime = typeof window !== 'undefined' && '__TAURI__' in window;

  return {
    autoSave: isTauriRuntime,
    notifications: true,
  };
}

export function getRuntimeCapabilitiesFromSystemInfo(
  systemInfo?: RuntimeSystemInfoShape,
  completionCapabilities: CompletionCapabilities = DEFAULT_COMPLETION_CAPABILITIES,
): ProcessingRuntimeCapabilities {
  const supportedDevices = (systemInfo?.supported_devices?.filter(Boolean) as ComputeDevice[] | undefined) ??
    (systemInfo?.device ? (['auto', systemInfo.device].filter(Boolean) as ComputeDevice[]) : undefined);
  const supportedQualities = systemInfo?.supported_qualities?.filter(Boolean) as ProcessingQuality[] | undefined;
  const supportedOutputFormats = systemInfo?.supported_output_formats?.filter(Boolean) as AudioFormat[] | undefined;

  return {
    supportedDevices: supportedDevices?.length
      ? Array.from(new Set(['auto', ...supportedDevices]))
      : DEFAULT_RUNTIME_CAPABILITIES.supportedDevices,
    supportedQualities: supportedQualities?.length
      ? Array.from(new Set(supportedQualities))
      : DEFAULT_RUNTIME_CAPABILITIES.supportedQualities,
    supportedOutputFormats: supportedOutputFormats?.length
      ? Array.from(new Set(supportedOutputFormats))
      : DEFAULT_RUNTIME_CAPABILITIES.supportedOutputFormats,
    completionCapabilities,
  };
}

export function getStoredAppSettings(options: SettingsReadOptions = {}): AppSettings {
  const storage = options.storage ?? getBrowserStorage();
  const storedSettings = safeParseSettings(storage?.getItem?.(APP_SETTINGS_STORAGE_KEY));
  const cookieLocale = parseLocaleCookie(options.cookieHeader);
  const legacyLocale = storage?.getItem?.(LEGACY_LOCALE_STORAGE_KEY);

  const locale = isLocale(storedSettings.locale)
    ? storedSettings.locale
    : cookieLocale ?? (isLocale(legacyLocale) ? legacyLocale : defaultLocale);

  return normalizeAppSettings({
    ...storedSettings,
    locale,
  });
}

function buildLocaleCookie(locale: Locale): string {
  const encodedLocale = encodeURIComponent(locale);
  return `${LOCALE_COOKIE_KEY}=${encodedLocale}; path=/; max-age=31536000; samesite=lax`;
}

export function persistAppSettings(
  settings: AppSettings,
  options: SettingsWriteOptions = {},
): AppSettings {
  const normalized = normalizeAppSettings(settings);
  const storage = options.storage ?? getBrowserStorage();

  storage?.setItem?.(APP_SETTINGS_STORAGE_KEY, JSON.stringify(normalized));
  storage?.setItem?.(LEGACY_LOCALE_STORAGE_KEY, normalized.locale);

  if (options.cookieStore) {
    options.cookieStore.cookie = buildLocaleCookie(normalized.locale);
  } else if (typeof document !== 'undefined') {
    document.cookie = buildLocaleCookie(normalized.locale);
  }

  return normalized;
}
