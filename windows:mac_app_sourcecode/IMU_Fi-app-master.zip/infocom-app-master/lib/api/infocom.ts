/**
 * INFOCOM API Client
 * 
 * Client library for interacting with the INFOCOM REST API server.
 */

import { getStoredAppSettings } from '../app-settings';
import type { AudioFormat, ComputeDevice, ProcessingQuality } from '../types';

const STORAGE_KEY = 'infocom-settings';
const DEFAULT_API_URL = 'http://localhost:8000';
const DESKTOP_API_URL_CACHE_KEY = '__INFOCOM_DESKTOP_API_URL__';

type DesktopRuntimeWindow = Window & {
  __TAURI__?: unknown;
  __INFOCOM_DESKTOP_API_URL__?: string;
};

export interface ApiSettings {
  apiUrl: string;
}

export interface HealthResponse {
  status: string;
  version: string;
  timestamp: string;
  readiness_status?: string;
  is_ready?: boolean;
  degraded_reason?: string | null;
}

export interface ReadinessResponse {
  status: string;
  version: string;
  timestamp: string;
  is_ready: boolean;
  configured_device: string;
  effective_device: string;
  supported_devices: ComputeDevice[];
  degraded_reason: string | null;
}

export interface SystemInfo {
  version: string;
  python_version: string;
  platform: string;
  cuda_available: boolean;
  mps_available: boolean;
  configured_device: string;
  device: string;
  supported_devices: ComputeDevice[];
  status: string;
  is_ready: boolean;
  degraded_reason: string | null;
  generator_loaded: boolean;
  denoise_loaded: boolean;
  generator_model_exists: boolean;
  denoise_model_exists: boolean;
  generator_error?: string | null;
  denoise_error?: string | null;
  supported_qualities?: ProcessingQuality[];
  supported_output_formats?: AudioFormat[];
  default_quality?: ProcessingQuality;
  default_output_format?: AudioFormat;
}

export interface FileUploadResponse {
  success: boolean;
  file_id: string;
  filename: string;
  size: number;
  content_type: string;
  path: string;
}

export type DeviceType = ComputeDevice;

export interface EnhancementRequestOptions {
  device?: DeviceType;
  quality?: ProcessingQuality;
  outputFormat?: AudioFormat;
}

export interface EnhanceResponse {
  success: boolean;
  task_id: string;
  status: string;
  requested_device?: DeviceType;
  effective_device?: DeviceType;
  quality?: ProcessingQuality;
  output_format?: AudioFormat;
  output_file?: string;
  output_url?: string;
}

export type TaskStatusValue = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface ProcessingStep {
  index: number;
  name: string;
  status: TaskStatusValue;
  progress: number;
  message: string;
  duration: number | null;
}

export interface TaskStatus {
  task_id: string;
  status: TaskStatusValue;
  progress: number;
  message?: string;
  steps: ProcessingStep[];
  result?: Record<string, unknown> | null;
  error?: string | null;
  requested_device?: DeviceType | null;
  effective_device?: DeviceType | null;
  created_at: string;
  updated_at: string;
}

export interface ApiError {
  error: string;
  message: string;
  path?: string;
}

function getDesktopRuntimeWindow(): DesktopRuntimeWindow | null {
  if (typeof window === 'undefined') {
    return null;
  }

  return window as DesktopRuntimeWindow;
}

function getCachedDesktopApiUrl(): string | null {
  const runtimeWindow = getDesktopRuntimeWindow();
  const cachedUrl = runtimeWindow?.[DESKTOP_API_URL_CACHE_KEY];
  return typeof cachedUrl === 'string' && cachedUrl.length > 0 ? cachedUrl : null;
}

function setCachedDesktopApiUrl(apiUrl: string): void {
  const runtimeWindow = getDesktopRuntimeWindow();
  if (runtimeWindow) {
    runtimeWindow[DESKTOP_API_URL_CACHE_KEY] = apiUrl;
  }
}

function buildDesktopApiUrl(port: number): string {
  return `http://127.0.0.1:${port}`;
}

/**
 * Get the API URL with multi-mode detection:
 * 1. Tauri desktop → invoke get_server_port for local sidecar
 * 2. User-configured remote server (mobile or manual override)
 * 3. Default dev server (localhost:8000)
 */
export async function getApiUrl(): Promise<string> {
  if (typeof window === 'undefined') return DEFAULT_API_URL;

  const desktopApiUrl = getCachedDesktopApiUrl();
  if (desktopApiUrl) {
    return desktopApiUrl;
  }

  // 1. Tauri desktop mode: query sidecar port.
  // Tauri 2 does not expose `window.__TAURI__` unless `app.withGlobalTauri` is enabled,
  // so we probe the command directly and fall back cleanly when the runtime is unavailable.
  try {
    const { invoke } = await import('@tauri-apps/api/core');
    const port = await invoke<number>('get_server_port');
    if (!Number.isInteger(port) || port <= 0) {
      throw new Error(`Invalid sidecar port: ${String(port)}`);
    }
    const apiUrl = buildDesktopApiUrl(port);
    setCachedDesktopApiUrl(apiUrl);
    return apiUrl;
  } catch {
    // Tauri runtime or command unavailable, fall through to stored settings/defaults.
  }

  // 2. User-configured remote server URL
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const settings = JSON.parse(saved);
      if (settings.apiUrl) return settings.apiUrl;
    }
    return getStoredAppSettings().apiUrl;
  } catch {
    // Ignore parse errors
  }

  // 3. Default dev mode
  return DEFAULT_API_URL;
}

function resolveEnhancementOptions(
  options: EnhancementRequestOptions | DeviceType = 'auto',
): Required<EnhancementRequestOptions> {
  if (typeof options === 'string') {
    return {
      device: options,
      quality: 'balanced',
      outputFormat: 'wav',
    };
  }

  return {
    device: options.device ?? 'auto',
    quality: options.quality ?? 'balanced',
    outputFormat: options.outputFormat ?? 'wav',
  };
}

/**
 * Synchronous fallback for contexts where async isn't possible.
 * Prefers user settings, then default.
 */
export function getApiUrlSync(): string {
  if (typeof window === 'undefined') return DEFAULT_API_URL;

  const desktopApiUrl = getCachedDesktopApiUrl();
  if (desktopApiUrl) {
    return desktopApiUrl;
  }

  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const settings = JSON.parse(saved);
      return settings.apiUrl || DEFAULT_API_URL;
    }
  } catch {
    // Ignore parse errors
  }
  return DEFAULT_API_URL;
}

/**
 * Base fetch wrapper with error handling
 */
async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const apiUrl = await getApiUrl();
  const url = `${apiUrl}${endpoint}`;
  
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  
  if (!response.ok) {
    const error: ApiError = await response.json().catch(() => ({
      error: 'Network Error',
      message: `Request failed with status ${response.status}`,
    }));
    throw new Error(error.message || error.error);
  }
  
  return response.json();
}

/**
 * Check API server health
 */
export async function checkHealth(): Promise<HealthResponse> {
  return apiFetch<HealthResponse>('/health');
}

/**
 * Check backend readiness
 */
export async function checkReadiness(): Promise<ReadinessResponse> {
  return apiFetch<ReadinessResponse>('/ready');
}

/**
 * Get system information
 */
export async function getSystemInfo(): Promise<SystemInfo> {
  return apiFetch<SystemInfo>('/api/v1/system/info');
}

/**
 * Upload a file to the server
 */
export async function uploadFile(
  file: File,
  onProgress?: (progress: number) => void
): Promise<FileUploadResponse> {
  const apiUrl = await getApiUrl();
  const formData = new FormData();
  formData.append('file', file);
  
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable && onProgress) {
        const progress = Math.round((e.loaded / e.total) * 100);
        onProgress(progress);
      }
    });
    
    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText));
        } catch {
          reject(new Error('Failed to parse response'));
        }
      } else {
        try {
          const error = JSON.parse(xhr.responseText);
          reject(new Error(error.message || error.error || 'Upload failed'));
        } catch {
          reject(new Error(`Upload failed with status ${xhr.status}`));
        }
      }
    });
    
    xhr.addEventListener('error', () => {
      reject(new Error('Network error during upload'));
    });
    
    xhr.addEventListener('abort', () => {
      reject(new Error('Upload aborted'));
    });
    
    xhr.open('POST', `${apiUrl}/api/v1/files/upload`);
    xhr.send(formData);
  });
}

/**
 * Start audio enhancement with three files (multipart upload).
 * Matches server endpoint: POST /api/v1/enhance
 */
export async function startEnhance(
  audioFile: File,
  accelFile: File,
  gyroFile: File,
  options: EnhancementRequestOptions | DeviceType = 'auto',
): Promise<EnhanceResponse> {
  const apiUrl = await getApiUrl();
  const formData = new FormData();
  formData.append('audio_file', audioFile);
  formData.append('accel_file', accelFile);
  formData.append('gyro_file', gyroFile);

  const resolvedOptions = resolveEnhancementOptions(options);
  const params = new URLSearchParams({
    device: resolvedOptions.device,
    quality: resolvedOptions.quality,
    output_format: resolvedOptions.outputFormat,
  });
  const response = await fetch(`${apiUrl}/api/v1/enhance?${params}`, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: `HTTP ${response.status}` }));
    throw new Error(error.message || error.detail || 'Enhancement request failed');
  }

  return response.json();
}

/**
 * Start enhancement using previously uploaded file IDs.
 * Matches server endpoint: POST /api/v1/enhance/uploaded
 */
export async function startEnhanceByIds(
  audioFileId: string,
  accelFileId: string,
  gyroFileId: string,
  options: EnhancementRequestOptions | DeviceType = 'auto',
): Promise<EnhanceResponse> {
  const apiUrl = await getApiUrl();
  const resolvedOptions = resolveEnhancementOptions(options);
  const params = new URLSearchParams({
    audio_file_id: audioFileId,
    accel_file_id: accelFileId,
    gyro_file_id: gyroFileId,
    device: resolvedOptions.device,
    quality: resolvedOptions.quality,
    output_format: resolvedOptions.outputFormat,
  });

  const response = await fetch(`${apiUrl}/api/v1/enhance/uploaded?${params}`, {
    method: 'POST',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: `HTTP ${response.status}` }));
    throw new Error(error.message || error.detail || 'Enhancement request failed');
  }

  return response.json();
}

/**
 * Get task status
 */
export async function getTaskStatus(taskId: string): Promise<TaskStatus> {
  return apiFetch<TaskStatus>(`/api/v1/tasks/${taskId}`);
}

/**
 * Cancel a running task
 */
export async function cancelTask(taskId: string): Promise<{ success: boolean }> {
  return apiFetch<{ success: boolean }>(`/api/v1/tasks/${taskId}/cancel`, {
    method: 'POST',
  });
}

/**
 * Download a processed file
 */
export function getDownloadUrl(fileId: string): string {
  const apiUrl = getApiUrlSync();
  return `${apiUrl}/api/v1/files/download/${fileId}`;
}

/**
 * WebSocket connection for real-time task updates
 */
export function createTaskWebSocket(
  taskId: string,
  onMessage: (status: TaskStatus) => void,
  onError?: (error: Error) => void,
  onClose?: () => void
): WebSocket {
  const apiUrl = getApiUrlSync();
  const wsUrl = apiUrl.replace(/^http/, 'ws');
  const ws = new WebSocket(`${wsUrl}/ws/tasks/${taskId}`);
  
  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === 'ping') return; // heartbeat
      onMessage(data as TaskStatus);
    } catch (e) {
      console.error('Failed to parse WebSocket message:', e);
    }
  };
  
  ws.onerror = () => {
    onError?.(new Error('WebSocket connection error'));
  };
  
  ws.onclose = () => {
    onClose?.();
  };
  
  return ws;
}

/**
 * Full processing pipeline: upload three files → start enhance → poll until done.
 * Matches the server's POST /api/v1/enhance multipart endpoint.
 */
export interface ProcessingOptions {
  accelFile: File;
  gyroFile: File;
  audioFile: File;
  device?: DeviceType;
  quality?: ProcessingQuality;
  outputFormat?: AudioFormat;
  onProgress?: (task: TaskStatus) => void;
}

export interface ProcessingResult {
  success: boolean;
  task?: TaskStatus;
  outputFileId?: string;
  outputUrl?: string;
  error?: string;
}

export async function processAudioWithSensors(
  options: ProcessingOptions
): Promise<ProcessingResult> {
  const { accelFile, gyroFile, audioFile, device = 'auto', quality = 'balanced', outputFormat = 'wav', onProgress } = options;

  try {
    // Start enhancement (multipart upload of all three files)
    const enhanceResult = await startEnhance(audioFile, accelFile, gyroFile, {
      device,
      quality,
      outputFormat,
    });

    if (!enhanceResult.success) {
      throw new Error('Failed to start enhancement');
    }

    // Poll until done
    const startTime = Date.now();
    const timeoutMs = 300000; // 5 minutes
    const intervalMs = 500;

    while (true) {
      const task = await getTaskStatus(enhanceResult.task_id);
      onProgress?.(task);

      if (task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled') {
        if (task.status === 'failed') {
          throw new Error(task.error || 'Enhancement failed');
        }
        if (task.status === 'cancelled') {
          throw new Error('Enhancement was cancelled');
        }

        const result = task.result as Record<string, unknown> | undefined;
        const outputFileId = result?.output_file_id as string | undefined;
        const outputUrl = result?.output_url as string | undefined;

        return {
          success: true,
          task,
          outputFileId,
          outputUrl: outputUrl || (outputFileId ? getDownloadUrl(outputFileId) : undefined),
        };
      }

      if (Date.now() - startTime > timeoutMs) {
        throw new Error('Enhancement timed out');
      }

      await new Promise((r) => setTimeout(r, intervalMs));
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}
