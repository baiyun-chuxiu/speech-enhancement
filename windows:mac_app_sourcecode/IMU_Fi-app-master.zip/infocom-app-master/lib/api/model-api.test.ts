import { modelApi, MockModelApi, InfocomModelApi } from './model-api';
import type { ModelProcessRequest, TextFileInfo, AudioFileInfo } from '../types';

// Mock URL.createObjectURL
global.URL.createObjectURL = jest.fn(() => 'blob:mock-url');

// Mock the infocom API module
jest.mock('./infocom', () => ({
  checkHealth: jest.fn(),
  checkReadiness: jest.fn(),
  getSystemInfo: jest.fn(),
  uploadFile: jest.fn(),
  startEnhance: jest.fn(),
  startEnhanceByIds: jest.fn(),
  getTaskStatus: jest.fn(),
  cancelTask: jest.fn(),
  getDownloadUrl: jest.fn(),
}));

// Mock the enhancer API module
jest.mock('./enhancer-api', () => ({
  checkEnhancerHealth: jest.fn(),
  checkEnhancerReadiness: jest.fn(),
  getEnhancerSystemInfo: jest.fn(),
  startEnhancement: jest.fn(),
  pollEnhancerTask: jest.fn(),
  cancelEnhancerTask: jest.fn(),
  getEnhancerDownloadUrl: jest.fn(),
  getEnhancerApiUrl: jest.fn(() => 'http://localhost:8000'),
  setEnhancerApiUrl: jest.fn(),
  getEnhancerTaskStatus: jest.fn(),
  uploadEnhancerFile: jest.fn(),
  startEnhancementByIds: jest.fn(),
  createEnhancerTaskWebSocket: jest.fn(),
  enhanceAudioFull: jest.fn(),
  ENHANCER_PIPELINE_STEPS: [
    'IMU Data Preprocessing',
    'GAN Video Displacement Generation',
    'Audio Feature Extraction (STFT)',
    'Joint Denoise Inference',
    'Spectrogram Post-processing',
    'Audio Reconstruction (ISTFT)',
  ],
}));

import * as infocomApi from './infocom';

describe('ModelApi', () => {
  describe('MockModelApi', () => {
    const mockApi = new MockModelApi();

    it('returns successful response with mock audio', async () => {
      const request: ModelProcessRequest = {
        textFile: {
          id: 'text-1',
          name: 'test.txt',
          size: 100,
          type: 'text/plain',
          status: 'success',
          uploadedAt: new Date(),
          content: 'test content',
          lineCount: 10,
          wordCount: 50,
        } as TextFileInfo,
        audioFile: {
          id: 'audio-1',
          name: 'test.wav',
          size: 1000,
          type: 'audio/wav',
          status: 'success',
          uploadedAt: new Date(),
          duration: 5,
          format: 'wav',
          sampleRate: 44100,
        } as AudioFileInfo,
        textContent: 'test content',
      };

      const result = await mockApi.process(request);

      expect(result.success).toBe(true);
      expect(result.outputAudio).toBeDefined();
      expect(result.outputAudio?.format).toBe('wav');
      expect(result.outputAudio?.url).toMatch(/^blob:/);
    });

    it('returns available model status', async () => {
      const status = await mockApi.checkModelStatus();

      expect(status.isAvailable).toBe(true);
      expect(status.modelName).toBe('mock-model');
      expect(status.capabilities).toContain('text-to-speech');
    });

    it('returns progress steps', async () => {
      const steps = await mockApi.getProgress();

      expect(Array.isArray(steps)).toBe(true);
      expect(steps.length).toBeGreaterThan(0);
    });

    it('cancel process completes without error', async () => {
      await expect(mockApi.cancelProcess()).resolves.not.toThrow();
    });
  });

  describe('InfocomModelApi', () => {
    const infocomModelApi = new InfocomModelApi();

    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('checks health and calls startEnhance', async () => {
      const mockAudioFile = new File(['audio'], 'test.wav', { type: 'audio/wav' });
      const mockAccelFile = new File(['accel'], 'accel.txt', { type: 'text/plain' });
      const mockGyroFile = new File(['gyro'], 'gyro.txt', { type: 'text/plain' });

      (infocomApi.checkReadiness as jest.Mock).mockResolvedValue({ is_ready: true });
      (infocomApi.startEnhance as jest.Mock).mockResolvedValue({
        success: true,
        task_id: 'task-123',
      });
      (infocomApi.getTaskStatus as jest.Mock).mockResolvedValue({
        status: 'completed',
        progress: 100,
        steps: [],
        result: { output_file_id: 'out-123' },
      });
      (infocomApi.getDownloadUrl as jest.Mock).mockReturnValue('http://localhost:8000/api/v1/files/download/out-123');

      const request: ModelProcessRequest = {
        textFile: {
          id: 'text-1',
          name: 'test.txt',
          size: 100,
          type: 'text/plain',
          status: 'success',
          uploadedAt: new Date(),
        } as TextFileInfo,
        audioFile: {
          id: 'audio-1',
          name: 'test.wav',
          size: 1000,
          type: 'audio/wav',
          status: 'success',
          uploadedAt: new Date(),
          file: mockAudioFile,
        } as AudioFileInfo,
        options: {
          accelFile: mockAccelFile,
          gyroFile: mockGyroFile,
        } as unknown as import('../types').ModelProcessOptions,
      };

      const result = await infocomModelApi.process(request);

      expect(infocomApi.checkReadiness).toHaveBeenCalled();
      expect(infocomApi.startEnhance).toHaveBeenCalledWith(
        mockAudioFile,
        mockAccelFile,
        mockGyroFile,
        expect.objectContaining({
          device: 'auto',
          quality: 'balanced',
          outputFormat: 'wav',
        }),
      );
      expect(result.success).toBe(true);
    });

    it('returns error when accel/gyro files missing', async () => {
      (infocomApi.checkReadiness as jest.Mock).mockResolvedValue({ is_ready: true });

      const request: ModelProcessRequest = {
        textFile: {
          id: 'text-1',
          name: 'test.txt',
          size: 100,
          type: 'text/plain',
          status: 'success',
          uploadedAt: new Date(),
        } as TextFileInfo,
        audioFile: {
          id: 'audio-1',
          name: 'test.wav',
          size: 1000,
          type: 'audio/wav',
          status: 'success',
          uploadedAt: new Date(),
          file: new File(['audio'], 'test.wav', { type: 'audio/wav' }),
        } as AudioFileInfo,
      };

      const result = await infocomModelApi.process(request);

      expect(result.success).toBe(false);
      expect(result.error).toContain('Accelerometer and gyroscope files are required');
    });

    it('returns error when health check fails', async () => {
      (infocomApi.checkReadiness as jest.Mock).mockRejectedValue(new Error('Connection failed'));

      const request: ModelProcessRequest = {
        textFile: {
          id: 'text-1',
          name: 'test.txt',
          size: 100,
          type: 'text/plain',
          status: 'success',
          uploadedAt: new Date(),
        } as TextFileInfo,
        audioFile: {
          id: 'audio-1',
          name: 'test.wav',
          size: 1000,
          type: 'audio/wav',
          status: 'success',
          uploadedAt: new Date(),
        } as AudioFileInfo,
      };

      const result = await infocomModelApi.process(request);

      expect(result.success).toBe(false);
      expect(result.error).toBe('Connection failed');
    });

    it('checks model status correctly', async () => {
      (infocomApi.checkReadiness as jest.Mock).mockResolvedValue({ is_ready: true });
      (infocomApi.getSystemInfo as jest.Mock).mockResolvedValue({ 
        version: '1.0.0',
        cuda_available: true,
      });

      const status = await infocomModelApi.checkModelStatus();

      expect(status.isAvailable).toBe(true);
      expect(status.modelName).toBe('infocom-enhance');
    });

    it('returns unavailable when health check fails', async () => {
      (infocomApi.checkReadiness as jest.Mock).mockRejectedValue(new Error('Failed'));

      const status = await infocomModelApi.checkModelStatus();

      expect(status.isAvailable).toBe(false);
    });

    it('cancels task correctly', async () => {
      (infocomApi.cancelTask as jest.Mock).mockResolvedValue({ success: true });

      await infocomModelApi.cancelProcess('task-123');

      expect(infocomApi.cancelTask).toHaveBeenCalledWith('task-123');
    });

    it('gets progress correctly', async () => {
      (infocomApi.getTaskStatus as jest.Mock).mockResolvedValue({
        task_id: 'task-123',
        status: 'running',
        progress: 50,
        steps: [
          { index: 0, name: 'IMU Data Preprocessing', status: 'completed', progress: 100, message: '' },
          { index: 1, name: 'GAN Video Displacement', status: 'running', progress: 50, message: '' },
        ],
      });

      const steps = await infocomModelApi.getProgress('task-123');

      expect(steps.length).toBe(2);
      expect(steps[0].status).toBe('completed');
      expect(steps[1].status).toBe('processing');
      expect(steps[1].progress).toBe(50);
    });
  });

  describe('modelApi singleton', () => {
    it('defaults to enhancer mode', () => {
      // Default mode is enhancer
      expect(modelApi).toBeDefined();
    });

    it('can switch to mock mode', () => {
      modelApi.setUseMock(true);
      expect(modelApi).toBeDefined();
    });

    it('can switch to infocom mode', () => {
      modelApi.setUseMock(false);
      expect(modelApi).toBeDefined();
    });

    it('can set mode directly', () => {
      modelApi.setMode('mock');
      expect(modelApi).toBeDefined();
      
      modelApi.setMode('infocom');
      expect(modelApi).toBeDefined();

      modelApi.setMode('enhancer');
      expect(modelApi).toBeDefined();
    });
  });
});
