/**
 * 本地模型 API 接口层
 * 
 * ============ 技术栈说明 ============
 * 
 * 本接口支持三种通信方式，按优先级排序：
 * 
 * 1. Tauri invoke (推荐)
 *    - 通过 Rust 后端直接调用本地模型
 *    - 性能最优，安全性最高
 *    - 适用于: 桌面应用、iOS/Android Tauri 移动端
 *    - 依赖: @tauri-apps/api
 * 
 * 2. HTTP REST API
 *    - 通过 localhost HTTP 服务调用
 *    - 兼容性好，易于调试
 *    - 适用于: 独立模型服务、微服务架构
 *    - 端点: http://localhost:8080/api
 * 
 * 3. WebSocket
 *    - 实时双向通信
 *    - 适用于: 流式处理、实时进度更新
 *    - 端点: ws://localhost:8080/ws
 * 
 * ============ 本地模型推荐 ============
 * 
 * iOS 平台:
 *   - Core ML: Apple 官方框架，性能优异
 *   - MLX: Apple Silicon 优化的 ML 框架
 *   - whisper.cpp: 语音识别，支持 Core ML 加速
 * 
 * Android 平台:
 *   - TensorFlow Lite: Google 官方，生态完善
 *   - ONNX Runtime Mobile: 跨平台，模型兼容性好
 *   - MediaPipe: 实时音频处理
 * 
 * 跨平台 (通过 Tauri Rust FFI):
 *   - whisper.cpp: 语音转文字
 *   - llama.cpp: 文本生成
 *   - Coqui TTS: 文字转语音
 *   - bark.cpp: 高质量语音合成
 */

import type {
  ComputeDevice,
  ModelProcessRequest,
  ModelProcessResponse,
  ModelStatus,
  ProcessStep,
  ProcessingQuality,
  ProcessedAudio,
  AudioFormat,
} from '../types';
import {
  DEFAULT_APP_SETTINGS,
  getClientCompletionCapabilities,
  getRuntimeCapabilitiesFromSystemInfo,
  normalizeAppSettings,
} from '../app-settings';
import * as infocomApi from './infocom';
import * as enhancerApi from './enhancer-api';

// API 配置
const API_CONFIG = {
  HTTP_BASE_URL: 'http://localhost:8080/api',
  WS_URL: 'ws://localhost:8080/ws',
  TIMEOUT: 300000, // 5分钟超时
};

// 检测运行环境
const isTauri = (): boolean => {
  return typeof window !== 'undefined' && '__TAURI__' in window;
};

/**
 * Tauri API 实现
 * 通过 Rust 后端调用本地模型
 */
class TauriModelApi {
  private async invoke<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
    if (!isTauri()) {
      throw new Error('Tauri API 不可用，请在 Tauri 环境中运行');
    }
    const { invoke } = await import('@tauri-apps/api/core');
    return invoke<T>(cmd, args);
  }

  async process(request: ModelProcessRequest): Promise<ModelProcessResponse> {
    try {
      const result = await this.invoke<ModelProcessResponse>('process_audio_text', {
        textPath: request.textFile.path,
        audioPath: request.audioFile.path,
        textContent: request.textContent,
        options: request.options,
      });
      return result;
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : '处理失败',
      };
    }
  }

  async getProgress(taskId: string): Promise<ProcessStep[]> {
    return this.invoke<ProcessStep[]>('get_process_progress', { taskId });
  }

  async cancelProcess(taskId: string): Promise<void> {
    await this.invoke<void>('cancel_process', { taskId });
  }

  async checkModelStatus(): Promise<ModelStatus> {
    try {
      return await this.invoke<ModelStatus>('check_model_status');
    } catch {
      return {
        isAvailable: false,
        modelName: 'unknown',
        modelVersion: '0.0.0',
        capabilities: [],
      };
    }
  }

  async saveOutputAudio(audioData: ArrayBuffer, format: AudioFormat): Promise<string> {
    const uint8Array = new Uint8Array(audioData);
    return this.invoke<string>('save_audio_file', {
      data: Array.from(uint8Array),
      format,
    });
  }

  async readTextFile(path: string): Promise<string> {
    return this.invoke<string>('read_text_file', { path });
  }

  async readAudioFile(path: string): Promise<Uint8Array> {
    const data = await this.invoke<number[]>('read_audio_file', { path });
    return new Uint8Array(data);
  }
}

/**
 * HTTP API 实现
 * 通过 localhost HTTP 服务调用
 */
class HttpModelApi {
  private baseUrl = API_CONFIG.HTTP_BASE_URL;

  async process(request: ModelProcessRequest): Promise<ModelProcessResponse> {
    try {
      const formData = new FormData();
      
      if (request.textFile.file) {
        formData.append('textFile', request.textFile.file);
      }
      if (request.audioFile.file) {
        formData.append('audioFile', request.audioFile.file);
      }
      if (request.options) {
        formData.append('options', JSON.stringify(request.options));
      }

      const response = await fetch(`${this.baseUrl}/process`, {
        method: 'POST',
        body: formData,
        signal: AbortSignal.timeout(API_CONFIG.TIMEOUT),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      
      // 如果返回了音频数据，转换为 ProcessedAudio
      if (result.audioData) {
        const audioBlob = new Blob(
          [Uint8Array.from(atob(result.audioData), c => c.charCodeAt(0))],
          { type: `audio/${result.format || 'wav'}` }
        );
        result.outputAudio = {
          ...result.outputAudio,
          url: URL.createObjectURL(audioBlob),
        } as ProcessedAudio;
      }

      return result;
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : '处理失败',
      };
    }
  }

  async getProgress(taskId: string): Promise<ProcessStep[]> {
    const response = await fetch(`${this.baseUrl}/progress/${taskId}`);
    if (!response.ok) {
      throw new Error(`获取进度失败: ${response.statusText}`);
    }
    return response.json();
  }

  async cancelProcess(taskId: string): Promise<void> {
    await fetch(`${this.baseUrl}/process/${taskId}`, { method: 'DELETE' });
  }

  async checkModelStatus(): Promise<ModelStatus> {
    try {
      const response = await fetch(`${this.baseUrl}/model/status`, {
        signal: AbortSignal.timeout(5000),
      });
      if (!response.ok) {
        throw new Error('模型服务不可用');
      }
      return response.json();
    } catch {
      return {
        isAvailable: false,
        modelName: 'unknown',
        modelVersion: '0.0.0',
        capabilities: [],
      };
    }
  }
}

/**
 * WebSocket API 实现
 * 用于实时进度更新和流式处理
 */
class WebSocketModelApi {
  private ws: WebSocket | null = null;
  private wsUrl = API_CONFIG.WS_URL;

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.wsUrl);
      this.ws.onopen = () => resolve();
      this.ws.onerror = (error) => reject(error);
    });
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  onProgress(callback: (step: ProcessStep) => void): void {
    if (this.ws) {
      this.ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === 'progress') {
          callback(data.step);
        }
      };
    }
  }

  sendProcessRequest(request: ModelProcessRequest): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'process',
        payload: request,
      }));
    }
  }
}

/**
 * INFOCOM API 实现
 * 通过 INFOCOM REST API 服务调用
 */
class InfocomModelApi {
  async process(request: ModelProcessRequest): Promise<ModelProcessResponse> {
    try {
      // 检查服务器健康状态
      await infocomApi.checkReadiness();
      const systemInfo = await infocomApi.getSystemInfo();
      const runtimeCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        systemInfo,
        getClientCompletionCapabilities(),
      );

      const audioFile = request.audioFile.file;
      if (!audioFile) {
        throw new Error('Audio file is required');
      }

      // Extract accel/gyro files from options (same pattern as EnhancerModelApi)
      const accelFile = (request.options as Record<string, unknown>)?.accelFile as File | undefined;
      const gyroFile = (request.options as Record<string, unknown>)?.gyroFile as File | undefined;

      if (!accelFile || !gyroFile) {
        throw new Error('Accelerometer and gyroscope files are required');
      }

      const resolvedSettings = normalizeAppSettings(
        {
          ...DEFAULT_APP_SETTINGS,
          device: ((request.options as Record<string, unknown>)?.device as ComputeDevice | undefined) ?? 'auto',
          quality: request.options?.quality as ProcessingQuality | undefined,
          outputFormat: request.options?.outputFormat,
        },
        runtimeCapabilities,
      );

      // Start enhancement (multipart upload of all three files)
      const enhanceResult = await infocomApi.startEnhance(audioFile, accelFile, gyroFile, {
        device: resolvedSettings.device,
        quality: resolvedSettings.quality,
        outputFormat: resolvedSettings.outputFormat,
      });

      // Poll until done
      let status = await infocomApi.getTaskStatus(enhanceResult.task_id);
      while (status.status === 'pending' || status.status === 'running') {
        await new Promise(r => setTimeout(r, 500));
        status = await infocomApi.getTaskStatus(enhanceResult.task_id);
      }

      if (status.status === 'failed') {
        throw new Error(status.error || '处理失败');
      }

      // 构建输出音频
      const result = status.result as Record<string, unknown> | undefined;
      const outputFileId = result?.output_file_id as string | undefined;
      const outputUrl = outputFileId
        ? infocomApi.getDownloadUrl(outputFileId)
        : (result?.output_url as string) || '';

      return {
        success: true,
        outputAudio: {
          id: enhanceResult.task_id,
          data: new ArrayBuffer(0),
          url: outputUrl,
          fileName: (result?.output_file_name as string | undefined) || undefined,
          format: (result?.output_format as ProcessedAudio['format']) || resolvedSettings.outputFormat,
          duration: request.audioFile.duration || 0,
          sampleRate: (result?.sample_rate as number) || 44100,
          size: (result?.output_size as number) || 0,
          createdAt: new Date(),
        },
        metadata: {
          processingTime: ((result?.total_time as number) || 0) * 1000,
          modelUsed: 'infocom-enhance',
          inputTextLength: request.textContent?.length || 0,
          inputAudioDuration: request.audioFile.duration || 0,
          outputAudioDuration: request.audioFile.duration || 0,
          appliedSettings: {
            device: ((result?.device as ComputeDevice | undefined) || resolvedSettings.device),
            quality: (result?.quality as ProcessingQuality | undefined) || resolvedSettings.quality,
            outputFormat: (result?.output_format as ProcessedAudio['format'] | undefined) || resolvedSettings.outputFormat,
            sampleRate: (result?.sample_rate as number) || 44100,
          },
          runtimeCapabilities,
          steps: status.steps.map(s => ({
            name: s.name,
            status: s.status === 'completed' ? 'completed' as const :
                    s.status === 'failed' ? 'failed' as const :
                    s.status === 'running' ? 'processing' as const : 'pending' as const,
            progress: s.progress,
          })),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : '处理失败',
      };
    }
  }

  async getProgress(taskId: string): Promise<ProcessStep[]> {
    const status = await infocomApi.getTaskStatus(taskId);
    return status.steps.map(s => ({
      name: s.name,
      status: s.status === 'completed' ? 'completed' as const :
              s.status === 'failed' ? 'failed' as const :
              s.status === 'running' ? 'processing' as const : 'pending' as const,
      progress: s.progress,
    }));
  }

  async cancelProcess(taskId: string): Promise<void> {
    await infocomApi.cancelTask(taskId);
  }

  async checkModelStatus(): Promise<ModelStatus> {
    try {
      const readiness = await infocomApi.checkReadiness();
      const info = await infocomApi.getSystemInfo();
      const runtimeCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        info,
        getClientCompletionCapabilities(),
      );
      return {
        isAvailable: readiness.is_ready,
        modelName: 'infocom-enhance',
        modelVersion: info.version || '1.0.0',
        capabilities: ['audio-enhance', 'imu-process', 'multimodal-denoise'],
        runtimeCapabilities,
      };
    } catch {
      return {
        isAvailable: false,
        modelName: 'infocom-enhance',
        modelVersion: '0.0.0',
        capabilities: [],
      };
    }
  }
}

/**
 * Enhancer API 实现
 * 通过 Audio Enhancer Python 后端调用
 */
class EnhancerModelApi {
  async process(request: ModelProcessRequest): Promise<ModelProcessResponse> {
    try {
      // Check health first
      await enhancerApi.checkEnhancerReadiness();
      const systemInfo = await enhancerApi.getEnhancerSystemInfo();
      const runtimeCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        systemInfo,
        getClientCompletionCapabilities(),
      );

      // We need all three files: audio + accel + gyro
      const audioFile = request.audioFile.file;
      if (!audioFile) {
        throw new Error('Audio file is required');
      }

      // The textFile in the current architecture maps to sensor data files
      // For enhancer mode, we expect the textFile to contain sensor data
      // or we need separate accel/gyro files passed via options
      const accelFile = (request.options as Record<string, unknown>)?.accelFile as File | undefined;
      const gyroFile = (request.options as Record<string, unknown>)?.gyroFile as File | undefined;

      if (!accelFile || !gyroFile) {
        throw new Error('Accelerometer and gyroscope files are required for enhancement');
      }

      const resolvedSettings = normalizeAppSettings(
        {
          ...DEFAULT_APP_SETTINGS,
          device: ((request.options as Record<string, unknown>)?.device as ComputeDevice | undefined) ?? 'auto',
          quality: request.options?.quality as ProcessingQuality | undefined,
          outputFormat: request.options?.outputFormat,
        },
        runtimeCapabilities,
      );

      // Start enhancement
      const enhanceResponse = await enhancerApi.startEnhancement(
        audioFile,
        accelFile,
        gyroFile,
        {
          device: resolvedSettings.device,
          quality: resolvedSettings.quality,
          outputFormat: resolvedSettings.outputFormat,
        },
      );

      // Poll until done
      const taskResult = await enhancerApi.pollEnhancerTask(enhanceResponse.task_id);

      if (taskResult.status === 'failed') {
        throw new Error(taskResult.error || 'Enhancement failed');
      }

      if (taskResult.status === 'cancelled') {
        throw new Error('Enhancement was cancelled');
      }

      // Build output audio
      const outputUrl = taskResult.result?.output_url
        ? enhancerApi.getEnhancerDownloadUrl(taskResult.result.output_file_id || '')
        : '';

      return {
        success: true,
        outputAudio: {
          id: taskResult.task_id,
          data: new ArrayBuffer(0),
          url: outputUrl,
          fileName: taskResult.result?.output_file_name,
          format: taskResult.result?.output_format || resolvedSettings.outputFormat,
          duration: request.audioFile.duration || 0,
          sampleRate: taskResult.result?.sample_rate || 44100,
          size: taskResult.result?.output_size || 0,
          createdAt: new Date(),
        },
        metadata: {
          processingTime: (taskResult.result?.total_time || 0) * 1000,
          modelUsed: 'enhancer-pipeline',
          inputTextLength: 0,
          inputAudioDuration: request.audioFile.duration || 0,
          outputAudioDuration: request.audioFile.duration || 0,
          appliedSettings: {
            device: (taskResult.result?.device || resolvedSettings.device) as ComputeDevice,
            quality: taskResult.result?.quality || resolvedSettings.quality,
            outputFormat: taskResult.result?.output_format || resolvedSettings.outputFormat,
            sampleRate: taskResult.result?.sample_rate || 44100,
          },
          runtimeCapabilities,
          steps: taskResult.steps.map(s => ({
            name: s.name,
            status: s.status === 'completed' ? 'completed' as const :
                    s.status === 'failed' ? 'failed' as const :
                    s.status === 'running' ? 'processing' as const : 'pending' as const,
            progress: s.progress,
          })),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Enhancement failed',
      };
    }
  }

  async getProgress(taskId: string): Promise<ProcessStep[]> {
    const task = await enhancerApi.getEnhancerTaskStatus(taskId);
    return task.steps.map(s => ({
      name: s.name,
      status: s.status === 'completed' ? 'completed' as const :
              s.status === 'failed' ? 'failed' as const :
              s.status === 'running' ? 'processing' as const : 'pending' as const,
      progress: s.progress,
    }));
  }

  async cancelProcess(taskId: string): Promise<void> {
    await enhancerApi.cancelEnhancerTask(taskId);
  }

  async checkModelStatus(): Promise<ModelStatus> {
    try {
      const readiness = await enhancerApi.checkEnhancerReadiness();
      const info = await enhancerApi.getEnhancerSystemInfo();
      const runtimeCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        info,
        getClientCompletionCapabilities(),
      );
      return {
        isAvailable: readiness.is_ready,
        modelName: 'enhancer-pipeline',
        modelVersion: info.version || '1.0.0',
        capabilities: ['audio-enhance', 'imu-process', 'multimodal-denoise'],
        runtimeCapabilities,
      };
    } catch {
      return {
        isAvailable: false,
        modelName: 'enhancer-pipeline',
        modelVersion: '0.0.0',
        capabilities: [],
      };
    }
  }
}

/**
 * Mock API 实现
 * 用于开发和测试，模拟模型处理过程
 */
class MockModelApi {
  async process(request: ModelProcessRequest): Promise<ModelProcessResponse> {
    // 模拟处理延迟
    await this.delay(2000);
    
    // 创建模拟的输出音频
    const mockAudioUrl = this.createMockAudioUrl();
    
    return {
      success: true,
      outputAudio: {
        id: crypto.randomUUID(),
        data: new ArrayBuffer(0),
        url: mockAudioUrl,
        format: 'wav',
        duration: 10.5,
        sampleRate: 44100,
        size: 924000,
        createdAt: new Date(),
      },
      metadata: {
        processingTime: 2000,
        modelUsed: 'mock-model-v1',
        inputTextLength: request.textContent?.length || 0,
        inputAudioDuration: request.audioFile.duration || 0,
        outputAudioDuration: 10.5,
        steps: [
          { name: '文本解析', status: 'completed', progress: 100 },
          { name: '音频分析', status: 'completed', progress: 100 },
          { name: '模型推理', status: 'completed', progress: 100 },
          { name: '音频合成', status: 'completed', progress: 100 },
        ],
      },
    };
  }

  async getProgress(): Promise<ProcessStep[]> {
    return [
      { name: '准备中', status: 'completed', progress: 100 },
      { name: '处理中', status: 'processing', progress: 50 },
    ];
  }

  async cancelProcess(): Promise<void> {
    // Mock 取消
  }

  async checkModelStatus(): Promise<ModelStatus> {
    return {
      isAvailable: true,
      modelName: 'mock-model',
      modelVersion: '1.0.0',
      capabilities: ['text-to-speech', 'audio-analysis', 'voice-clone'],
    };
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private createMockAudioUrl(): string {
    // 创建一个简单的静音音频 blob URL 用于测试
    const sampleRate = 44100;
    const duration = 1;
    const numChannels = 1;
    const bitsPerSample = 16;
    const numSamples = sampleRate * duration;
    const dataSize = numSamples * numChannels * (bitsPerSample / 8);
    const buffer = new ArrayBuffer(44 + dataSize);
    const view = new DataView(buffer);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numChannels * (bitsPerSample / 8), true);
    view.setUint16(32, numChannels * (bitsPerSample / 8), true);
    view.setUint16(34, bitsPerSample, true);
    writeString(36, 'data');
    view.setUint32(40, dataSize, true);

    // 生成简单的正弦波
    const frequency = 440; // A4 音符
    for (let i = 0; i < numSamples; i++) {
      const sample = Math.sin(2 * Math.PI * frequency * i / sampleRate) * 0.3;
      const intSample = Math.max(-32768, Math.min(32767, sample * 32767));
      view.setInt16(44 + i * 2, intSample, true);
    }

    const blob = new Blob([buffer], { type: 'audio/wav' });
    return URL.createObjectURL(blob);
  }
}

/**
 * 统一的模型 API 接口
 * 根据运行环境自动选择最佳实现
 */
type ApiMode = 'mock' | 'infocom' | 'tauri' | 'http' | 'enhancer';

class ModelApi {
  private tauriApi = new TauriModelApi();
  private httpApi = new HttpModelApi();
  private wsApi = new WebSocketModelApi();
  private mockApi = new MockModelApi();
  private infocomApi = new InfocomModelApi();
  private enhancerModelApi = new EnhancerModelApi();
  
  private mode: ApiMode = 'enhancer'; // 默认使用 Enhancer

  setMode(mode: ApiMode): void {
    this.mode = mode;
  }

  setUseMock(useMock: boolean): void {
    this.mode = useMock ? 'mock' : 'infocom';
  }

  private getApi() {
    switch (this.mode) {
      case 'mock':
        return this.mockApi;
      case 'infocom':
        return this.infocomApi;
      case 'tauri':
        return this.tauriApi;
      case 'http':
        return this.httpApi;
      case 'enhancer':
        return this.enhancerModelApi;
      default:
        if (isTauri()) {
          return this.tauriApi;
        }
        return this.infocomApi;
    }
  }

  async process(request: ModelProcessRequest): Promise<ModelProcessResponse> {
    return this.getApi().process(request);
  }

  async getProgress(taskId: string): Promise<ProcessStep[]> {
    return this.getApi().getProgress(taskId);
  }

  async cancelProcess(taskId: string): Promise<void> {
    return this.getApi().cancelProcess(taskId);
  }

  async checkModelStatus(): Promise<ModelStatus> {
    return this.getApi().checkModelStatus();
  }

  // WebSocket 相关方法
  async connectWebSocket(): Promise<void> {
    return this.wsApi.connect();
  }

  disconnectWebSocket(): void {
    this.wsApi.disconnect();
  }

  onWebSocketProgress(callback: (step: ProcessStep) => void): void {
    this.wsApi.onProgress(callback);
  }

  // Tauri 专用方法
  async saveAudio(audioData: ArrayBuffer, format: AudioFormat): Promise<string> {
    if (isTauri()) {
      return this.tauriApi.saveOutputAudio(audioData, format);
    }
    throw new Error('保存音频仅在 Tauri 环境中可用');
  }

  async readTextFile(path: string): Promise<string> {
    if (isTauri()) {
      return this.tauriApi.readTextFile(path);
    }
    throw new Error('读取文件仅在 Tauri 环境中可用');
  }
}

export const modelApi = new ModelApi();
export { TauriModelApi, HttpModelApi, WebSocketModelApi, MockModelApi, InfocomModelApi, EnhancerModelApi };
export type { ApiMode };
