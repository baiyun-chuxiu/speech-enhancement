/**
 * Audio Enhancer API Client
 *
 * Dedicated client for the IMU-assisted audio enhancement backend.
 * Supports multipart file upload, task polling, WebSocket progress, and file download.
 */

import { getStoredAppSettings } from '../app-settings';
import type { AudioFormat, ComputeDevice, ProcessingQuality } from '../types';

const STORAGE_KEY = 'enhancer-settings';
const DEFAULT_API_URL = 'http://localhost:8000';
const DESKTOP_API_URL_CACHE_KEY = '__ENHANCER_DESKTOP_API_URL__';
const DESKTOP_STARTUP_TIMEOUT_MS = 30000;
const DESKTOP_STARTUP_INTERVAL_MS = 500;

type DesktopRuntimeWindow = Window & {
  __TAURI__?: unknown;
  __ENHANCER_DESKTOP_API_URL__?: string;
};

export interface EnhancerSettings {
  apiUrl: string;
}

// ------------------------------------------------------------------
// Response types (matching server schemas)
// ------------------------------------------------------------------

export interface EnhancerHealthResponse {
  status: string;
  version: string;
  timestamp: string;
  readiness_status?: string;
  is_ready?: boolean;
  degraded_reason?: string | null;
}

export interface EnhancerReadinessResponse {
  status: string;
  version: string;
  timestamp: string;
  is_ready: boolean;
  configured_device: string;
  effective_device: string;
  supported_devices: ComputeDevice[];
  degraded_reason: string | null;
}

export interface EnhancerSystemInfo {
  version: string;
  python_version: string;
  platform: string;
  cuda_available: boolean;
  mps_available: boolean;
  configured_device: string;
  device: string;
  supported_devices: ComputeDevice[];
  status: string;
  is_ready: boolean;
  degraded_reason: string | null;
  generator_loaded: boolean;
  denoise_loaded: boolean;
  generator_model_exists: boolean;
  denoise_model_exists: boolean;
  generator_error?: string | null;
  denoise_error?: string | null;
  supported_qualities?: ProcessingQuality[];
  supported_output_formats?: AudioFormat[];
  default_quality?: ProcessingQuality;
  default_output_format?: AudioFormat;
}

export interface EnhancerFileUploadResponse {
  success: boolean;
  file_id: string;
  filename: string;
  size: number;
  content_type: string;
  path: string;
}

export type EnhancerTaskStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface EnhancerProcessingStep {
  index: number;
  name: string;
  status: EnhancerTaskStatus;
  progress: number;
  message: string;
  duration: number | null;
}

export interface EnhancerTaskInfo {
  task_id: string;
  status: EnhancerTaskStatus;
  progress: number;
  message: string;
  steps: EnhancerProcessingStep[];
  result: EnhancerResult | null;
  error: string | null;
  requested_device?: ComputeDevice | null;
  effective_device?: ComputeDevice | null;
  created_at: string;
  updated_at: string;
}

export interface EnhancerResult {
  output_file_id?: string;
  output_url?: string;
  output_path?: string;
  output_file_name?: string;
  output_size?: number;
  total_time?: number;
  step_times?: Record<string, number>;
  requested_device?: ComputeDevice;
  effective_device?: ComputeDevice;
  device?: ComputeDevice;
  quality?: ProcessingQuality;
  output_format?: AudioFormat;
  sample_rate?: number;
}

export interface EnhancerEnhanceResponse {
  success: boolean;
  task_id: string;
  status: EnhancerTaskStatus;
  requested_device?: ComputeDevice;
  effective_device?: ComputeDevice;
  quality?: ProcessingQuality;
  output_format?: AudioFormat;
  output_file?: string;
  output_url?: string;
}

export interface EnhancementRequestOptions {
  device?: ComputeDevice;
  quality?: ProcessingQuality;
  outputFormat?: AudioFormat;
}

// ------------------------------------------------------------------
// Pipeline step names (must match server PIPELINE_STEPS)
// ------------------------------------------------------------------

export const ENHANCER_PIPELINE_STEPS = [
  'IMU Data Preprocessing',
  'GAN Video Displacement Generation',
  'Audio Feature Extraction (STFT)',
  'Joint Denoise Inference',
  'Spectrogram Post-processing',
  'Audio Reconstruction (ISTFT)',
] as const;

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

function getDesktopRuntimeWindow(): DesktopRuntimeWindow | null {
  if (typeof window === 'undefined') {
    return null;
  }

  return window as DesktopRuntimeWindow;
}

function getCachedDesktopApiUrl(): string | null {
  const runtimeWindow = getDesktopRuntimeWindow();
  const cachedUrl = runtimeWindow?.[DESKTOP_API_URL_CACHE_KEY];
  return typeof cachedUrl === 'string' && cachedUrl.length > 0 ? cachedUrl : null;
}

function setCachedDesktopApiUrl(apiUrl: string): void {
  const runtimeWindow = getDesktopRuntimeWindow();
  if (runtimeWindow) {
    runtimeWindow[DESKTOP_API_URL_CACHE_KEY] = apiUrl;
  }
}

function buildDesktopApiUrl(port: number): string {
  return `http://127.0.0.1:${port}`;
}

async function waitForDesktopServer(apiUrl: string): Promise<void> {
  const deadline = Date.now() + DESKTOP_STARTUP_TIMEOUT_MS;
  let lastError: string | null = null;

  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${apiUrl}/health`, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        return;
      }

      lastError = `health check returned ${response.status}`;
    } catch (error) {
      lastError = error instanceof Error ? error.message : 'network error';
    }

    await new Promise((resolve) => setTimeout(resolve, DESKTOP_STARTUP_INTERVAL_MS));
  }

  throw new Error(`Desktop audio server failed to start: ${lastError ?? 'startup timed out'}`);
}

async function resolveEnhancerApiUrl(): Promise<string> {
  if (typeof window === 'undefined') return DEFAULT_API_URL;

  const desktopApiUrl = getCachedDesktopApiUrl();
  if (desktopApiUrl) {
    return desktopApiUrl;
  }

  let invoke: (<T>(cmd: string, args?: Record<string, unknown>) => Promise<T>) | null = null;
  try {
    ({ invoke } = await import('@tauri-apps/api/core'));
  } catch {
    return getEnhancerApiUrl();
  }

  // Best-effort recovery for packaged desktop apps where setup-time spawn failed.
  try {
    await invoke('start_server');
  } catch {
    // Ignore and continue; the sidecar may already be running or command may be unavailable.
  }

  try {
    const port = await invoke<number>('get_server_port');
    if (!Number.isInteger(port) || port <= 0) {
      return getEnhancerApiUrl();
    }

    const apiUrl = buildDesktopApiUrl(port);
    await waitForDesktopServer(apiUrl);
    setCachedDesktopApiUrl(apiUrl);
    return apiUrl;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('Desktop audio server failed to start:')) {
      throw error;
    }

    // Not running in Tauri or command unavailable, fall back to stored settings/default.
  }

  return getEnhancerApiUrl();
}

export function getEnhancerApiUrl(): string {
  if (typeof window === 'undefined') return DEFAULT_API_URL;

  const desktopApiUrl = getCachedDesktopApiUrl();
  if (desktopApiUrl) {
    return desktopApiUrl;
  }

  try {
    // Check enhancer-specific settings first
    const enhancerSaved = localStorage.getItem(STORAGE_KEY);
    if (enhancerSaved) {
      const settings = JSON.parse(enhancerSaved) as EnhancerSettings;
      if (settings.apiUrl) return settings.apiUrl;
    }
    return getStoredAppSettings().apiUrl;
  } catch {
    // ignore
  }
  return DEFAULT_API_URL;
}

export function setEnhancerApiUrl(url: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ apiUrl: url }));
}

async function enhancerFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const apiUrl = await resolveEnhancerApiUrl();
  const url = `${apiUrl}${endpoint}`;

  const response = await fetch(url, {
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      error: 'Network Error',
      message: `Request failed with status ${response.status}`,
    }));
    throw new Error(error.message || error.detail || error.error || `HTTP ${response.status}`);
  }

  return response.json();
}

function resolveEnhancementOptions(
  options: EnhancementRequestOptions | ComputeDevice = 'auto',
): Required<EnhancementRequestOptions> {
  if (typeof options === 'string') {
    return {
      device: options,
      quality: 'balanced',
      outputFormat: 'wav',
    };
  }

  return {
    device: options.device ?? 'auto',
    quality: options.quality ?? 'balanced',
    outputFormat: options.outputFormat ?? 'wav',
  };
}

// ------------------------------------------------------------------
// API Functions
// ------------------------------------------------------------------

/** Health check */
export async function checkEnhancerHealth(): Promise<EnhancerHealthResponse> {
  return enhancerFetch<EnhancerHealthResponse>('/health');
}

/** Readiness check */
export async function checkEnhancerReadiness(): Promise<EnhancerReadinessResponse> {
  return enhancerFetch<EnhancerReadinessResponse>('/ready');
}

/** System info */
export async function getEnhancerSystemInfo(): Promise<EnhancerSystemInfo> {
  return enhancerFetch<EnhancerSystemInfo>('/api/v1/system/info');
}

/** Upload a single file */
export async function uploadEnhancerFile(
  file: File,
  onProgress?: (progress: number) => void
): Promise<EnhancerFileUploadResponse> {
  const apiUrl = await resolveEnhancerApiUrl();
  const formData = new FormData();
  formData.append('file', file);

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable && onProgress) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    });

    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText));
        } catch {
          reject(new Error('Failed to parse response'));
        }
      } else {
        try {
          const error = JSON.parse(xhr.responseText);
          reject(new Error(error.message || error.detail || 'Upload failed'));
        } catch {
          reject(new Error(`Upload failed with status ${xhr.status}`));
        }
      }
    });

    xhr.addEventListener('error', () => reject(new Error('Network error during upload')));
    xhr.addEventListener('abort', () => reject(new Error('Upload aborted')));

    xhr.open('POST', `${apiUrl}/api/v1/files/upload`);
    xhr.send(formData);
  });
}

/**
 * Start audio enhancement with three files (multipart upload).
 * Returns a task_id for polling / WebSocket tracking.
 */
export async function startEnhancement(
  audioFile: File,
  accelFile: File,
  gyroFile: File,
  options: EnhancementRequestOptions | ComputeDevice = 'auto',
): Promise<EnhancerEnhanceResponse> {
  const apiUrl = await resolveEnhancerApiUrl();
  const formData = new FormData();
  formData.append('audio_file', audioFile);
  formData.append('accel_file', accelFile);
  formData.append('gyro_file', gyroFile);

  const resolvedOptions = resolveEnhancementOptions(options);
  const params = new URLSearchParams({
    device: resolvedOptions.device,
    quality: resolvedOptions.quality,
    output_format: resolvedOptions.outputFormat,
  });
  const response = await fetch(`${apiUrl}/api/v1/enhance?${params}`, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: `HTTP ${response.status}` }));
    throw new Error(error.message || error.detail || 'Enhancement request failed');
  }

  return response.json();
}

/**
 * Start enhancement using previously uploaded file IDs.
 */
export async function startEnhancementByIds(
  audioFileId: string,
  accelFileId: string,
  gyroFileId: string,
  options: EnhancementRequestOptions | ComputeDevice = 'auto',
): Promise<EnhancerEnhanceResponse> {
  const apiUrl = await resolveEnhancerApiUrl();
  const resolvedOptions = resolveEnhancementOptions(options);
  const params = new URLSearchParams({
    audio_file_id: audioFileId,
    accel_file_id: accelFileId,
    gyro_file_id: gyroFileId,
    device: resolvedOptions.device,
    quality: resolvedOptions.quality,
    output_format: resolvedOptions.outputFormat,
  });

  const response = await fetch(`${apiUrl}/api/v1/enhance/uploaded?${params}`, {
    method: 'POST',
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: `HTTP ${response.status}` }));
    throw new Error(error.message || error.detail || 'Enhancement request failed');
  }

  return response.json();
}

/** Get task status */
export async function getEnhancerTaskStatus(taskId: string): Promise<EnhancerTaskInfo> {
  return enhancerFetch<EnhancerTaskInfo>(`/api/v1/tasks/${taskId}`);
}

/** Cancel a task */
export async function cancelEnhancerTask(taskId: string): Promise<{ success: boolean }> {
  return enhancerFetch<{ success: boolean }>(`/api/v1/tasks/${taskId}/cancel`, {
    method: 'POST',
  });
}

/** Get download URL for an output file */
export function getEnhancerDownloadUrl(fileId: string): string {
  const apiUrl = getEnhancerApiUrl();
  return `${apiUrl}/api/v1/files/download/${fileId}`;
}

/**
 * Create a WebSocket connection for real-time task progress.
 */
export function createEnhancerTaskWebSocket(
  taskId: string,
  onMessage: (task: EnhancerTaskInfo) => void,
  onError?: (error: Error) => void,
  onClose?: () => void,
): WebSocket {
  const apiUrl = getEnhancerApiUrl();
  const wsUrl = apiUrl.replace(/^http/, 'ws');
  const ws = new WebSocket(`${wsUrl}/ws/tasks/${taskId}`);

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === 'ping') return; // heartbeat
      onMessage(data as EnhancerTaskInfo);
    } catch (e) {
      console.error('Failed to parse WebSocket message:', e);
    }
  };

  ws.onerror = () => {
    onError?.(new Error('WebSocket connection error'));
  };

  ws.onclose = () => {
    onClose?.();
  };

  return ws;
}

/**
 * Poll task status until completion, calling onUpdate for each poll.
 * Returns the final task info.
 */
export async function pollEnhancerTask(
  taskId: string,
  onUpdate?: (task: EnhancerTaskInfo) => void,
  intervalMs: number = 500,
  timeoutMs: number = 300000,
): Promise<EnhancerTaskInfo> {
  const startTime = Date.now();

  while (true) {
    const task = await getEnhancerTaskStatus(taskId);
    onUpdate?.(task);

    if (task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled') {
      return task;
    }

    if (Date.now() - startTime > timeoutMs) {
      throw new Error('Enhancement timed out');
    }

    await new Promise((r) => setTimeout(r, intervalMs));
  }
}

/**
 * Full enhancement flow: upload files → start task → poll until done → return result.
 */
export async function enhanceAudioFull(
  audioFile: File,
  accelFile: File,
  gyroFile: File,
  onProgress?: (task: EnhancerTaskInfo) => void,
  options: EnhancementRequestOptions | ComputeDevice = 'auto',
): Promise<EnhancerTaskInfo> {
  // Start enhancement (multipart upload)
  const response = await startEnhancement(audioFile, accelFile, gyroFile, options);

  if (!response.success) {
    throw new Error('Failed to start enhancement');
  }

  // Poll until done
  return pollEnhancerTask(response.task_id, onProgress);
}

// ------------------------------------------------------------------
// Batch Enhancement
// ------------------------------------------------------------------

export interface BatchEnhanceResponse {
  success: boolean;
  task_id: string;
  status: EnhancerTaskStatus;
  total_samples: number;
  requested_device?: ComputeDevice | null;
  effective_device?: ComputeDevice | null;
}

export interface BatchResultItem {
  success: boolean;
  output_file_id?: string;
  output_url?: string;
  total_time?: number;
  requested_device?: ComputeDevice;
  effective_device?: ComputeDevice;
  error?: string;
}

/**
 * Start batch enhancement with multiple file triplets.
 * Files arrays must have the same length and matching order.
 */
export async function startBatchEnhancement(
  audioFiles: File[],
  accelFiles: File[],
  gyroFiles: File[],
  options: EnhancementRequestOptions | ComputeDevice = 'auto',
): Promise<BatchEnhanceResponse> {
  const apiUrl = await resolveEnhancerApiUrl();
  const formData = new FormData();

  for (const f of audioFiles) formData.append('audio_files', f);
  for (const f of accelFiles) formData.append('accel_files', f);
  for (const f of gyroFiles) formData.append('gyro_files', f);

  const resolvedOptions = resolveEnhancementOptions(options);
  const params = new URLSearchParams({
    device: resolvedOptions.device,
    quality: resolvedOptions.quality,
    output_format: resolvedOptions.outputFormat,
  });
  const response = await fetch(`${apiUrl}/api/v1/enhance/batch?${params}`, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: `HTTP ${response.status}` }));
    throw new Error(error.message || error.detail || 'Batch enhancement request failed');
  }

  return response.json();
}

/**
 * Full batch enhancement flow: upload → start → poll until done.
 */
export async function enhanceBatchFull(
  audioFiles: File[],
  accelFiles: File[],
  gyroFiles: File[],
  onProgress?: (task: EnhancerTaskInfo) => void,
  options: EnhancementRequestOptions | ComputeDevice = 'auto',
): Promise<EnhancerTaskInfo> {
  const response = await startBatchEnhancement(audioFiles, accelFiles, gyroFiles, options);

  if (!response.success) {
    throw new Error('Failed to start batch enhancement');
  }

  return pollEnhancerTask(response.task_id, onProgress, 1000, 600000);
}
