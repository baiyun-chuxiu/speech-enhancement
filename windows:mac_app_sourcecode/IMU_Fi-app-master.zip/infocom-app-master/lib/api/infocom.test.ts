import {
  getApiUrl,
  getApiUrlSync,
  checkHealth,
  checkReadiness,
  getSystemInfo,
  uploadFile,
  startEnhance,
  startEnhanceByIds,
  getTaskStatus,
  cancelTask,
  getDownloadUrl,
  createTaskWebSocket,
} from './infocom';

const tauriInvokeMock = jest.fn();

jest.mock('@tauri-apps/api/core', () => ({
  invoke: (...args: unknown[]) => tauriInvokeMock(...args),
}));

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

// Mock fetch
global.fetch = jest.fn();

// Mock WebSocket
class MockWebSocket {
  onmessage: ((event: { data: string }) => void) | null = null;
  onerror: ((error: Error) => void) | null = null;
  onclose: (() => void) | null = null;
  
  constructor(public url: string) {}
  
  close() {}
}
global.WebSocket = MockWebSocket as unknown as typeof WebSocket;

describe('Infocom API Client', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    tauriInvokeMock.mockRejectedValue(new Error('not running in tauri'));
    localStorageMock.getItem.mockReturnValue(null);
    delete (window as Window & { __TAURI__?: unknown }).__TAURI__;
    delete (window as Window & { __INFOCOM_DESKTOP_API_URL__?: string }).__INFOCOM_DESKTOP_API_URL__;
  });

  describe('getApiUrl', () => {
    it('returns the Tauri-managed loopback URL and caches it for sync consumers even without a global __TAURI__ flag', async () => {
      tauriInvokeMock.mockResolvedValueOnce(4312);

      expect(await getApiUrl()).toBe('http://127.0.0.1:4312');
      expect(getApiUrlSync()).toBe('http://127.0.0.1:4312');
      expect(tauriInvokeMock).toHaveBeenCalledWith('get_server_port');
    });

    it('falls back to saved settings when Tauri port lookup fails', async () => {
      tauriInvokeMock.mockRejectedValueOnce(new Error('command unavailable'));
      localStorageMock.getItem.mockReturnValue(
        JSON.stringify({ apiUrl: 'http://custom:9000' })
      );

      expect(await getApiUrl()).toBe('http://custom:9000');
    });

    it('falls back to stored settings when Tauri port lookup returns an invalid port', async () => {
      tauriInvokeMock.mockResolvedValueOnce(undefined);
      localStorageMock.getItem.mockReturnValue(
        JSON.stringify({ apiUrl: 'http://custom:9000' })
      );

      expect(await getApiUrl()).toBe('http://custom:9000');
    });

    it('returns default URL when no settings saved', async () => {
      expect(await getApiUrl()).toBe('http://localhost:8000');
    });

    it('returns saved URL from localStorage', async () => {
      localStorageMock.getItem.mockReturnValue(
        JSON.stringify({ apiUrl: 'http://custom:9000' })
      );
      expect(await getApiUrl()).toBe('http://custom:9000');
    });

    it('returns default URL on parse error', async () => {
      localStorageMock.getItem.mockReturnValue('invalid json');
      expect(await getApiUrl()).toBe('http://localhost:8000');
    });
  });

  describe('getApiUrlSync', () => {
    it('returns default URL when no settings saved', () => {
      expect(getApiUrlSync()).toBe('http://localhost:8000');
    });

    it('returns saved URL from localStorage', () => {
      localStorageMock.getItem.mockReturnValue(
        JSON.stringify({ apiUrl: 'http://custom:9000' })
      );
      expect(getApiUrlSync()).toBe('http://custom:9000');
    });
  });

  describe('checkHealth', () => {
    it('calls health endpoint', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ status: 'ok', version: '1.0.0' }),
      });

      const result = await checkHealth();
      
      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/health',
        expect.objectContaining({
          headers: { 'Content-Type': 'application/json' },
        })
      );
      expect(result.status).toBe('ok');
    });

    it('throws error on failure', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 500,
        json: async () => ({ error: 'Server Error', message: 'Internal error' }),
      });

      await expect(checkHealth()).rejects.toThrow('Internal error');
    });
  });

  describe('checkReadiness', () => {
    it('calls readiness endpoint', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({
          status: 'ready',
          version: '1.0.0',
          is_ready: true,
          configured_device: 'cpu',
          effective_device: 'cpu',
          supported_devices: ['cpu'],
          degraded_reason: null,
        }),
      });

      const result = await checkReadiness();

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/ready',
        expect.objectContaining({
          headers: { 'Content-Type': 'application/json' },
        })
      );
      expect(result.is_ready).toBe(true);
      expect(result.status).toBe('ready');
    });
  });

  describe('getSystemInfo', () => {
    it('calls system info endpoint', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({
          version: '1.0.0',
          python_version: '3.10.0',
          cuda_available: true,
        }),
      });

      const result = await getSystemInfo();
      
      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/api/v1/system/info',
        expect.anything()
      );
      expect(result.version).toBe('1.0.0');
    });
  });

  describe('uploadFile', () => {
    it('uploads file with progress', async () => {
      const mockFile = new File(['test content'], 'test.txt', { type: 'text/plain' });
      const progressCallback = jest.fn();

      // Mock XMLHttpRequest
      const mockXhr = {
        upload: {
          addEventListener: jest.fn((event, callback) => {
            if (event === 'progress') {
              callback({ lengthComputable: true, loaded: 50, total: 100 });
            }
          }),
        },
        addEventListener: jest.fn((event, callback) => {
          if (event === 'load') {
            setTimeout(() => callback(), 0);
          }
        }),
        open: jest.fn(),
        send: jest.fn(),
        status: 200,
        responseText: JSON.stringify({ success: true, file_id: 'abc123' }),
      };
      
      global.XMLHttpRequest = jest.fn(() => mockXhr) as unknown as typeof XMLHttpRequest;

      const result = await uploadFile(mockFile, progressCallback);
      
      expect(mockXhr.open).toHaveBeenCalledWith('POST', 'http://localhost:8000/api/v1/files/upload');
      expect(progressCallback).toHaveBeenCalledWith(50);
      expect(result.file_id).toBe('abc123');
    });
  });

  describe('startEnhance', () => {
    it('calls enhance endpoint with multipart form', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, task_id: 'task123' }),
      });

      const audioFile = new File(['audio'], 'audio.wav', { type: 'audio/wav' });
      const accelFile = new File(['accel'], 'accel.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'gyro.txt', { type: 'text/plain' });

      const result = await startEnhance(audioFile, accelFile, gyroFile);

      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/v1/enhance'),
        expect.objectContaining({
          method: 'POST',
        })
      );
      expect(result.task_id).toBe('task123');
    });

    it('throws error on failure', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 400,
        json: async () => ({ message: 'Bad request' }),
      });

      const audioFile = new File(['audio'], 'audio.wav', { type: 'audio/wav' });
      const accelFile = new File(['accel'], 'accel.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'gyro.txt', { type: 'text/plain' });

      await expect(startEnhance(audioFile, accelFile, gyroFile)).rejects.toThrow('Bad request');
    });
  });

  describe('startEnhanceByIds', () => {
    it('calls enhance/uploaded endpoint with file IDs', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, task_id: 'task456' }),
      });

      const result = await startEnhanceByIds('audio-id', 'accel-id', 'gyro-id');

      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/v1/enhance/uploaded'),
        expect.objectContaining({
          method: 'POST',
        })
      );
      expect(result.task_id).toBe('task456');
    });
  });

  describe('getTaskStatus', () => {
    it('gets task status', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({
          task_id: 'task123',
          status: 'running',
          progress: 50,
        }),
      });

      const result = await getTaskStatus('task123');
      
      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/api/v1/tasks/task123',
        expect.anything()
      );
      expect(result.status).toBe('running');
      expect(result.progress).toBe(50);
    });
  });

  describe('cancelTask', () => {
    it('cancels task', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true }),
      });

      const result = await cancelTask('task123');
      
      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/api/v1/tasks/task123/cancel',
        expect.objectContaining({ method: 'POST' })
      );
      expect(result.success).toBe(true);
    });
  });

  describe('getDownloadUrl', () => {
    it('returns download URL', () => {
      const url = getDownloadUrl('file123');
      expect(url).toBe('http://localhost:8000/api/v1/files/download/file123');
    });
  });

  describe('createTaskWebSocket', () => {
    it('creates WebSocket connection', () => {
      const onMessage = jest.fn();
      const onError = jest.fn();
      const onClose = jest.fn();

      const ws = createTaskWebSocket('task123', onMessage, onError, onClose);
      
      expect(ws.url).toBe('ws://localhost:8000/ws/tasks/task123');
    });

    it('handles incoming messages', () => {
      const onMessage = jest.fn();
      
      const ws = createTaskWebSocket('task123', onMessage);
      
      // Simulate message
      if (ws.onmessage) {
        ws.onmessage({ data: JSON.stringify({ status: 'running', progress: 50 }) } as MessageEvent);
      }
      
      expect(onMessage).toHaveBeenCalledWith({ status: 'running', progress: 50 });
    });

    it('filters out ping heartbeat messages', () => {
      const onMessage = jest.fn();
      
      const ws = createTaskWebSocket('task123', onMessage);
      
      // Simulate ping heartbeat
      if (ws.onmessage) {
        ws.onmessage({ data: JSON.stringify({ type: 'ping' }) } as MessageEvent);
      }
      
      expect(onMessage).not.toHaveBeenCalled();
    });
  });
});
