import {
  getEnhancerApiUrl,
  setEnhancerApiUrl,
  checkEnhancerHealth,
  checkEnhancerReadiness,
  getEnhancerSystemInfo,
  uploadEnhancerFile,
  startEnhancement,
  startEnhancementByIds,
  getEnhancerTaskStatus,
  cancelEnhancerTask,
  getEnhancerDownloadUrl,
  createEnhancerTaskWebSocket,
  pollEnhancerTask,
  enhanceAudioFull,
  ENHANCER_PIPELINE_STEPS,
} from './enhancer-api';
import type { EnhancerTaskInfo } from './enhancer-api';

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

const tauriInvokeMock = jest.fn();

jest.mock('@tauri-apps/api/core', () => ({
  invoke: (...args: unknown[]) => tauriInvokeMock(...args),
}));

const localStorageMock: {
  store: Record<string, string>;
  getItem: jest.Mock;
  setItem: jest.Mock;
  removeItem: jest.Mock;
  clear: jest.Mock;
} = {
  store: {} as Record<string, string>,
  getItem: jest.fn((key: string): string | null => localStorageMock.store[key] ?? null),
  setItem: jest.fn((key: string, value: string) => {
    localStorageMock.store[key] = value;
  }),
  removeItem: jest.fn((key: string) => {
    delete localStorageMock.store[key];
  }),
  clear: jest.fn(() => {
    localStorageMock.store = {};
  }),
};
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

global.fetch = jest.fn();

class MockWebSocket {
  onmessage: ((event: { data: string }) => void) | null = null;
  onerror: ((event: Event) => void) | null = null;
  onclose: (() => void) | null = null;

  constructor(public url: string) {}

  close() {}
}
global.WebSocket = MockWebSocket as unknown as typeof WebSocket;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function mockFetchOk(data: unknown) {
  (global.fetch as jest.Mock).mockResolvedValueOnce({
    ok: true,
    json: async () => data,
  });
}

function mockFetchError(status: number, body: unknown) {
  (global.fetch as jest.Mock).mockResolvedValueOnce({
    ok: false,
    status,
    json: async () => body,
  });
}

function mockFetchNetworkError() {
  (global.fetch as jest.Mock).mockRejectedValueOnce(new Error('Network error'));
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('Enhancer API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    tauriInvokeMock.mockReset();
    (global.fetch as jest.Mock).mockReset();
    tauriInvokeMock.mockRejectedValue(new Error('not running in tauri'));
    localStorageMock.store = {};
    // Re-apply implementations after clearAllMocks strips them
    localStorageMock.getItem.mockImplementation((key: string): string | null => localStorageMock.store[key] ?? null);
    localStorageMock.setItem.mockImplementation((key: string, value: string) => {
      localStorageMock.store[key] = value;
    });
    delete (
      window as Window & { __ENHANCER_DESKTOP_API_URL__?: string }
    ).__ENHANCER_DESKTOP_API_URL__;
  });

  // =========================================================================
  // Constants
  // =========================================================================
  describe('ENHANCER_PIPELINE_STEPS', () => {
    it('contains 6 pipeline steps', () => {
      expect(ENHANCER_PIPELINE_STEPS).toHaveLength(6);
    });

    it('starts with IMU Data Preprocessing', () => {
      expect(ENHANCER_PIPELINE_STEPS[0]).toBe('IMU Data Preprocessing');
    });

    it('ends with Audio Reconstruction', () => {
      expect(ENHANCER_PIPELINE_STEPS[5]).toBe('Audio Reconstruction (ISTFT)');
    });
  });

  // =========================================================================
  // getEnhancerApiUrl
  // =========================================================================
  describe('getEnhancerApiUrl', () => {
    it('returns default URL when no settings saved', () => {
      expect(getEnhancerApiUrl()).toBe('http://localhost:8000');
    });

    it('returns URL from enhancer-settings (highest priority)', () => {
      localStorageMock.store['enhancer-settings'] = JSON.stringify({
        apiUrl: 'http://enhancer:9000',
      });
      expect(getEnhancerApiUrl()).toBe('http://enhancer:9000');
    });

    it('falls back to infocom-settings when no enhancer-settings', () => {
      localStorageMock.store['infocom-settings'] = JSON.stringify({
        apiUrl: 'http://infocom:8080',
      });
      expect(getEnhancerApiUrl()).toBe('http://infocom:8080');
    });

    it('prefers enhancer-settings over infocom-settings', () => {
      localStorageMock.store['enhancer-settings'] = JSON.stringify({
        apiUrl: 'http://enhancer:9000',
      });
      localStorageMock.store['infocom-settings'] = JSON.stringify({
        apiUrl: 'http://infocom:8080',
      });
      expect(getEnhancerApiUrl()).toBe('http://enhancer:9000');
    });

    it('returns default on JSON parse error', () => {
      localStorageMock.store['enhancer-settings'] = 'invalid json';
      expect(getEnhancerApiUrl()).toBe('http://localhost:8000');
    });

    it('returns default when apiUrl is empty string', () => {
      localStorageMock.store['enhancer-settings'] = JSON.stringify({
        apiUrl: '',
      });
      // Falls through to infocom-settings, then default
      expect(getEnhancerApiUrl()).toBe('http://localhost:8000');
    });
  });

  // =========================================================================
  // setEnhancerApiUrl
  // =========================================================================
  describe('setEnhancerApiUrl', () => {
    it('saves URL to localStorage', () => {
      setEnhancerApiUrl('http://custom:5000');
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'enhancer-settings',
        JSON.stringify({ apiUrl: 'http://custom:5000' })
      );
    });
  });

  // =========================================================================
  // checkEnhancerHealth
  // =========================================================================
  describe('checkEnhancerHealth', () => {
    it('starts the desktop sidecar on demand and caches the Tauri-managed loopback URL even without a global __TAURI__ flag', async () => {
      tauriInvokeMock.mockResolvedValueOnce('Sidecar started');
      tauriInvokeMock.mockResolvedValueOnce(4312);
      mockFetchOk({ status: 'ok', version: '1.0.0', timestamp: '2024-01-01' });
      mockFetchOk({ status: 'ok', version: '1.0.0', timestamp: '2024-01-01' });

      await checkEnhancerHealth();

      expect(tauriInvokeMock.mock.calls).toEqual([
        ['start_server'],
        ['get_server_port'],
      ]);
      expect(global.fetch).toHaveBeenNthCalledWith(
        1,
        'http://127.0.0.1:4312/health',
        expect.anything()
      );
      expect(global.fetch).toHaveBeenNthCalledWith(
        2,
        'http://127.0.0.1:4312/health',
        expect.objectContaining({
          headers: expect.objectContaining({ 'Content-Type': 'application/json' }),
        })
      );
      expect(getEnhancerDownloadUrl('file-001')).toBe(
        'http://127.0.0.1:4312/api/v1/files/download/file-001'
      );
      expect(tauriInvokeMock).toHaveBeenCalledTimes(2);
    });

    it('calls /health endpoint', async () => {
      mockFetchOk({ status: 'ok', version: '1.0.0', timestamp: '2024-01-01' });

      const result = await checkEnhancerHealth();

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/health',
        expect.objectContaining({
          headers: expect.objectContaining({ 'Content-Type': 'application/json' }),
        })
      );
      expect(result.status).toBe('ok');
      expect(result.version).toBe('1.0.0');
    });

    it('throws on server error', async () => {
      mockFetchError(500, { message: 'Internal error' });
      await expect(checkEnhancerHealth()).rejects.toThrow('Internal error');
    });

    it('throws on network error', async () => {
      mockFetchNetworkError();
      await expect(checkEnhancerHealth()).rejects.toThrow('Network error');
    });

    it('handles non-JSON error response', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 502,
        json: async () => { throw new Error('not json'); },
      });
      await expect(checkEnhancerHealth()).rejects.toThrow('Request failed with status 502');
    });
  });

  // =========================================================================
  // checkEnhancerReadiness
  // =========================================================================
  describe('checkEnhancerReadiness', () => {
    it('calls /ready endpoint', async () => {
      mockFetchOk({
        status: 'ready',
        version: '1.0.0',
        timestamp: '2024-01-01',
        is_ready: true,
        configured_device: 'cpu',
        effective_device: 'cpu',
        supported_devices: ['cpu'],
        degraded_reason: null,
      });

      const result = await checkEnhancerReadiness();

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/ready',
        expect.objectContaining({
          headers: expect.objectContaining({ 'Content-Type': 'application/json' }),
        })
      );
      expect(result.is_ready).toBe(true);
      expect(result.status).toBe('ready');
    });
  });

  // =========================================================================
  // getEnhancerSystemInfo
  // =========================================================================
  describe('getEnhancerSystemInfo', () => {
    it('calls /api/v1/system/info', async () => {
      mockFetchOk({
        version: '1.0.0',
        python_version: '3.10.0',
        platform: 'win32',
        cuda_available: true,
        mps_available: false,
        device: 'cuda',
        generator_loaded: true,
        denoise_loaded: true,
        supported_devices: ['auto', 'cpu', 'cuda'],
        supported_qualities: ['balanced'],
        supported_output_formats: ['wav'],
      });

      const result = await getEnhancerSystemInfo();

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/api/v1/system/info',
        expect.anything()
      );
      expect(result.cuda_available).toBe(true);
      expect(result.device).toBe('cuda');
      expect(result.supported_devices).toEqual(['auto', 'cpu', 'cuda']);
      expect(result.supported_output_formats).toEqual(['wav']);
    });
  });

  // =========================================================================
  // uploadEnhancerFile
  // =========================================================================
  describe('uploadEnhancerFile', () => {
    it('uploads file with progress via XHR', async () => {
      const mockFile = new File(['test content'], 'test.txt', { type: 'text/plain' });
      const progressCallback = jest.fn();

      const mockXhr = {
        upload: {
          addEventListener: jest.fn((event: string, callback: (e: ProgressEvent) => void) => {
            if (event === 'progress') {
              callback({ lengthComputable: true, loaded: 50, total: 100 } as ProgressEvent);
            }
          }),
        },
        addEventListener: jest.fn((event: string, callback: () => void) => {
          if (event === 'load') {
            setTimeout(() => callback(), 0);
          }
        }),
        open: jest.fn(),
        send: jest.fn(),
        status: 200,
        responseText: JSON.stringify({
          success: true,
          file_id: 'abc123',
          filename: 'test.txt',
          size: 12,
          content_type: 'text/plain',
          path: '/uploads/test.txt',
        }),
      };
      global.XMLHttpRequest = jest.fn(() => mockXhr) as unknown as typeof XMLHttpRequest;

      const result = await uploadEnhancerFile(mockFile, progressCallback);

      expect(mockXhr.open).toHaveBeenCalledWith(
        'POST',
        'http://localhost:8000/api/v1/files/upload'
      );
      expect(progressCallback).toHaveBeenCalledWith(50);
      expect(result.file_id).toBe('abc123');
      expect(result.success).toBe(true);
    });

    it('rejects on upload failure', async () => {
      const mockFile = new File(['test'], 'test.txt', { type: 'text/plain' });

      const mockXhr = {
        upload: { addEventListener: jest.fn() },
        addEventListener: jest.fn((event: string, callback: () => void) => {
          if (event === 'load') {
            setTimeout(() => callback(), 0);
          }
        }),
        open: jest.fn(),
        send: jest.fn(),
        status: 400,
        responseText: JSON.stringify({ message: 'Bad request' }),
      };
      global.XMLHttpRequest = jest.fn(() => mockXhr) as unknown as typeof XMLHttpRequest;

      await expect(uploadEnhancerFile(mockFile)).rejects.toThrow('Bad request');
    });

    it('rejects on network error', async () => {
      const mockFile = new File(['test'], 'test.txt', { type: 'text/plain' });

      const mockXhr = {
        upload: { addEventListener: jest.fn() },
        addEventListener: jest.fn((event: string, callback: () => void) => {
          if (event === 'error') {
            setTimeout(() => callback(), 0);
          }
        }),
        open: jest.fn(),
        send: jest.fn(),
      };
      global.XMLHttpRequest = jest.fn(() => mockXhr) as unknown as typeof XMLHttpRequest;

      await expect(uploadEnhancerFile(mockFile)).rejects.toThrow('Network error during upload');
    });

    it('rejects on abort', async () => {
      const mockFile = new File(['test'], 'test.txt', { type: 'text/plain' });

      const mockXhr = {
        upload: { addEventListener: jest.fn() },
        addEventListener: jest.fn((event: string, callback: () => void) => {
          if (event === 'abort') {
            setTimeout(() => callback(), 0);
          }
        }),
        open: jest.fn(),
        send: jest.fn(),
      };
      global.XMLHttpRequest = jest.fn(() => mockXhr) as unknown as typeof XMLHttpRequest;

      await expect(uploadEnhancerFile(mockFile)).rejects.toThrow('Upload aborted');
    });

    it('rejects on unparseable success response', async () => {
      const mockFile = new File(['test'], 'test.txt', { type: 'text/plain' });

      const mockXhr = {
        upload: { addEventListener: jest.fn() },
        addEventListener: jest.fn((event: string, callback: () => void) => {
          if (event === 'load') {
            setTimeout(() => callback(), 0);
          }
        }),
        open: jest.fn(),
        send: jest.fn(),
        status: 200,
        responseText: 'not json',
      };
      global.XMLHttpRequest = jest.fn(() => mockXhr) as unknown as typeof XMLHttpRequest;

      await expect(uploadEnhancerFile(mockFile)).rejects.toThrow('Failed to parse response');
    });
  });

  // =========================================================================
  // startEnhancement
  // =========================================================================
  describe('startEnhancement', () => {
    it('sends multipart form with three files', async () => {
      mockFetchOk({ success: true, task_id: 'task-001', status: 'pending' });

      const audioFile = new File(['audio'], 'audio.wav', { type: 'audio/wav' });
      const accelFile = new File(['accel'], 'accel.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'gyro.txt', { type: 'text/plain' });

      const result = await startEnhancement(audioFile, accelFile, gyroFile);

      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/v1/enhance?device=auto'),
        expect.objectContaining({ method: 'POST' })
      );

      // Check FormData was passed
      const call = (global.fetch as jest.Mock).mock.calls[0];
      expect(call[1].body).toBeInstanceOf(FormData);
      expect(result.task_id).toBe('task-001');
      expect(result.success).toBe(true);
    });

    it('passes device parameter', async () => {
      mockFetchOk({ success: true, task_id: 'task-002', status: 'pending' });

      const audioFile = new File(['audio'], 'a.wav', { type: 'audio/wav' });
      const accelFile = new File(['acc'], 'acc.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'g.txt', { type: 'text/plain' });

      await startEnhancement(audioFile, accelFile, gyroFile, 'cuda');

      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('device=cuda'),
        expect.anything()
      );
    });

    it('throws on error response', async () => {
      mockFetchError(400, { message: 'Invalid file format' });

      const audioFile = new File(['audio'], 'a.wav', { type: 'audio/wav' });
      const accelFile = new File(['acc'], 'acc.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'g.txt', { type: 'text/plain' });

      await expect(startEnhancement(audioFile, accelFile, gyroFile)).rejects.toThrow(
        'Invalid file format'
      );
    });

    it('uses detail field from error response', async () => {
      mockFetchError(422, { detail: 'Validation error' });

      const audioFile = new File(['audio'], 'a.wav', { type: 'audio/wav' });
      const accelFile = new File(['acc'], 'acc.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'g.txt', { type: 'text/plain' });

      await expect(startEnhancement(audioFile, accelFile, gyroFile)).rejects.toThrow(
        'Validation error'
      );
    });
  });

  // =========================================================================
  // startEnhancementByIds
  // =========================================================================
  describe('startEnhancementByIds', () => {
    it('sends file IDs as URL params', async () => {
      mockFetchOk({ success: true, task_id: 'task-003', status: 'pending' });

      const result = await startEnhancementByIds('audio-id', 'accel-id', 'gyro-id');

      const url = (global.fetch as jest.Mock).mock.calls[0][0] as string;
      expect(url).toContain('/api/v1/enhance/uploaded');
      expect(url).toContain('audio_file_id=audio-id');
      expect(url).toContain('accel_file_id=accel-id');
      expect(url).toContain('gyro_file_id=gyro-id');
      expect(result.task_id).toBe('task-003');
    });

    it('throws on error', async () => {
      mockFetchError(404, { message: 'File not found' });
      await expect(startEnhancementByIds('a', 'b', 'c')).rejects.toThrow('File not found');
    });
  });

  // =========================================================================
  // getEnhancerTaskStatus
  // =========================================================================
  describe('getEnhancerTaskStatus', () => {
    it('calls /api/v1/tasks/:taskId', async () => {
      mockFetchOk({
        task_id: 'task-001',
        status: 'running',
        progress: 50,
        message: 'Processing...',
        steps: [],
        result: null,
        error: null,
        created_at: '2024-01-01T00:00:00',
        updated_at: '2024-01-01T00:01:00',
      });

      const result = await getEnhancerTaskStatus('task-001');

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/api/v1/tasks/task-001',
        expect.anything()
      );
      expect(result.status).toBe('running');
      expect(result.progress).toBe(50);
    });
  });

  // =========================================================================
  // cancelEnhancerTask
  // =========================================================================
  describe('cancelEnhancerTask', () => {
    it('calls cancel endpoint with POST', async () => {
      mockFetchOk({ success: true });

      const result = await cancelEnhancerTask('task-001');

      expect(global.fetch).toHaveBeenCalledWith(
        'http://localhost:8000/api/v1/tasks/task-001/cancel',
        expect.objectContaining({ method: 'POST' })
      );
      expect(result.success).toBe(true);
    });
  });

  // =========================================================================
  // getEnhancerDownloadUrl
  // =========================================================================
  describe('getEnhancerDownloadUrl', () => {
    it('returns download URL', () => {
      const url = getEnhancerDownloadUrl('file-001');
      expect(url).toBe('http://localhost:8000/api/v1/files/download/file-001');
    });

    it('uses custom API URL from settings', () => {
      localStorageMock.store['enhancer-settings'] = JSON.stringify({
        apiUrl: 'http://custom:9000',
      });
      const url = getEnhancerDownloadUrl('file-002');
      expect(url).toBe('http://custom:9000/api/v1/files/download/file-002');
    });
  });

  // =========================================================================
  // createEnhancerTaskWebSocket
  // =========================================================================
  describe('createEnhancerTaskWebSocket', () => {
    it('creates WebSocket with ws:// protocol', () => {
      const onMessage = jest.fn();
      const ws = createEnhancerTaskWebSocket('task-001', onMessage);

      expect(ws.url).toBe('ws://localhost:8000/ws/tasks/task-001');
    });

    it('converts https to wss', () => {
      localStorageMock.store['enhancer-settings'] = JSON.stringify({
        apiUrl: 'https://secure.example.com',
      });
      const onMessage = jest.fn();
      const ws = createEnhancerTaskWebSocket('task-001', onMessage);

      expect(ws.url).toBe('wss://secure.example.com/ws/tasks/task-001');
    });

    it('handles incoming task messages', () => {
      const onMessage = jest.fn();
      const ws = createEnhancerTaskWebSocket('task-001', onMessage);

      const taskData = { task_id: 'task-001', status: 'running', progress: 50 };
      if (ws.onmessage) {
        ws.onmessage({ data: JSON.stringify(taskData) } as MessageEvent);
      }

      expect(onMessage).toHaveBeenCalledWith(taskData);
    });

    it('filters out ping heartbeat messages', () => {
      const onMessage = jest.fn();
      const ws = createEnhancerTaskWebSocket('task-001', onMessage);

      if (ws.onmessage) {
        ws.onmessage({ data: JSON.stringify({ type: 'ping' }) } as MessageEvent);
      }

      expect(onMessage).not.toHaveBeenCalled();
    });

    it('calls onError on WebSocket error', () => {
      const onMessage = jest.fn();
      const onError = jest.fn();
      const ws = createEnhancerTaskWebSocket('task-001', onMessage, onError);

      if (ws.onerror) {
        ws.onerror(new Event('error'));
      }

      expect(onError).toHaveBeenCalledWith(expect.any(Error));
    });

    it('calls onClose on WebSocket close', () => {
      const onMessage = jest.fn();
      const onError = jest.fn();
      const onClose = jest.fn();
      const ws = createEnhancerTaskWebSocket('task-001', onMessage, onError, onClose);

      if (ws.onclose) {
        ws.onclose(new CloseEvent('close'));
      }

      expect(onClose).toHaveBeenCalled();
    });

    it('handles malformed JSON gracefully', () => {
      const onMessage = jest.fn();
      const consoleSpy = jest.spyOn(console, 'error').mockImplementation();

      const ws = createEnhancerTaskWebSocket('task-001', onMessage);

      if (ws.onmessage) {
        ws.onmessage({ data: 'not json' } as MessageEvent);
      }

      expect(onMessage).not.toHaveBeenCalled();
      expect(consoleSpy).toHaveBeenCalled();
      consoleSpy.mockRestore();
    });
  });

  // =========================================================================
  // pollEnhancerTask
  // =========================================================================
  describe('pollEnhancerTask', () => {
    it('polls until completed', async () => {
      // First poll: running
      mockFetchOk({
        task_id: 'task-001',
        status: 'running',
        progress: 50,
        message: 'Processing...',
        steps: [],
        result: null,
        error: null,
        created_at: '',
        updated_at: '',
      } satisfies EnhancerTaskInfo);
      // Second poll: completed
      mockFetchOk({
        task_id: 'task-001',
        status: 'completed',
        progress: 100,
        message: 'Done',
        steps: [],
        result: { output_file_id: 'out-001' },
        error: null,
        created_at: '',
        updated_at: '',
      } satisfies EnhancerTaskInfo);

      const onUpdate = jest.fn();
      const result = await pollEnhancerTask('task-001', onUpdate, 10, 5000);

      expect(result.status).toBe('completed');
      expect(onUpdate).toHaveBeenCalledTimes(2);
    });

    it('returns on failed status', async () => {
      mockFetchOk({
        task_id: 'task-001',
        status: 'failed',
        progress: 30,
        message: 'Failed',
        steps: [],
        result: null,
        error: 'Model error',
        created_at: '',
        updated_at: '',
      } satisfies EnhancerTaskInfo);

      const result = await pollEnhancerTask('task-001', undefined, 10, 5000);

      expect(result.status).toBe('failed');
      expect(result.error).toBe('Model error');
    });

    it('returns on cancelled status', async () => {
      mockFetchOk({
        task_id: 'task-001',
        status: 'cancelled',
        progress: 0,
        message: '',
        steps: [],
        result: null,
        error: null,
        created_at: '',
        updated_at: '',
      } satisfies EnhancerTaskInfo);

      const result = await pollEnhancerTask('task-001', undefined, 10, 5000);
      expect(result.status).toBe('cancelled');
    });

    it('throws on timeout', async () => {
      // Always return running
      const runningResponse = {
        task_id: 'task-001',
        status: 'running' as const,
        progress: 50,
        message: 'Processing...',
        steps: [],
        result: null,
        error: null,
        created_at: '',
        updated_at: '',
      } satisfies EnhancerTaskInfo;

      // Mock enough calls to exceed timeout
      for (let i = 0; i < 20; i++) {
        mockFetchOk(runningResponse);
      }

      await expect(
        pollEnhancerTask('task-001', undefined, 10, 50) // 50ms timeout
      ).rejects.toThrow('Enhancement timed out');
    });
  });

  // =========================================================================
  // enhanceAudioFull
  // =========================================================================
  describe('enhanceAudioFull', () => {
    beforeEach(() => {
      // Fully reset fetch mock to clear any leftover mockResolvedValueOnce queue
      (global.fetch as jest.Mock).mockReset();
    });

    it('runs full flow: start → poll → result', async () => {
      let fetchCallCount = 0;
      (global.fetch as jest.Mock).mockImplementation(async () => {
        fetchCallCount++;
        if (fetchCallCount === 1) {
          // startEnhancement response
          return {
            ok: true,
            json: async () => ({ success: true, task_id: 'task-full', status: 'pending' }),
          };
        }
        // pollEnhancerTask → getEnhancerTaskStatus response
        return {
          ok: true,
          json: async () => ({
            task_id: 'task-full',
            status: 'completed',
            progress: 100,
            message: 'Done',
            steps: [],
            result: { output_file_id: 'out-full' },
            error: null,
            created_at: '',
            updated_at: '',
          }),
        };
      });

      const audioFile = new File(['audio'], 'audio.wav', { type: 'audio/wav' });
      const accelFile = new File(['accel'], 'accel.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'gyro.txt', { type: 'text/plain' });

      const onProgress = jest.fn();
      const result = await enhanceAudioFull(audioFile, accelFile, gyroFile, onProgress);

      expect(result.status).toBe('completed');
      expect(result.result?.output_file_id).toBe('out-full');
      expect(onProgress).toHaveBeenCalled();
      expect(fetchCallCount).toBe(2);
    });

    it('throws when start fails', async () => {
      mockFetchOk({ success: false, task_id: '', status: 'failed' });

      const audioFile = new File(['audio'], 'audio.wav', { type: 'audio/wav' });
      const accelFile = new File(['accel'], 'accel.txt', { type: 'text/plain' });
      const gyroFile = new File(['gyro'], 'gyro.txt', { type: 'text/plain' });

      await expect(enhanceAudioFull(audioFile, accelFile, gyroFile)).rejects.toThrow(
        'Failed to start enhancement'
      );
    });
  });
});
