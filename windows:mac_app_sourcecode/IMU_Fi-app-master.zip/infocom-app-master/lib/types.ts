/**
 * 音频和文本上传工具 - 类型定义
 * 
 * 本地模型对接技术栈说明：
 * - iOS: Core ML, MLX (Apple Silicon 优化), whisper.cpp
 * - Android: TensorFlow Lite, ONNX Runtime Mobile
 * - 跨平台: llama.cpp, whisper.cpp (通过 Tauri Rust FFI 调用)
 * - 通信协议: Tauri invoke 命令 (首选) 或 HTTP localhost:8080 API
 */

// ============ 文件相关类型 ============

export interface FileInfo {
  id: string;
  name: string;
  size: number;
  type: string;
  lastModified: number;
  uploadedAt: Date;
  status: UploadStatus;
  progress: number;
  file?: File;
  path?: string; // Tauri 文件路径
}

export type UploadStatus = 
  | 'idle' 
  | 'uploading' 
  | 'success' 
  | 'error' 
  | 'validating';

export interface TextFileInfo extends FileInfo {
  content?: string;
  encoding?: string;
  lineCount?: number;
  wordCount?: number;
}

export interface AudioFileInfo extends FileInfo {
  duration?: number; // 秒
  sampleRate?: number;
  channels?: number;
  bitRate?: number;
  format?: AudioFormat;
}

export type AudioFormat = 'mp3' | 'wav' | 'm4a' | 'ogg' | 'flac' | 'aac';
export type ComputeDevice = 'auto' | 'cpu' | 'cuda' | 'mps';
export type ProcessingQuality = 'fast' | 'balanced' | 'quality';

// ============ 音频分析类型 ============

export interface AudioAnalysis {
  duration: number;
  sampleRate: number;
  channels: number;
  bitRate: number;
  format: AudioFormat;
  sourceSize?: number;
  waveformData: number[]; // 归一化的波形数据 0-1
  frequencyData?: number[]; // 频谱数据
  peakAmplitude: number;
  averageAmplitude: number;
  silenceRatio: number; // 静音比例
}

export interface AudioPlaybackState {
  isPlaying: boolean;
  isPaused: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  playbackRate: number;
  isLoading: boolean;
  error?: string;
}

// ============ 模型处理类型 ============

/**
 * 模型处理请求
 * 
 * 技术栈预留接口:
 * 1. Tauri invoke: 通过 Rust 后端调用本地模型
 * 2. HTTP API: POST http://localhost:8080/api/process
 * 3. WebSocket: ws://localhost:8080/ws/process (实时流式处理)
 */
export interface ModelProcessRequest {
  textFile: TextFileInfo;
  audioFile: AudioFileInfo;
  textContent?: string; // 文本内容
  audioData?: ArrayBuffer; // 音频二进制数据
  options?: ModelProcessOptions;
}

export interface ModelProcessOptions {
  model?: string; // 模型名称
  language?: string; // 处理语言
  quality?: ProcessingQuality;
  outputFormat?: AudioFormat;
  sampleRate?: number;
}

export interface ModelProcessResponse {
  success: boolean;
  outputAudio?: ProcessedAudio;
  metadata?: ProcessMetadata;
  error?: string;
}

export interface ProcessedAudio {
  id: string;
  data: ArrayBuffer;
  url?: string; // Blob URL 用于播放
  path?: string; // 本地文件路径
  fileName?: string;
  format: AudioFormat;
  duration: number;
  sampleRate: number;
  size: number;
  createdAt: Date;
}

export interface CompletionCapabilities {
  autoSave: boolean;
  notifications: boolean;
}

export interface ProcessingRuntimeCapabilities {
  supportedDevices: ComputeDevice[];
  supportedQualities: ProcessingQuality[];
  supportedOutputFormats: AudioFormat[];
  completionCapabilities: CompletionCapabilities;
}

export interface AppliedProcessingSettings {
  device: ComputeDevice;
  quality: ProcessingQuality;
  outputFormat: AudioFormat;
  sampleRate: number;
}

export interface ProcessMetadata {
  processingTime: number; // 毫秒
  modelUsed: string;
  inputTextLength: number;
  inputAudioDuration: number;
  outputAudioDuration: number;
  steps: ProcessStep[];
  appliedSettings?: AppliedProcessingSettings;
  runtimeCapabilities?: ProcessingRuntimeCapabilities;
}

export interface ProcessStep {
  name: string;
  status: ProcessStatus;
  progress: number;
  startTime?: Date;
  endTime?: Date;
  message?: string;
}

export type ProcessStatus = 
  | 'pending' 
  | 'processing' 
  | 'completed' 
  | 'failed' 
  | 'skipped';

// ============ 应用状态类型 ============

export interface AppState {
  // 上传状态
  textFile: TextFileInfo | null;
  audioFile: AudioFileInfo | null;
  
  // 处理状态
  isProcessing: boolean;
  processProgress: number;
  processSteps: ProcessStep[];
  processError: string | null;
  
  // 输出结果
  outputAudio: ProcessedAudio | null;
  outputAnalysis: AudioAnalysis | null;
  
  // 播放状态
  playbackState: AudioPlaybackState;
}

// ============ API 接口定义 ============

/**
 * 本地模型 API 接口
 * 
 * 实现方式优先级:
 * 1. Tauri invoke 命令 (推荐，性能最优)
 * 2. HTTP REST API (兼容性好)
 * 3. WebSocket (适合流式处理)
 */
export interface ModelApiInterface {
  /**
   * 处理音频和文本
   * Tauri: invoke('process_audio_text', { textPath, audioPath, options })
   * HTTP: POST /api/process
   */
  process(request: ModelProcessRequest): Promise<ModelProcessResponse>;
  
  /**
   * 获取处理进度
   * Tauri: invoke('get_process_progress', { taskId })
   * HTTP: GET /api/progress/:taskId
   * WebSocket: 订阅 progress 事件
   */
  getProgress(taskId: string): Promise<ProcessStep[]>;
  
  /**
   * 取消处理任务
   * Tauri: invoke('cancel_process', { taskId })
   * HTTP: DELETE /api/process/:taskId
   */
  cancelProcess(taskId: string): Promise<void>;
  
  /**
   * 检查模型是否可用
   * Tauri: invoke('check_model_status')
   * HTTP: GET /api/model/status
   */
  checkModelStatus(): Promise<ModelStatus>;
}

export interface ModelStatus {
  isAvailable: boolean;
  modelName: string;
  modelVersion: string;
  capabilities: string[];
  memoryUsage?: number;
  gpuAvailable?: boolean;
  runtimeCapabilities?: ProcessingRuntimeCapabilities;
}

// ============ 事件类型 ============

export type UploadEvent = 
  | { type: 'file_selected'; file: File }
  | { type: 'upload_start' }
  | { type: 'upload_progress'; progress: number }
  | { type: 'upload_complete'; fileInfo: FileInfo }
  | { type: 'upload_error'; error: string }
  | { type: 'file_removed' };

export type ProcessEvent =
  | { type: 'process_start' }
  | { type: 'step_update'; step: ProcessStep }
  | { type: 'process_progress'; progress: number }
  | { type: 'process_complete'; result: ModelProcessResponse }
  | { type: 'process_error'; error: string }
  | { type: 'process_cancelled' };

// ============ Audio Enhancer Types ============
// Pipeline step names and EnhancerProcessingStep are defined in
// lib/api/enhancer-api.ts (ENHANCER_PIPELINE_STEPS, EnhancerProcessingStep).
// Import from there to avoid duplication.

export interface EnhancerConfig {
  apiUrl: string;
  device: ComputeDevice;
  dbRange: number;
}

export interface EnhancerTaskResult {
  output_file_id?: string;
  output_url?: string;
  output_file_name?: string;
  output_size?: number;
  total_time?: number;
  step_times?: Record<string, number>;
  device?: ComputeDevice;
  quality?: ProcessingQuality;
  output_format?: AudioFormat;
  sample_rate?: number;
}
