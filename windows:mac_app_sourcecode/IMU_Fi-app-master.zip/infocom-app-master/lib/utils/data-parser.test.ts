import {
  parseTimestamp,
  formatTimestamp,
  parseDataFile,
  getPagedData,
  getChartData,
  formatValue,
  formatDuration,
  getColumnsForSensorType,
} from './data-parser';
import type { ParsedData } from './data-parser';

// ---------------------------------------------------------------------------
// Real IMU sensor data snippets (from 测试数据/单个wavtxt测试数据)
// ---------------------------------------------------------------------------

const REAL_ACCEL_DATA = `21:04:00.078 0.001494 0.001578 -0.006411
21:04:00.166 0.004318 -0.003994 -0.004055
21:04:00.168 0.003485 -0.001886 -0.000576
21:04:00.198 0.004494 0.000718 -0.004624
21:04:00.282 0.000995 0.000404 -0.006306
21:04:00.284 -0.000211 0.000808 -0.007553
21:04:00.316 0.000355 -0.002853 -0.008155
21:04:00.402 -0.002053 -0.004121 -0.005605
21:04:00.404 -0.003151 0.001129 -0.005551
21:04:00.435 -0.001243 0.005374 -0.006717`;

const REAL_GYRO_DATA = `21:04:00.078 0.005739 0.010407 -0.012239
21:04:00.166 0.014061 0.019466 -0.01844
21:04:00.168 0.008272 0.001755 -0.0109
21:04:00.198 -0.000926 -0.011372 0.008437
21:04:00.282 0.00059 -0.005017 0.028463`;

// Data with scientific notation values (from real segment data)
const SCIENTIFIC_NOTATION_DATA = `21:04:00.762 0.003536 -3.3e-05 -0.011
21:04:01.127 2e-05 0.007108 -0.000511
21:04:01.157 -0.003308 -0.019111 0.0
21:04:03.916 0.00121 -9.8e-05 -0.006313
21:04:03.949 0.003038 -6e-06 -0.006334`;

// Pure numeric format (no timestamps, 3 columns)
const NUMERIC_DATA = `0.001494 0.001578 -0.006411
0.004318 -0.003994 -0.004055
0.003485 -0.001886 -0.000576
0.004494 0.000718 -0.004624`;

// CSV format with header
const CSV_DATA = `timestamp,x,y,z
0.000,0.012,-0.003,9.801
0.010,0.015,-0.002,9.798
0.020,0.011,-0.005,9.803`;

// Tab-separated format
const TAB_DATA = `21:04:00.078\t0.001494\t0.001578\t-0.006411
21:04:00.166\t0.004318\t-0.003994\t-0.004055`;

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('data-parser', () => {
  // =========================================================================
  // parseTimestamp
  // =========================================================================
  describe('parseTimestamp', () => {
    it('parses HH:MM:SS.mmm format correctly', () => {
      expect(parseTimestamp('21:04:00.078')).toBe(
        21 * 3600000 + 4 * 60000 + 0 * 1000 + 78
      );
    });

    it('parses HH:MM:SS without milliseconds', () => {
      expect(parseTimestamp('21:04:00')).toBe(
        21 * 3600000 + 4 * 60000
      );
    });

    it('parses midnight correctly', () => {
      expect(parseTimestamp('00:00:00.000')).toBe(0);
    });

    it('parses end of day correctly', () => {
      expect(parseTimestamp('23:59:59.999')).toBe(
        23 * 3600000 + 59 * 60000 + 59 * 1000 + 999
      );
    });

    it('pads milliseconds with trailing zeros', () => {
      // "21:04:00.1" should be interpreted as 100ms
      expect(parseTimestamp('21:04:00.1')).toBe(
        21 * 3600000 + 4 * 60000 + 100
      );
    });

    it('handles single-digit hours', () => {
      expect(parseTimestamp('1:02:03.456')).toBe(
        1 * 3600000 + 2 * 60000 + 3 * 1000 + 456
      );
    });

    it('returns 0 for invalid format', () => {
      expect(parseTimestamp('invalid')).toBe(0);
      expect(parseTimestamp('')).toBe(0);
      expect(parseTimestamp('12:34')).toBe(0);
      expect(parseTimestamp('abc:de:fg')).toBe(0);
    });
  });

  // =========================================================================
  // formatTimestamp
  // =========================================================================
  describe('formatTimestamp', () => {
    it('formats 0 ms correctly', () => {
      expect(formatTimestamp(0)).toBe('00:00:00.000');
    });

    it('formats typical timestamp', () => {
      const ms = 21 * 3600000 + 4 * 60000 + 78;
      expect(formatTimestamp(ms)).toBe('21:04:00.078');
    });

    it('formats end of day', () => {
      const ms = 23 * 3600000 + 59 * 60000 + 59 * 1000 + 999;
      expect(formatTimestamp(ms)).toBe('23:59:59.999');
    });

    it('roundtrips with parseTimestamp', () => {
      const timestamps = [
        '00:00:00.000',
        '12:30:45.123',
        '23:59:59.999',
        '21:04:00.078',
      ];
      for (const ts of timestamps) {
        expect(formatTimestamp(parseTimestamp(ts))).toBe(ts);
      }
    });
  });

  // =========================================================================
  // getColumnsForSensorType
  // =========================================================================
  describe('getColumnsForSensorType', () => {
    it('returns accelerometer columns', () => {
      const cols = getColumnsForSensorType('accelerometer');
      expect(cols).toHaveLength(4);
      expect(cols[0]).toContain('timestamp');
      expect(cols[1]).toContain('accelX');
      expect(cols[2]).toContain('accelY');
      expect(cols[3]).toContain('accelZ');
    });

    it('returns gyroscope columns', () => {
      const cols = getColumnsForSensorType('gyroscope');
      expect(cols).toHaveLength(4);
      expect(cols[0]).toContain('timestamp');
      expect(cols[1]).toContain('gyroX');
      expect(cols[2]).toContain('gyroY');
      expect(cols[3]).toContain('gyroZ');
    });
  });

  // =========================================================================
  // parseDataFile — Real IMU data
  // =========================================================================
  describe('parseDataFile', () => {
    describe('real accelerometer data', () => {
      let parsed: ParsedData;

      beforeAll(() => {
        parsed = parseDataFile(REAL_ACCEL_DATA);
      });

      it('parses all rows', () => {
        expect(parsed.rows).toHaveLength(10);
        expect(parsed.errors).toHaveLength(0);
      });

      it('extracts timestamps', () => {
        expect(parsed.rows[0].timestamp).toBe('21:04:00.078');
        expect(parsed.rows[9].timestamp).toBe('21:04:00.435');
      });

      it('extracts 3 value columns per row', () => {
        expect(parsed.rows[0].values).toHaveLength(3);
        expect(parsed.rows[0].values[0]).toBeCloseTo(0.001494);
        expect(parsed.rows[0].values[1]).toBeCloseTo(0.001578);
        expect(parsed.rows[0].values[2]).toBeCloseTo(-0.006411);
      });

      it('computes correct time range', () => {
        expect(parsed.stats.timeRange.start).toBe('21:04:00.078');
        expect(parsed.stats.timeRange.end).toBe('21:04:00.435');
        expect(parsed.stats.timeRange.durationMs).toBe(
          parseTimestamp('21:04:00.435') - parseTimestamp('21:04:00.078')
        );
      });

      it('computes correct stats', () => {
        expect(parsed.stats.totalRows).toBe(10);
        expect(parsed.stats.validRows).toBe(10);
        expect(parsed.stats.columnCount).toBe(4); // timestamp + 3 values
        expect(parsed.stats.valueRanges).toHaveLength(3);
      });

      it('computes min/max correctly for first column', () => {
        const range = parsed.stats.valueRanges[0];
        const col0Values = parsed.rows.map(r => r.values[0]);
        expect(range.min).toBeCloseTo(Math.min(...col0Values));
        expect(range.max).toBeCloseTo(Math.max(...col0Values));
      });

      it('computes avg correctly', () => {
        const range = parsed.stats.valueRanges[0];
        const col0Values = parsed.rows.map(r => r.values[0]);
        const expectedAvg = col0Values.reduce((a, b) => a + b, 0) / col0Values.length;
        expect(range.avg).toBeCloseTo(expectedAvg, 6);
      });

      it('computes stdDev > 0', () => {
        for (const range of parsed.stats.valueRanges) {
          expect(range.stdDev).toBeGreaterThan(0);
        }
      });

      it('preserves raw line', () => {
        expect(parsed.rows[0].raw).toBe('21:04:00.078 0.001494 0.001578 -0.006411');
      });
    });

    describe('real gyroscope data', () => {
      let parsed: ParsedData;

      beforeAll(() => {
        parsed = parseDataFile(REAL_GYRO_DATA);
      });

      it('parses all rows', () => {
        expect(parsed.rows).toHaveLength(5);
        expect(parsed.errors).toHaveLength(0);
      });

      it('handles negative values', () => {
        // Row 3: -0.000926 -0.011372 0.008437
        expect(parsed.rows[3].values[0]).toBeCloseTo(-0.000926);
        expect(parsed.rows[3].values[1]).toBeCloseTo(-0.011372);
        expect(parsed.rows[3].values[2]).toBeCloseTo(0.008437);
      });
    });

    describe('scientific notation values', () => {
      let parsed: ParsedData;

      beforeAll(() => {
        parsed = parseDataFile(SCIENTIFIC_NOTATION_DATA);
      });

      it('parses all rows without errors', () => {
        expect(parsed.rows).toHaveLength(5);
        expect(parsed.errors).toHaveLength(0);
      });

      it('correctly parses -3.3e-05', () => {
        expect(parsed.rows[0].values[1]).toBeCloseTo(-3.3e-05, 8);
      });

      it('correctly parses 2e-05', () => {
        expect(parsed.rows[1].values[0]).toBeCloseTo(2e-05, 8);
      });

      it('correctly parses 0.0', () => {
        expect(parsed.rows[2].values[2]).toBe(0);
      });

      it('correctly parses -9.8e-05', () => {
        expect(parsed.rows[3].values[1]).toBeCloseTo(-9.8e-05, 8);
      });

      it('correctly parses -6e-06', () => {
        expect(parsed.rows[4].values[1]).toBeCloseTo(-6e-06, 9);
      });
    });

    describe('pure numeric format (no timestamps)', () => {
      let parsed: ParsedData;

      beforeAll(() => {
        parsed = parseDataFile(NUMERIC_DATA);
      });

      it('parses all rows', () => {
        expect(parsed.rows).toHaveLength(4);
        expect(parsed.errors).toHaveLength(0);
      });

      it('assigns sequential index-based timestamps', () => {
        expect(parsed.rows[0].timestamp).toBe('0');
        expect(parsed.rows[1].timestamp).toBe('1');
        expect(parsed.rows[2].timestamp).toBe('2');
      });

      it('assigns 8ms intervals for timeMs (~125 Hz)', () => {
        expect(parsed.rows[0].timeMs).toBe(0);
        expect(parsed.rows[1].timeMs).toBe(8);
        expect(parsed.rows[2].timeMs).toBe(16);
        expect(parsed.rows[3].timeMs).toBe(24);
      });

      it('extracts 3 values per row', () => {
        expect(parsed.rows[0].values).toEqual([0.001494, 0.001578, -0.006411]);
      });
    });

    describe('CSV format with header', () => {
      it('skips header line if it is not parseable as data', () => {
        const parsed = parseDataFile(CSV_DATA);
        // Header "timestamp,x,y,z" — "timestamp" is not a number so it falls into
        // the timestamp format path but fails to parse; should be an error or skipped
        // The remaining 3 data rows should parse
        expect(parsed.rows.length).toBeGreaterThanOrEqual(3);
      });
    });

    describe('tab-separated format', () => {
      it('parses tab-separated data correctly', () => {
        const parsed = parseDataFile(TAB_DATA);
        expect(parsed.rows).toHaveLength(2);
        expect(parsed.errors).toHaveLength(0);
        expect(parsed.rows[0].timestamp).toBe('21:04:00.078');
        expect(parsed.rows[0].values[0]).toBeCloseTo(0.001494);
      });
    });

    describe('custom columns', () => {
      it('uses custom column names', () => {
        const customCols = ['Time', 'Ax', 'Ay', 'Az'];
        const parsed = parseDataFile(REAL_ACCEL_DATA, customCols);
        expect(parsed.columns).toEqual(customCols);
      });
    });

    describe('edge cases', () => {
      it('handles empty content', () => {
        const parsed = parseDataFile('');
        expect(parsed.rows).toHaveLength(0);
        expect(parsed.stats.totalRows).toBe(0);
      });

      it('handles single line', () => {
        const parsed = parseDataFile('21:04:00.078 0.001 0.002 -0.003');
        expect(parsed.rows).toHaveLength(1);
        expect(parsed.errors).toHaveLength(0);
      });

      it('handles lines with only whitespace', () => {
        const data = `21:04:00.078 0.001 0.002 -0.003
   
21:04:00.166 0.004 -0.003 -0.004`;
        const parsed = parseDataFile(data);
        expect(parsed.rows).toHaveLength(2);
      });

      it('handles comment lines starting with #', () => {
        const data = `# This is a comment
21:04:00.078 0.001 0.002 -0.003
# Another comment
21:04:00.166 0.004 -0.003 -0.004`;
        const parsed = parseDataFile(data);
        expect(parsed.rows).toHaveLength(2);
      });

      it('reports errors for invalid value lines', () => {
        const data = `21:04:00.078 0.001 abc -0.003
21:04:00.166 0.004 -0.003 -0.004`;
        const parsed = parseDataFile(data);
        expect(parsed.errors).toHaveLength(1);
        expect(parsed.errors[0].line).toBe(1);
        expect(parsed.rows).toHaveLength(1);
      });

      it('reports errors for lines with insufficient columns', () => {
        const data = `21:04:00.078
21:04:00.166 0.004 -0.003 -0.004`;
        const parsed = parseDataFile(data);
        expect(parsed.errors).toHaveLength(1);
        expect(parsed.rows).toHaveLength(1);
      });

      it('handles trailing newline', () => {
        const data = `21:04:00.078 0.001 0.002 -0.003
21:04:00.166 0.004 -0.003 -0.004
`;
        const parsed = parseDataFile(data);
        expect(parsed.rows).toHaveLength(2);
      });
    });
  });

  // =========================================================================
  // getPagedData
  // =========================================================================
  describe('getPagedData', () => {
    let parsed: ParsedData;

    beforeAll(() => {
      parsed = parseDataFile(REAL_ACCEL_DATA);
    });

    it('returns first page', () => {
      const page = getPagedData(parsed, 0, 5);
      expect(page).toHaveLength(5);
      expect(page[0].index).toBe(0);
      expect(page[4].index).toBe(4);
    });

    it('returns second page', () => {
      const page = getPagedData(parsed, 1, 5);
      expect(page).toHaveLength(5);
      expect(page[0].index).toBe(5);
    });

    it('returns partial last page', () => {
      const page = getPagedData(parsed, 1, 7);
      expect(page).toHaveLength(3); // 10 total, 7 per page, page 1 = 3 remaining
    });

    it('returns empty for out-of-range page', () => {
      const page = getPagedData(parsed, 10, 5);
      expect(page).toHaveLength(0);
    });

    it('returns all data when pageSize >= total', () => {
      const page = getPagedData(parsed, 0, 100);
      expect(page).toHaveLength(10);
    });
  });

  // =========================================================================
  // getChartData
  // =========================================================================
  describe('getChartData', () => {
    let parsed: ParsedData;

    beforeAll(() => {
      parsed = parseDataFile(REAL_ACCEL_DATA);
    });

    it('returns timestamps and series', () => {
      const chart = getChartData(parsed);
      expect(chart.timestamps).toBeDefined();
      expect(chart.series).toBeDefined();
      expect(chart.timestamps.length).toBeGreaterThan(0);
    });

    it('returns 3 series for 3-column data', () => {
      const chart = getChartData(parsed);
      expect(chart.series).toHaveLength(3);
    });

    it('series data length matches timestamps length', () => {
      const chart = getChartData(parsed);
      for (const s of chart.series) {
        expect(s.data).toHaveLength(chart.timestamps.length);
      }
    });

    it('respects maxPoints parameter', () => {
      const chart = getChartData(parsed, 3);
      // step = floor(10/3) = 3, so indices 0,3,6,9 → 4 sampled points
      expect(chart.timestamps.length).toBeLessThanOrEqual(5);
      expect(chart.timestamps.length).toBeLessThan(parsed.rows.length);
    });

    it('returns all points when maxPoints > total', () => {
      const chart = getChartData(parsed, 1000);
      expect(chart.timestamps).toHaveLength(10);
    });

    it('downsamples large datasets', () => {
      // Build a large dataset
      const lines: string[] = [];
      for (let i = 0; i < 1000; i++) {
        const s = Math.floor(i / 10);
        const ms = (i % 10) * 100;
        lines.push(`00:00:${s.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')} ${i * 0.001} ${i * 0.002} ${i * 0.003}`);
      }
      const largeParsed = parseDataFile(lines.join('\n'));
      const chart = getChartData(largeParsed, 100);
      expect(chart.timestamps.length).toBeLessThanOrEqual(100);
    });
  });

  // =========================================================================
  // formatValue
  // =========================================================================
  describe('formatValue', () => {
    it('formats normal values with default precision', () => {
      expect(formatValue(0.001494)).toBe('0.001494');
    });

    it('formats negative values', () => {
      expect(formatValue(-0.006411)).toBe('-0.006411');
    });

    it('uses scientific notation for very small values', () => {
      const result = formatValue(0.0000001);
      expect(result).toMatch(/e/i);
    });

    it('formats with custom precision', () => {
      expect(formatValue(0.123456789, 3)).toBe('0.123');
    });

    it('formats zero', () => {
      // 0 < 0.000001 so it uses scientific notation
      expect(formatValue(0)).toMatch(/0\.00e\+0|0\.00e0/);
    });

    it('formats exactly at threshold', () => {
      // 0.000001 is at the boundary
      const result = formatValue(0.000001);
      // Should still use fixed notation (not scientific)
      expect(result).toBe('0.000001');
    });

    it('uses scientific for values below threshold', () => {
      const result = formatValue(0.0000001);
      expect(result).toContain('e');
    });
  });

  // =========================================================================
  // formatDuration
  // =========================================================================
  describe('formatDuration', () => {
    it('formats milliseconds', () => {
      expect(formatDuration(500)).toBe('500ms');
    });

    it('formats seconds', () => {
      expect(formatDuration(2500)).toBe('2.5s');
    });

    it('formats minutes and seconds', () => {
      expect(formatDuration(90000)).toBe('1m 30.0s');
    });

    it('formats exactly 1 second', () => {
      expect(formatDuration(1000)).toBe('1.0s');
    });

    it('formats 0 ms', () => {
      expect(formatDuration(0)).toBe('0ms');
    });

    it('formats boundary: 999ms', () => {
      expect(formatDuration(999)).toBe('999ms');
    });

    it('formats boundary: 59999ms', () => {
      expect(formatDuration(59999)).toBe('60.0s');
    });

    it('formats large durations', () => {
      expect(formatDuration(300000)).toBe('5m 0.0s');
    });
  });
});
