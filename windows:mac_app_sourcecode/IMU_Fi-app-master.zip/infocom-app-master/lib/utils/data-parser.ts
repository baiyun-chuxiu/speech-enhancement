import type { Locale } from '@/i18n/config';
import { formatDurationMsLabel } from './upload-formatters';

/**
 * TXT/CSV 数据解析工具
 * 
 * 支持解析格式:
 * 时间戳 数值1 数值2 数值3
 * 例如: 21:04:00.078 0.001494 0.001578 -0.006411
 */

export interface DataRow {
  index: number;
  timestamp: string;
  timeMs: number; // 毫秒时间戳，用于排序和图表
  values: number[];
  raw: string;
}

export interface ParsedData {
  rows: DataRow[];
  columns: string[];
  stats: DataStats;
  errors: ParseError[];
}

export interface DataStats {
  totalRows: number;
  validRows: number;
  columnCount: number;
  timeRange: {
    start: string;
    end: string;
    durationMs: number;
  };
  valueRanges: {
    column: string;
    min: number;
    max: number;
    avg: number;
    stdDev: number;
  }[];
}

export interface ParseError {
  line: number;
  message: string;
  raw: string;
}

export type SensorType = 'accelerometer' | 'gyroscope';

const ACCELEROMETER_COLUMNS = ['dataParser.timestamp', 'dataParser.accelX', 'dataParser.accelY', 'dataParser.accelZ'];
const GYROSCOPE_COLUMNS = ['dataParser.timestamp', 'dataParser.gyroX', 'dataParser.gyroY', 'dataParser.gyroZ'];

const DEFAULT_COLUMNS = ACCELEROMETER_COLUMNS;

function buildResolvedColumns(rows: DataRow[], columns: string[]) {
  const valueColumnCount = rows.length > 0 ? Math.max(...rows.map((row) => row.values.length)) : Math.max(columns.length - 1, 0);
  const [timestampColumn = 'dataParser.timestamp', ...valueColumns] = columns;

  return [
    timestampColumn,
    ...Array.from({ length: valueColumnCount }, (_, index) => valueColumns[index] ?? `dataParser.column:${index + 1}`),
  ];
}

export function getColumnsForSensorType(type: SensorType): string[] {
  return type === 'accelerometer' ? ACCELEROMETER_COLUMNS : GYROSCOPE_COLUMNS;
}

/**
 * 解析时间戳字符串为毫秒数
 * 支持格式: HH:MM:SS.mmm 或 HH:MM:SS
 */
export function parseTimestamp(timestamp: string): number {
  const match = timestamp.match(/^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$/);
  if (!match) return 0;
  
  const [, hours, minutes, seconds, ms = '0'] = match;
  return (
    parseInt(hours) * 3600000 +
    parseInt(minutes) * 60000 +
    parseInt(seconds) * 1000 +
    parseInt(ms.padEnd(3, '0'))
  );
}

/**
 * 格式化毫秒为时间字符串
 */
export function formatTimestamp(ms: number): string {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  const milliseconds = ms % 1000;
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${milliseconds.toString().padStart(3, '0')}`;
}

/**
 * 计算标准差
 */
function calculateStdDev(values: number[], avg: number): number {
  if (values.length === 0) return 0;
  const squareDiffs = values.map(v => Math.pow(v - avg, 2));
  const avgSquareDiff = squareDiffs.reduce((a, b) => a + b, 0) / values.length;
  return Math.sqrt(avgSquareDiff);
}

/**
 * Detect if the data format is timestamp-based (4+ columns with HH:MM:SS)
 * or pure numeric (3 columns: x y z, no timestamp).
 */
function detectFormat(lines: string[]): 'timestamp' | 'numeric' {
  for (const line of lines.slice(0, 5)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    // If the first field matches HH:MM:SS pattern, it's timestamp format
    if (/^\d{1,2}:\d{2}:\d{2}/.test(trimmed)) return 'timestamp';
    // If all fields are pure numbers, it's numeric format
    const parts = trimmed.split(/[\s,\t]+/);
    if (parts.length >= 3 && parts.every(p => !isNaN(parseFloat(p)))) return 'numeric';
  }
  return 'timestamp'; // fallback
}

/**
 * 解析 TXT 数据文件
 * 
 * Supports two formats:
 * 1. Timestamp format: "HH:MM:SS.mmm x y z" (4+ columns)
 * 2. Numeric format: "x y z" (3 columns, no timestamp) — used by IMU sensor data
 */
export function parseDataFile(content: string, customColumns?: string[]): ParsedData {
  const lines = content.trim().split('\n');
  const rows: DataRow[] = [];
  const errors: ParseError[] = [];
  
  // 检测分隔符 (空格、制表符、逗号)
  const firstLine = lines[0] || '';
  const separator = firstLine.includes('\t') ? /\t+/ : 
                    firstLine.includes(',') ? /,\s*/ : /\s+/;

  const format = detectFormat(lines);
  const columns = customColumns || DEFAULT_COLUMNS;

  lines.forEach((line, index) => {
    const trimmedLine = line.trim();
    if (!trimmedLine || trimmedLine.startsWith('#')) {
      return; // 跳过空行和注释
    }

    const parts = trimmedLine.split(separator);

    if (format === 'numeric') {
      // Pure numeric format: all columns are values, no timestamp
      const values = parts.map(v => parseFloat(v));
      if (values.length < 2 || values.some(isNaN)) {
        errors.push({
          line: index + 1,
          message: 'errors.invalidValues',
          raw: trimmedLine,
        });
        return;
      }
      rows.push({
        index: rows.length,
        timestamp: `${rows.length}`,
        timeMs: rows.length * 8, // ~125 Hz → 8ms per sample
        values,
        raw: trimmedLine,
      });
    } else {
      // Timestamp format: first column is timestamp, rest are values
      if (parts.length < 2) {
        errors.push({
          line: index + 1,
          message: 'errors.insufficientColumns',
          raw: trimmedLine,
        });
        return;
      }

      const timestamp = parts[0];
      const timeMs = parseTimestamp(timestamp);
      const values = parts.slice(1).map(v => parseFloat(v));

      // 检查是否有无效数值
      if (values.some(isNaN)) {
        errors.push({
          line: index + 1,
          message: 'errors.invalidValues',
          raw: trimmedLine,
        });
        return;
      }

      rows.push({
        index: rows.length,
        timestamp,
        timeMs,
        values,
        raw: trimmedLine,
      });
    }
  });

  const resolvedColumns = buildResolvedColumns(rows, columns);

  // 计算统计信息
  const stats = calculateStats(rows, resolvedColumns);

  return {
    rows,
    columns: resolvedColumns,
    stats,
    errors,
  };
}

/**
 * 计算数据统计信息
 */
function calculateStats(rows: DataRow[], columns: string[]): DataStats {
  if (rows.length === 0) {
    return {
      totalRows: 0,
      validRows: 0,
      columnCount: 0,
      timeRange: { start: '', end: '', durationMs: 0 },
      valueRanges: [],
    };
  }

  const sortedRows = [...rows].sort((a, b) => a.timeMs - b.timeMs);
  const firstRow = sortedRows[0];
  const lastRow = sortedRows[sortedRows.length - 1];
  const columnCount = Math.max(...rows.map(r => r.values.length));

  const valueRanges = [];
  for (let i = 0; i < columnCount; i++) {
    const columnValues = rows.map(r => r.values[i]).filter(v => v !== undefined);
    const min = Math.min(...columnValues);
    const max = Math.max(...columnValues);
    const avg = columnValues.reduce((a, b) => a + b, 0) / columnValues.length;
    const stdDev = calculateStdDev(columnValues, avg);

    valueRanges.push({
      column: columns[i + 1] || `dataParser.column:${i + 1}`,
      min,
      max,
      avg,
      stdDev,
    });
  }

  return {
    totalRows: rows.length,
    validRows: rows.length,
    columnCount: columnCount + 1, // 包含时间戳列
    timeRange: {
      start: firstRow.timestamp,
      end: lastRow.timestamp,
      durationMs: lastRow.timeMs - firstRow.timeMs,
    },
    valueRanges,
  };
}

/**
 * 获取分页数据
 */
export function getPagedData(
  data: ParsedData,
  page: number,
  pageSize: number
): DataRow[] {
  const start = page * pageSize;
  const end = start + pageSize;
  return data.rows.slice(start, end);
}

/**
 * 获取图表数据 (降采样以提高性能)
 */
export function getChartData(
  data: ParsedData,
  maxPoints: number = 500
): { timestamps: number[]; series: { name: string; data: number[] }[] } {
  const rows = data.rows;
  
  // 如果数据点过多，进行降采样
  const step = Math.max(1, Math.floor(rows.length / maxPoints));
  const sampledRows = rows.filter((_, i) => i % step === 0);
  
  const timestamps = sampledRows.map(r => r.timeMs);
  const columnCount = data.stats.columnCount - 1; // 排除时间戳列
  
  const series = [];
  for (let i = 0; i < columnCount; i++) {
    series.push({
      name: data.columns[i + 1] || `dataParser.column:${i + 1}`,
      data: sampledRows.map(r => r.values[i] ?? 0),
    });
  }

  return { timestamps, series };
}

/**
 * 格式化数值显示
 */
export function formatValue(value: number, precision: number = 6): string {
  if (Math.abs(value) < 0.000001) {
    return value.toExponential(2);
  }
  return value.toFixed(precision);
}

/**
 * 格式化时长
 */
export function formatDuration(
  ms: number,
  locale: Locale | string = 'en',
  t?: (key: string, values?: Record<string, string | number>) => string,
): string {
  return formatDurationMsLabel(ms, locale, t);
}
