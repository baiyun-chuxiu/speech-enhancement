import type { Locale } from '@/i18n/config';

type TranslationValues = Record<string, string | number>;
type FormatTranslator = (key: string, values?: TranslationValues) => string;

const fallbackMessages: Record<string, string> = {
  'common.unavailable': 'Unavailable',
  'uploadFormats.fileSizeBytes': '{value} B',
  'uploadFormats.fileSizeKilobytes': '{value} KB',
  'uploadFormats.fileSizeMegabytes': '{value} MB',
  'uploadFormats.fileSizeGigabytes': '{value} GB',
  'uploadFormats.sampleRateKilohertz': '{value} kHz',
  'uploadFormats.decibels': '{value} dB',
  'uploadFormats.durationMilliseconds': '{value}ms',
  'uploadFormats.durationSeconds': '{value}s',
  'uploadFormats.durationMinutesSeconds': '{minutes}m {seconds}s',
};

function interpolate(template: string, values?: TranslationValues) {
  if (!values) {
    return template;
  }

  return template.replace(/\{(\w+)\}/g, (_, token: string) => {
    const value = values[token];
    return value === undefined ? `{${token}}` : String(value);
  });
}

function translateMessage(key: string, values?: TranslationValues, t?: FormatTranslator) {
  if (t) {
    return t(key, values);
  }

  return interpolate(fallbackMessages[key] ?? key, values);
}

export function formatLocaleNumber(locale: Locale | string, value: number, options?: Intl.NumberFormatOptions) {
  return new Intl.NumberFormat(locale, options).format(value);
}

function formatCompactDecimal(locale: Locale | string, value: number, minimumFractionDigits = 0, maximumFractionDigits = 2) {
  return formatLocaleNumber(locale, value, {
    minimumFractionDigits,
    maximumFractionDigits,
  });
}

export function formatUnavailableLabel(t?: FormatTranslator) {
  return translateMessage('common.unavailable', undefined, t);
}

export function formatFileSizeLabel(bytes: number, locale: Locale | string, t?: FormatTranslator) {
  if (bytes <= 0) {
    return translateMessage('uploadFormats.fileSizeBytes', { value: 0 }, t);
  }

  const units = [
    { key: 'uploadFormats.fileSizeBytes', size: 1 },
    { key: 'uploadFormats.fileSizeKilobytes', size: 1024 },
    { key: 'uploadFormats.fileSizeMegabytes', size: 1024 ** 2 },
    { key: 'uploadFormats.fileSizeGigabytes', size: 1024 ** 3 },
  ];

  const unit = units.findLast(({ size }) => bytes >= size) ?? units[0];
  const rawValue = bytes / unit.size;
  const value = formatCompactDecimal(
    locale,
    rawValue,
    Number.isInteger(rawValue) ? 0 : 1,
    2,
  );

  return translateMessage(unit.key, { value }, t);
}

export function formatSampleRateLabel(sampleRate: number, locale: Locale | string, t?: FormatTranslator) {
  const value = formatCompactDecimal(locale, sampleRate / 1000, 1, 1);
  return translateMessage('uploadFormats.sampleRateKilohertz', { value }, t);
}

export function formatDecibelLabel(value: number | null | undefined, locale: Locale | string, t?: FormatTranslator) {
  if (value === null || value === undefined || !Number.isFinite(value)) {
    return formatUnavailableLabel(t);
  }

  const formatted = formatCompactDecimal(locale, value, 1, 1);
  return translateMessage('uploadFormats.decibels', { value: formatted }, t);
}

export function formatDurationMsLabel(ms: number, locale: Locale | string, t?: FormatTranslator) {
  if (ms < 1000) {
    return translateMessage(
      'uploadFormats.durationMilliseconds',
      { value: formatCompactDecimal(locale, ms, 0, 0) },
      t,
    );
  }

  if (ms < 60000) {
    return translateMessage(
      'uploadFormats.durationSeconds',
      { value: formatCompactDecimal(locale, ms / 1000, 1, 1) },
      t,
    );
  }

  const minutes = Math.floor(ms / 60000);
  const seconds = (ms % 60000) / 1000;

  return translateMessage(
    'uploadFormats.durationMinutesSeconds',
    {
      minutes: formatCompactDecimal(locale, minutes, 0, 0),
      seconds: formatCompactDecimal(locale, seconds, 1, 1),
    },
    t,
  );
}

export function formatShortDateTimeLabel(value: Date | number, locale: Locale | string) {
  return new Intl.DateTimeFormat(locale, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(value);
}

export function formatClockTimeLabel(value: Date | number, locale: Locale | string) {
  return new Intl.DateTimeFormat(locale, {
    hour: 'numeric',
    minute: '2-digit',
  }).format(value);
}

export function localizeDataColumnLabel(label: string, t: FormatTranslator) {
  if (label.startsWith('dataParser.column:')) {
    return t('dataParser.column', { index: label.split(':')[1] ?? '' });
  }

  if (label.startsWith('dataParser.')) {
    return t(label);
  }

  const fallbackColumn = label.match(/^Col\s+(\d+)$/i);
  if (fallbackColumn) {
    return t('dataParser.column', { index: fallbackColumn[1] });
  }

  return label;
}
