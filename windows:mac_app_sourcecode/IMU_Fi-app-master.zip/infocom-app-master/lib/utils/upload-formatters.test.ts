const translate = (dictionary: Record<string, string>) => {
  return (key: string, values?: Record<string, string | number>) => {
    const template = dictionary[key] ?? key;

    return template.replace(/\{(\w+)\}/g, (_, token: string) => {
      const value = values?.[token];
      return value === undefined ? `{${token}}` : String(value);
    });
  };
};

describe('upload-formatters', () => {
  it('formats file sizes with localized templates', async () => {
    const { formatFileSizeLabel } = await import('./upload-formatters');
    const t = translate({
      'uploadFormats.fileSizeKilobytes': '{value} KB',
    });

    expect(formatFileSizeLabel(1536, 'en', t)).toBe('1.5 KB');
  });

  it('formats sample rates with localized templates', async () => {
    const { formatSampleRateLabel } = await import('./upload-formatters');
    const t = translate({
      'uploadFormats.sampleRateKilohertz': '{value} kHz',
    });

    expect(formatSampleRateLabel(44100, 'en', t)).toBe('44.1 kHz');
  });

  it('returns translated unavailable copy for missing values', async () => {
    const { formatUnavailableLabel } = await import('./upload-formatters');
    const t = translate({
      'common.unavailable': 'Unavailable',
    });

    expect(formatUnavailableLabel(t)).toBe('Unavailable');
  });

  it('formats data preview durations through locale-aware templates', async () => {
    const { formatDurationMsLabel } = await import('./upload-formatters');
    const t = translate({
      'uploadFormats.durationMinutesSeconds': '{minutes}分 {seconds}秒',
    });

    expect(formatDurationMsLabel(65000, 'zh-CN', t)).toBe('1分 5.0秒');
  });
});
