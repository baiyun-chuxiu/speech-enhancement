const cookiesMock = jest.fn();

jest.mock('next/headers', () => ({
  cookies: () => cookiesMock(),
}));

jest.mock('next-intl/server', () => ({
  getRequestConfig: (factory: () => Promise<unknown>) => factory,
}));

import getRequestConfig from './request';

describe('i18n request config', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns the static default locale without reading request cookies', async () => {
    const result = await getRequestConfig({
      requestLocale: Promise.resolve(undefined),
    });

    expect(result).toMatchObject({
      locale: 'zh-CN',
    });
    expect(cookiesMock).not.toHaveBeenCalled();
  });
});
