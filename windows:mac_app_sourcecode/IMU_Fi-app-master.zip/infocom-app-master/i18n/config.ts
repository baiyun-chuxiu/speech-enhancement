export const locales = ['zh-CN', 'en'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'zh-CN';
export const LOCALE_COOKIE_KEY = 'infocom-locale';

export const localeNames: Record<Locale, string> = {
  'zh-CN': '中文',
  'en': 'English',
};

export const LOCALE_STORAGE_KEY = 'infocom-locale';

export function isLocale(value: string | null | undefined): value is Locale {
  return Boolean(value && locales.includes(value as Locale));
}
