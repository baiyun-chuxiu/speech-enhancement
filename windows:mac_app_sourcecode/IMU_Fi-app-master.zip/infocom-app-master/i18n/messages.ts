import type { AbstractIntlMessages } from 'next-intl';

import { defaultLocale, type Locale } from './config';

import zhCN from '@/messages/zh-CN.json';
import en from '@/messages/en.json';

export const messagesMap: Record<Locale, AbstractIntlMessages> = {
  'zh-CN': zhCN,
  en,
};

export function getMessagesForLocale(locale: Locale): AbstractIntlMessages {
  return messagesMap[locale] ?? messagesMap[defaultLocale];
}
