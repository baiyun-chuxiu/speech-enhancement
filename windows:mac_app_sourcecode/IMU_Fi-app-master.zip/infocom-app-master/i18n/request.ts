import { getRequestConfig } from 'next-intl/server';
import { defaultLocale } from './config';
import { getMessagesForLocale } from './messages';

export default getRequestConfig(async () => {
  return {
    locale: defaultLocale,
    messages: getMessagesForLocale(defaultLocale),
    timeZone: 'UTC',
  };
});
