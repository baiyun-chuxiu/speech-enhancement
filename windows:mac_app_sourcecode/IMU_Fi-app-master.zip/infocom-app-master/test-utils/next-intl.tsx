import React, { createContext, useContext } from 'react';
import type { ReactNode } from 'react';
import { LOCALE_STORAGE_KEY, defaultLocale, type Locale } from '@/i18n/config';
import zhCN from '@/messages/zh-CN.json';
import en from '@/messages/en.json';

type Messages = typeof zhCN;

const messagesByLocale: Record<Locale, Messages> = {
  'zh-CN': zhCN,
  en,
};

type TranslationValues = Record<string, string | number | Date>;

interface IntlContextValue {
  locale: Locale;
  messages: Messages;
}

const TestIntlContext = createContext<IntlContextValue>({
  locale: defaultLocale,
  messages: messagesByLocale[defaultLocale],
});

function isLocale(value: string | null): value is Locale {
  return value === 'zh-CN' || value === 'en';
}

function getStoredLocale(): Locale {
  if (typeof window === 'undefined') {
    return defaultLocale;
  }

  const stored = window.localStorage.getItem(LOCALE_STORAGE_KEY);
  return isLocale(stored) ? stored : defaultLocale;
}

function interpolate(message: string, values?: TranslationValues) {
  if (!values) {
    return message;
  }

  return message.replace(/\{(\w+)\}/g, (_, key: string) => {
    const value = values[key];
    return value === undefined ? `{${key}}` : String(value);
  });
}

function resolveMessage(messages: Messages, path: string) {
  const keys = path.split('.');
  let current: unknown = messages;

  for (const key of keys) {
    if (current && typeof current === 'object' && key in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[key];
      continue;
    }

    return undefined;
  }

  return typeof current === 'string' ? current : undefined;
}

export function getCurrentTestLocale() {
  return getStoredLocale();
}

export function TestNextIntlClientProvider({
  children,
  locale = defaultLocale,
  messages,
}: {
  children: ReactNode;
  locale?: string;
  messages?: Messages;
}) {
  const resolvedLocale = isLocale(locale) ? locale : defaultLocale;
  const resolvedMessages = messages ?? messagesByLocale[resolvedLocale];

  return (
    <TestIntlContext.Provider
      value={{
        locale: resolvedLocale,
        messages: resolvedMessages,
      }}
    >
      {children}
    </TestIntlContext.Provider>
  );
}

export function useTestTranslations(namespace?: string) {
  const { messages } = useContext(TestIntlContext);

  return (key: string, values?: TranslationValues) => {
    const path = namespace ? `${namespace}.${key}` : key;
    const message = resolveMessage(messages, path);

    if (!message) {
      return path;
    }

    return interpolate(message, values);
  };
}

export function useTestLocale() {
  return useContext(TestIntlContext).locale;
}

export function useTestMessages() {
  return useContext(TestIntlContext).messages;
}

export function useTestFormatter() {
  const locale = useTestLocale();

  return {
    number(value: number, options?: Intl.NumberFormatOptions) {
      return new Intl.NumberFormat(locale, options).format(value);
    },
    dateTime(value: Date | number, options?: Intl.DateTimeFormatOptions) {
      return new Intl.DateTimeFormat(locale, options).format(value);
    },
  };
}
