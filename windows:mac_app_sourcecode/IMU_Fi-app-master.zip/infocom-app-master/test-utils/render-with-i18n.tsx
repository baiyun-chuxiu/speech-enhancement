import React from 'react';
import { render, type RenderOptions } from '@testing-library/react';
import { NextIntlClientProvider } from 'next-intl';
import { LOCALE_STORAGE_KEY, defaultLocale, type Locale } from '@/i18n/config';
import zhCN from '@/messages/zh-CN.json';
import en from '@/messages/en.json';

interface RenderWithI18nOptions extends Omit<RenderOptions, 'wrapper'> {
  locale?: Locale;
}

export function renderWithI18n(
  ui: React.ReactElement,
  { locale = defaultLocale, ...options }: RenderWithI18nOptions = {},
) {
  window.localStorage.setItem(LOCALE_STORAGE_KEY, locale);
  document.documentElement.lang = locale;

  const messages = locale === 'en' ? en : zhCN;

  return render(ui, {
    wrapper: ({ children }) => (
      <NextIntlClientProvider locale={locale} messages={messages}>
        {children}
      </NextIntlClientProvider>
    ),
    ...options,
  });
}
