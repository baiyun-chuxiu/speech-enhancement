/**
 * Jest setup file
 * This file is executed before each test file
 */

import '@testing-library/jest-dom';
import React from 'react';
import {
  TestNextIntlClientProvider,
  useTestFormatter,
  useTestLocale,
  useTestMessages,
  useTestTranslations,
} from '@/test-utils/next-intl';

jest.mock('next-intl', () => {
  return {
    __esModule: true,
    NextIntlClientProvider: TestNextIntlClientProvider,
    IntlProvider: TestNextIntlClientProvider,
    useTranslations: useTestTranslations,
    useLocale: useTestLocale,
    useMessages: useTestMessages,
    useFormatter: useTestFormatter,
    useNow: () => new Date('2024-01-01T00:00:00.000Z'),
    useTimeZone: () => 'UTC',
  };
});

jest.mock('next-intl/server', () => ({
  __esModule: true,
  getRequestConfig: (factory: () => unknown) => factory,
}));

// Mock Next.js Image component
jest.mock('next/image', () => ({
  __esModule: true,
  default: (props: React.ImgHTMLAttributes<HTMLImageElement>) => {
    return React.createElement('img', props);
  },
}));

// Mock Next.js router
jest.mock('next/navigation', () => ({
  useRouter() {
    return {
      push: jest.fn(),
      replace: jest.fn(),
      prefetch: jest.fn(),
      back: jest.fn(),
      pathname: '/',
      query: {},
      asPath: '/',
    };
  },
  usePathname() {
    return '/';
  },
  useSearchParams() {
    return new URLSearchParams();
  },
}));

afterEach(() => {
  if (typeof window !== 'undefined') {
    window.localStorage.clear();
  }

  if (typeof document !== 'undefined') {
    document.documentElement.lang = 'zh-CN';
  }
});

// Suppress console errors in tests (optional)
// global.console = {
//   ...console,
//   error: jest.fn(),
//   warn: jest.fn(),
// };

class MockResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}

global.ResizeObserver = MockResizeObserver as unknown as typeof ResizeObserver;

