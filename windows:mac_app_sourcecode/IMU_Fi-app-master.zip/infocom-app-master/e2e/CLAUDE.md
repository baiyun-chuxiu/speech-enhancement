# E2E Tests Module

[根目录](../CLAUDE.md) > **e2e/**

## Module Overview

Playwright end-to-end test suite covering the InfoCom application's critical user flows across multiple browsers and devices.

## Module Structure

```
e2e/
├── helpers/
│   ├── index.ts              # Helper exports
│   ├── test-utils.ts         # Common test utilities
│   └── api-mock.ts           # API mocking utilities
│
├── upload-complete-flow.spec.ts       # Full upload workflow
├── upload-validation.spec.ts          # File validation tests
├── api-integration.spec.ts            # API backend integration
├── navigation.spec.ts                 # Navigation between pages
├── file-drag-drop.spec.ts             # Drag and drop functionality
├── settings.spec.ts                   # Settings page tests
├── audio-player.spec.ts               # Audio playback tests
├── data-visualization.spec.ts         # Chart and preview tests
├── responsive.spec.ts                 # Mobile/responsive design
├── accessibility.spec.ts              # A11y compliance tests
├── performance.spec.ts                # Performance benchmarks
└── edge-cases.spec.ts                 # Error handling
```

## Playwright Configuration

### Test Projects

```typescript
projects: [
  { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
  { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  { name: 'mobile-chrome', use: { ...devices['Pixel 5'] } },
  { name: 'mobile-safari', use: { ...devices['iPhone 12'] } },
]
```

### Key Settings

- **Base URL**: `http://localhost:3000`
- **Timeout**: 60s (test), 10s (expect), 30s (navigation)
- **Auto-retries**: 2 (CI only)
- **Trace**: On first retry
- **Screenshot**: On failure
- **Video**: Retain on failure

## Test Categories

### 1. Upload Complete Flow (`upload-complete-flow.spec.ts`)

Tests the end-to-end upload and processing workflow.

**Scenarios**:
- Upload accelerometer, gyroscope, and audio files
- Verify data preview appears
- Start processing
- Verify processing status updates
- Verify output audio appears
- Play output audio

### 2. Upload Validation (`upload-validation.spec.ts`)

Tests file upload validation rules.

**Scenarios**:
- Reject files exceeding size limit
- Reject unsupported file types
- Accept valid sensor data files
- Accept valid audio formats
- Display appropriate error messages

### 3. API Integration (`api-integration.spec.ts`)

Tests integration with different backend APIs.

**Scenarios**:
- Mock API mode works correctly
- INFOCOM API mode connects
- HTTP API mode connects
- WebSocket progress updates
- API error handling

### 4. Navigation (`navigation.spec.ts`)

Tests navigation between pages.

**Scenarios**:
- Navigate to home page
- Navigate to upload page
- Navigate to help page
- Navigate to settings page
- Browser back/forward buttons

### 5. File Drag & Drop (`file-drag-drop.spec.ts`)

Tests drag and drop file upload.

**Scenarios**:
- Drag single file to drop zone
- Drag multiple files
- Drag invalid file type
- Drop zone visual feedback
- Cancel drag operation

### 6. Settings (`settings.spec.ts`)

Tests settings page functionality.

**Scenarios**:
- Change API backend mode
- Toggle dark mode
- Adjust audio quality setting
- Save and restore settings

### 7. Audio Player (`audio-player.spec.ts`)

Tests audio player functionality.

**Scenarios**:
- Play/pause audio
- Seek within audio
- Adjust volume
- Mute/unmute
- Playback rate control
- Waveform visualization

### 8. Data Visualization (`data-visualization.spec.ts`)

Tests data preview and chart components.

**Scenarios**:
- Data preview table renders
- Chart displays all three axes
- Chart tooltip on hover
- Chart auto-scales
- Large dataset handling

### 9. Responsive (`responsive.spec.ts`)

Tests responsive design across viewports.

**Scenarios**:
- Mobile layout (< 640px)
- Tablet layout (640px - 1024px)
- Desktop layout (> 1024px)
- Touch interactions on mobile
- Keyboard navigation on desktop

### 10. Accessibility (`accessibility.spec.ts`)

Tests WCAG compliance.

**Scenarios**:
- All images have alt text
- Keyboard navigation works
- ARIA labels are present
- Color contrast meets standards
- Screen reader announcements

### 11. Performance (`performance.spec.ts`)

Tests application performance metrics.

**Scenarios**:
- Initial page load < 3s
- Time to interactive < 5s
- File upload progress updates smoothly
- Chart rendering performance
- Memory leak detection

### 12. Edge Cases (`edge-cases.spec.ts`)

Tests error handling and edge cases.

**Scenarios**:
- Network timeout during upload
- API returns 500 error
- Invalid JSON response
- File upload interruption
- Concurrent uploads

## Test Utilities

### `test-utils.ts`

Common helper functions for tests.

```typescript
// Upload a file programmatically
async function uploadFile(
  page: Page,
  fileType: 'accelerometer' | 'gyroscope' | 'audio',
  filePath: string
): Promise<void>

// Wait for processing to complete
async function waitForProcessing(
  page: Page,
  timeout?: number
): Promise<void>

// Mock API responses
function mockApiResponse(
  endpoint: string,
  response: object
): void

// Get test file path
function getTestFile(filename: string): string
```

### `api-mock.ts`

Utilities for mocking backend API responses.

```typescript
// Mock INFOCOM health check
function mockHealthCheck(status: 'ok' | 'error'): void

// Mock file upload
function mockFileUpload(fileId: string): void

// Mock audio enhancement
function mockAudioEnhancement(taskId: string): void

// Mock task status updates
function mockTaskProgress(
  taskId: string,
  steps: ProcessStep[]
): void
```

## Running Tests

### All Tests

```bash
pnpm test:e2e
```

### Specific Browser

```bash
pnpm test:e2e:chromium   # Chrome only
pnpm test:e2e:firefox     # Firefox only
pnpm test:e2e:webkit      # Safari only
```

### Debug Mode

```bash
pnpm test:e2e:debug      # Open Playwright Inspector
```

### UI Mode

```bash
pnpm test:e2e:ui         # Run with UI interface
```

### Headed Mode

```bash
pnpm test:e2e:headed     # Show browser window
```

### View Report

```bash
pnpm test:e2e:report     # Open HTML report
```

## Test Fixtures

Test files are located in `e2e/fixtures/`:
- `test-accelerometer.txt` - Sample accelerometer data
- `test-gyroscope.txt` - Sample gyroscope data
- `test-audio.wav` - Sample audio file
- `large-data.txt` - Large file for performance tests
- `invalid-format.xyz` - Invalid file for validation tests

## Continuous Integration

Tests run automatically on:
- Pull request creation
- Push to main branch
- Manual workflow dispatch

**CI Configuration** (`.github/workflows/e2e.yml`):
- Runs on Ubuntu, Windows, macOS
- Tests all browsers (Chromium, Firefox, WebKit)
- Uploads test results and artifacts
- Fails if any test fails

## Coverage

**Current Coverage**: 12 test files covering all major features

| Feature | Test Files | Coverage |
|---------|-----------|----------|
| Upload workflow | 2 | Complete |
| Navigation | 1 | Complete |
| Audio player | 1 | Complete |
| Data visualization | 1 | Complete |
| API integration | 1 | Partial |
| Settings | 1 | Partial |
| Accessibility | 1 | Partial |
| Performance | 1 | Basic |
| Edge cases | 1 | Growing |

## Known Gaps

1. **Visual regression tests** - No screenshot comparison
2. **Mobile gestures** - Limited touch gesture testing
3. **Network conditions** - No 3G/4G simulation
4. **Multi-tab** - No tests for multiple tabs
5. **Concurrent users** - No multi-user scenarios

## Best Practices

### Writing New Tests

1. **Use Page Object Model**: Create reusable page objects
2. **Wait for elements**: Use `await expect(page.locator()).toBeVisible()`
3. **Clean up state**: Reset application state between tests
4. **Use data-testid**: Add test IDs for reliable selectors
5. **Avoid flakiness**: Don't rely on arbitrary timeouts

### Example Test

```typescript
test('upload accelerometer file', async ({ page }) => {
  await page.goto('/upload');

  const fileInput = page.locator('input[type="file"]').first();
  await fileInput.setInputFiles('e2e/fixtures/test-accelerometer.txt');

  await expect(page.locator('[data-testid="file-name"]'))
    .toHaveText('test-accelerometer.txt');

  await expect(page.locator('[data-testid="upload-progress"]'))
    .toHaveAttribute('value', '100');
});
```

### Adding Test IDs to Components

```tsx
<button data-testid="upload-button">
  Upload File
</button>

<div data-testid="processing-status">
  Processing...
</div>
```

## Troubleshooting

### Tests Fail Locally But Pass in CI

- Check for hardcoded localhost URLs
- Verify test fixtures are committed
- Ensure dev server starts before tests

### Flaky Tests

- Increase timeout: `test.setTimeout(60000)`
- Use explicit waits instead of `waitForTimeout`
- Check for race conditions in async operations

### Browser Not Found

```bash
# Install missing browsers
npx playwright install
```

### Dev Server Won't Start

```bash
# Manually start dev server
pnpm dev

# Run tests without starting server
TEST_URL=http://localhost:3000 pnpm test:e2e
```

## Resources

- [Playwright Documentation](https://playwright.dev/)
- [Playwright Best Practices](https://playwright.dev/docs/best-practices)
- [Playwright API Reference](https://playwright.dev/docs/api/class-playwright)
- [Testing Library](https://testing-library.com/)
