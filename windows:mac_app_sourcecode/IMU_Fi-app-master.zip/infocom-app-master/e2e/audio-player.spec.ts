import { test, expect } from '@playwright/test';
import {
  setupHappyPathMocks,
  mockTaskStatus,
  mockDownload,
} from './helpers/api-mock';
import { waitForPageLoad, navigateTo } from './helpers/test-utils';

test.describe('E2E-006: Audio Player Functionality', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
    await mockTaskStatus(page, {
      progressSteps: [100],
      finalStatus: 'completed',
      outputUrl: '/outputs/result.wav',
    });
    await mockDownload(page);
  });

  test.describe('Playback Controls', () => {
    test('6.1 should play and pause audio', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Audio player appears after processing completes
      // For this test, we'll look for any audio player component
      const audioPlayer = page.locator('audio, [data-testid="audio-player"], [class*="audio-player"]').first();
      const playButton = page.getByRole('button', { name: /播放|Play|▶/i }).first();

      if (await playButton.isVisible().catch(() => false)) {
        // Click play
        await playButton.click();
        await page.waitForTimeout(500);

        // Look for pause button (play button may have changed)
        const pauseButton = page.getByRole('button', { name: /暂停|Pause|⏸/i }).first();

        if (await pauseButton.isVisible().catch(() => false)) {
          // Click pause
          await pauseButton.click();
          await page.waitForTimeout(500);
        }
      }
    });

    test('6.2 should seek via progress bar', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find progress bar / seek slider
      const progressBar = page.locator('[type="range"], [role="slider"], .progress-bar, .seek-bar').first();

      if (await progressBar.isVisible().catch(() => false)) {
        // Get the bounding box
        const box = await progressBar.boundingBox();

        if (box) {
          // Click in the middle of the progress bar
          await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
          await page.waitForTimeout(300);
        }
      }
    });

    test('6.3 should adjust volume', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find volume slider
      const volumeSlider = page.locator('[aria-label*="volume"], [aria-label*="音量"], input[type="range"]').first();
      const volumeButton = page.getByRole('button', { name: /音量|Volume|🔊/i }).first();

      if (await volumeSlider.isVisible().catch(() => false)) {
        // Adjust volume
        await volumeSlider.fill('50');
      } else if (await volumeButton.isVisible().catch(() => false)) {
        // Click volume button to show slider
        await volumeButton.click();
        await page.waitForTimeout(300);
      }
    });

    test('6.4 should toggle mute', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find mute button
      const muteButton = page.getByRole('button', { name: /静音|Mute|🔇|🔊/i }).first();

      if (await muteButton.isVisible().catch(() => false)) {
        // Click to mute
        await muteButton.click();
        await page.waitForTimeout(300);

        // Click to unmute
        await muteButton.click();
        await page.waitForTimeout(300);
      }
    });

    test('6.5 should change playback speed', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find speed selector
      const speedSelector = page.locator('select, [role="combobox"]').filter({ hasText: /速度|Speed|1x|2x/i }).first();
      const speedButton = page.getByRole('button', { name: /速度|Speed|1x/i }).first();

      if (await speedSelector.isVisible().catch(() => false)) {
        await speedSelector.selectOption('2').catch(async () => {
          await speedSelector.click();
          await page.getByRole('option', { name: /2x/i }).click();
        });
      } else if (await speedButton.isVisible().catch(() => false)) {
        await speedButton.click();
        await page.waitForTimeout(300);
      }
    });

    test('6.6 should handle playback end', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // This test verifies UI state after audio playback ends
      // In real implementation, may need to wait for audio to finish
      // or simulate the 'ended' event
    });

    test('6.7 should download audio file', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find download button
      const downloadButton = page.getByRole('button', { name: /下载|Download/i }).first()
        .or(page.getByRole('link', { name: /下载|Download/i }).first());

      if (await downloadButton.isVisible().catch(() => false)) {
        // Start waiting for download before clicking
        const downloadPromise = page.waitForEvent('download', { timeout: 5000 }).catch(() => null);

        await downloadButton.click();

        const download = await downloadPromise;
        // Download may be triggered
      }
    });
  });

  test.describe('Audio Player Display', () => {
    test('should display current time', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const timeDisplay = page.getByText(/^\d+:\d{2}$/).first();

      if (await timeDisplay.isVisible().catch(() => false)) {
        await expect(timeDisplay).toHaveText(/\d+:\d{2}/);
      }
    });

    test('should display total duration', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Duration is typically displayed alongside current time
    });

    test('should show waveform visualization', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Look for waveform or visualizer element
      const waveform = page.locator('[class*="waveform"], [class*="visualizer"], canvas').first();

      // Waveform may be visible after audio loads
    });
  });

  test.describe('Audio Player Keyboard Controls', () => {
    test('should support spacebar for play/pause', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Focus the audio player area
      const playerArea = page.locator('[data-testid="audio-player"], [class*="audio-player"]').first();

      if (await playerArea.isVisible().catch(() => false)) {
        await playerArea.focus();
        await page.keyboard.press('Space');
        await page.waitForTimeout(500);
      }
    });

    test('should support arrow keys for seeking', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const playerArea = page.locator('[data-testid="audio-player"], [class*="audio-player"]').first();

      if (await playerArea.isVisible().catch(() => false)) {
        await playerArea.focus();
        await page.keyboard.press('ArrowRight');
        await page.waitForTimeout(300);
        await page.keyboard.press('ArrowLeft');
        await page.waitForTimeout(300);
      }
    });
  });
});

test.describe('E2E-006: Audio Player Error States', () => {
  test('should handle audio load error', async ({ page }) => {
    await setupHappyPathMocks(page);

    // Mock a failed audio download
    await page.route('**/outputs/**', (route) => {
      route.fulfill({ status: 404 });
    });

    await navigateTo(page, '/upload');
    await waitForPageLoad(page);

    // Should show error state or fallback UI
  });

  test('should handle unsupported audio format', async ({ page }) => {
    await setupHappyPathMocks(page);

    await navigateTo(page, '/upload');
    await waitForPageLoad(page);

    // Player should handle format errors gracefully
  });
});
