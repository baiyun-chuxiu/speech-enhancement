import { test, expect } from '@playwright/test';
import { setupHappyPathMocks } from './helpers/api-mock';
import { waitForPageLoad, navigateTo, VIEWPORTS } from './helpers/test-utils';

test.describe('E2E-008: Responsive Layout', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test.describe('Desktop Layout (1920x1080)', () => {
    test('8.1 should display two-column layout on desktop', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.desktop);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const controlRegion = page.getByTestId('upload-control-region');

      // Verify all upload areas are visible
      await expect(controlRegion.getByText('加速度计数据')).toBeVisible();
      await expect(controlRegion.getByText('陀螺仪数据')).toBeVisible();
      await expect(controlRegion.getByText('音频文件')).toBeVisible();

      // Desktop may have side-by-side layout
      const mainContent = page.locator('main, [class*="main"], [class*="content"]').first();
      const box = await mainContent.boundingBox();

      if (box) {
        // Desktop should use wider layout
        expect(box.width).toBeGreaterThan(1000);
      }
    });

    test('should show all navigation items on desktop', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.desktop);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Navigation should be fully visible
      const nav = page.locator('nav, header, [class*="nav"]').first();
      await expect(nav).toBeVisible();

      // Menu items should be visible (not hidden in hamburger)
      const helpLink = page.getByRole('link', { name: /帮助|Help/i });
      const settingsLink = page.getByRole('link', { name: /设置|Settings/i });

      // At least some nav items should be directly visible
    });
  });

  test.describe('Tablet Layout (768x1024)', () => {
    test('8.2 should adapt layout for tablet', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.tablet);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Page should still be functional
      await expect(page.getByText('加速度计数据')).toBeVisible();

      // Layout may switch to single column
    });

    test('should show responsive navigation on tablet', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.tablet);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // May show hamburger menu or condensed nav
      const menuButton = page.locator('[aria-label*="menu"], button:has(svg)').first();
      // Menu button may be visible on tablet
    });
  });

  test.describe('Mobile Layout (375x667)', () => {
    test('8.3 should display single column on mobile', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.mobile);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Content should be stacked vertically
      await expect(page.getByText('加速度计数据')).toBeVisible();

      // Upload areas should stack
      const uploadAreas = page.locator('[class*="upload"], label').filter({
        hasText: /点击或拖拽|加速度计|陀螺仪|音频/i,
      });

      const count = await uploadAreas.count();
      // Should still have all upload areas
    });

    test('should show mobile navigation menu', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.mobile);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Look for hamburger menu
      const menuButton = page.locator('[aria-label*="menu"], [aria-label*="菜单"]').first()
        .or(page.locator('button').filter({ has: page.locator('svg') }).first());

      if (await menuButton.isVisible().catch(() => false)) {
        await menuButton.click();
        await page.waitForTimeout(300);

        // Mobile menu should open
      }
    });

    test('should have touch-friendly buttons', async ({ page }) => {
      await page.setViewportSize(VIEWPORTS.mobile);
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Buttons should be large enough for touch (min 44x44px)
      const buttons = page.getByRole('button');
      const count = await buttons.count();

      for (let i = 0; i < Math.min(count, 5); i++) {
        const button = buttons.nth(i);
        if (await button.isVisible().catch(() => false)) {
          const box = await button.boundingBox();
          if (box) {
            // Touch target should be at least 40px
            expect(box.height).toBeGreaterThanOrEqual(32);
          }
        }
      }
    });
  });

  test.describe('Wide Screen Layout (2560x1440)', () => {
    test('8.4 should not exceed max width on wide screens', async ({ page }) => {
      await page.setViewportSize({ width: 2560, height: 1440 });
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Content should be centered with max-width
      const mainContent = page.locator('main, [class*="container"], [class*="content"]').first();
      const box = await mainContent.boundingBox();

      if (box) {
        // Content should not span full width on very wide screens
        // Typically max-width is around 1200-1400px
      }
    });
  });

  test.describe('Orientation Changes', () => {
    test('8.5 should handle portrait to landscape', async ({ page }) => {
      // Start in portrait (mobile)
      await page.setViewportSize({ width: 375, height: 667 });
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Rotate to landscape
      await page.setViewportSize({ width: 667, height: 375 });
      await page.waitForTimeout(300);

      // Page should adapt
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });

    test('should handle landscape to portrait', async ({ page }) => {
      // Start in landscape
      await page.setViewportSize({ width: 1024, height: 768 });
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Rotate to portrait
      await page.setViewportSize({ width: 768, height: 1024 });
      await page.waitForTimeout(300);

      // Page should adapt
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });
  });
});

test.describe('E2E-008: Responsive Components', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test('buttons should be full width on mobile', async ({ page }) => {
    await page.setViewportSize(VIEWPORTS.mobile);
    await navigateTo(page, '/upload');
    await waitForPageLoad(page);

    // Primary action buttons may be full width on mobile
    const processButton = page.getByRole('button', { name: /开始处理|处理|Start/i });

    if (await processButton.isVisible().catch(() => false)) {
      const box = await processButton.boundingBox();
      const viewport = page.viewportSize();

      if (box && viewport) {
        // Button may be close to full width on mobile
      }
    }
  });

  test('cards should stack on mobile', async ({ page }) => {
    await page.setViewportSize(VIEWPORTS.mobile);
    await navigateTo(page, '/help');
    await waitForPageLoad(page);

    // Cards should stack vertically
    const cards = page.locator('[class*="card"]');
    const count = await cards.count();

    if (count > 1) {
      const card1Box = await cards.nth(0).boundingBox();
      const card2Box = await cards.nth(1).boundingBox();

      if (card1Box && card2Box) {
        // Cards should be stacked (card2 below card1)
        expect(card2Box.y).toBeGreaterThan(card1Box.y);
      }
    }
  });

  test('form inputs should be full width on mobile', async ({ page }) => {
    await page.setViewportSize(VIEWPORTS.mobile);
    await navigateTo(page, '/settings');
    await waitForPageLoad(page);

    const inputs = page.locator('input:not([type="checkbox"]):not([type="radio"])');
    const count = await inputs.count();

    if (count > 0) {
      const input = inputs.first();
      if (await input.isVisible().catch(() => false)) {
        const box = await input.boundingBox();
        const viewport = page.viewportSize();

        // Inputs should be reasonably wide on mobile
      }
    }
  });
});
