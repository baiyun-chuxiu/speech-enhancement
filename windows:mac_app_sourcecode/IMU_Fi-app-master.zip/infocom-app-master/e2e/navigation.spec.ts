import { test, expect } from '@playwright/test';
import { setupHappyPathMocks } from './helpers/api-mock';
import { waitForPageLoad, navigateTo } from './helpers/test-utils';

test.describe('E2E-003: Navigation and Page Routing', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test.describe('Main Navigation', () => {
    test('3.1 should navigate to help page', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find and click help link/button
      const helpLink = page.getByRole('link', { name: /帮助|Help/i });
      const helpButton = page.getByRole('button', { name: /帮助|Help/i });

      if (await helpLink.isVisible().catch(() => false)) {
        await helpLink.click();
      } else if (await helpButton.isVisible().catch(() => false)) {
        await helpButton.click();
      } else {
        // Try navigation via URL directly
        await page.goto('/help');
      }

      await waitForPageLoad(page);

      // Verify we're on help page
      await expect(page).toHaveURL(/.*help.*/);
      await expect(page.getByText(/帮助|Help Center|帮助中心/i).first()).toBeVisible();
    });

    test('3.2 should switch tabs on help page', async ({ page }) => {
      await navigateTo(page, '/help');
      await waitForPageLoad(page);

      // Find tabs
      const tabs = page.getByRole('tab');
      const tabCount = await tabs.count();

      if (tabCount > 1) {
        // Click through each tab
        for (let i = 0; i < tabCount; i++) {
          const tab = tabs.nth(i);
          await tab.click();
          await page.waitForTimeout(300);

          // Verify tab is selected
          await expect(tab).toHaveAttribute('aria-selected', 'true').catch(() => {
            // Some implementations use different attributes
          });
        }
      }
    });

    test('3.3 should navigate back from help to upload', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      await page.goto('/help');
      await waitForPageLoad(page);

      // Find and click back button/link
      const backButton = page.getByRole('button', { name: /返回|Back|←/i });
      const backLink = page.getByRole('link', { name: /返回|Back|上传/i });

      if (await backButton.isVisible().catch(() => false)) {
        await backButton.click();
      } else if (await backLink.isVisible().catch(() => false)) {
        await backLink.click();
      } else {
        // Use browser back
        await page.goBack();
      }

      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*upload.*/);
    });

    test('3.4 should navigate to settings page', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find settings link/button
      const settingsLink = page.getByRole('link', { name: /设置|Settings/i });
      const settingsButton = page.getByRole('button', { name: /设置|Settings/i });
      const settingsIcon = page.locator('[aria-label*="settings"], [aria-label*="设置"]');

      if (await settingsLink.isVisible().catch(() => false)) {
        await settingsLink.click();
      } else if (await settingsButton.isVisible().catch(() => false)) {
        await settingsButton.click();
      } else if (await settingsIcon.isVisible().catch(() => false)) {
        await settingsIcon.click();
      } else {
        await page.goto('/settings');
      }

      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*settings.*/);
    });

    test('3.5 should navigate back from settings', async ({ page }) => {
      await navigateTo(page, '/settings');
      await waitForPageLoad(page);

      const backButton = page.getByRole('button', { name: /返回|Back|←/i });
      const backLink = page.getByRole('link', { name: /返回|Back/i });

      if (await backButton.isVisible().catch(() => false)) {
        await backButton.click();
      } else if (await backLink.isVisible().catch(() => false)) {
        await backLink.click();
      } else {
        await page.goBack();
      }

      await waitForPageLoad(page);
    });

    test('3.6 should handle direct URL access', async ({ page }) => {
      // Access pages directly via URL
      await page.goto('/help');
      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*help.*/);

      await page.goto('/settings');
      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*settings.*/);

      await page.goto('/upload');
      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*upload.*/);
    });
  });

  test.describe('URL Handling', () => {
    test('should redirect root to upload page', async ({ page }) => {
      await page.goto('/');
      await waitForPageLoad(page);

      // Root may redirect to upload or show home page
      // Check that page loads without error
      const heading = page.getByRole('heading').first();
      await expect(heading).toBeVisible();
    });

    test('should handle 404 for invalid routes', async ({ page }) => {
      await page.goto('/invalid-route-12345');
      await waitForPageLoad(page);

      // Should show 404 page or redirect
      // Next.js typically shows a 404 page
    });

    test('should preserve query parameters during navigation', async ({ page }) => {
      await page.goto('/upload?source=test');
      await waitForPageLoad(page);

      // Query params should be accessible
      expect(page.url()).toContain('source=test');
    });
  });

  test.describe('Browser History', () => {
    test('should support browser back/forward navigation', async ({ page }) => {
      await navigateTo(page, '/upload');
      await navigateTo(page, '/help');
      await navigateTo(page, '/settings');

      // Go back twice
      await page.goBack();
      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*help.*/);

      await page.goBack();
      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*upload.*/);

      // Go forward
      await page.goForward();
      await waitForPageLoad(page);
      await expect(page).toHaveURL(/.*help.*/);
    });

    test('should handle page refresh', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Refresh the page
      await page.reload();
      await waitForPageLoad(page);

      // Page should still be functional
      await expect(page).toHaveURL(/.*upload.*/);
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });
  });

  test.describe('External Links', () => {
    test('should have working external links on help page', async ({ page }) => {
      await navigateTo(page, '/help');
      await waitForPageLoad(page);

      // Find external links (API docs, etc.)
      const externalLinks = page.locator('a[target="_blank"], a[href^="http"]');
      const count = await externalLinks.count();

      // Verify external links have proper attributes
      for (let i = 0; i < Math.min(count, 5); i++) {
        const link = externalLinks.nth(i);
        const href = await link.getAttribute('href');

        if (href && href.startsWith('http')) {
          // External links should open in new tab
          await expect(link).toHaveAttribute('target', '_blank').catch(() => {
            // Some links may not have target="_blank"
          });
        }
      }
    });
  });
});

test.describe('E2E-003: Mobile Navigation', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
    await page.setViewportSize({ width: 375, height: 667 });
  });

  test('should display mobile menu on small screens', async ({ page }) => {
    await navigateTo(page, '/upload');
    await waitForPageLoad(page);

    // Look for hamburger menu or mobile nav
    const menuButton = page.locator('[aria-label*="menu"], [aria-label*="菜单"], button:has(svg)').first();

    if (await menuButton.isVisible().catch(() => false)) {
      await menuButton.click();
      await page.waitForTimeout(300);

      // Mobile menu should open
    }
  });

  test('should navigate using mobile menu', async ({ page }) => {
    await navigateTo(page, '/upload');
    await waitForPageLoad(page);

    // Mobile navigation should still work
    await page.goto('/help');
    await waitForPageLoad(page);
    await expect(page).toHaveURL(/.*help.*/);
  });
});
