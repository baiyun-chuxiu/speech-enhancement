import { test, expect } from '@playwright/test';
import * as path from 'path';
import { setupHappyPathMocks, mockHealthCheck } from './helpers/api-mock';
import {
  createMockWavFile,
  waitForPageLoad,
  navigateTo,
  setLocalStorageItem,
  clearLocalStorage,
  writeFixtureFile,
} from './helpers/test-utils';

const FIXTURES_PATH = path.join(__dirname, 'fixtures');

test.describe('E2E-013: Edge Cases and Error Handling', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test.describe('File Edge Cases', () => {
    test('13.1 should handle very small file', async ({ page }, testInfo) => {
      const tinyFilePath = writeFixtureFile(testInfo.outputPath('tiny.txt'), 'x');

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(tinyFilePath);

      await page.waitForTimeout(500);

      // Should handle tiny file
    });

    test('13.2 should handle file at size limit boundary', async ({ page }, testInfo) => {
      const content = 'x'.repeat(9.9 * 1024 * 1024);
      const borderFilePath = writeFixtureFile(testInfo.outputPath('border.txt'), content);

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(borderFilePath);

      await page.waitForTimeout(1000);

      // Should accept file just under limit
    });

    test('13.6 should handle browser refresh during operation', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Start an upload
      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(200);

      // Refresh the page
      await page.reload();
      await waitForPageLoad(page);

      // Page should recover gracefully
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });

    test('13.7 should handle browser back/forward navigation', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Upload a file
      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));
      await page.waitForTimeout(500);

      // Navigate away
      await page.goto('/help');
      await waitForPageLoad(page);

      // Go back
      await page.goBack();
      await waitForPageLoad(page);

      // Page should work (file state may or may not be preserved)
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });

    test('13.8 should prevent rapid repeated clicks', async ({ page }, testInfo) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const inputs = page.locator('input[type="file"]');
      const audioFilePath = createMockWavFile(testInfo.outputPath('rapid-click-audio.wav'));

      await inputs.nth(0).setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));
      await inputs.nth(1).setInputFiles(path.join(FIXTURES_PATH, 'sample-gyro.txt'));
      await inputs.nth(2).setInputFiles(audioFilePath);
      await page.waitForTimeout(300);

      const processButton = page.getByRole('button', { name: /开始处理|处理|Start/i });

      await expect(processButton).toBeEnabled();
      await Promise.allSettled([
        processButton.click(),
        processButton.click(),
        processButton.click(),
      ]);
    });

    test('13.9 should handle special characters in filename', async ({ page }, testInfo) => {
      const specialFilePath = writeFixtureFile(
        testInfo.outputPath('test-file-[special]-文件.txt'),
        'timestamp,x,y,z\n0.000,0.012,-0.003,9.801'
      );

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(specialFilePath);

      await page.waitForTimeout(500);

      // Should handle the file
    });
  });

  test.describe('Network Edge Cases', () => {
    test('13.3 should handle network disconnect', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Go offline
      await page.context().setOffline(true);

      // Try to interact
      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(500);

      // Should show offline indicator or error

      // Go back online
      await page.context().setOffline(false);
    });

    test('13.4 should recover after network restore', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Go offline briefly
      await page.context().setOffline(true);
      await page.waitForTimeout(1000);

      // Go back online
      await page.context().setOffline(false);
      await page.waitForTimeout(1000);

      // Page should be functional
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });

    test('should handle API server down', async ({ page }) => {
      await mockHealthCheck(page, false);

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Should show connection error or fallback UI
    });
  });

  test.describe('Storage Edge Cases', () => {
    test('13.10 should handle localStorage quota exceeded', async ({ page }) => {
      await navigateTo(page, '/settings');
      await waitForPageLoad(page);

      await page.locator('#apiUrl').fill('http://quota-test:8000');

      await page.evaluate(() => {
        try {
          const largeData = 'x'.repeat(5 * 1024 * 1024); // 5MB
          for (let i = 0; i < 10; i++) {
            localStorage.setItem(`test-${i}`, largeData);
          }
        } catch {
          // Expected to fail
        }
      });

      const saveButton = page.getByRole('button', { name: /保存|Save/i });
      if (
        (await saveButton.isVisible().catch(() => false)) &&
        (await saveButton.isEnabled().catch(() => false))
      ) {
        await saveButton.click();
        await page.waitForTimeout(500);
      }

      // Clean up
      await clearLocalStorage(page);
    });

    test('should handle corrupted localStorage data', async ({ page }) => {
      await setLocalStorageItem(page, 'infocom-settings', 'invalid-json{{{');

      await navigateTo(page, '/settings');
      await waitForPageLoad(page);

      // Page should handle corrupted data gracefully
      await expect(page.locator('body')).toBeVisible();

      // Clean up
      await clearLocalStorage(page);
    });
  });

  test.describe('State Edge Cases', () => {
    test('should handle empty state gracefully', async ({ page }) => {
      // Clear all stored data
      await page.goto('/');
      await clearLocalStorage(page);

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Page should load with default/empty state
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });

    test('should handle rapid state changes', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Rapidly upload and remove files
      const input = page.locator('input[type="file"]').first();

      for (let i = 0; i < 3; i++) {
        await input.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));
        await page.waitForTimeout(100);

        const removeButton = page.getByRole('button', { name: /删除|Remove/i }).first();
        if (await removeButton.isVisible().catch(() => false)) {
          await removeButton.click();
          await page.waitForTimeout(100);
        }
      }

      // Page should remain stable
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });
  });

  test.describe('Input Edge Cases', () => {
    test('should handle paste event', async ({ page }) => {
      await navigateTo(page, '/settings');
      await waitForPageLoad(page);

      // Find an input
      const input = page.locator('input[type="text"]').first();

      if (await input.isVisible().catch(() => false)) {
        await input.focus();

        // Simulate paste
        await page.keyboard.insertText('pasted-text');

        await expect(input).toHaveValue(/pasted-text/);
      }
    });

    test('should handle very long input', async ({ page }) => {
      await navigateTo(page, '/settings');
      await waitForPageLoad(page);

      const input = page.locator('input[type="text"]').first();

      if (await input.isVisible().catch(() => false)) {
        // Enter very long text
        const longText = 'http://' + 'a'.repeat(500) + '.com:8000';
        await input.fill(longText);

        // Should handle or truncate
      }
    });
  });

  test.describe('Browser Compatibility Edge Cases', () => {
    test('should work with JavaScript errors in console', async ({ page }) => {
      // Track console errors
      const errors: string[] = [];
      page.on('pageerror', (error) => {
        errors.push(error.message);
      });

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Interact with page
      const input = page.locator('input[type="file"]').first();
      await input.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Log any errors found (for debugging)
      if (errors.length > 0) {
        console.log('Console errors:', errors);
      }

      // Page should still be functional
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });
  });
});
