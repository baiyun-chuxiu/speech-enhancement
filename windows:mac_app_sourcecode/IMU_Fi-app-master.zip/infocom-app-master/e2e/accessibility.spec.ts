import { test, expect } from '@playwright/test';
import { setupHappyPathMocks } from './helpers/api-mock';
import { waitForPageLoad, navigateTo } from './helpers/test-utils';

test.describe('E2E-011: Accessibility (A11y)', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test.describe('Keyboard Navigation', () => {
    test('11.1 should navigate all interactive elements via Tab', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const focusableElements: string[] = [];

      // Tab through the page and collect focused elements
      for (let i = 0; i < 20; i++) {
        await page.keyboard.press('Tab');
        await page.waitForTimeout(100);

        const focused = await page.evaluate(() => {
          const el = document.activeElement;
          return el ? el.tagName + (el.id ? `#${el.id}` : '') : null;
        });

        if (focused) {
          focusableElements.push(focused);
        }
      }

      // Should have multiple focusable elements
      expect(focusableElements.length).toBeGreaterThan(0);
    });

    test('should support Shift+Tab for reverse navigation', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Tab forward a few times
      for (let i = 0; i < 5; i++) {
        await page.keyboard.press('Tab');
      }

      // Tab backward
      await page.keyboard.press('Shift+Tab');
      await page.waitForTimeout(100);

      // Should move focus backward
    });

    test('should support Enter/Space to activate buttons', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Find a button and focus it
      const button = page.getByRole('button').first();

      if (await button.isVisible().catch(() => false)) {
        await button.focus();

        // Press Enter
        await page.keyboard.press('Enter');
        await page.waitForTimeout(200);

        // Or press Space
        await button.focus();
        await page.keyboard.press('Space');
      }
    });

    test('should trap focus in modal dialogs', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Look for a button that opens a modal
      const dialogTrigger = page.getByRole('button', { name: /打开|Open|详情|Details/i }).first();

      if (await dialogTrigger.isVisible().catch(() => false)) {
        await dialogTrigger.click();
        await page.waitForTimeout(300);

        // If dialog opened, focus should be trapped
        const dialog = page.getByRole('dialog');
        if (await dialog.isVisible().catch(() => false)) {
          // Tab should cycle within dialog
          for (let i = 0; i < 10; i++) {
            await page.keyboard.press('Tab');
            const focused = await page.evaluate(() => {
              const el = document.activeElement;
              const dialog = document.querySelector('[role="dialog"]');
              return dialog?.contains(el);
            });
            expect(focused).toBe(true);
          }
        }
      }
    });
  });

  test.describe('ARIA Attributes', () => {
    test('11.2 should have proper ARIA labels', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Check buttons have accessible names
      const buttons = page.getByRole('button');
      const count = await buttons.count();

      for (let i = 0; i < Math.min(count, 10); i++) {
        const button = buttons.nth(i);
        if (await button.isVisible().catch(() => false)) {
          const name = await button.getAttribute('aria-label')
            || await button.textContent();

          // Button should have some accessible name
          expect(name?.trim().length).toBeGreaterThan(0);
        }
      }
    });

    test('should have proper form labels', async ({ page }) => {
      await navigateTo(page, '/settings');
      await waitForPageLoad(page);

      // All inputs should have associated labels
      const inputs = page.locator('input:not([type="hidden"])');
      const count = await inputs.count();

      for (let i = 0; i < Math.min(count, 10); i++) {
        const input = inputs.nth(i);
        if (await input.isVisible().catch(() => false)) {
          // Check for label, aria-label, or aria-labelledby
          const hasLabel = await input.evaluate((el) => {
            const id = el.id;
            const ariaLabel = el.getAttribute('aria-label');
            const ariaLabelledBy = el.getAttribute('aria-labelledby');
            const label = id ? document.querySelector(`label[for="${id}"]`) : null;

            return !!(label || ariaLabel || ariaLabelledBy);
          });

          // Input should have some form of label
        }
      }
    });

    test('should have proper heading hierarchy', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Get all headings
      const headings = await page.evaluate(() => {
        const h = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
        return Array.from(h).map((el) => ({
          level: parseInt(el.tagName[1]),
          text: el.textContent?.trim(),
        }));
      });

      // Should have at least one heading
      expect(headings.length).toBeGreaterThan(0);

      // Check heading hierarchy (no skipping levels)
      let prevLevel = 0;
      for (const heading of headings) {
        // Heading level should not skip more than 1 level
        expect(heading.level - prevLevel).toBeLessThanOrEqual(2);
        prevLevel = heading.level;
      }
    });

    test('should have proper roles for interactive elements', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Check that custom components have proper roles
      const tabs = page.locator('[role="tab"]');
      const tabpanels = page.locator('[role="tabpanel"]');
      const buttons = page.getByRole('button');

      // Interactive elements should be findable by role
    });
  });

  test.describe('Color Contrast', () => {
    test('11.3 should have sufficient text contrast', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // This would typically use axe-core or similar tool
      // For now, we'll do a basic check
      const bodyStyles = await page.evaluate(() => {
        const body = document.body;
        const style = window.getComputedStyle(body);
        return {
          color: style.color,
          backgroundColor: style.backgroundColor,
        };
      });

      // Basic check that colors are defined
      expect(bodyStyles.color).toBeDefined();
      expect(bodyStyles.backgroundColor).toBeDefined();
    });
  });

  test.describe('Focus Indicators', () => {
    test('11.4 should show visible focus indicators', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Tab to first focusable element
      await page.keyboard.press('Tab');
      await page.waitForTimeout(100);

      // Check that focused element has visible focus style
      const focusVisible = await page.evaluate(() => {
        const el = document.activeElement;
        if (!el) return false;

        const style = window.getComputedStyle(el);
        const outline = style.outline;
        const boxShadow = style.boxShadow;

        // Should have some focus indicator
        return outline !== 'none' || boxShadow !== 'none';
      });

      // Focus should be visible (outline or box-shadow)
    });
  });

  test.describe('Screen Reader Support', () => {
    test('11.5 should have alt text for images', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const images = page.locator('img');
      const count = await images.count();

      for (let i = 0; i < count; i++) {
        const img = images.nth(i);
        const alt = await img.getAttribute('alt');
        const ariaLabel = await img.getAttribute('aria-label');
        const role = await img.getAttribute('role');

        // Images should have alt text or be marked decorative
        const isAccessible = alt !== null || ariaLabel !== null || role === 'presentation';
        expect(isAccessible).toBe(true);
      }
    });

    test('should announce status changes', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Check for live regions
      const liveRegions = page.locator('[aria-live], [role="alert"], [role="status"]');
      // Live regions should exist for status updates
    });
  });

  test.describe('Reduced Motion', () => {
    test('should respect prefers-reduced-motion', async ({ page }) => {
      // Emulate reduced motion preference
      await page.emulateMedia({ reducedMotion: 'reduce' });

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Page should still be functional
      await expect(page.getByText('加速度计数据')).toBeVisible();

      // Animations should be reduced or disabled
    });
  });
});

test.describe('E2E-011: Page-specific A11y', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test('help page tabs should be keyboard accessible', async ({ page }) => {
    await navigateTo(page, '/help');
    await waitForPageLoad(page);

    const tabs = page.getByRole('tab');
    const count = await tabs.count();

    if (count > 1) {
      // Focus first tab
      await tabs.first().focus();

      // Arrow keys should navigate tabs
      await page.keyboard.press('ArrowRight');
      await page.waitForTimeout(100);

      // Second tab should be focused
    }
  });

  test('settings form should be accessible', async ({ page }) => {
    await navigateTo(page, '/settings');
    await waitForPageLoad(page);

    // Form should be navigable via keyboard
    await page.keyboard.press('Tab');

    // First input should be focused
    const focused = await page.evaluate(() => {
      return document.activeElement?.tagName;
    });

    // Should focus an input or button
  });
});
