import { test, expect } from '@playwright/test';
import * as path from 'path';
import { setupHappyPathMocks, mockTaskStatus } from './helpers/api-mock';
import { waitForPageLoad, navigateTo } from './helpers/test-utils';

const FIXTURES_PATH = path.join(__dirname, 'fixtures');

test.describe('E2E-007: Data Visualization', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test.describe('Sensor Data Charts', () => {
    test('7.1 should display accelerometer data chart after upload', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Upload accelerometer file
      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Look for chart component
      const chart = page.locator('canvas, svg, [class*="chart"], [class*="graph"], [data-testid="chart"]').first();

      // Chart may appear after data is parsed
      if (await chart.isVisible({ timeout: 5000 }).catch(() => false)) {
        await expect(chart).toBeVisible();
      }
    });

    test('7.2 should display gyroscope data chart after upload', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Upload gyroscope file
      const gyroInput = page.locator('input[type="file"]').nth(1);
      await gyroInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-gyro.txt'));

      await page.waitForTimeout(1000);

      // Look for chart component
      const chart = page.locator('canvas, svg, [class*="chart"]');
      // Chart may appear after data is parsed
    });

    test('7.3 should display data statistics', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Upload file
      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Look for statistics display
      const stats = page.locator('[class*="stats"], [class*="info"], [data-testid="file-stats"]');

      // May show line count, word count, etc.
    });
  });

  test.describe('Audio Visualization', () => {
    test('7.4 should display output audio waveform', async ({ page }) => {
      await mockTaskStatus(page, {
        progressSteps: [100],
        finalStatus: 'completed',
        outputUrl: '/outputs/result.wav',
      });

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Audio waveform appears after processing
      const waveform = page.locator('[class*="waveform"], [class*="wave"], canvas').first();
      // Waveform visibility depends on processing state
    });

    test('7.5 should display frequency spectrum', async ({ page }) => {
      await mockTaskStatus(page, {
        progressSteps: [100],
        finalStatus: 'completed',
      });

      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      // Spectrum analyzer may be visible
      const spectrum = page.locator('[class*="spectrum"], [class*="analyzer"], [class*="frequency"]');
      // Spectrum visibility depends on implementation
    });
  });

  test.describe('Data Preview', () => {
    test('should show raw data preview', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Look for data preview section
      const preview = page.locator('[class*="preview"], [class*="data"], pre, code');
      // Preview may show first few lines of data
    });

    test('should show parsed data table', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Look for table component
      const table = page.locator('table, [role="grid"], [class*="table"]');
      // Table may display parsed CSV data
    });
  });

  test.describe('Chart Interactions', () => {
    test('should show tooltip on chart hover', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Find chart
      const chart = page.locator('canvas, svg, [class*="chart"]').first();

      if (await chart.isVisible().catch(() => false)) {
        // Hover over chart
        await chart.hover();
        await page.waitForTimeout(300);

        // Tooltip may appear
      }
    });

    test('should support chart zoom/pan', async ({ page }) => {
      await navigateTo(page, '/upload');
      await waitForPageLoad(page);

      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));

      await page.waitForTimeout(1000);

      // Chart zoom controls may be available
      const zoomIn = page.getByRole('button', { name: /放大|Zoom In|\+/i });
      const zoomOut = page.getByRole('button', { name: /缩小|Zoom Out|-/i });

      if (await zoomIn.isVisible().catch(() => false)) {
        await zoomIn.click();
        await page.waitForTimeout(200);
      }
    });
  });
});
