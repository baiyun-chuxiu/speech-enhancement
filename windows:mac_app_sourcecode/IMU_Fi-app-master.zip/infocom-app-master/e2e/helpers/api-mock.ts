import { Page } from '@playwright/test';

/**
 * API Mock Utilities for E2E Testing
 */

const API_BASE = 'http://localhost:8000';

/**
 * Mock health check endpoint
 */
export async function mockHealthCheck(page: Page, healthy = true) {
  await page.route(`${API_BASE}/health`, (route) => {
    if (healthy) {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ status: 'healthy' }),
      });
    } else {
      route.abort('connectionrefused');
    }
  });
}

/**
 * Mock system info endpoint
 */
export async function mockSystemInfo(page: Page, info?: Partial<SystemInfo>) {
  const defaultInfo: SystemInfo = {
    version: '1.0.0',
    python_version: '3.11.0',
    cuda_available: true,
    mps_available: false,
    device: 'cuda',
    models_loaded: ['model_v1'],
    uptime: 3600,
  };

  await page.route(`${API_BASE}/api/v1/system/info`, (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ ...defaultInfo, ...info }),
    });
  });
}

interface SystemInfo {
  version: string;
  python_version: string;
  cuda_available: boolean;
  mps_available: boolean;
  device: string;
  models_loaded: string[];
  uptime: number;
}

/**
 * Mock file upload endpoint
 */
export async function mockFileUpload(
  page: Page,
  options?: {
    delay?: number;
    shouldFail?: boolean;
    errorMessage?: string;
  }
) {
  const { delay = 100, shouldFail = false, errorMessage = 'Upload failed' } = options || {};

  await page.route(`${API_BASE}/api/v1/files/upload`, async (route) => {
    if (delay > 0) {
      await new Promise((resolve) => setTimeout(resolve, delay));
    }

    if (shouldFail) {
      route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({ error: errorMessage }),
      });
    } else {
      const fileId = `file_${Date.now()}`;
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          id: fileId,
          filename: 'uploaded_file',
          path: `/uploads/${fileId}`,
          size: 1024,
        }),
      });
    }
  });
}

/**
 * Mock audio enhance endpoint
 */
export async function mockAudioEnhance(
  page: Page,
  options?: {
    delay?: number;
    shouldFail?: boolean;
    taskId?: string;
  }
) {
  const { delay = 100, shouldFail = false, taskId = `task_${Date.now()}` } = options || {};

  await page.route(`${API_BASE}/api/v1/audiophase/enhance`, async (route) => {
    if (delay > 0) {
      await new Promise((resolve) => setTimeout(resolve, delay));
    }

    if (shouldFail) {
      route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'Enhancement failed' }),
      });
    } else {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          task_id: taskId,
          status: 'processing',
        }),
      });
    }
  });
}

/**
 * Mock sensor process endpoint
 */
export async function mockSensorProcess(
  page: Page,
  options?: {
    delay?: number;
    shouldFail?: boolean;
    taskId?: string;
  }
) {
  const { delay = 100, shouldFail = false, taskId = `task_${Date.now()}` } = options || {};

  await page.route(`${API_BASE}/api/v1/sensor/process`, async (route) => {
    if (delay > 0) {
      await new Promise((resolve) => setTimeout(resolve, delay));
    }

    if (shouldFail) {
      route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'Processing failed' }),
      });
    } else {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          task_id: taskId,
          status: 'processing',
        }),
      });
    }
  });
}

/**
 * Mock task status endpoint with progress simulation
 */
export async function mockTaskStatus(
  page: Page,
  options?: {
    taskId?: string;
    progressSteps?: number[];
    finalStatus?: 'completed' | 'failed' | 'cancelled';
    outputUrl?: string;
  }
) {
  const {
    progressSteps = [20, 40, 60, 80, 100],
    finalStatus = 'completed',
    outputUrl = '/outputs/result.wav',
  } = options || {};

  let callCount = 0;

  await page.route(`${API_BASE}/api/v1/tasks/*`, (route) => {
    const progress = progressSteps[Math.min(callCount, progressSteps.length - 1)];
    const isComplete = callCount >= progressSteps.length - 1;
    callCount++;

    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: isComplete ? finalStatus : 'processing',
        progress,
        current_step: Math.min(callCount, 5),
        total_steps: 5,
        output_url: isComplete && finalStatus === 'completed' ? outputUrl : null,
        error: finalStatus === 'failed' && isComplete ? 'Task failed' : null,
      }),
    });
  });
}

/**
 * Mock task cancel endpoint
 */
export async function mockTaskCancel(page: Page, shouldSucceed = true) {
  await page.route(`${API_BASE}/api/v1/tasks/*/cancel`, (route) => {
    if (shouldSucceed) {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ status: 'cancelled' }),
      });
    } else {
      route.fulfill({
        status: 400,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'Cannot cancel task' }),
      });
    }
  });
}

/**
 * Mock download endpoint
 */
export async function mockDownload(page: Page) {
  await page.route(`${API_BASE}/outputs/*`, (route) => {
    // Return a minimal WAV file header for testing
    const wavHeader = Buffer.from([
      0x52, 0x49, 0x46, 0x46, // "RIFF"
      0x24, 0x00, 0x00, 0x00, // File size - 8
      0x57, 0x41, 0x56, 0x45, // "WAVE"
      0x66, 0x6d, 0x74, 0x20, // "fmt "
      0x10, 0x00, 0x00, 0x00, // Subchunk1Size (16)
      0x01, 0x00,             // AudioFormat (PCM)
      0x01, 0x00,             // NumChannels (1)
      0x44, 0xac, 0x00, 0x00, // SampleRate (44100)
      0x88, 0x58, 0x01, 0x00, // ByteRate
      0x02, 0x00,             // BlockAlign
      0x10, 0x00,             // BitsPerSample (16)
      0x64, 0x61, 0x74, 0x61, // "data"
      0x00, 0x00, 0x00, 0x00, // Subchunk2Size
    ]);

    route.fulfill({
      status: 200,
      contentType: 'audio/wav',
      body: wavHeader,
    });
  });
}

/**
 * Setup all API mocks for happy path testing
 */
export async function setupHappyPathMocks(page: Page) {
  await mockHealthCheck(page, true);
  await mockSystemInfo(page);
  await mockFileUpload(page);
  await mockAudioEnhance(page);
  await mockSensorProcess(page);
  await mockTaskStatus(page);
  await mockTaskCancel(page);
  await mockDownload(page);
}

/**
 * Setup API mocks for error testing
 */
export async function setupErrorMocks(
  page: Page,
  errorType: 'upload' | 'process' | 'network' | 'timeout'
) {
  await mockHealthCheck(page, errorType !== 'network');
  await mockSystemInfo(page);

  switch (errorType) {
    case 'upload':
      await mockFileUpload(page, { shouldFail: true, errorMessage: '文件上传失败' });
      break;
    case 'process':
      await mockFileUpload(page);
      await mockAudioEnhance(page, { shouldFail: true });
      break;
    case 'network':
      // Health check already set to fail
      break;
    case 'timeout':
      await mockFileUpload(page, { delay: 60000 });
      break;
  }
}

/**
 * Clear all route handlers
 */
export async function clearAllMocks(page: Page) {
  await page.unrouteAll();
}
