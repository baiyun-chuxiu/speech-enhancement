import { Page, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

/**
 * E2E Test Utilities
 */

export const FIXTURES_PATH = path.join(__dirname, '../fixtures');

function hasDocumentStorageAccess(page: Page): boolean {
  const url = page.url();
  return url.startsWith('http://') || url.startsWith('https://');
}

/**
 * Wait for page to be fully loaded
 */
export async function waitForPageLoad(page: Page) {
  await page.waitForLoadState('networkidle');
  await page.waitForLoadState('domcontentloaded');
}

/**
 * Upload a file to a file input element
 */
export async function uploadFile(
  page: Page,
  selector: string,
  fileName: string
) {
  const filePath = path.join(FIXTURES_PATH, fileName);
  const fileInput = page.locator(selector);
  await fileInput.setInputFiles(filePath);
}

/**
 * Upload file via drag and drop simulation
 */
export async function uploadFileByDragDrop(
  page: Page,
  dropZoneSelector: string,
  fileName: string
) {
  const filePath = path.join(FIXTURES_PATH, fileName);
  const dropZone = page.locator(dropZoneSelector);

  const dataTransfer = await page.evaluateHandle(() => new DataTransfer());

  await page.dispatchEvent(dropZoneSelector, 'dragenter', { dataTransfer });
  await page.dispatchEvent(dropZoneSelector, 'dragover', { dataTransfer });

  await dropZone.setInputFiles(filePath);
}

/**
 * Wait for upload to complete
 */
export async function waitForUploadComplete(
  page: Page,
  timeout = 30000
) {
  await page.waitForSelector('[data-testid="upload-success"], [data-status="success"]', {
    timeout,
    state: 'visible',
  }).catch(() => {
    // Fallback: wait for progress to reach 100% or success indicator
  });
}

/**
 * Wait for processing to complete
 */
export async function waitForProcessingComplete(
  page: Page,
  timeout = 120000
) {
  await page.waitForSelector(
    '[data-testid="processing-complete"], [data-status="completed"], text=处理完成',
    { timeout, state: 'visible' }
  ).catch(() => {
    // Processing may show different completion states
  });
}

/**
 * Check if element is visible
 */
export async function isVisible(page: Page, selector: string): Promise<boolean> {
  try {
    await page.waitForSelector(selector, { state: 'visible', timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

/**
 * Get text content of an element
 */
export async function getTextContent(
  page: Page,
  selector: string
): Promise<string | null> {
  const element = page.locator(selector);
  return element.textContent();
}

/**
 * Click button by text
 */
export async function clickButtonByText(page: Page, text: string) {
  await page.getByRole('button', { name: text }).click();
}

/**
 * Fill input by label
 */
export async function fillInputByLabel(
  page: Page,
  label: string,
  value: string
) {
  await page.getByLabel(label).fill(value);
}

/**
 * Select option from dropdown
 */
export async function selectOption(
  page: Page,
  selector: string,
  value: string
) {
  await page.locator(selector).selectOption(value);
}

/**
 * Check for error message
 */
export async function hasErrorMessage(
  page: Page,
  errorText?: string
): Promise<boolean> {
  if (errorText) {
    return isVisible(page, `text=${errorText}`);
  }
  return isVisible(page, '[data-testid="error-message"], [role="alert"], .error');
}

/**
 * Navigate and wait for page
 */
export async function navigateTo(page: Page, path: string) {
  await page.goto(path);
  await waitForPageLoad(page);
}

/**
 * Take screenshot with timestamp
 */
export async function takeScreenshot(page: Page, name: string) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  await page.screenshot({
    path: `e2e-results/screenshots/${name}-${timestamp}.png`,
    fullPage: true,
  });
}

/**
 * Mock API response
 */
export async function mockApiResponse(
  page: Page,
  urlPattern: string | RegExp,
  response: {
    status?: number;
    body?: unknown;
    headers?: Record<string, string>;
  }
) {
  await page.route(urlPattern, (route) => {
    route.fulfill({
      status: response.status || 200,
      contentType: 'application/json',
      body: JSON.stringify(response.body || {}),
      headers: response.headers,
    });
  });
}

/**
 * Mock API error
 */
export async function mockApiError(
  page: Page,
  urlPattern: string | RegExp,
  statusCode = 500,
  errorMessage = 'Internal Server Error'
) {
  await page.route(urlPattern, (route) => {
    route.fulfill({
      status: statusCode,
      contentType: 'application/json',
      body: JSON.stringify({ error: errorMessage }),
    });
  });
}

/**
 * Wait for network idle
 */
export async function waitForNetworkIdle(page: Page, timeout = 5000) {
  await page.waitForLoadState('networkidle', { timeout });
}

/**
 * Check localStorage value
 */
export async function getLocalStorageItem(
  page: Page,
  key: string
): Promise<string | null> {
  if (!hasDocumentStorageAccess(page)) {
    return null;
  }

  return page.evaluate((k) => localStorage.getItem(k), key);
}

/**
 * Set localStorage value
 */
export async function setLocalStorageItem(
  page: Page,
  key: string,
  value: string
) {
  if (!hasDocumentStorageAccess(page)) {
    await page.addInitScript(
      ({ k, v }) => {
        window.localStorage.setItem(k, v);
      },
      { k: key, v: value }
    );
    return;
  }

  await page.evaluate(
    ({ k, v }) => localStorage.setItem(k, v),
    { k: key, v: value }
  );
}

/**
 * Clear localStorage
 */
export async function clearLocalStorage(page: Page) {
  if (!hasDocumentStorageAccess(page)) {
    await page.addInitScript(() => {
      window.localStorage.clear();
    });
    return;
  }

  await page.evaluate(() => localStorage.clear());
}

/**
 * Viewport sizes for responsive testing
 */
export const VIEWPORTS = {
  desktop: { width: 1920, height: 1080 },
  laptop: { width: 1366, height: 768 },
  tablet: { width: 768, height: 1024 },
  mobile: { width: 375, height: 667 },
  mobileL: { width: 414, height: 896 },
};

/**
 * Set viewport size
 */
export async function setViewport(
  page: Page,
  size: keyof typeof VIEWPORTS | { width: number; height: number }
) {
  const viewport = typeof size === 'string' ? VIEWPORTS[size] : size;
  await page.setViewportSize(viewport);
}

/**
 * Generate large test file content
 */
export function generateLargeFileContent(sizeInMB: number): string {
  const line = 'timestamp,x,y,z\n0.000,0.012,-0.003,9.801\n';
  const lineSize = line.length;
  const targetSize = sizeInMB * 1024 * 1024;
  const repetitions = Math.ceil(targetSize / lineSize);
  return line.repeat(repetitions);
}

export function writeFixtureFile(filePath: string, content: string | Uint8Array): string {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content);
  return filePath;
}

export function createMockWavFile(filePath: string): string {
  const wavHeader = Buffer.from([
    0x52, 0x49, 0x46, 0x46,
    0x24, 0x00, 0x00, 0x00,
    0x57, 0x41, 0x56, 0x45,
    0x66, 0x6d, 0x74, 0x20,
    0x10, 0x00, 0x00, 0x00,
    0x01, 0x00,
    0x01, 0x00,
    0x44, 0xac, 0x00, 0x00,
    0x88, 0x58, 0x01, 0x00,
    0x02, 0x00,
    0x10, 0x00,
    0x64, 0x61, 0x74, 0x61,
    0x00, 0x00, 0x00, 0x00,
  ]);

  return writeFixtureFile(filePath, wavHeader);
}

/**
 * Assert element count
 */
export async function assertElementCount(
  page: Page,
  selector: string,
  expectedCount: number
) {
  const elements = page.locator(selector);
  await expect(elements).toHaveCount(expectedCount);
}

/**
 * Wait for toast/notification
 */
export async function waitForToast(page: Page, text?: string, timeout = 5000) {
  const toastSelector = text
    ? `[role="status"]:has-text("${text}"), .toast:has-text("${text}")`
    : '[role="status"], .toast';
  await page.waitForSelector(toastSelector, { timeout, state: 'visible' });
}
