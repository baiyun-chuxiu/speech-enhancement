import { test, expect } from '@playwright/test';
import * as path from 'path';
import { setupHappyPathMocks } from './helpers/api-mock';
import {
  waitForPageLoad,
  generateLargeFileContent,
  writeFixtureFile,
} from './helpers/test-utils';

const FIXTURES_PATH = path.join(__dirname, 'fixtures');

test.describe('E2E-010: Performance Tests', () => {
  test.beforeEach(async ({ page }) => {
    await setupHappyPathMocks(page);
  });

  test.describe('Page Load Performance', () => {
    test('10.1 should load upload page within acceptable time', async ({ page }) => {
      await page.goto('/upload');
      await waitForPageLoad(page);

      const startTime = Date.now();

      await page.goto('/upload');
      await page.waitForLoadState('domcontentloaded');

      const domContentLoaded = Date.now() - startTime;

      await page.waitForLoadState('networkidle');

      const fullyLoaded = Date.now() - startTime;

      // Warm-route DOM load should stay comfortably under local dev contention.
      expect(domContentLoaded).toBeLessThan(4000);

      // Full page should load within reasonable time (< 10s)
      expect(fullyLoaded).toBeLessThan(10000);
    });

    test('10.2 should have acceptable First Input Delay', async ({ page }) => {
      await page.goto('/upload');
      await waitForPageLoad(page);

      // Measure time to first interaction
      const startTime = Date.now();

      // Click a button
      const button = page.getByRole('button').first();
      if (await button.isVisible().catch(() => false)) {
        await button.click();
      }

      const interactionTime = Date.now() - startTime;

      // Interaction should be responsive (< 500ms)
      expect(interactionTime).toBeLessThan(500);
    });

    test('10.3 should have minimal layout shift', async ({ page }) => {
      await page.goto('/upload');

      // Take initial screenshot for reference
      const initialScreenshot = await page.screenshot();

      await waitForPageLoad(page);

      // Take final screenshot
      const finalScreenshot = await page.screenshot();

      // Visual comparison would be done here
      // For now, just verify page is stable
      await expect(page.getByText('加速度计数据')).toBeVisible();
    });
  });

  test.describe('File Handling Performance', () => {
    test('10.4 should handle large file upload without freezing', async ({ page }, testInfo) => {
      const largeContent = generateLargeFileContent(5);
      const largeFilePath = writeFixtureFile(
        testInfo.outputPath('large-perf-test.txt'),
        largeContent
      );

      await page.goto('/upload');
      await waitForPageLoad(page);

      const startTime = Date.now();

      // Upload large file
      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(largeFilePath);

      // Page should remain responsive
      const button = page.getByRole('button').first();
      await expect(button).toBeVisible({ timeout: 5000 });

      const uploadTime = Date.now() - startTime;

      // Upload should complete in reasonable time
      expect(uploadTime).toBeLessThan(30000);
    });

    test('should show progress during large file upload', async ({ page }, testInfo) => {
      const largeContent = generateLargeFileContent(3);
      const largeFilePath = writeFixtureFile(
        testInfo.outputPath('progress-test.txt'),
        largeContent
      );

      await page.goto('/upload');
      await waitForPageLoad(page);

      const accelInput = page.locator('input[type="file"]').first();
      await accelInput.setInputFiles(largeFilePath);

      // Progress indicator should appear
      // Note: With mocked uploads, progress may be instant
    });
  });

  test.describe('Concurrent Operations', () => {
    test('10.5 should handle multiple tabs without state conflicts', async ({ browser }) => {
      // Open two tabs
      const context = await browser.newContext();
      const page1 = await context.newPage();
      const page2 = await context.newPage();

      await setupHappyPathMocks(page1);
      await setupHappyPathMocks(page2);

      // Navigate both to upload page
      await page1.goto('/upload');
      await page2.goto('/upload');

      await waitForPageLoad(page1);
      await waitForPageLoad(page2);

      // Upload different files in each tab
      const input1 = page1.locator('input[type="file"]').first();
      const input2 = page2.locator('input[type="file"]').first();

      await input1.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));
      await input2.setInputFiles(path.join(FIXTURES_PATH, 'sample-gyro.txt'));

      // Both pages should work independently
      await expect(page1.getByText('sample-accel.txt')).toBeVisible({ timeout: 5000 }).catch(() => {});
      await expect(page2.getByText('sample-gyro.txt')).toBeVisible({ timeout: 5000 }).catch(() => {});

      await context.close();
    });
  });

  test.describe('Memory and Resource Usage', () => {
    test('should not leak memory on repeated operations', async ({ page }) => {
      await page.goto('/upload');
      await waitForPageLoad(page);

      // Get initial memory (if available)
      const initialMetrics = await page.evaluate(() => {
        if ('memory' in performance) {
          return (performance as Performance & { memory: { usedJSHeapSize: number } }).memory.usedJSHeapSize;
        }
        return null;
      });

      // Perform repeated operations
      for (let i = 0; i < 5; i++) {
        const input = page.locator('input[type="file"]').first();
        await input.setInputFiles(path.join(FIXTURES_PATH, 'sample-accel.txt'));
        await page.waitForTimeout(500);

        // Clear/reset
        const resetButton = page.getByRole('button', { name: /重置|Reset|删除|Remove/i }).first();
        if (await resetButton.isVisible().catch(() => false)) {
          await resetButton.click();
          await page.waitForTimeout(300);
        }
      }

      // Get final memory
      const finalMetrics = await page.evaluate(() => {
        if ('memory' in performance) {
          return (performance as Performance & { memory: { usedJSHeapSize: number } }).memory.usedJSHeapSize;
        }
        return null;
      });

      // Memory should not grow excessively
      if (initialMetrics && finalMetrics) {
        const memoryGrowth = finalMetrics - initialMetrics;
        // Allow some growth, but not excessive (e.g., < 50MB)
        expect(memoryGrowth).toBeLessThan(50 * 1024 * 1024);
      }
    });
  });

  test.describe('Network Performance', () => {
    test('should minimize API requests', async ({ page }) => {
      const apiRequests: string[] = [];

      // Track API requests
      page.on('request', (request) => {
        if (request.url().includes('/api/')) {
          apiRequests.push(request.url());
        }
      });

      await page.goto('/upload');
      await waitForPageLoad(page);

      // Initial page load should not make excessive API calls
      // Actual number depends on implementation
    });

    test('should handle slow network gracefully', async ({ page }) => {
      // Simulate slow network
      const client = await page.context().newCDPSession(page);
      await client.send('Network.emulateNetworkConditions', {
        offline: false,
        downloadThroughput: 100 * 1024, // 100 KB/s
        uploadThroughput: 50 * 1024, // 50 KB/s
        latency: 500, // 500ms latency
      });

      await page.goto('/upload');

      // Page should still load (may take longer)
      await expect(page.getByText('加速度计数据')).toBeVisible({ timeout: 30000 });

      // Reset network conditions
      await client.send('Network.emulateNetworkConditions', {
        offline: false,
        downloadThroughput: -1,
        uploadThroughput: -1,
        latency: 0,
      });
    });
  });
});
