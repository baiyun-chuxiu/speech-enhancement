'use client';

import { useState, useCallback, useRef } from 'react';
import { useTranslations } from 'next-intl';
import {
  getClientCompletionCapabilities,
  getRuntimeCapabilitiesFromSystemInfo,
  normalizeAppSettings,
  type AppSettings,
} from '@/lib/app-settings';
import { modelApi } from '@/lib/api/model-api';
import {
  startEnhancement,
  pollEnhancerTask,
  cancelEnhancerTask,
  checkEnhancerReadiness,
  getEnhancerSystemInfo,
  getEnhancerDownloadUrl,
  createEnhancerTaskWebSocket,
  type EnhancerTaskInfo,
} from '@/lib/api/enhancer-api';
import type {
  ModelProcessRequest,
  ModelProcessResponse,
  ModelStatus,
  ProcessStep,
  ProcessedAudio,
  TextFileInfo,
  AudioFileInfo,
  ModelProcessOptions,
} from '@/lib/types';

interface UseModelApiOptions {
  onStepUpdate?: (step: ProcessStep) => void;
  onProgress?: (progress: number) => void;
  onComplete?: (response: ModelProcessResponse) => void;
  onError?: (error: string) => void;
}

interface UseModelApiReturn {
  isProcessing: boolean;
  progress: number;
  steps: ProcessStep[];
  outputAudio: ProcessedAudio | null;
  error: string | null;
  modelStatus: ModelStatus | null;
  process: (textFile: TextFileInfo, audioFile: AudioFileInfo, options?: ModelProcessOptions) => Promise<ModelProcessResponse>;
  processEnhance: (audioFile: File, accelFile: File, gyroFile: File, settings?: Partial<AppSettings>) => Promise<ModelProcessResponse>;
  cancelProcess: () => Promise<void>;
  checkStatus: () => Promise<ModelStatus>;
  reset: () => void;
}

const DEFAULT_STEP_KEYS = [
  'processing.stepPrepareFiles',
  'processing.stepTextParsing',
  'processing.stepAudioAnalysis',
  'processing.stepModelInference',
  'processing.stepGenerateAudio',
];

const ENHANCER_STEP_KEYS = [
  'processing.stepIMUPreprocess',
  'processing.stepVideoDisplacement',
  'processing.stepAudioSTFT',
  'processing.stepJointDenoise',
  'processing.stepSpecPostprocess',
  'processing.stepAudioReconstruct',
];

export function useModelApi(options: UseModelApiOptions = {}): UseModelApiReturn {
  const t = useTranslations();
  const { onStepUpdate, onProgress, onComplete, onError } = options;

  const DEFAULT_STEPS: ProcessStep[] = DEFAULT_STEP_KEYS.map(key => ({
    name: t(key),
    status: 'pending' as const,
    progress: 0,
  }));

  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [steps, setSteps] = useState<ProcessStep[]>(DEFAULT_STEPS);
  const [outputAudio, setOutputAudio] = useState<ProcessedAudio | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [modelStatus, setModelStatus] = useState<ModelStatus | null>(null);

  const taskIdRef = useRef<string | null>(null);
  const abortedRef = useRef(false);

  const updateStep = useCallback((index: number, update: Partial<ProcessStep>) => {
    setSteps(prev => {
      const newSteps = [...prev];
      newSteps[index] = { ...newSteps[index], ...update };
      return newSteps;
    });
  }, []);

  const simulateProgress = useCallback(async (stepIndex: number, stepName: string) => {
    if (abortedRef.current) return;
    
    updateStep(stepIndex, { status: 'processing', progress: 0 });
    onStepUpdate?.({ name: stepName, status: 'processing', progress: 0 });

    for (let p = 0; p <= 100; p += 20) {
      if (abortedRef.current) return;
      await new Promise(resolve => setTimeout(resolve, 200));
      updateStep(stepIndex, { progress: p });
      
      const overallProgress = ((stepIndex * 100 + p) / (DEFAULT_STEP_KEYS.length * 100)) * 100;
      setProgress(overallProgress);
      onProgress?.(overallProgress);
    }

    updateStep(stepIndex, { status: 'completed', progress: 100 });
    onStepUpdate?.({ name: stepName, status: 'completed', progress: 100 });
  }, [updateStep, onStepUpdate, onProgress]);

  const process = useCallback(async (
    textFile: TextFileInfo,
    audioFile: AudioFileInfo,
    processOptions?: ModelProcessOptions
  ): Promise<ModelProcessResponse> => {
    setIsProcessing(true);
    setError(null);
    setProgress(0);
    setOutputAudio(null);
    setSteps(DEFAULT_STEPS.map(s => ({ ...s, status: 'pending', progress: 0 })));
    abortedRef.current = false;
    taskIdRef.current = crypto.randomUUID();

    try {
      // 模拟处理步骤进度
      for (let i = 0; i < DEFAULT_STEPS.length; i++) {
        if (abortedRef.current) {
          throw new Error(t('errors.processingCancelled'));
        }
        await simulateProgress(i, DEFAULT_STEPS[i].name);
      }

      // 调用实际 API
      const request: ModelProcessRequest = {
        textFile,
        audioFile,
        textContent: textFile.content,
        options: processOptions,
      };

      const response = await modelApi.process(request);

      if (response.success && response.outputAudio) {
        setOutputAudio(response.outputAudio);
      } else if (!response.success) {
        throw new Error(response.error || t('errors.processingFailed'));
      }

      setProgress(100);
      onComplete?.(response);
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : t('errors.processingFailed');
      setError(errorMessage);
      onError?.(errorMessage);
      
      // 标记当前步骤为失败
      setSteps(prev => prev.map(s => 
        s.status === 'processing' ? { ...s, status: 'failed' } : s
      ));

      return { success: false, error: errorMessage };
    } finally {
      setIsProcessing(false);
      taskIdRef.current = null;
    }
  }, [simulateProgress, onComplete, onError, DEFAULT_STEPS, t]);

  const processEnhance = useCallback(async (
    audioFile: File,
    accelFile: File,
    gyroFile: File,
    settings: Partial<AppSettings> = {},
  ): Promise<ModelProcessResponse> => {
    const enhancerSteps: ProcessStep[] = ENHANCER_STEP_KEYS.map(key => ({
      name: t(key),
      status: 'pending' as const,
      progress: 0,
    }));

    setIsProcessing(true);
    setError(null);
    setProgress(0);
    setOutputAudio(null);
    setSteps(enhancerSteps);
    abortedRef.current = false;

    try {
      const readiness = await checkEnhancerReadiness();
      if (!readiness.is_ready) {
        throw new Error(readiness.degraded_reason || t('errors.processingFailed'));
      }

      const systemInfo = await getEnhancerSystemInfo();
      const runtimeCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        systemInfo,
        getClientCompletionCapabilities(),
      );
      const resolvedSettings = normalizeAppSettings(settings, runtimeCapabilities);

      // Start enhancement via direct API
      const enhanceResponse = await startEnhancement(audioFile, accelFile, gyroFile, {
        device: resolvedSettings.device,
        quality: resolvedSettings.quality,
        outputFormat: resolvedSettings.outputFormat,
      });
      taskIdRef.current = enhanceResponse.task_id;

      if (!enhanceResponse.success) {
        throw new Error('Failed to start enhancement');
      }

      // Progress handler shared by both WebSocket and polling
      const onTaskUpdate = (task: EnhancerTaskInfo) => {
        if (abortedRef.current) return;

        const updatedSteps: ProcessStep[] = task.steps.map(s => ({
          name: s.name,
          status: s.status === 'completed' ? 'completed' as const :
                  s.status === 'failed' ? 'failed' as const :
                  s.status === 'running' ? 'processing' as const : 'pending' as const,
          progress: s.progress,
        }));
        setSteps(updatedSteps);
        setProgress(task.progress);
        onProgress?.(task.progress);

        for (const step of updatedSteps) {
          onStepUpdate?.(step);
        }
      };

      // Try WebSocket first for real-time updates, fall back to polling
      const finalTask = await new Promise<EnhancerTaskInfo>((resolve, reject) => {
        let resolved = false;
        let ws: WebSocket | null = null;

        const cleanup = () => {
          if (ws && ws.readyState <= WebSocket.OPEN) {
            ws.close();
          }
        };

        try {
          ws = createEnhancerTaskWebSocket(
            enhanceResponse.task_id,
            (task) => {
              onTaskUpdate(task);
              if (task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled') {
                resolved = true;
                cleanup();
                resolve(task);
              }
            },
            () => {
              // WebSocket error: fall back to polling
              if (!resolved) {
                cleanup();
                pollEnhancerTask(enhanceResponse.task_id, onTaskUpdate, 500, 300000)
                  .then(resolve)
                  .catch(reject);
              }
            },
            () => {
              // WebSocket closed before task finished: fall back to polling
              if (!resolved) {
                pollEnhancerTask(enhanceResponse.task_id, onTaskUpdate, 500, 300000)
                  .then(resolve)
                  .catch(reject);
              }
            },
          );
        } catch {
          // WebSocket creation failed: fall back to polling
          pollEnhancerTask(enhanceResponse.task_id, onTaskUpdate, 500, 300000)
            .then(resolve)
            .catch(reject);
        }
      });

      if (finalTask.status === 'failed') {
        throw new Error(finalTask.error || t('errors.processingFailed'));
      }

      if (finalTask.status === 'cancelled') {
        throw new Error(t('errors.processingCancelled'));
      }

      // Build output audio from result
      const outputFileId = finalTask.result?.output_file_id;
      const outputUrl = outputFileId
        ? getEnhancerDownloadUrl(outputFileId)
        : finalTask.result?.output_url || '';

      const outputAudioResult: ProcessedAudio = {
        id: finalTask.task_id,
        data: new ArrayBuffer(0),
        url: outputUrl,
        fileName: finalTask.result?.output_file_name,
        format: finalTask.result?.output_format || resolvedSettings.outputFormat,
        duration: 0, // will be resolved by audio player on load
        sampleRate: finalTask.result?.sample_rate || 44100,
        size: finalTask.result?.output_size || 0,
        createdAt: new Date(),
      };

      setOutputAudio(outputAudioResult);
      setProgress(100);

      const response: ModelProcessResponse = {
        success: true,
        outputAudio: outputAudioResult,
        metadata: {
          processingTime: (finalTask.result?.total_time || 0) * 1000,
          modelUsed: 'enhancer-pipeline',
          inputTextLength: 0,
          inputAudioDuration: 0,
          outputAudioDuration: 0,
          appliedSettings: {
            device: (finalTask.result?.device || resolvedSettings.device) as AppSettings['device'],
            quality: finalTask.result?.quality || resolvedSettings.quality,
            outputFormat: finalTask.result?.output_format || resolvedSettings.outputFormat,
            sampleRate: finalTask.result?.sample_rate || 44100,
          },
          runtimeCapabilities,
          steps: finalTask.steps.map(s => ({
            name: s.name,
            status: s.status === 'completed' ? 'completed' as const :
                    s.status === 'failed' ? 'failed' as const :
                    s.status === 'running' ? 'processing' as const : 'pending' as const,
            progress: s.progress,
          })),
        },
      };

      onComplete?.(response);
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : t('errors.processingFailed');
      setError(errorMessage);
      onError?.(errorMessage);

      setSteps(prev => prev.map(s =>
        s.status === 'processing' ? { ...s, status: 'failed' } : s
      ));

      return { success: false, error: errorMessage };
    } finally {
      setIsProcessing(false);
      taskIdRef.current = null;
    }
  }, [t, onStepUpdate, onProgress, onComplete, onError]);

  const cancelProcess = useCallback(async () => {
    abortedRef.current = true;
    if (taskIdRef.current) {
      try {
        await cancelEnhancerTask(taskIdRef.current).catch(() => {});
        await modelApi.cancelProcess(taskIdRef.current).catch(() => {});
      } catch {
        // 忽略取消错误
      }
    }
    setIsProcessing(false);
    setError(t('errors.processingCancelled'));
    setSteps(prev => prev.map(s => ({
      ...s,
      status: s.status === 'processing' ? 'failed' : s.status,
    })));
  }, [t]);

  const checkStatus = useCallback(async (): Promise<ModelStatus> => {
    // Try enhancer first, fallback to generic modelApi
    try {
      const readiness = await checkEnhancerReadiness();
      const info = await getEnhancerSystemInfo();
      const runtimeCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        info,
        getClientCompletionCapabilities(),
      );
      const status: ModelStatus = {
        isAvailable: readiness.is_ready,
        modelName: 'enhancer-pipeline',
        modelVersion: info.version || '1.0.0',
        capabilities: ['audio-enhance', 'imu-process', 'multimodal-denoise'],
        runtimeCapabilities,
      };
      setModelStatus(status);
      return status;
    } catch {
      const status = await modelApi.checkModelStatus();
      setModelStatus(status);
      return status;
    }
  }, []);

  const reset = useCallback(() => {
    setIsProcessing(false);
    setProgress(0);
    setSteps(DEFAULT_STEPS.map(s => ({ ...s, status: 'pending', progress: 0 })));
    setOutputAudio(null);
    setError(null);
    abortedRef.current = false;
    taskIdRef.current = null;
  }, [DEFAULT_STEPS]);

  return {
    isProcessing,
    progress,
    steps,
    outputAudio,
    error,
    modelStatus,
    process,
    processEnhance,
    cancelProcess,
    checkStatus,
    reset,
  };
}
