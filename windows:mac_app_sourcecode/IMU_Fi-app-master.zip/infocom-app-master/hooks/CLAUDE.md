# Hooks Module

[根目录](../CLAUDE.md) > **hooks/**

## Module Overview

Custom React hooks implementing the application's state management pattern. Each hook encapsulates a specific domain logic with callback-based parent coordination.

## Module Structure

```
hooks/
├── useFileUpload.ts       # File upload with validation & progress
├── useAudioPlayer.ts      # Audio playback & waveform analysis
├── useModelApi.ts         # Model processing orchestration
└── index.ts               # Public API exports
```

## Core Hooks

### useFileUpload

Manages file upload state, validation, and progress tracking.

**Features**:
- File size and type validation
- Upload progress simulation
- Audio duration detection
- Text file content reading
- Error handling with abort support

**Parameters**:
```typescript
interface UseFileUploadOptions {
  maxSize?: number;        // Default: 100MB
  acceptedTypes?: string[];
  onSuccess?: (fileInfo: FileInfo) => void;
  onError?: (error: string) => void;
}
```

**Returns**:
```typescript
interface UseFileUploadReturn {
  fileInfo: FileInfo | null;
  isUploading: boolean;
  progress: number;
  error: string | null;
  selectFile: (file: File) => Promise<void>;
  removeFile: () => void;
  reset: () => void;
}
```

**Specialized Variants**:
- `useTextFileUpload()` - Pre-configured for `.txt` files
- `useAudioFileUpload()` - Pre-configured for audio formats

**Usage Example**:
```typescript
const upload = useAudioFileUpload({
  maxSize: 100 * 1024 * 1024, // 100MB
  onSuccess: (file) => console.log('Uploaded:', file.name),
  onError: (err) => console.error('Error:', err),
});

<input type="file" onChange={(e) => e.target.files?.[0] && upload.selectFile(e.target.files[0])} />
```

### useAudioPlayer

Handles audio playback state, AudioContext management, and waveform analysis.

**Features**:
- Play/pause/stop/seek controls
- Volume and mute controls
- Playback rate adjustment
- Waveform analysis using Web Audio API
- Frequency spectrum data
- Automatic cleanup on unmount

**Parameters**:
```typescript
interface UseAudioPlayerOptions {
  onPlay?: () => void;
  onPause?: () => void;
  onEnded?: () => void;
  onTimeUpdate?: (currentTime: number) => void;
  onError?: (error: string) => void;
  autoPlay?: boolean;
}
```

**Returns**:
```typescript
interface UseAudioPlayerReturn {
  state: AudioPlaybackState;
  analysis: AudioAnalysis | null;
  audioRef: RefObject<HTMLAudioElement>;
  canvasRef: RefObject<HTMLCanvasElement>;
  load: (src: string) => void;
  play: () => Promise<void>;
  pause: () => void;
  toggle: () => Promise<void>;
  stop: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setPlaybackRate: (rate: number) => void;
  analyzeAudio: () => Promise<AudioAnalysis | null>;
}
```

**Audio Analysis Returns**:
```typescript
interface AudioAnalysis {
  duration: number;
  sampleRate: number;
  channels: number;
  waveformData: number[];      // Normalized 0-1
  peakAmplitude: number;
  averageAmplitude: number;
  silenceRatio: number;
}
```

**Usage Example**:
```typescript
const player = useAudioPlayer({
  onEnded: () => console.log('Playback finished'),
});

useEffect(() => {
  if (audioUrl) player.load(audioUrl);
}, [audioUrl]);

<button onClick={() => player.toggle()}>Play/Pause</button>
```

### useModelApi

Orchestrates model API processing with step tracking and progress updates.

**Features**:
- Multi-step progress simulation
- Error handling and recovery
- Task cancellation support
- Step-by-step status tracking
- Callback-based parent coordination

**Parameters**:
```typescript
interface UseModelApiOptions {
  onStepUpdate?: (step: ProcessStep) => void;
  onProgress?: (progress: number) => void;
  onComplete?: (response: ModelProcessResponse) => void;
  onError?: (error: string) => void;
}
```

**Returns**:
```typescript
interface UseModelApiReturn {
  isProcessing: boolean;
  progress: number;
  steps: ProcessStep[];
  outputAudio: ProcessedAudio | null;
  error: string | null;
  modelStatus: ModelStatus | null;
  process: (textFile, audioFile, options?) => Promise<ModelProcessResponse>;
  cancelProcess: () => Promise<void>;
  checkStatus: () => Promise<ModelStatus>;
  reset: () => void;
}
```

**Default Processing Steps**:
1. 准备文件 (Prepare Files)
2. 解析文本 (Parse Text)
3. 分析音频 (Analyze Audio)
4. 模型推理 (Model Inference)
5. 生成音频 (Generate Audio)

**Usage Example**:
```typescript
const modelApi = useModelApi({
  onComplete: (response) => {
    if (response.success) {
      console.log('Output:', response.outputAudio);
    }
  },
  onError: (err) => console.error('Failed:', err),
});

await modelApi.process(textFile, audioFile, {
  quality: 'balanced',
  outputFormat: 'wav',
});
```

## State Management Pattern

```mermaid
graph TD
    Component[Page Component]
    Hook[Custom Hook]
    State[Local State]
    Callbacks[Callback Options]

    Component -->|props| Hook
    Hook --> State
    Hook -->|events| Callbacks
    Callbacks -->|notify| Component

    style Hook fill:#e8f5e9
    style State fill:#fff3e0
    style Callbacks fill:#fce4ec
```

**Design Principles**:
1. **No global state** - Each hook manages its own state
2. **Callback-based coordination** - Parents subscribe to events via options
3. **Unidirectional data flow** - State flows from hooks to components
4. **Shallow component tree** - Props drilling is manageable (2-3 levels)

## Testing

- **Test Coverage**: 0% (tested indirectly through component tests)
- **Recommended**: Add dedicated unit tests for each hook

**Test Strategy**:
```typescript
// Example: useFileUpload.test.ts
describe('useFileUpload', () => {
  it('should validate file size', async () => {
    const { result } = renderHook(() => useFileUpload({ maxSize: 1000 }));
    const largeFile = new File(['x'.repeat(2000)], 'large.txt');
    await act(() => result.current.selectFile(largeFile));
    expect(result.current.error).toContain('超过限制');
  });
});
```

## Dependencies

```typescript
import type {
  FileInfo,
  AudioFileInfo,
  TextFileInfo,
  AudioPlaybackState,
  AudioAnalysis,
  ModelProcessRequest,
  ModelProcessResponse,
  ProcessStep,
} from "@/lib/types";
import { modelApi } from "@/lib/api/model-api";
```

## Known Limitations

1. **No unit tests** - Hooks are only tested through E2E and component tests
2. **Progress simulation** - `useModelApi` simulates progress rather than polling real API
3. **AudioContext limitations** - Browser autoplay policies require user interaction
4. **File parsing** - Text files are parsed entirely in memory (not suitable for very large files)

## Future Enhancements

1. **Real API progress polling** - Replace simulated progress with actual task status
2. **Chunked file reading** - Support for large text files with streaming
3. **Offline audio caching** - Cache analyzed audio data using IndexedDB
4. **Resume/pause processing** - Support for pausing long-running tasks
5. **Batch processing** - Queue multiple files for sequential processing
