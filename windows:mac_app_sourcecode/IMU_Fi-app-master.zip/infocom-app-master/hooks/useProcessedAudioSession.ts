'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';

import { getClientCompletionCapabilities, type AppSettings } from '@/lib/app-settings';
import { modelApi } from '@/lib/api/model-api';
import type { AudioAnalysis, AudioPlaybackState, ProcessedAudio } from '@/lib/types';

import { useAudioPlayer } from './useAudioPlayer';

type CompletionPreferences = Pick<AppSettings, 'autoSave' | 'notifications'>;

interface UseProcessedAudioSessionOptions {
  audio: ProcessedAudio | null;
  preferences?: Partial<CompletionPreferences> | null;
}

export interface ProcessedAudioSession {
  audio: ProcessedAudio | null;
  resolvedAudio: ProcessedAudio | null;
  analysis: AudioAnalysis | null;
  analysisError: string | null;
  state: AudioPlaybackState;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  play: () => Promise<void>;
  pause: () => void;
  toggle: () => Promise<void>;
  stop: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setPlaybackRate: (rate: number) => void;
  download: () => Promise<void>;
  saveToDisk: () => Promise<string | null>;
}

const DEFAULT_COMPLETION_PREFERENCES: CompletionPreferences = {
  autoSave: false,
  notifications: false,
};

export function useProcessedAudioSession({
  audio,
  preferences,
}: UseProcessedAudioSessionOptions): ProcessedAudioSession {
  const t = useTranslations();
  const {
    state,
    audioRef,
    play,
    pause,
    toggle,
    stop,
    seek,
    setVolume,
    toggleMute,
    setPlaybackRate,
    load,
    analyzeAudio,
  } = useAudioPlayer();
  const [analyzedUrl, setAnalyzedUrl] = useState<string | null>(null);
  const [rawAnalysis, setRawAnalysis] = useState<AudioAnalysis | null>(null);
  const [rawAnalysisError, setRawAnalysisError] = useState<string | null>(null);
  const completionHandledForId = useRef<string | null>(null);
  const completionPreferences = {
    ...DEFAULT_COMPLETION_PREFERENCES,
    ...preferences,
  };

  useEffect(() => {
    if (!audio?.url) {
      return;
    }

    const audioUrl = audio.url;
    let cancelled = false;
    load(audioUrl);

    void analyzeAudio().then((nextAnalysis) => {
      if (cancelled) {
        return;
      }

      if (!nextAnalysis) {
        setAnalyzedUrl(audioUrl);
        setRawAnalysis(null);
        setRawAnalysisError('audioAnalyzer.analysisUnavailable');
        return;
      }

      setAnalyzedUrl(audioUrl);
      setRawAnalysis(nextAnalysis);
      setRawAnalysisError(null);
    });

    return () => {
      cancelled = true;
    };
  }, [analyzeAudio, audio?.url, load]);

  const analysis = audio?.url === analyzedUrl ? rawAnalysis : null;
  const analysisError = audio?.url === analyzedUrl ? rawAnalysisError : null;
  const resolvedAudio = useMemo(() => {
    if (!audio) {
      return null;
    }

    if (!analysis) {
      return audio;
    }

    return {
      ...audio,
      duration: analysis.duration || audio.duration || state.duration,
      sampleRate: analysis.sampleRate || audio.sampleRate,
      size: analysis.sourceSize ?? audio.size,
      format: analysis.format || audio.format,
    };
  }, [analysis, audio, state.duration]);

  const saveToDisk = useCallback(async (): Promise<string | null> => {
    if (!resolvedAudio?.url) {
      return null;
    }

    const response = await fetch(resolvedAudio.url);
    const arrayBuffer = await response.arrayBuffer();
    return modelApi.saveAudio(arrayBuffer, resolvedAudio.format);
  }, [resolvedAudio]);

  const download = useCallback(async () => {
    if (!resolvedAudio?.url) {
      return;
    }

    const anchor = document.createElement('a');
    anchor.href = resolvedAudio.url;
    anchor.download = resolvedAudio.fileName ?? `output.${resolvedAudio.format}`;
    anchor.click();
  }, [resolvedAudio]);

  useEffect(() => {
    if (!resolvedAudio?.id || !resolvedAudio.url) {
      return;
    }

    if (completionHandledForId.current === resolvedAudio.id) {
      return;
    }

    completionHandledForId.current = resolvedAudio.id;

    void (async () => {
      if (completionPreferences.autoSave) {
        const completionCapabilities = getClientCompletionCapabilities();

        if (completionCapabilities.autoSave) {
          try {
            await saveToDisk();
            toast.success(t('audioPlayer.autoSaved'));
          } catch {
            toast.error(t('errors.saveAudioFailed'));
          }
        } else {
          toast.message(t('errors.saveAudioTauriOnly'));
        }
      }

      if (completionPreferences.notifications) {
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
          new Notification(t('processing.completed'));
        } else {
          toast.success(t('processing.completed'));
        }
      }
    })();
  }, [
    completionPreferences.autoSave,
    completionPreferences.notifications,
    resolvedAudio,
    saveToDisk,
    t,
  ]);

  return {
    audio,
    resolvedAudio,
    analysis,
    analysisError,
    state,
    audioRef,
    play,
    pause,
    toggle,
    stop,
    seek,
    setVolume,
    toggleMute,
    setPlaybackRate,
    download,
    saveToDisk,
  };
}
