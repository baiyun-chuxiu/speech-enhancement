import { act, renderHook } from '@testing-library/react';

import { useAudioPlayer } from './useAudioPlayer';

class MockAudio {
  src = '';
  duration = 0;
  currentTime = 0;
  volume = 1;
  muted = false;
  playbackRate = 1;
  onloadedmetadata: (() => void) | null = null;
  ontimeupdate: (() => void) | null = null;
  onplay: (() => void) | null = null;
  onpause: (() => void) | null = null;
  onended: (() => void) | null = null;
  onerror: (() => void) | null = null;
  onvolumechange: (() => void) | null = null;

  load = jest.fn();
  play = jest.fn().mockResolvedValue(undefined);
  pause = jest.fn();
}

describe('useAudioPlayer', () => {
  const decodeAudioDataMock = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();

    Object.defineProperty(globalThis, 'Audio', {
      configurable: true,
      writable: true,
      value: MockAudio,
    });

    Object.defineProperty(globalThis, 'OfflineAudioContext', {
      configurable: true,
      writable: true,
      value: class MockOfflineAudioContext {
        decodeAudioData = decodeAudioDataMock;
      },
    });

    Object.defineProperty(globalThis, 'fetch', {
      configurable: true,
      writable: true,
      value: jest.fn().mockResolvedValue({
        arrayBuffer: async () => new ArrayBuffer(16),
        headers: {
          get: jest.fn().mockReturnValue('audio/wav'),
        },
      }),
    });
  });

  it('analyzes large audio buffers without overflowing the call stack', async () => {
    const rawData = new Float32Array(250_000).fill(0.25);
    rawData[42] = 0.9;
    rawData[84] = -0.6;
    rawData[126] = 0;

    decodeAudioDataMock.mockResolvedValue({
      duration: 250_000 / 44_100,
      sampleRate: 44_100,
      numberOfChannels: 1,
      getChannelData: () => rawData,
    });

    const { result } = renderHook(() => useAudioPlayer());

    act(() => {
      result.current.load('https://example.com/test-audio.wav');
    });

    await act(async () => {
      await result.current.analyzeAudio();
    });

    const resolvedAnalysis = result.current.analysis;

    expect(resolvedAnalysis).not.toBeNull();
    if (!resolvedAnalysis) {
      throw new Error('Expected audio analysis to be available');
    }

    expect(resolvedAnalysis.peakAmplitude).toBeCloseTo(0.9);
    expect(resolvedAnalysis.averageAmplitude).toBeGreaterThan(0);
    expect(resolvedAnalysis.waveformData).toHaveLength(200);
    expect(globalThis.fetch).toHaveBeenCalledWith('https://example.com/test-audio.wav');
  });
});
