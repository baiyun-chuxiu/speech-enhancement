'use client';

import { useState, useCallback, useRef } from 'react';
import { useTranslations } from 'next-intl';
import type { 
  FileInfo, 
  TextFileInfo, 
  AudioFileInfo, 
  UploadStatus,
  AudioFormat 
} from '@/lib/types';
import { formatFileSizeLabel } from '@/lib/utils/upload-formatters';

interface UseFileUploadOptions {
  maxSize?: number; // 最大文件大小 (bytes)
  acceptedTypes?: string[]; // 允许的文件类型
  onSuccess?: (fileInfo: FileInfo) => void;
  onError?: (error: string) => void;
}

interface UseFileUploadReturn {
  fileInfo: FileInfo | null;
  isUploading: boolean;
  progress: number;
  error: string | null;
  selectFile: (file: File) => Promise<void>;
  removeFile: () => void;
  reset: () => void;
}

const AUDIO_TYPES = ['audio/mpeg', 'audio/wav', 'audio/mp4', 'audio/ogg', 'audio/flac', 'audio/aac', 'audio/x-m4a'];
const TEXT_TYPES = ['text/plain', 'application/txt'];

const DEFAULT_MAX_SIZE = 100 * 1024 * 1024; // 100MB

export function useFileUpload(options: UseFileUploadOptions = {}): UseFileUploadReturn {
  const t = useTranslations('errors');
  const { 
    maxSize = DEFAULT_MAX_SIZE, 
    acceptedTypes = [],
    onSuccess,
    onError 
  } = options;

  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const validateFile = useCallback((file: File): string | null => {
    // 检查文件大小
    if (file.size > maxSize) {
      return t('fileTooLarge', { maxSize: formatFileSize(maxSize) });
    }

    // 检查文件类型
    if (acceptedTypes.length > 0) {
      const isAccepted = acceptedTypes.some(type => {
        if (type.startsWith('.')) {
          return file.name.toLowerCase().endsWith(type.toLowerCase());
        }
        return file.type === type || file.type.startsWith(type.replace('*', ''));
      });
      if (!isAccepted) {
        return t('unsupportedType', { type: file.type || t('unknown') });
      }
    }

    return null;
  }, [maxSize, acceptedTypes, t]);

  const getAudioDuration = (file: File): Promise<number> => {
    return new Promise((resolve) => {
      const audio = new Audio();
      audio.src = URL.createObjectURL(file);
      audio.onloadedmetadata = () => {
        resolve(audio.duration);
        URL.revokeObjectURL(audio.src);
      };
      audio.onerror = () => {
        resolve(0);
        URL.revokeObjectURL(audio.src);
      };
    });
  };

  const getTextContent = async (file: File): Promise<{ content: string; lineCount: number; wordCount: number }> => {
    const content = await file.text();
    const lineCount = content.split('\n').length;
    const wordCount = content.trim().split(/\s+/).filter(Boolean).length;
    return { content, lineCount, wordCount };
  };

  const selectFile = useCallback(async (file: File) => {
    setError(null);
    setProgress(0);

    // 验证文件
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      onError?.(validationError);
      return;
    }

    setIsUploading(true);
    abortControllerRef.current = new AbortController();

    try {
      // 模拟上传进度
      for (let i = 0; i <= 100; i += 10) {
        if (abortControllerRef.current?.signal.aborted) {
          throw new Error(t('uploadCancelled'));
        }
        setProgress(i);
        await new Promise(resolve => setTimeout(resolve, 50));
      }

      const baseInfo: FileInfo = {
        id: crypto.randomUUID(),
        name: file.name,
        size: file.size,
        type: file.type,
        lastModified: file.lastModified,
        uploadedAt: new Date(),
        status: 'success' as UploadStatus,
        progress: 100,
        file,
      };

      // 根据文件类型获取额外信息
      const isAudio = AUDIO_TYPES.includes(file.type) || file.name.match(/\.(mp3|wav|m4a|ogg|flac|aac)$/i);
      const isText = TEXT_TYPES.includes(file.type) || file.name.endsWith('.txt');

      let finalInfo: FileInfo;

      if (isAudio) {
        const duration = await getAudioDuration(file);
        const format = file.name.split('.').pop()?.toLowerCase() as AudioFormat;
        finalInfo = {
          ...baseInfo,
          duration,
          format,
        } as AudioFileInfo;
      } else if (isText) {
        const { content, lineCount, wordCount } = await getTextContent(file);
        finalInfo = {
          ...baseInfo,
          content,
          lineCount,
          wordCount,
          encoding: 'utf-8',
        } as TextFileInfo;
      } else {
        finalInfo = baseInfo;
      }

      setFileInfo(finalInfo);
      onSuccess?.(finalInfo);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : t('uploadFailed');
      setError(errorMessage);
      onError?.(errorMessage);
    } finally {
      setIsUploading(false);
      abortControllerRef.current = null;
    }
  }, [validateFile, onSuccess, onError, t]);

  const removeFile = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setFileInfo(null);
    setProgress(0);
    setError(null);
    setIsUploading(false);
  }, []);

  const reset = useCallback(() => {
    removeFile();
  }, [removeFile]);

  return {
    fileInfo,
    isUploading,
    progress,
    error,
    selectFile,
    removeFile,
    reset,
  };
}

// 文本文件上传 hook
export function useTextFileUpload(options: Omit<UseFileUploadOptions, 'acceptedTypes'> = {}) {
  return useFileUpload({
    ...options,
    acceptedTypes: ['.txt', 'text/plain'],
  });
}

// 音频文件上传 hook
export function useAudioFileUpload(options: Omit<UseFileUploadOptions, 'acceptedTypes'> = {}) {
  return useFileUpload({
    ...options,
    acceptedTypes: ['.mp3', '.wav', '.m4a', '.ogg', '.flac', '.aac', ...AUDIO_TYPES],
  });
}

// 工具函数
function formatFileSize(bytes: number, locale: string = 'en'): string {
  return formatFileSizeLabel(bytes, locale);
}

export { formatFileSize };
