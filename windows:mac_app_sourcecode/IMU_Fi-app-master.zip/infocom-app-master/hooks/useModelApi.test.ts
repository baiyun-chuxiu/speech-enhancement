import { act, renderHook } from '@testing-library/react';

import { useModelApi } from './useModelApi';

const checkEnhancerHealthMock = jest.fn();
const checkEnhancerReadinessMock = jest.fn();
const getEnhancerSystemInfoMock = jest.fn();
const startEnhancementMock = jest.fn();
const pollEnhancerTaskMock = jest.fn();
const cancelEnhancerTaskMock = jest.fn();
const createEnhancerTaskWebSocketMock = jest.fn();

jest.mock('next-intl', () => ({
  useTranslations: () => (key: string) => key,
}));

jest.mock('@/lib/api/model-api', () => ({
  modelApi: {
    cancelProcess: jest.fn(),
    checkModelStatus: jest.fn(),
  },
}));

jest.mock('@/lib/api/enhancer-api', () => ({
  startEnhancement: (...args: unknown[]) => startEnhancementMock(...args),
  pollEnhancerTask: (...args: unknown[]) => pollEnhancerTaskMock(...args),
  cancelEnhancerTask: (...args: unknown[]) => cancelEnhancerTaskMock(...args),
  checkEnhancerHealth: (...args: unknown[]) => checkEnhancerHealthMock(...args),
  checkEnhancerReadiness: (...args: unknown[]) => checkEnhancerReadinessMock(...args),
  getEnhancerSystemInfo: (...args: unknown[]) => getEnhancerSystemInfoMock(...args),
  getEnhancerDownloadUrl: (fileId: string) => `http://localhost:8000/api/v1/files/download/${fileId}`,
  createEnhancerTaskWebSocket: (...args: unknown[]) => createEnhancerTaskWebSocketMock(...args),
}));

describe('useModelApi', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    checkEnhancerHealthMock.mockResolvedValue({
      status: 'ok',
      is_ready: true,
    });
    checkEnhancerReadinessMock.mockResolvedValue({
      status: 'degraded',
      is_ready: false,
      degraded_reason: 'missing-model-files',
      configured_device: 'cpu',
      effective_device: 'cpu',
      supported_devices: ['cpu'],
      version: '1.0.0',
      timestamp: '2026-03-13T00:00:00.000Z',
    });
    getEnhancerSystemInfoMock.mockResolvedValue({
      version: '1.0.0',
      python_version: '3.11.0',
      platform: 'test',
      cuda_available: false,
      mps_available: false,
      configured_device: 'cpu',
      device: 'cpu',
      supported_devices: ['cpu'],
      supported_qualities: ['balanced'],
      supported_output_formats: ['wav'],
      status: 'ready',
      is_ready: true,
      degraded_reason: null,
      generator_loaded: true,
      denoise_loaded: true,
      generator_model_exists: true,
      denoise_model_exists: true,
    });
    startEnhancementMock.mockResolvedValue({
      success: true,
      task_id: 'task-1',
      status: 'pending',
    });
    pollEnhancerTaskMock.mockResolvedValue({
      task_id: 'task-1',
      status: 'completed',
      progress: 100,
      message: 'done',
      steps: [],
      result: {
        output_file_id: 'output-1',
        output_format: 'wav',
        output_size: 0,
        sample_rate: 44100,
        total_time: 0.01,
      },
      error: null,
      created_at: '2026-03-13T00:00:00.000Z',
      updated_at: '2026-03-13T00:00:00.000Z',
    });
    createEnhancerTaskWebSocketMock.mockImplementation(() => {
      throw new Error('websocket disabled in tests');
    });
  });

  it('blocks enhancement before uploading files when readiness reports degraded mode', async () => {
    const { result } = renderHook(() => useModelApi());
    let response:
      | Awaited<ReturnType<typeof result.current.processEnhance>>
      | undefined;

    await act(async () => {
      response = await result.current.processEnhance(
        new File(['audio'], 'audio.wav', { type: 'audio/wav' }),
        new File(['accel'], 'accel.txt', { type: 'text/plain' }),
        new File(['gyro'], 'gyro.txt', { type: 'text/plain' }),
      );
    });

    expect(checkEnhancerReadinessMock).toHaveBeenCalled();
    expect(startEnhancementMock).not.toHaveBeenCalled();
    expect(response).toMatchObject({
      success: false,
      error: 'missing-model-files',
    });
  });
});
