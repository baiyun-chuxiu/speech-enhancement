import { renderHook, act } from '@testing-library/react';
import { formatFileSize } from './useFileUpload';

// ---------------------------------------------------------------------------
// Browser API mocks for jsdom
// ---------------------------------------------------------------------------

// File.prototype.text() is not available in jsdom
if (!File.prototype.text) {
  File.prototype.text = function () {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsText(this);
    });
  };
}

// URL.createObjectURL / revokeObjectURL
global.URL.createObjectURL = jest.fn(() => 'blob:mock-url');
global.URL.revokeObjectURL = jest.fn();

// Audio constructor for getAudioDuration
class MockAudio {
  src = '';
  duration = 5.0;
  onloadedmetadata: (() => void) | null = null;
  onerror: (() => void) | null = null;

  set _src(val: string) {
    this.src = val;
    // Simulate async metadata load
    setTimeout(() => {
      if (this.onloadedmetadata) this.onloadedmetadata();
    }, 0);
  }
}

Object.defineProperty(MockAudio.prototype, 'src', {
  set(val: string) {
    this._srcVal = val;
    setTimeout(() => {
      if (this.onloadedmetadata) this.onloadedmetadata();
    }, 0);
  },
  get() {
    return this._srcVal || '';
  },
});

global.Audio = MockAudio as unknown as typeof Audio;

// Mock next-intl
jest.mock('next-intl', () => ({
  useTranslations: () => (key: string, params?: Record<string, string>) => {
    const messages: Record<string, string> = {
      fileTooLarge: `File too large (max ${params?.maxSize ?? ''})`,
      unsupportedType: `Unsupported type: ${params?.type ?? ''}`,
      uploadCancelled: 'Upload cancelled',
      uploadFailed: 'Upload failed',
      unknown: 'unknown',
    };
    return messages[key] || key;
  },
}));

// ---------------------------------------------------------------------------
// formatFileSize (pure utility — no hooks)
// ---------------------------------------------------------------------------
describe('formatFileSize', () => {
  it('formats 0 bytes', () => {
    expect(formatFileSize(0)).toBe('0 B');
  });

  it('formats bytes', () => {
    expect(formatFileSize(500)).toBe('500 B');
  });

  it('formats kilobytes', () => {
    expect(formatFileSize(1024)).toBe('1 KB');
  });

  it('formats fractional kilobytes', () => {
    expect(formatFileSize(1536)).toBe('1.5 KB');
  });

  it('formats megabytes', () => {
    expect(formatFileSize(1048576)).toBe('1 MB');
  });

  it('formats fractional megabytes', () => {
    expect(formatFileSize(5242880)).toBe('5 MB');
  });

  it('formats gigabytes', () => {
    expect(formatFileSize(1073741824)).toBe('1 GB');
  });

  it('formats 100MB (default max)', () => {
    const result = formatFileSize(100 * 1024 * 1024);
    expect(result).toBe('100 MB');
  });

  it('rounds to 2 decimal places', () => {
    // 1234567 bytes = ~1.18 MB
    const result = formatFileSize(1234567);
    expect(result).toBe('1.18 MB');
  });
});

// ---------------------------------------------------------------------------
// useFileUpload hook
// ---------------------------------------------------------------------------
describe('useFileUpload', () => {
  // We need to import dynamically to ensure mocks are applied
  let useFileUpload: typeof import('./useFileUpload').useFileUpload;

  beforeAll(async () => {
    const mod = await import('./useFileUpload');
    useFileUpload = mod.useFileUpload;
  });

  beforeEach(() => {
    jest.clearAllMocks();
    // Mock crypto.randomUUID
    jest.spyOn(crypto, 'randomUUID').mockReturnValue('test-uuid-1234' as `${string}-${string}-${string}-${string}-${string}`);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('initial state', () => {
    it('returns null fileInfo initially', () => {
      const { result } = renderHook(() => useFileUpload());
      expect(result.current.fileInfo).toBeNull();
      expect(result.current.isUploading).toBe(false);
      expect(result.current.progress).toBe(0);
      expect(result.current.error).toBeNull();
    });
  });

  describe('file validation', () => {
    it('rejects files exceeding maxSize', async () => {
      const onError = jest.fn();
      const { result } = renderHook(() =>
        useFileUpload({ maxSize: 100, onError })
      );

      const largeFile = new File(['x'.repeat(200)], 'big.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(largeFile);
      });

      expect(result.current.error).toContain('File too large');
      expect(onError).toHaveBeenCalled();
      expect(result.current.fileInfo).toBeNull();
    });

    it('rejects unsupported file types', async () => {
      const onError = jest.fn();
      const { result } = renderHook(() =>
        useFileUpload({ acceptedTypes: ['.txt', 'text/plain'], onError })
      );

      const pdfFile = new File(['pdf content'], 'doc.pdf', { type: 'application/pdf' });

      await act(async () => {
        await result.current.selectFile(pdfFile);
      });

      expect(result.current.error).toContain('Unsupported type');
      expect(onError).toHaveBeenCalled();
    });

    it('accepts file matching extension', async () => {
      const onSuccess = jest.fn();
      const { result } = renderHook(() =>
        useFileUpload({ acceptedTypes: ['.txt'], onSuccess })
      );

      const txtFile = new File(['hello'], 'data.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(txtFile);
      });

      expect(result.current.error).toBeNull();
      expect(result.current.fileInfo).not.toBeNull();
      expect(onSuccess).toHaveBeenCalled();
    });

    it('accepts file matching MIME type', async () => {
      const { result } = renderHook(() =>
        useFileUpload({ acceptedTypes: ['text/plain'] })
      );

      const txtFile = new File(['hello'], 'data.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(txtFile);
      });

      expect(result.current.error).toBeNull();
      expect(result.current.fileInfo).not.toBeNull();
    });
  });

  describe('text file upload', () => {
    it('extracts content, lineCount, and wordCount for .txt files', async () => {
      const content = 'line one\nline two\nline three';
      const { result } = renderHook(() => useFileUpload());

      const txtFile = new File([content], 'sensor.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(txtFile);
      });

      const info = result.current.fileInfo;
      expect(info).not.toBeNull();
      expect(info?.name).toBe('sensor.txt');
      expect(info?.status).toBe('success');
      expect(info?.progress).toBe(100);
      // TextFileInfo properties
      expect((info as { content?: string })?.content).toBe(content);
      expect((info as { lineCount?: number })?.lineCount).toBe(3);
      expect((info as { wordCount?: number })?.wordCount).toBe(6);
    });
  });

  describe('removeFile', () => {
    it('clears file state', async () => {
      const { result } = renderHook(() => useFileUpload());

      const txtFile = new File(['hello'], 'data.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(txtFile);
      });

      expect(result.current.fileInfo).not.toBeNull();

      act(() => {
        result.current.removeFile();
      });

      expect(result.current.fileInfo).toBeNull();
      expect(result.current.progress).toBe(0);
      expect(result.current.error).toBeNull();
    });
  });

  describe('reset', () => {
    it('resets all state', async () => {
      const { result } = renderHook(() => useFileUpload());

      const txtFile = new File(['hello'], 'data.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(txtFile);
      });

      act(() => {
        result.current.reset();
      });

      expect(result.current.fileInfo).toBeNull();
      expect(result.current.isUploading).toBe(false);
      expect(result.current.progress).toBe(0);
      expect(result.current.error).toBeNull();
    });
  });

  describe('callbacks', () => {
    it('calls onSuccess after successful upload', async () => {
      const onSuccess = jest.fn();
      const { result } = renderHook(() => useFileUpload({ onSuccess }));

      const txtFile = new File(['hello'], 'data.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(txtFile);
      });

      expect(onSuccess).toHaveBeenCalledTimes(1);
      expect(onSuccess).toHaveBeenCalledWith(
        expect.objectContaining({
          name: 'data.txt',
          status: 'success',
        })
      );
    });

    it('calls onError on validation failure', async () => {
      const onError = jest.fn();
      const { result } = renderHook(() =>
        useFileUpload({ maxSize: 1, onError })
      );

      const bigFile = new File(['too big'], 'big.txt', { type: 'text/plain' });

      await act(async () => {
        await result.current.selectFile(bigFile);
      });

      expect(onError).toHaveBeenCalledTimes(1);
    });
  });
});

// ---------------------------------------------------------------------------
// useTextFileUpload
// ---------------------------------------------------------------------------
describe('useTextFileUpload', () => {
  let useTextFileUpload: typeof import('./useFileUpload').useTextFileUpload;

  beforeAll(async () => {
    const mod = await import('./useFileUpload');
    useTextFileUpload = mod.useTextFileUpload;
  });

  beforeEach(() => {
    jest.spyOn(crypto, 'randomUUID').mockReturnValue('test-uuid-5678' as `${string}-${string}-${string}-${string}-${string}`);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('accepts .txt files', async () => {
    const { result } = renderHook(() => useTextFileUpload());

    const txtFile = new File(['data'], 'sensor.txt', { type: 'text/plain' });

    await act(async () => {
      await result.current.selectFile(txtFile);
    });

    expect(result.current.error).toBeNull();
    expect(result.current.fileInfo).not.toBeNull();
  });

  it('rejects non-txt files', async () => {
    const { result } = renderHook(() => useTextFileUpload());

    const pdfFile = new File(['data'], 'doc.pdf', { type: 'application/pdf' });

    await act(async () => {
      await result.current.selectFile(pdfFile);
    });

    expect(result.current.error).toContain('Unsupported type');
  });
});

// ---------------------------------------------------------------------------
// useAudioFileUpload
// ---------------------------------------------------------------------------
describe('useAudioFileUpload', () => {
  let useAudioFileUpload: typeof import('./useFileUpload').useAudioFileUpload;

  beforeAll(async () => {
    const mod = await import('./useFileUpload');
    useAudioFileUpload = mod.useAudioFileUpload;
  });

  beforeEach(() => {
    jest.spyOn(crypto, 'randomUUID').mockReturnValue('test-uuid-abcd' as `${string}-${string}-${string}-${string}-${string}`);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('accepts .wav files', async () => {
    const { result } = renderHook(() => useAudioFileUpload());

    const wavFile = new File(['audio data'], 'segment.wav', { type: 'audio/wav' });

    await act(async () => {
      await result.current.selectFile(wavFile);
    });

    expect(result.current.error).toBeNull();
    expect(result.current.fileInfo).not.toBeNull();
  });

  it('accepts .mp3 files', async () => {
    const { result } = renderHook(() => useAudioFileUpload());

    const mp3File = new File(['audio data'], 'test.mp3', { type: 'audio/mpeg' });

    await act(async () => {
      await result.current.selectFile(mp3File);
    });

    expect(result.current.error).toBeNull();
    expect(result.current.fileInfo).not.toBeNull();
  });

  it('rejects non-audio files', async () => {
    const { result } = renderHook(() => useAudioFileUpload());

    const txtFile = new File(['text'], 'data.txt', { type: 'text/plain' });

    await act(async () => {
      await result.current.selectFile(txtFile);
    });

    expect(result.current.error).toContain('Unsupported type');
  });
});
