'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import type { AudioPlaybackState, AudioAnalysis, AudioFormat } from '@/lib/types';

interface UseAudioPlayerOptions {
  onPlay?: () => void;
  onPause?: () => void;
  onEnded?: () => void;
  onTimeUpdate?: (currentTime: number) => void;
  onError?: (error: string) => void;
  autoPlay?: boolean;
}

interface UseAudioPlayerReturn {
  state: AudioPlaybackState;
  analysis: AudioAnalysis | null;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  load: (src: string) => void;
  play: () => Promise<void>;
  pause: () => void;
  toggle: () => Promise<void>;
  stop: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setPlaybackRate: (rate: number) => void;
  analyzeAudio: () => Promise<AudioAnalysis | null>;
}

const initialState: AudioPlaybackState = {
  isPlaying: false,
  isPaused: false,
  currentTime: 0,
  duration: 0,
  volume: 1,
  isMuted: false,
  playbackRate: 1,
  isLoading: false,
  error: undefined,
};

function inferAudioFormat(src: string, contentType: string | null): AudioFormat {
  const lowerContentType = contentType?.toLowerCase() ?? '';
  if (lowerContentType.includes('mpeg')) return 'mp3';
  if (lowerContentType.includes('wav')) return 'wav';
  if (lowerContentType.includes('ogg')) return 'ogg';
  if (lowerContentType.includes('flac')) return 'flac';
  if (lowerContentType.includes('aac')) return 'aac';
  if (lowerContentType.includes('mp4') || lowerContentType.includes('m4a')) return 'm4a';

  const normalizedSrc = src.toLowerCase();
  if (normalizedSrc.endsWith('.mp3')) return 'mp3';
  if (normalizedSrc.endsWith('.ogg')) return 'ogg';
  if (normalizedSrc.endsWith('.flac')) return 'flac';
  if (normalizedSrc.endsWith('.aac')) return 'aac';
  if (normalizedSrc.endsWith('.m4a')) return 'm4a';
  return 'wav';
}

export function useAudioPlayer(options: UseAudioPlayerOptions = {}): UseAudioPlayerReturn {
  const t = useTranslations();
  const { onPlay, onPause, onEnded, onTimeUpdate, onError, autoPlay = false } = options;

  const [state, setState] = useState<AudioPlaybackState>(initialState);
  const [analysis, setAnalysis] = useState<AudioAnalysis | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // 清理函数
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current.load();
      }
    };
  }, []);

  const getAudioElement = useCallback(() => {
    if (!audioRef.current) {
      const audio = new Audio();
      audio.preload = 'metadata';
      audio.crossOrigin = 'anonymous';
      audio.setAttribute('playsinline', 'true');
      audioRef.current = audio;
    }

    return audioRef.current;
  }, []);

  const load = useCallback((src: string) => {
    const audio = getAudioElement();
    audio.pause();
    audio.preload = 'metadata';
    audio.crossOrigin = 'anonymous';
    audio.setAttribute('playsinline', 'true');

    setAnalysis(null);
    setState(prev => ({
      ...prev,
      isPlaying: false,
      isPaused: false,
      currentTime: 0,
      duration: 0,
      isLoading: true,
      error: undefined,
    }));

    if (audio.src === src) {
      audio.currentTime = 0;
      audio.load();
      return;
    }

    audio.src = src;
    audio.load();

    audio.onloadedmetadata = () => {
      setState(prev => ({
        ...prev,
        duration: audio.duration,
        isLoading: false,
      }));

      if (autoPlay) {
        void audio.play().catch(() => {
          const errorMessage = t('errors.audioLoadFailed');
          setState(prev => ({ ...prev, error: errorMessage, isLoading: false }));
          onError?.(errorMessage);
        });
      }
    };

    audio.ondurationchange = () => {
      setState(prev => ({
        ...prev,
        duration: Number.isFinite(audio.duration) ? audio.duration : prev.duration,
      }));
    };

    audio.ontimeupdate = () => {
      setState(prev => ({ ...prev, currentTime: audio.currentTime }));
      onTimeUpdate?.(audio.currentTime);
    };

    audio.onplay = () => {
      setState(prev => ({ ...prev, isPlaying: true, isPaused: false }));
      onPlay?.();
    };

    audio.onpause = () => {
      setState(prev => ({ ...prev, isPlaying: false, isPaused: true }));
      onPause?.();
    };

    audio.onended = () => {
      setState(prev => ({ ...prev, isPlaying: false, isPaused: false, currentTime: 0 }));
      onEnded?.();
    };

    audio.onerror = () => {
      const errorMessage = t('errors.audioLoadFailed');
      setState(prev => ({ ...prev, error: errorMessage, isLoading: false }));
      onError?.(errorMessage);
    };

    audio.onvolumechange = () => {
      setState(prev => ({
        ...prev,
        volume: audio.volume,
        isMuted: audio.muted,
      }));
    };
  }, [autoPlay, getAudioElement, onPlay, onPause, onEnded, onTimeUpdate, onError, t]);

  const play = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio?.src) {
      return;
    }

    try {
      await audio.play();
    } catch {
      const errorMessage = t('errors.audioLoadFailed');
      setState(prev => ({ ...prev, error: errorMessage, isLoading: false }));
      onError?.(errorMessage);
    }
  }, [onError, t]);

  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
  }, []);

  const toggle = useCallback(async () => {
    if (state.isPlaying) {
      pause();
    } else {
      await play();
    }
  }, [state.isPlaying, play, pause]);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setState(prev => ({ ...prev, isPlaying: false, isPaused: false, currentTime: 0 }));
    }
  }, []);

  const seek = useCallback((time: number) => {
    if (audioRef.current) {
      const nextTime = Math.max(0, Math.min(time, state.duration || Number.POSITIVE_INFINITY));
      audioRef.current.currentTime = nextTime;
      setState(prev => ({ ...prev, currentTime: nextTime }));
    }
  }, [state.duration]);

  const setVolume = useCallback((volume: number) => {
    if (audioRef.current) {
      const nextVolume = Math.max(0, Math.min(1, volume));
      audioRef.current.volume = nextVolume;
      if (audioRef.current.muted && nextVolume > 0) {
        audioRef.current.muted = false;
      }
      setState(prev => ({
        ...prev,
        volume: nextVolume,
        isMuted: audioRef.current?.muted ?? prev.isMuted,
      }));
    }
  }, []);

  const toggleMute = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.muted = !audioRef.current.muted;
      setState(prev => ({ ...prev, isMuted: audioRef.current?.muted ?? prev.isMuted }));
    }
  }, []);

  const setPlaybackRate = useCallback((rate: number) => {
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
    }
    setState(prev => ({ ...prev, playbackRate: rate }));
  }, []);

  // 分析音频并生成波形数据
  const analyzeAudio = useCallback(async (): Promise<AudioAnalysis | null> => {
    if (!audioRef.current?.src) return null;

    try {
      const response = await fetch(audioRef.current.src);
      const arrayBuffer = await response.arrayBuffer();
      const format = inferAudioFormat(audioRef.current.src, response.headers.get('content-type'));
      
      const offlineContext = new OfflineAudioContext(1, 44100 * 60, 44100);
      const audioBuffer = await offlineContext.decodeAudioData(arrayBuffer);
      
      const rawData = audioBuffer.getChannelData(0);
      const samples = 200; // 波形采样数
      const blockSize = Math.max(1, Math.floor(rawData.length / samples));
      const waveformData: number[] = [];

      if (rawData.length === 0) {
        waveformData.push(...Array.from({ length: samples }, () => 0));
      }

      for (let i = 0; i < samples && rawData.length > 0; i++) {
        let sum = 0;
        let sampleCount = 0;
        const start = i * blockSize;
        const end = Math.min(start + blockSize, rawData.length);

        for (let j = start; j < end; j++) {
          sum += Math.abs(rawData[j]);
          sampleCount += 1;
        }

        waveformData.push(sampleCount === 0 ? 0 : sum / sampleCount);
      }

      while (waveformData.length < samples) {
        waveformData.push(0);
      }

      // 归一化
      const maxValue = Math.max(...waveformData);
      const normalizedData = maxValue > 0 ? waveformData.map(v => v / maxValue) : waveformData;

      // 以单次遍历统计整段音频，避免大数组展开触发调用栈溢出。
      const silenceThreshold = 0.01;
      let silentSamples = 0;
      let peakAmplitude = 0;
      let amplitudeSum = 0;

      for (const sample of rawData) {
        const amplitude = Math.abs(sample);
        amplitudeSum += amplitude;

        if (amplitude > peakAmplitude) {
          peakAmplitude = amplitude;
        }

        if (amplitude < silenceThreshold) {
          silentSamples += 1;
        }
      }

      const silenceRatio = silentSamples / rawData.length;
      const averageAmplitude = amplitudeSum / rawData.length;

      const analysisResult: AudioAnalysis = {
        duration: audioBuffer.duration,
        sampleRate: audioBuffer.sampleRate,
        channels: audioBuffer.numberOfChannels,
        bitRate: 0, // 需要从文件头读取
        format,
        sourceSize: arrayBuffer.byteLength,
        waveformData: normalizedData,
        peakAmplitude,
        averageAmplitude,
        silenceRatio,
      };

      setAnalysis(analysisResult);
      return analysisResult;
    } catch (error) {
      console.error('音频分析失败:', error);
      return null;
    }
  }, []);

  return {
    state,
    analysis,
    audioRef,
    canvasRef,
    load,
    play,
    pause,
    toggle,
    stop,
    seek,
    setVolume,
    toggleMute,
    setPlaybackRate,
    analyzeAudio,
  };
}

// 格式化时间
export function formatTime(seconds: number): string {
  if (!isFinite(seconds) || isNaN(seconds)) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
