import { renderHook, waitFor } from '@testing-library/react';

import type { AudioAnalysis, ProcessedAudio } from '@/lib/types';
import { useProcessedAudioSession } from './useProcessedAudioSession';

const loadMock = jest.fn();
const analyzeAudioMock = jest.fn();

const mockPlaybackState = {
  isPlaying: false,
  isPaused: false,
  currentTime: 0,
  duration: 12.4,
  volume: 1,
  isMuted: false,
  playbackRate: 1,
  isLoading: false,
};

jest.mock('./useAudioPlayer', () => ({
  useAudioPlayer: () => ({
    state: mockPlaybackState,
    analysis: null,
    audioRef: { current: null },
    canvasRef: { current: null },
    load: loadMock,
    play: jest.fn(),
    pause: jest.fn(),
    toggle: jest.fn(),
    stop: jest.fn(),
    seek: jest.fn(),
    setVolume: jest.fn(),
    toggleMute: jest.fn(),
    setPlaybackRate: jest.fn(),
    analyzeAudio: analyzeAudioMock,
  }),
}));

jest.mock('@/lib/api/model-api', () => ({
  modelApi: {
    saveAudio: jest.fn(),
  },
}));

jest.mock('sonner', () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    message: jest.fn(),
  },
}));

jest.mock('next-intl', () => ({
  useTranslations: () => (key: string) => key,
}));

const baseAudio: ProcessedAudio = {
  id: 'task-1',
  data: new ArrayBuffer(0),
  url: 'http://localhost:8000/audio.wav',
  fileName: 'enhanced.wav',
  format: 'wav',
  duration: 0,
  sampleRate: 44100,
  size: 0,
  createdAt: new Date('2026-03-13T00:00:00Z'),
};

const analysisResult: AudioAnalysis = {
  duration: 12.4,
  sampleRate: 48000,
  channels: 2,
  bitRate: 0,
  format: 'wav',
  waveformData: [0.1, 0.3, 0.6],
  peakAmplitude: 0.9,
  averageAmplitude: 0.4,
  silenceRatio: 0.1,
  sourceSize: 4096,
};

describe('useProcessedAudioSession', () => {
  const saveAudioMock = jest.requireMock('@/lib/api/model-api').modelApi.saveAudio as jest.Mock;
  const toastSuccessMock = jest.requireMock('sonner').toast.success as jest.Mock;

  beforeEach(() => {
    jest.clearAllMocks();
    (global.fetch as jest.Mock | undefined) = jest.fn().mockResolvedValue({
      ok: true,
      arrayBuffer: async () => new ArrayBuffer(16),
    });
    (window as Window & { __TAURI__?: unknown }).__TAURI__ = {};
  });

  it('hydrates resolved metadata from the analyzed audio asset', async () => {
    analyzeAudioMock.mockResolvedValue(analysisResult);

    const { result } = renderHook(() =>
      useProcessedAudioSession({
        audio: baseAudio,
        preferences: {
          autoSave: false,
          notifications: false,
        },
      }),
    );

    await waitFor(() => {
      expect(loadMock).toHaveBeenCalledWith(baseAudio.url);
      expect(result.current.resolvedAudio?.duration).toBe(12.4);
    });

    expect(result.current.resolvedAudio?.sampleRate).toBe(48000);
    expect(result.current.resolvedAudio?.size).toBe(4096);
  });

  it('preserves the output session when analysis fails', async () => {
    analyzeAudioMock.mockResolvedValue(null);

    const { result } = renderHook(() =>
      useProcessedAudioSession({
        audio: baseAudio,
        preferences: {
          autoSave: false,
          notifications: false,
        },
      }),
    );

    await waitFor(() => {
      expect(loadMock).toHaveBeenCalledWith(baseAudio.url);
      expect(result.current.analysisError).toBe('audioAnalyzer.analysisUnavailable');
    });

    expect(result.current.resolvedAudio?.id).toBe(baseAudio.id);
    expect(result.current.analysis).toBeNull();
  });

  it('runs capability-gated completion behavior from the shared session', async () => {
    analyzeAudioMock.mockResolvedValue(analysisResult);

    renderHook(() =>
      useProcessedAudioSession({
        audio: baseAudio,
        preferences: {
          autoSave: true,
          notifications: true,
        },
      }),
    );

    await waitFor(() => {
      expect(saveAudioMock).toHaveBeenCalled();
      expect(toastSuccessMock).toHaveBeenCalled();
    });
  });
});
