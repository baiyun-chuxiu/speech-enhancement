# Linux 部署

## 前置要求

- Ubuntu 22.04+ / Fedora 38+ / Arch Linux
- Rust 工具链
- Node.js 20+ & pnpm
- Python 3.10+ & uv

### 系统依赖

=== "Ubuntu / Debian"

    ```bash
    sudo apt-get install -y \
      libgtk-3-dev \
      libwebkit2gtk-4.1-dev \
      libappindicator3-dev \
      librsvg2-dev \
      patchelf \
      libssl-dev
    ```

=== "Fedora"

    ```bash
    sudo dnf install -y \
      gtk3-devel \
      webkit2gtk4.1-devel \
      libappindicator-gtk3-devel \
      librsvg2-devel \
      patchelf \
      openssl-devel
    ```

=== "Arch Linux"

    ```bash
    sudo pacman -S \
      gtk3 \
      webkit2gtk-4.1 \
      libappindicator-gtk3 \
      librsvg \
      patchelf \
      openssl
    ```

## 构建步骤

### 1. 构建 Sidecar

```bash
pnpm build:sidecar-linux
# 输出: src-tauri/binaries/audio-enhancer-server-x86_64-unknown-linux-gnu
```

### 2. 构建 Tauri 应用

```bash
pnpm tauri build
```

产物位于 `src-tauri/target/release/bundle/`：

```text
bundle/
├── appimage/
│   └── infocom-app_0.1.0_amd64.AppImage
└── deb/
    └── infocom-app_0.1.0_amd64.deb
```

## 安装包格式

### AppImage

便携式格式，无需安装：

```bash
chmod +x infocom-app_0.1.0_amd64.AppImage
./infocom-app_0.1.0_amd64.AppImage
```

特点：

- 单文件分发，免安装
- 跨 Linux 发行版兼容
- 包含所有依赖
- 可通过 AppImageLauncher 集成到桌面

### DEB 包

Debian/Ubuntu 系统标准安装包：

```bash
sudo dpkg -i infocom-app_0.1.0_amd64.deb
# 或
sudo apt install ./infocom-app_0.1.0_amd64.deb
```

安装后从应用菜单启动，或命令行运行：

```bash
infocom-app
```

## 分发

### GitHub Releases

上传 `.AppImage` 和 `.deb` 到 GitHub Releases，覆盖大多数 Linux 发行版用户。

### Flatpak（可选）

可以创建 Flatpak 清单文件将应用发布到 Flathub。

### Snap（可选）

可以创建 snapcraft.yaml 将应用发布到 Snap Store。

## 故障排除

### WebKitGTK 缺失

```text
error: could not find system library 'webkit2gtk-4.1'
```

安装对应系统的 WebKitGTK 开发包（见上方系统依赖）。

### AppImage 无法运行

```bash
# 确保 FUSE 已安装
sudo apt-get install libfuse2

# 或以 --appimage-extract-and-run 模式运行
./infocom-app.AppImage --appimage-extract-and-run
```

### Sidecar 权限

确保 Sidecar 二进制文件有执行权限：

```bash
chmod +x src-tauri/binaries/audio-enhancer-server-x86_64-unknown-linux-gnu
```

### GPU 加速（CUDA）

在有 NVIDIA GPU 的 Linux 系统上：

1. 安装 NVIDIA 驱动
2. 安装 CUDA Toolkit
3. 安装 PyTorch CUDA 版本：`uv pip install torch --index-url https://download.pytorch.org/whl/cu121`
4. 设置 `ENHANCER_DEVICE=cuda`
