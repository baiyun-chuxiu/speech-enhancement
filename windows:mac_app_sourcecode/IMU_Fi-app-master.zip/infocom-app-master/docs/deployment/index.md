# 部署

InfoCom App 支持 Web 部署和桌面应用分发两种模式。

## 部署模式对比

| 模式 | 适用场景 | 后端要求 |
| --- | --- | --- |
| Web 部署 | 静态站点托管 + 独立后端 | 需单独部署 Python 后端 |
| 桌面应用 | 终端用户分发 | Sidecar 内嵌（无需额外部署） |

## 章节导航

- [**Web 部署**](web.md) — Vercel / Nginx 静态站点部署
- [**macOS**](macos.md) — macOS 桌面应用构建与分发
- [**Windows**](windows.md) — Windows 桌面应用构建与分发
- [**Linux**](linux.md) — Linux 桌面应用构建与分发
