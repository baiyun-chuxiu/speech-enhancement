# Windows 部署

## 前置要求

- Windows 10/11 (64-bit)
- Visual Studio C++ Build Tools (通过 Visual Studio Installer)
- Rust 工具链
- Node.js 20+ & pnpm
- Python 3.10+ & uv

## 构建步骤

### 1. 构建 Sidecar

```powershell
pnpm build:sidecar-win
# 输出: src-tauri/binaries/audio-enhancer-server-x86_64-pc-windows-msvc.exe
```

### 2. 构建 Tauri 应用

```powershell
pnpm tauri build
```

产物位于 `src-tauri/target/release/bundle/`：

```text
bundle/
├── msi/
│   └── infocom-app_0.1.0_x64_en-US.msi
└── nsis/
    └── infocom-app_0.1.0_x64-setup.exe
```

## 安装包格式

### MSI 安装包

- 企业级分发标准格式
- 支持静默安装：`msiexec /i infocom-app.msi /quiet`
- 支持组策略部署
- 包含卸载程序注册

### NSIS 安装包

- 面向终端用户的安装向导
- 支持安装路径自定义
- 包含开始菜单快捷方式
- 更小的文件大小

## 代码签名（可选）

### 使用 SignTool

```powershell
# 使用 PFX 证书签名
signtool sign /f certificate.pfx /p password /fd sha256 /tr http://timestamp.digicert.com /td sha256 infocom-app_0.1.0_x64-setup.exe
```

### CI/CD 自动签名

在 GitHub Actions 中配置：

| Secret | 说明 |
| --- | --- |
| `WINDOWS_CERTIFICATE` | Base64 编码的 .pfx 证书 |
| `WINDOWS_CERTIFICATE_PASSWORD` | 证书密码 |

## 分发

### 直接分发

1. 上传 `.msi` 或 `setup.exe` 到 GitHub Releases
2. 用户下载并运行安装程序
3. 应用安装到 `C:\Program Files\infocom-app\`
4. 从开始菜单或桌面快捷方式启动

### Microsoft Store（可选）

Tauri 应用可打包为 MSIX 格式上传到 Microsoft Store。

## 故障排除

### WebView2 缺失

Windows 10 旧版本可能没有预装 WebView2。NSIS 安装程序会自动安装 WebView2 运行时。

也可手动安装：[Microsoft Edge WebView2](https://developer.microsoft.com/en-us/microsoft-edge/webview2/)

### VC++ 运行时缺失

如果出现 DLL 缺失错误，安装 [Visual C++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe)。

### 防病毒软件误报

未签名的 Sidecar 二进制可能触发 Windows Defender 或第三方杀毒软件。建议对生产版本进行代码签名。

### 防火墙

首次运行时 Windows 防火墙可能提示允许 Python Sidecar 的网络访问，需要允许以便前端连接后端。
