# macOS 部署

本文档是当前仓库的 macOS 发布速查表，只记录已经能和仓库脚本、Tauri 配置、以及 CI 工作流对上的路径。做不到自动化的部分会明确标注为限制，而不是默认视为“已支持”。

## 支持范围

| 路径 | 当前状态 | 说明 |
| --- | --- | --- |
| 本机未签名构建 | 已支持 | 适合开发测试或内部验证，默认会触发 Gatekeeper 警告。 |
| 本机已签名 + 已公证构建 | 已支持 | 需要 Apple Developer 证书和 notarization 凭据。 |
| GitHub Actions 自动化发布 | 部分就绪 | 工作流已有 macOS matrix，但当前没有预构建 sidecar、导入模型文件、或启用签名环境变量。 |
| `universal-apple-darwin` 通用应用包 | Tauri 支持，仓库未自动化完整链路 | Tauri 可产出 universal app，但当前仓库没有自动合并双架构 sidecar。 |

!!! warning "当前仓库限制"
    - `pnpm build:sidecar` / `pnpm build:sidecar-mac` 只会按当前 macOS 主机的 `rustc --print host-tuple` 生成 sidecar，不支持通过 `TAURI_TARGET=...` 把 PyInstaller sidecar 变成另一种 macOS 架构产物。
    - `.github/workflows/ci.yml` 当前直接执行 `pnpm tauri build --target ...`，但没有先构建 `src-tauri/binaries/audio-enhancer-server-*`，也不会提供 `server/models/` 中的真实模型文件。
    - `server/models/` 现在仓库里只有 `.gitkeep`。如果不放入实际模型文件，sidecar 可以被打包，但桌面应用运行时无法完成完整增强流程。

## 前置要求

- macOS 12+（Monterey 或更新）
- Xcode Command Line Tools
- Rust stable 工具链
- Node.js 20+、pnpm
- Python 3.10+、uv
- `server/models/` 中的真实模型文件（不能只有 `.gitkeep`）

## 1. 本机未签名构建

先确认当前主机的 Rust target triple：

```bash
rustc --print host-tuple
```

常见输出：

- Apple Silicon: `aarch64-apple-darwin`
- Intel Mac: `x86_64-apple-darwin`

然后构建 sidecar 和未签名的 Tauri 应用：

```bash
# 构建宿主机原生 sidecar
pnpm build:sidecar
# 等价的 macOS 别名：
# pnpm build:sidecar-mac

# 构建未签名应用包
pnpm tauri build --no-sign
```

预期产物：

```text
src-tauri/binaries/
├── audio-enhancer-server-aarch64-apple-darwin
└── audio-enhancer-server-x86_64-apple-darwin

src-tauri/target/release/bundle/
├── dmg/
│   └── infocom-app_0.1.0_<arch>.dmg
└── macos/
    └── infocom-app.app
```

!!! note "关于 `build:desktop`"
    `pnpm build:desktop` 仍然是便捷命令，等价于先跑 `pnpm build:sidecar` 再跑 `pnpm tauri build`。如果当前 shell 中没有配置 Apple 签名/公证环境变量，它会产生未签名构建；如果配置了签名环境变量，则会走签名路径。

!!! warning "关于通用二进制"
    `pnpm tauri build --target universal-apple-darwin` 只解决 Tauri app 本体。当前仓库没有自动构建并合并双架构 Python sidecar，因此不要把它当作完整可分发的 universal 桌面包流程。

## 2. 本机已签名与已公证构建

### 2.1 凭据路径

| 场景 | 需要的材料/变量 | 说明 |
| --- | --- | --- |
| 本地钥匙串签名 | Developer ID Application 证书，必要时 `APPLE_SIGNING_IDENTITY` | 适合开发机本地构建。 |
| 干净环境或 CI 导入证书 | `APPLE_CERTIFICATE`, `APPLE_CERTIFICATE_PASSWORD` | `APPLE_CERTIFICATE` 为 Base64 编码的 `.p12`，Tauri 可据此推断 `APPLE_SIGNING_IDENTITY`。 |
| Apple ID 公证 | `APPLE_ID`, `APPLE_PASSWORD`, `APPLE_TEAM_ID` | `APPLE_PASSWORD` 是 App-Specific Password。 |
| App Store Connect API key 公证 | `APPLE_API_KEY`, `APPLE_API_ISSUER`, `APPLE_API_KEY_PATH` | Tauri 2 支持；当前仓库工作流没有接入这条路径。 |

### 2.2 推荐的本机构建命令

如果证书已经导入本机钥匙串，可使用 Apple ID 路径完成签名与公证：

```bash
export APPLE_SIGNING_IDENTITY="Developer ID Application: Your Name (TEAM_ID)"
export APPLE_ID="your@email.com"
export APPLE_PASSWORD="xxxx-xxxx-xxxx-xxxx"
export APPLE_TEAM_ID="TEAMID1234"

pnpm build:sidecar
pnpm tauri build
```

如果你是在干净环境或 CI 上构建，再额外提供证书内容：

```bash
export APPLE_CERTIFICATE="$(base64 -i certificate.p12)"
export APPLE_CERTIFICATE_PASSWORD="certificate-password"
```

### 2.3 `--skip-stapling` 与手动验证

`pnpm tauri build --skip-stapling` 适合第一次 notarization 较慢时先放行构建，再稍后手动装订票据：

```bash
xcrun stapler staple src-tauri/target/release/bundle/dmg/infocom-app_0.1.0_aarch64.dmg
xcrun stapler validate src-tauri/target/release/bundle/dmg/infocom-app_0.1.0_aarch64.dmg
spctl -a -vv src-tauri/target/release/bundle/macos/infocom-app.app
```

如果你绕过了 Tauri 的自动公证流程，也可以手动提交：

```bash
xcrun notarytool submit \
  src-tauri/target/release/bundle/dmg/infocom-app_0.1.0_aarch64.dmg \
  --apple-id "your@email.com" \
  --password "xxxx-xxxx-xxxx-xxxx" \
  --team-id "TEAMID1234" \
  --wait
```

## 3. GitHub Actions 现状

当前 `.github/workflows/ci.yml` 的 macOS matrix 包含：

- `x86_64-apple-darwin`
- `aarch64-apple-darwin`

但它目前只执行：

```bash
pnpm tauri build --target ${{ matrix.target }}
```

这意味着当前工作流还**没有**完成下面这些桌面发布前置步骤：

1. 安装 Python / uv 并构建 host-matched sidecar。
2. 提供 `server/models/` 的真实模型文件。
3. 解开注释并注入 Apple 签名 / 公证环境变量。
4. 接入 App Store Connect API key 路径（如果团队要使用这条 notarization 方式）。

当前工作流里已经预留、但默认注释掉的 Apple ID 路径 secrets 为：

| Secret | 说明 |
| --- | --- |
| `APPLE_CERTIFICATE` | Base64 编码的 `.p12` 证书 |
| `APPLE_CERTIFICATE_PASSWORD` | 证书密码 |
| `APPLE_SIGNING_IDENTITY` | 签名身份。提供 `APPLE_CERTIFICATE` 时通常可推断。 |
| `APPLE_ID` | Apple ID 邮箱 |
| `APPLE_PASSWORD` | App-Specific Password |
| `APPLE_TEAM_ID` | Apple Developer Team ID |

!!! note "CI 结论"
    当前仓库的 GitHub Actions 更接近“通用 Tauri 构建模板”，而不是“已可直接发布 InfoCom App 的 macOS release pipeline”。

## 4. 维护交叉检查表

更新 macOS 发布文档前，优先检查下表对应的源码位置：

| 文档项 | 当前源码来源 |
| --- | --- |
| Sidecar 构建命令 | `package.json` 的 `build:sidecar` / `build:sidecar-mac` |
| Sidecar 输出命名规则 | `server/build_sidecar.py` |
| Tauri 侧 sidecar 期望路径 | `src-tauri/tauri.conf.json` 的 `bundle.externalBin` |
| DMG / `.app` 产物目录 | `pnpm tauri build --help` 与 `src-tauri/target/` 结构 |
| 支持的 macOS target matrix | `.github/workflows/ci.yml` |
| 当前工作流真正注入的 Apple secrets | `.github/workflows/ci.yml` 的注释模板 |
| 模型文件是否会打进 sidecar | `server/build_sidecar.py` 和 `server/models/` |

## 5. 故障排除

### `failed to create sidecar command`

先检查 sidecar 是否已按当前宿主机 triple 生成：

```bash
rustc --print host-tuple
ls -la src-tauri/binaries/
```

### Gatekeeper 阻止打开

未签名应用仅适合开发/测试，可右键点击“打开”绕过，或在终端运行：

```bash
xattr -cr /Applications/infocom-app.app
```

### 为什么 universal 构建后仍然不能直接分发

`universal-apple-darwin` 只解决 Tauri app 本体。这个仓库还没有自动生成并合并双架构 `audio-enhancer-server-*` sidecar，因此 universal 桌面包仍需额外实现流程。

详细的环境配置和开发说明请参考 [macOS 完整配置指南](../macos-guide.md)。

## 参考资料

- [Tauri 2 macOS 签名与公证](https://v2.tauri.app/distribute/sign/macos/)
- [Tauri CLI build 选项](https://v2.tauri.app/reference/cli/#build)
- [Apple App-Specific Passwords](https://support.apple.com/en-us/102654)
- [Apple notarization workflow](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow)
