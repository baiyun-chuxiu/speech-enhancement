# Web 部署

## 前端部署

Next.js 配置为静态导出模式，可以部署到任意静态站点托管服务。

### 构建

```bash
pnpm build
# 输出到 out/ 目录
```

### Vercel 部署

```bash
# 安装 Vercel CLI
npm i -g vercel

# 部署
vercel --prod
```

!!! note "环境变量"
    在 Vercel Dashboard 中配置 `NEXT_PUBLIC_API_URL` 指向后端服务地址。

### Nginx 部署

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/infocom-app/out;
    index index.html;

    location / {
        try_files $uri $uri.html $uri/ =404;
    }

    # 代理后端 API
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }

    location /ws/ {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

### GitHub Pages

项目配置了 GitHub Pages 部署文档站点：

```bash
# 构建 MkDocs 文档
mkdocs build

# 部署到 gh-pages 分支
mkdocs gh-deploy
```

## 后端部署

### 直接运行

```bash
cd server
uv run python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

### Docker 部署

```dockerfile
FROM python:3.12-slim

WORKDIR /app

# 安装 uv
RUN pip install uv

# 复制项目文件
COPY server/ .

# 安装依赖
RUN uv sync

# 复制模型文件
COPY server/models/ ./models/

EXPOSE 8000

CMD ["uv", "run", "python", "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### systemd 服务

```ini
[Unit]
Description=InfoCom Audio Enhancer Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/infocom-app/server
ExecStart=/opt/infocom-app/server/.venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5
Environment=ENHANCER_DEVICE=cuda
Environment=ENHANCER_MODELS_DIR=/opt/infocom-app/server/models

[Install]
WantedBy=multi-user.target
```

### 环境变量

Web 部署时的关键环境变量：

| 变量 | 前端/后端 | 说明 |
| --- | --- | --- |
| `NEXT_PUBLIC_API_URL` | 前端 | 后端 API 地址 |
| `ENHANCER_HOST` | 后端 | 监听地址 |
| `ENHANCER_PORT` | 后端 | 监听端口 |
| `ENHANCER_DEVICE` | 后端 | 计算设备 |
| `ENHANCER_CORS_ORIGINS` | 后端 | 允许的前端域名 |
