# InfoCom App — macOS 配置与使用完整指南

本文档详细介绍如何在 **macOS** 上配置开发环境、运行、构建和分发 InfoCom App（IMU 辅助音频增强桌面应用）。

---

## 目录

- [系统要求](#系统要求)
- [一、安装前置依赖](#一安装前置依赖)
  - [1.1 Homebrew](#11-homebrew)
  - [1.2 Xcode 命令行工具](#12-xcode-命令行工具)
  - [1.3 Node.js 与 pnpm](#13-nodejs-与-pnpm)
  - [1.4 Rust 工具链](#14-rust-工具链)
  - [1.5 Python 与 uv](#15-python-与-uv)
  - [1.6 PyInstaller（构建 Sidecar 时需要）](#16-pyinstaller构建-sidecar-时需要)
- [二、克隆与初始化项目](#二克隆与初始化项目)
  - [2.1 克隆代码](#21-克隆代码)
  - [2.2 安装前端依赖](#22-安装前端依赖)
  - [2.3 安装 Python 后端依赖](#23-安装-python-后端依赖)
  - [2.4 放置模型文件](#24-放置模型文件)
- [三、开发模式](#三开发模式)
  - [3.1 仅 Web 前端开发](#31-仅-web-前端开发)
  - [3.2 前后端联合开发](#32-前后端联合开发)
  - [3.3 Tauri 桌面应用开发](#33-tauri-桌面应用开发)
  - [3.4 环境变量配置](#34-环境变量配置)
- [四、测试](#四测试)
  - [4.1 单元测试（Jest）](#41-单元测试jest)
  - [4.2 端到端测试（Playwright）](#42-端到端测试playwright)
  - [4.3 Python 后端测试](#43-python-后端测试)
- [五、生产构建](#五生产构建)
  - [5.1 构建 Web 应用](#51-构建-web-应用)
  - [5.2 构建 Python Sidecar](#52-构建-python-sidecar)
  - [5.3 构建 macOS 桌面应用](#53-构建-macos-桌面应用)
- [六、macOS 代码签名与公证](#六macos-代码签名与公证)
  - [6.1 准备工作](#61-准备工作)
  - [6.2 配置签名环境变量](#62-配置签名环境变量)
  - [6.3 公证（Notarization）](#63-公证notarization)
- [七、分发](#七分发)
- [八、项目结构速览](#八项目结构速览)
- [九、API 速览](#九api-速览)
- [十、常见问题与故障排除](#十常见问题与故障排除)
- [十一、参考链接](#十一参考链接)

---

## 系统要求

| 项目 | 最低要求 | 推荐 |
| --- | --- | --- |
| **macOS 版本** | macOS 12 Monterey | macOS 14 Sonoma 或更新 |
| **芯片** | Intel x86_64 / Apple Silicon (M1+) | Apple Silicon (M1/M2/M3/M4) |
| **内存** | 8 GB | 16 GB+（模型推理更流畅） |
| **磁盘空间** | 10 GB（含工具链） | 20 GB+ |
| **Node.js** | 20.x | 22.x LTS |
| **Rust** | 1.77.2 | 最新 stable |
| **Python** | 3.10 | 3.12 |

---

## 一、安装前置依赖

### 1.1 Homebrew

macOS 上的包管理器，用于安装 Node.js、Python 等工具。

```bash
# 安装 Homebrew（如果尚未安装）
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Apple Silicon 用户需确保 Homebrew 在 PATH 中
# 将以下内容添加到 ~/.zshrc（如果 Homebrew 安装脚本未自动添加）
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zshrc
source ~/.zshrc

# 验证
brew --version
```

### 1.2 Xcode 命令行工具

Tauri 在 macOS 上需要 Xcode 命令行工具来编译原生代码。

```bash
# 安装 Xcode Command Line Tools
xcode-select --install

# 验证安装
xcode-select -p
# 预期输出: /Library/Developer/CommandLineTools 或 /Applications/Xcode.app/Contents/Developer

# 如果需要构建 iOS 版本，请安装完整 Xcode（从 App Store）
```

> **注意**：如果已安装完整版 Xcode，命令行工具会自动包含，无需单独安装。

### 1.3 Node.js 与 pnpm

```bash
# 方法 A：通过 Homebrew 安装
brew install node@22

# 方法 B：通过 nvm 安装（推荐，便于多版本管理）
brew install nvm
echo 'export NVM_DIR="$HOME/.nvm"' >> ~/.zshrc
echo '[ -s "/opt/homebrew/opt/nvm/nvm.sh" ] && \. "/opt/homebrew/opt/nvm/nvm.sh"' >> ~/.zshrc
source ~/.zshrc
nvm install 22
nvm use 22

# 验证 Node.js
node --version   # 应 >= 20.x
npm --version

# 安装 pnpm
npm install -g pnpm

# 验证 pnpm
pnpm --version   # 应 >= 8.x
```

### 1.4 Rust 工具链

```bash
# 安装 Rust（通过 rustup）
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# 按提示选择默认安装（选 1）
# 安装完成后加载环境
source "$HOME/.cargo/env"

# 验证
rustc --version   # 应 >= 1.77.2
cargo --version
rustup show       # 查看当前工具链与目标

# Apple Silicon 用户默认 target 为 aarch64-apple-darwin
# Intel Mac 用户默认 target 为 x86_64-apple-darwin
rustc --print host-tuple
```

#### 可选：添加交叉编译 target

```bash
# 如需在 Apple Silicon 上构建 Intel 版本（或反之）
rustup target add x86_64-apple-darwin
rustup target add aarch64-apple-darwin
```

### 1.5 Python 与 uv

本项目的 Python 后端使用 [uv](https://docs.astral.sh/uv/) 进行依赖管理。

```bash
# 安装 uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# 或通过 Homebrew
brew install uv

# 验证
uv --version

# uv 会自动管理 Python 版本，无需手动安装 Python
# 项目指定 Python 3.12（见 server/.python-version）
# 首次 uv sync 时会自动下载对应版本
```

#### 手动安装 Python（可选）

```bash
# 如果偏好手动管理 Python
brew install python@3.12

# 验证
python3 --version   # 应 >= 3.10，推荐 3.12
```

### 1.6 PyInstaller（构建 Sidecar 时需要）

仅在需要构建独立桌面应用时才需要安装 PyInstaller。

```bash
# 在项目的 Python 虚拟环境中安装
cd server
uv pip install pyinstaller
```

---

## 二、克隆与初始化项目

### 2.1 克隆代码

```bash
git clone https://github.com/AstroAir/infocom-app.git
cd infocom-app
```

### 2.2 安装前端依赖

```bash
pnpm setup:macos
```

该命令会检查 Xcode Command Line Tools、`uv` 和 `rustc`，然后执行：

- `pnpm install`
- `uv sync`（在 `server/` 目录）
- `pnpm tauri info`
- 在缺少 `.env.local` 时基于 `.env.local.example` 自动创建

模型文件仍需手动放到 `server/models/`。

如果你需要手动执行或排查初始化步骤，可使用下面的等价命令。

### 2.3 安装 Python 后端依赖

```bash
cd server
uv sync
cd ..
```

> `uv sync` 会自动创建 `.venv` 虚拟环境并安装所有依赖。

#### macOS Apple Silicon 上安装 PyTorch 说明

`uv sync` 默认安装 CPU 版 PyTorch。macOS Apple Silicon 设备支持 MPS (Metal Performance Shaders) 加速，**CPU 版 PyTorch 即可自动检测并使用 MPS**，无需特殊配置。

```bash
# 验证 MPS 是否可用（在虚拟环境中执行）
cd server
uv run python -c "import torch; print('MPS available:', torch.backends.mps.is_available())"
# Apple Silicon 设备预期输出: MPS available: True
```

### 2.4 放置模型文件

将以下模型文件放入 `server/models/` 目录：

```text
server/models/
├── generator_final.pth    (~30MB) — GAN 生成器（IMU → 视频位移）
└── best_model.pth         (~4MB)  — 音频降噪网络
```

> 模型文件不包含在 Git 仓库中，请联系项目负责人获取。

---

## 三、开发模式

### 3.1 仅 Web 前端开发

```bash
pnpm dev
```

访问 [http://localhost:3000](http://localhost:3000) 查看应用。修改文件后页面自动热更新。

### 3.2 前后端联合开发

同时启动 Next.js 前端和 Python 后端服务器：

```bash
# 方法 A：使用 concurrently 同时启动（推荐）
pnpm dev:all

# 方法 B：手动在两个终端分别启动
# 终端 1 - 前端
pnpm dev

# 终端 2 - 后端
pnpm dev:server
# 等效于: uv run --project server python -m server.main
```

- **前端**: [http://localhost:3000](http://localhost:3000)
- **后端 API**: [http://localhost:8000](http://localhost:8000)
- **API 文档 (Swagger)**: [http://localhost:8000/docs](http://localhost:8000/docs)

### 3.3 Tauri 桌面应用开发

```bash
pnpm tauri dev
```

此命令会：

1. 自动启动 Next.js 开发服务器（端口 3000）
2. 编译 Rust 代码
3. 启动桌面窗口应用
4. 自动启动 Python sidecar 服务（如果已构建 sidecar 二进制文件）

> **首次运行提示**：Rust 编译可能需要几分钟，后续增量编译会快很多。

#### 查看 Tauri 环境信息

```bash
pnpm tauri info
```

此命令输出当前 OS、Rust 版本、Node 版本、Tauri 版本等，用于排查环境问题。

### 3.4 环境变量配置

在项目根目录创建 `.env.local` 文件。若你已经执行过 `pnpm setup:macos`，该文件会在缺失时自动从 `.env.local.example` 生成：

```env
# ========== Next.js 前端 ==========
# 仅 NEXT_PUBLIC_ 前缀的变量会暴露给浏览器
NEXT_PUBLIC_ENHANCER_API_URL=http://localhost:8000
NEXT_PUBLIC_API_URL=http://localhost:8000

# ========== Python 后端 ==========
ENHANCER_HOST=0.0.0.0
ENHANCER_PORT=8000
ENHANCER_DEVICE=auto             # 可保持 auto；Apple Silicon 也可按需改成 mps
ENHANCER_MODELS_DIR=./server/models
ENHANCER_GENERATOR_PATH=./server/models/generator_final.pth
ENHANCER_DENOISE_PATH=./server/models/best_model.pth
ENHANCER_CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `ENHANCER_HOST` | `0.0.0.0` | 后端监听地址 |
| `ENHANCER_PORT` | `8000` | 后端端口 |
| `ENHANCER_DEVICE` | 自动检测 | 计算设备：`cpu`、`cuda`、`mps` |
| `ENHANCER_MODELS_DIR` | `./server/models` | 模型文件目录 |
| `ENHANCER_GENERATOR_PATH` | `{models_dir}/generator_final.pth` | GAN 生成器路径 |
| `ENHANCER_DENOISE_PATH` | `{models_dir}/best_model.pth` | 降噪模型路径 |
| `ENHANCER_CORS_ORIGINS` | `http://localhost:3000,...` | CORS 允许的来源 |

---

## 四、测试

### 4.1 单元测试（Jest）

```bash
# 运行所有单元测试
pnpm test

# 观察模式（文件变更自动重跑）
pnpm test:watch

# 生成覆盖率报告
pnpm test:coverage
```

### 4.2 端到端测试（Playwright）

```bash
# 安装 Playwright 浏览器（仅首次）
pnpm exec playwright install

# 运行所有 E2E 测试
pnpm test:e2e

# 仅运行 WebKit（Safari 引擎）测试
pnpm test:e2e:webkit

# 带 UI 界面的交互式测试
pnpm test:e2e:ui

# 带浏览器窗口的测试（可见模式）
pnpm test:e2e:headed

# 查看测试报告
pnpm test:e2e:report
```

### 4.3 Python 后端测试

```bash
cd server

# 安装开发依赖（包含 pytest）
uv sync --dev

# 运行测试
uv run pytest
```

---

## 五、生产构建

### 5.1 构建 Web 应用

```bash
pnpm build
```

输出目录为 `out/`，可部署到任何静态托管服务（Vercel、Netlify、Nginx 等）。

### 5.2 构建 Python Sidecar

Sidecar 是将 Python 后端打包为独立可执行文件，随桌面应用一起分发。

```bash
# 推荐：按宿主机 triple 自动构建
pnpm build:sidecar

# macOS 专用别名（行为与上面等价）
pnpm build:sidecar-mac
```

> **重要**：sidecar 二进制文件名必须包含正确的 Rust target triple 后缀。
>
> - Apple Silicon: `audio-enhancer-server-aarch64-apple-darwin`
> - Intel Mac: `audio-enhancer-server-x86_64-apple-darwin`
>
> 脚本 `build_sidecar.py` 会自动检测并使用当前宿主机的 triple。当前仓库**不支持**通过 `TAURI_TARGET=...` 把 PyInstaller sidecar 交叉生成另一种 macOS 架构文件名。

!!! warning "模型文件是运行前置条件"
    当前仓库的 `server/models/` 只跟踪 `.gitkeep`。如果没有补充真实模型文件，sidecar 仍可被构建和打包，但桌面应用无法完成完整增强流程。

构建完成后，输出文件位于：

```text
src-tauri/binaries/audio-enhancer-server-aarch64-apple-darwin
# 或
src-tauri/binaries/audio-enhancer-server-x86_64-apple-darwin
```

#### 验证 Sidecar

```bash
# 直接运行测试
./src-tauri/binaries/audio-enhancer-server-$(rustc --print host-tuple)

# 应看到 FastAPI 服务启动日志
# 按 Ctrl+C 停止
```

### 5.3 构建 macOS 桌面应用

```bash
# 一键构建（先构建 sidecar，再构建 Tauri 应用）
pnpm build:desktop

# 或分步执行
pnpm build:sidecar          # 步骤 1: 构建 Python sidecar
pnpm tauri build --no-sign   # 步骤 2: 构建未签名 Tauri 桌面应用
```

`pnpm build:desktop` 是否走签名流程，取决于你当前 shell 是否已经配置 Apple 相关环境变量；`--no-sign` 则会显式生成未签名构建，更适合本机调试和内部验证。

构建产物位于：

```text
src-tauri/target/release/bundle/
├── dmg/
│   └── infocom-app_0.1.0_aarch64.dmg    # DMG 安装镜像
└── macos/
    └── infocom-app.app/                  # 应用程序包
```

#### 构建选项

```bash
# 仅构建 DMG
pnpm tauri build --bundles dmg

# 构建 Debug 版本（含调试符号）
pnpm tauri build --debug

# 为指定架构构建
pnpm tauri build --target aarch64-apple-darwin    # Apple Silicon
pnpm tauri build --target x86_64-apple-darwin     # Intel

# 构建通用二进制（Universal Binary，同时支持两种架构）
pnpm tauri build --target universal-apple-darwin
```

!!! warning "关于 `universal-apple-darwin`"
    Tauri 可以构建 universal app，但当前仓库没有自动生成并合并双架构 Python sidecar，因此这不是一条“可直接发布”的完整流程。

---

## 六、macOS 代码签名与公证

### 6.1 准备工作

要在 macOS 上分发应用（不触发 Gatekeeper 警告），需要：

1. **Apple Developer 账户**（$99/年）：[developer.apple.com](https://developer.apple.com)
2. **Developer ID Application 证书**：用于签名应用
3. **Developer ID Installer 证书**（可选）：用于签名 .pkg 安装包

#### 创建证书

1. 登录 [Apple Developer](https://developer.apple.com/account/resources/certificates/list)
2. 点击 **+** 创建新证书
3. 选择 **Developer ID Application**
4. 按提示生成 CSR 并上传
5. 下载证书，双击安装到钥匙串

#### 创建 App 专用密码

用于公证（Notarization）：

1. 访问 [appleid.apple.com](https://appleid.apple.com)
2. 登录 → 安全 → App 专用密码 → 生成密码
3. 保存密码，后续配置时使用

### 6.2 配置签名环境变量

在 `.env.local` 或构建环境中设置：

```bash
# 代码签名（证书已在本机钥匙串时）
export APPLE_SIGNING_IDENTITY="Developer ID Application: Your Name (TEAM_ID)"

# 公证（Apple ID 路径）
export APPLE_ID="your@email.com"
export APPLE_PASSWORD="xxxx-xxxx-xxxx-xxxx"    # App 专用密码
export APPLE_TEAM_ID="XXXXXXXXXX"               # 10 位团队 ID
```

如果是在 CI 或干净环境里导入 `.p12` 证书，再额外提供：

```bash
export APPLE_CERTIFICATE="$(base64 -i certificate.p12)"
export APPLE_CERTIFICATE_PASSWORD="certificate-password"
```

> 当 `APPLE_CERTIFICATE` 存在时，Tauri 通常可以自动推断 `APPLE_SIGNING_IDENTITY`。

Tauri 2 也支持 App Store Connect API key 路径：

```bash
export APPLE_API_KEY="AuthKey_ABC123XYZ"
export APPLE_API_ISSUER="00000000-0000-0000-0000-000000000000"
export APPLE_API_KEY_PATH="/absolute/path/to/AuthKey_ABC123XYZ.p8"
```

> 当前仓库的 GitHub Actions 模板还没有接入这组 API key 变量。

或者使用 Keychain 中的签名身份：

```bash
# 查看可用的签名身份
security find-identity -v -p codesigning

# 输出示例:
# 1) ABCDEF... "Developer ID Application: Your Name (TEAM_ID)"
```

Tauri 在构建时会自动读取这些环境变量并完成签名。详见 [Tauri macOS 签名文档](https://v2.tauri.app/distribute/sign/macos/)。

### 6.3 公证（Notarization）

公证是 Apple 的安全审查流程，确保应用不含恶意软件。Tauri 2.x 在构建时可自动完成公证。

```bash
# 设置好环境变量后，正常构建即会自动签名和公证
APPLE_SIGNING_IDENTITY="Developer ID Application: ..." \
APPLE_ID="your@email.com" \
APPLE_PASSWORD="xxxx-xxxx-xxxx-xxxx" \
APPLE_TEAM_ID="XXXXXXXXXX" \
pnpm build:sidecar && \
pnpm tauri build
```

> **提示**：公证需要联网。首次 notarization 可能明显更慢，此时可以先使用 `pnpm tauri build --skip-stapling`，后续再手动 `stapler staple`。

#### 手动公证（如需单独操作）

```bash
# 提交公证
xcrun notarytool submit path/to/InfoCom\ App.dmg \
  --apple-id "your@email.com" \
  --password "xxxx-xxxx-xxxx-xxxx" \
  --team-id "XXXXXXXXXX" \
  --wait

# 装订票据（Staple）
xcrun stapler staple path/to/InfoCom\ App.dmg
xcrun stapler validate path/to/InfoCom\ App.dmg
```

---

## 七、分发

### DMG 安装镜像

构建完成后将 `.dmg` 文件分发给用户：

```text
src-tauri/target/release/bundle/dmg/infocom-app_0.1.0_aarch64.dmg
```

用户使用方式：

1. 双击 `.dmg` 文件挂载
2. 将 **InfoCom App** 拖拽到 **Applications** 文件夹
3. 从启动台或应用程序文件夹打开

### 未签名应用的临时运行

如果未进行代码签名，用户首次打开会被 Gatekeeper 阻止，可通过以下方式绕过（仅限开发/测试）：

```bash
# 方法 1：从系统偏好设置中允许
# 系统偏好设置 → 隐私与安全性 → 点击"仍要打开"

# 方法 2：移除隔离属性
xattr -cr /Applications/InfoCom\ App.app

# 方法 3：临时允许所有来源（不推荐用于生产）
sudo spctl --master-disable
```

---

## 八、项目结构速览

```text
infocom-app/
├── app/                          # Next.js App Router 页面
│   ├── layout.tsx               # 根布局（字体、主题、国际化）
│   ├── page.tsx                 # 首页
│   ├── globals.css              # 全局样式 + Tailwind CSS v4
│   ├── upload/                  # 文件上传页
│   ├── settings/                # 设置页
│   └── help/                    # 帮助页
├── components/
│   ├── ui/                      # shadcn/ui 基础组件（Button, Dialog, ...）
│   └── upload/                  # 上传功能业务组件（AudioPlayer, AudioAnalyzer, ...）
├── hooks/                       # 自定义 React Hooks
├── lib/
│   ├── api/                     # API 客户端（enhancer-api.ts 等）
│   ├── utils/                   # 工具函数（data-parser.ts 等）
│   ├── types.ts                 # 全局类型定义
│   └── utils.ts                 # 通用工具（cn 等）
├── i18n/                        # 国际化配置（next-intl）
├── messages/                    # 国际化翻译文件
│   ├── en.json                  # 英文
│   └── zh-CN.json               # 简体中文
├── server/                      # Python FastAPI 后端
│   ├── main.py                  # 服务入口
│   ├── config.py                # 配置管理
│   ├── routes.py                # API 路由
│   ├── pipeline.py              # 增强处理管线
│   ├── models.py                # 深度学习模型定义
│   ├── schemas.py               # Pydantic 数据模型
│   ├── models/                  # 模型权重文件（.pth）
│   ├── build_sidecar.py         # Sidecar 构建脚本
│   └── pyproject.toml           # Python 项目配置
├── src-tauri/                   # Tauri 桌面应用（Rust）
│   ├── src/
│   │   ├── main.rs              # Rust 入口
│   │   ├── lib.rs               # 应用初始化 & Sidecar 管理
│   │   └── commands/            # Tauri 命令（前端可调用的 Rust 函数）
│   ├── binaries/                # Sidecar 二进制文件（构建产物）
│   ├── capabilities/            # Tauri 权限配置
│   ├── icons/                   # 应用图标
│   ├── tauri.conf.json          # Tauri 主配置
│   └── Cargo.toml               # Rust 依赖
├── e2e/                         # Playwright E2E 测试
├── public/                      # 静态资源
├── package.json                 # Node.js 依赖和脚本
├── next.config.ts               # Next.js 配置
├── tsconfig.json                # TypeScript 配置
└── eslint.config.mjs            # ESLint 配置
```

---

## 九、API 速览

Python 后端在 `http://localhost:8000` 提供以下 API 端点：

| 方法 | 端点 | 说明 |
| --- | --- | --- |
| GET | `/health` | 健康检查 |
| GET | `/api/v1/system/info` | 系统信息（设备、模型状态等） |
| POST | `/api/v1/files/upload` | 上传文件 |
| GET | `/api/v1/files/download/{id}` | 下载结果文件 |
| POST | `/api/v1/enhance` | 启动增强处理（multipart 上传） |
| POST | `/api/v1/enhance/uploaded` | 启动增强处理（使用已上传文件） |
| GET | `/api/v1/tasks/{task_id}` | 查询任务状态 |
| POST | `/api/v1/tasks/{task_id}/cancel` | 取消任务 |
| WS | `/ws/tasks/{task_id}` | 实时进度推送（WebSocket） |

> 交互式 API 文档：启动后端后访问 [http://localhost:8000/docs](http://localhost:8000/docs)

---

## 十、常见问题与故障排除

### 10.1 Xcode 命令行工具相关

#### `xcrun: error: invalid active developer path`

```bash
# 重新安装命令行工具
sudo rm -rf /Library/Developer/CommandLineTools
xcode-select --install
```

#### Xcode license 未接受

```bash
sudo xcodebuild -license accept
```

### 10.2 端口冲突

#### `Port 3000 already in use`

```bash
# 查找并终止占用 3000 端口的进程
lsof -ti:3000 | xargs kill -9
```

#### `Port 8000 already in use`

```bash
lsof -ti:8000 | xargs kill -9
```

### 10.3 Rust / Tauri 构建问题

#### Tauri 构建失败

```bash
# 检查 Tauri 环境
pnpm tauri info

# 更新 Rust 工具链
rustup update

# 清理 Rust 构建缓存并重新编译
cd src-tauri && cargo clean && cd ..
pnpm tauri build
```

#### Apple Silicon 上 `cargo build` 出现链接错误

```bash
# 确保 Xcode CLT 正确安装
xcode-select -p

# 如果指向错误路径，重置
sudo xcode-select -r
```

### 10.4 Python / Sidecar 问题

#### `uv sync` 失败

```bash
# 确保 uv 已安装
uv --version

# 清理并重新同步
cd server
rm -rf .venv
uv sync
```

#### PyInstaller 构建的 sidecar 无法运行

```bash
# 直接运行测试
./src-tauri/binaries/audio-enhancer-server-aarch64-apple-darwin

# 如果报 "permission denied"
chmod +x ./src-tauri/binaries/audio-enhancer-server-aarch64-apple-darwin

# 如果报 "cannot be opened because the developer cannot be verified"
xattr -cr ./src-tauri/binaries/audio-enhancer-server-aarch64-apple-darwin
```

#### MPS (Metal) 设备检测失败

```bash
# 验证 PyTorch 版本（需 >= 2.0）
cd server
uv run python -c "import torch; print(torch.__version__); print('MPS:', torch.backends.mps.is_available())"

# 如果 MPS 不可用但你使用的是 Apple Silicon，尝试更新 PyTorch
uv pip install --upgrade torch
```

### 10.5 Node.js / 前端问题

#### 模块未找到错误

```bash
# 清除 Next.js 缓存
rm -rf .next

# 重新安装依赖
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

#### `next: command not found`

```bash
# 这是 pnpm 自带的全局 PATH 初始化命令，不是仓库的一键初始化命令
pnpm setup
source ~/.zshrc

# 项目级的 macOS 一键初始化命令仍然是：
pnpm setup:macos
```

### 10.6 Tauri Sidecar 启动失败

#### 桌面应用启动后 Python 服务未运行

检查 sidecar 二进制文件是否存在且文件名正确：

```bash
ls -la src-tauri/binaries/
# 应看到: audio-enhancer-server-aarch64-apple-darwin (Apple Silicon)
#      或: audio-enhancer-server-x86_64-apple-darwin  (Intel)
```

确认文件名中的 target triple 与当前系统匹配：

```bash
rustc --print host-tuple
```

确认 `tauri.conf.json` 中 `externalBin` 配置正确：

```json
{
  "bundle": {
    "externalBin": ["binaries/audio-enhancer-server"]
  }
}
```

> Tauri 会自动根据当前平台追加 target triple 后缀来查找正确的 sidecar 文件。

### 10.7 macOS Gatekeeper 问题

#### `"InfoCom App" is damaged and can't be opened`

```bash
xattr -cr /Applications/InfoCom\ App.app
```

#### `"InfoCom App" can't be opened because Apple cannot check it for malicious software`

前往 **系统偏好设置 → 隐私与安全性**，找到被阻止的应用并点击 **仍要打开**。

---

## 十一、参考链接

### 项目核心技术

| 技术 | 文档 |
| --- | --- |
| **Next.js 16** | [nextjs.org/docs](https://nextjs.org/docs) |
| **React 19** | [react.dev](https://react.dev) |
| **Tauri 2.x** | [v2.tauri.app](https://v2.tauri.app) |
| **Tailwind CSS v4** | [tailwindcss.com/docs](https://tailwindcss.com/docs) |
| **shadcn/ui** | [ui.shadcn.com](https://ui.shadcn.com) |
| **Zustand** | [zustand-demo.pmnd.rs](https://zustand-demo.pmnd.rs) |
| **FastAPI** | [fastapi.tiangolo.com](https://fastapi.tiangolo.com) |
| **PyTorch** | [pytorch.org](https://pytorch.org) |

### macOS 专项

| 主题 | 链接 |
| --- | --- |
| **Tauri macOS 前置条件** | [v2.tauri.app/start/prerequisites/#macos](https://v2.tauri.app/start/prerequisites/#macos) |
| **Tauri macOS 签名** | [v2.tauri.app/distribute/sign/macos](https://v2.tauri.app/distribute/sign/macos) |
| **Apple Developer 账户** | [developer.apple.com](https://developer.apple.com) |
| **Xcode CLI Tools** | [developer.apple.com/xcode/resources](https://developer.apple.com/xcode/resources/) |
| **uv 文档** | [docs.astral.sh/uv](https://docs.astral.sh/uv/) |
| **PyInstaller** | [pyinstaller.org](https://pyinstaller.org) |

### 工具

| 工具 | 安装/文档 |
| --- | --- |
| **Homebrew** | [brew.sh](https://brew.sh) |
| **nvm** | [github.com/nvm-sh/nvm](https://github.com/nvm-sh/nvm) |
| **rustup** | [rustup.rs](https://rustup.rs) |
| **pnpm** | [pnpm.io](https://pnpm.io) |

---

## 快速开始清单

面向首次配置 macOS 开发环境的快速检查清单：

```bash
# 1. 安装 Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. 安装 Xcode CLI Tools
xcode-select --install

# 3. 安装 Node.js + pnpm
brew install node@22
npm install -g pnpm

# 4. 安装 Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source "$HOME/.cargo/env"

# 5. 安装 uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# 6. 克隆项目
git clone https://github.com/AstroAir/infocom-app.git
cd infocom-app

# 7. 初始化仓库依赖与本地配置
pnpm setup:macos

# 8. 放置模型文件到 server/models/

# 9. 启动开发
pnpm dev:all          # Web + 后端联合开发
# 或
pnpm tauri dev        # 桌面应用开发

# 10. 构建生产版本
pnpm build:desktop    # 构建 macOS 桌面应用
```

---

> **最后更新**: 2026-02-09 | **适用版本**: InfoCom App v0.1.0 | **目标平台**: macOS 12+ (Intel & Apple Silicon)
