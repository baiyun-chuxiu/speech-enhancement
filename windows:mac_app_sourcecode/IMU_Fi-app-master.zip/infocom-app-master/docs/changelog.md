# 更新日志

本文件记录项目的所有重要变更。格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。

## [0.1.0] - 2024-XX-XX

### 新增

- **前端应用**
  - Next.js 16 + React 19 基础框架
  - 首页、上传页、设置页、帮助页
  - 文件上传（加速度计、陀螺仪、音频）
  - 实时处理进度展示（6 步管线）
  - 音频播放器与波形分析
  - 数据预览图表（Recharts）
  - 暗色模式支持
  - 中英文国际化（next-intl）
  - 响应式布局（移动端适配）

- **后端服务**
  - FastAPI 异步服务器
  - 6 步 IMU 辅助音频增强管线
  - REST API（文件上传、任务管理）
  - WebSocket 实时进度推送
  - 多设备支持（CUDA / MPS / CPU）
  - 自动 OpenAPI 文档

- **桌面应用**
  - Tauri 2.9 跨平台桌面应用
  - Python Sidecar 集成
  - 自动启动/关闭后端服务
  - Tauri IPC 命令

- **开发工具**
  - ESLint 代码检查
  - Jest 单元测试
  - Playwright E2E 测试
  - GitHub Actions CI/CD
  - 多平台构建（Windows、macOS x64/arm64、Linux）

- **文档**
  - MkDocs 文档站点
  - 完整 API 参考
  - 部署指南（Web / macOS / Windows / Linux）
  - 开发者贡献指南
