# 数据流

## 端到端数据流

从用户上传文件到获取增强音频的完整数据流：

```text
用户浏览器 / Tauri 窗口
│
├─ 1. 选择文件（加速度计 .txt + 陀螺仪 .txt + 音频 .wav）
│     └── useTextFileUpload / useAudioFileUpload hooks
│         └── 文件验证（大小、类型、格式）
│         └── 读取文件元信息（行数、时长等）
│
├─ 2. 触发处理 (useModelApi.processEnhance)
│     └── 构建 FormData（三个文件 + device 参数）
│     └── POST /api/v1/enhance → 返回 task_id
│
├─ 3. 轮询进度 (pollEnhancerTask)
│     └── GET /api/v1/tasks/{task_id}  (每 500ms)
│     └── 或 WebSocket /ws/tasks/{task_id}
│     └── 更新 UI 中的 6 步进度条
│
├─ 4. 后端处理管线 (EnhancerPipeline.process_single)
│     ├── Step 1: IMU 数据预处理
│     │   └── 读取 acc/gyro → 截断到 125 点 → 插值到 150 点 → 计算幅值
│     ├── Step 2: GAN 视频位移生成
│     │   └── IMU 幅值 (150,2) → Generator 网络 → 视频位移 (150,40)
│     ├── Step 3: 音频 STFT
│     │   └── WAV → librosa.stft → 归一化频谱图 (1025,431) + 相位
│     ├── Step 4: 联合降噪推理
│     │   └── 频谱图 + 视频位移 → AudioDenoiseNetwork → 干净频谱图
│     ├── Step 5: 频谱后处理
│     │   └── 量化 → 反归一化 → 翻转
│     └── Step 6: ISTFT 重建
│         └── 干净频谱 + 原始相位 → librosa.istft → 峰值归一化 → WAV
│
├─ 5. 结果返回
│     └── output_file_id → GET /api/v1/files/download/{id}
│     └── 前端构建 ProcessedAudio 对象
│
└─ 6. 音频播放 (useAudioPlayer)
      └── 加载 audio URL → Web Audio API
      └── 波形分析（OfflineAudioContext）
      └── 播放控制（播放/暂停/进度/音量/倍速）
```

## API 通信架构

### Web 模式

```text
┌─────────────┐          ┌─────────────┐
│   React App  │◄── HTTP──┤  FastAPI     │
│              │          │  Server     │
│  enhancer-   │── WS ───▶│  (uvicorn)  │
│  api.ts      │          └─────────────┘
└─────────────┘               port 8000
     port 3000
```

### 桌面模式

```text
┌──────────────┐       ┌──────────────┐        ┌────────────────┐
│  Tauri Window │◄─IPC─┤  Rust Process │◄─pipe─┤ Python Sidecar │
│  (WebView)   │       │  (lib.rs)    │        │ (PyInstaller)  │
└──────────────┘       └──────────────┘        └────────────────┘
     │                      │
     │  invoke命令           │ Sidecar管理
     │  ├── process_audio   │ ├── spawn_sidecar()
     │  ├── check_model     │ ├── stdin关机信号
     │  ├── read_text_file  │ └── 端口获取
     │  └── save_audio_file │
     │                      │
     └── HTTP 直连 ─────────┼──▶ FastAPI (localhost:random_port)
```

## 文件格式规范

### 加速度计 / 陀螺仪数据 (.txt)

每行包含至少三列数值，管线自动取最后三列（x, y, z 轴）：

```text
0.012 -9.81 0.03
0.015 -9.79 0.05
0.011 -9.82 0.02
...
```

处理参数：

- 截断长度：125 个采样点
- 插值目标：150 个采样点
- 输出：幅值向量 (150, 2) — 加速度幅值 + 陀螺仪幅值

### 音频文件 (.wav)

- 支持格式：WAV、MP3、M4A、OGG、FLAC、AAC
- STFT 参数：默认 FFT 大小 2048，hop 512
- 频谱图尺寸：(1025 频率 bins, 431 时间步)
- 输出采样率：22050 Hz（可配置）

## 状态管理流

```text
localStorage (持久化)
├── infocom-settings     → API URL, 主题, 设备, 通知偏好
├── enhancer-settings    → 增强器专用 API URL
└── infocom-locale       → 语言偏好 (zh-CN / en)

React State (运行时)
├── useFileUpload        → 文件信息, 上传进度, 错误状态
├── useModelApi          → 处理进度, 步骤状态, 输出音频
├── useAudioPlayer       → 播放状态, 音量, 波形分析数据
└── I18nContext          → 当前语言, setLocale 函数
```
