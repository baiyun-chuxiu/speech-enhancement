# 技术栈

## 前端

| 分类 | 技术 | 版本 | 说明 |
| --- | --- | --- | --- |
| 框架 | Next.js | 16.x | App Router，静态导出模式 |
| UI 库 | React | 19.x | 函数组件 + Hooks |
| 样式 | Tailwind CSS | v4 | 原子化 CSS |
| 组件库 | shadcn/ui | 最新 | 基于 Radix UI 的可复制组件 |
| 状态管理 | Zustand | 5.x | 轻量级全局状态 |
| 国际化 | next-intl | 最新 | 客户端 i18n |
| 图标 | Lucide React | 最新 | 开源图标库 |
| 图表 | Recharts | 2.x | React 声明式图表 |
| HTTP | Fetch API | 原生 | 文件上传使用 XMLHttpRequest |
| 字体 | Geist | 最新 | Vercel 出品的现代字体 |

### 核心前端依赖

```json
{
  "next": "^16.0.0",
  "react": "^19.0.0",
  "react-dom": "^19.0.0",
  "next-intl": "latest",
  "zustand": "^5.0.0",
  "recharts": "^2.0.0",
  "lucide-react": "latest",
  "@radix-ui/react-*": "latest"
}
```

## 后端

| 分类 | 技术 | 版本 | 说明 |
| --- | --- | --- | --- |
| 框架 | FastAPI | 最新 | 异步 Python Web 框架 |
| ASGI 服务器 | Uvicorn | 最新 | ASGI 高性能服务器 |
| 深度学习 | PyTorch | 最新 | 模型推理引擎 |
| 音频处理 | librosa | 最新 | 音频特征提取 |
| 音频 I/O | soundfile | 最新 | WAV 文件读写 |
| 图像处理 | OpenCV | 最新 | 频谱图处理 |
| 数据处理 | NumPy | 最新 | 数值计算 |
| 数据校验 | Pydantic | v2 | 请求/响应模型验证 |
| 包管理 | uv | 最新 | 高速 Python 包管理器 |
| Python | CPython | 3.12 | 指定在 `.python-version` |

### 核心后端依赖

```toml
[project]
dependencies = [
    "fastapi>=0.115.0",
    "uvicorn[standard]>=0.32.0",
    "torch>=2.0.0",
    "numpy>=1.24.0",
    "librosa>=0.10.0",
    "soundfile>=0.12.0",
    "opencv-python-headless>=4.8.0",
    "Pillow>=10.0.0",
    "python-multipart>=0.0.7",
    "websockets>=12.0",
    "pydantic>=2.0.0",
]
```

## 桌面应用

| 分类 | 技术 | 版本 | 说明 |
| --- | --- | --- | --- |
| 框架 | Tauri | 2.9 | Rust 原生桌面框架 |
| 语言 | Rust | 1.77+ | 系统级编程语言 |
| 进程管理 | tauri-plugin-shell | 最新 | Sidecar 进程管理 |
| 日志 | tauri-plugin-log | 最新 | 跨平台日志 |
| 异步运行时 | Tokio | 1.x | Rust 异步运行时 |
| 序列化 | Serde | 1.x | JSON 序列化/反序列化 |
| 打包 | PyInstaller | 最新 | Python → 独立二进制 |

## 开发工具

| 工具 | 用途 |
| --- | --- |
| ESLint | JavaScript/TypeScript 代码检查 |
| TypeScript | 类型安全 |
| Jest | 前端单元测试 |
| Playwright | E2E 端到端测试 |
| GitHub Actions | CI/CD 自动化 |
