# 项目结构

```text
infocom-app/
├── app/                          # Next.js App Router 路由
│   ├── layout.tsx                # 根布局（字体、元数据、I18nProvider）
│   ├── page.tsx                  # 首页（功能介绍、技术栈展示）
│   ├── globals.css               # 全局样式（Tailwind 导入）
│   ├── upload/                   # 上传与处理页面
│   │   ├── layout.tsx            # 上传页布局（移动端适配）
│   │   └── page.tsx              # 核心上传/处理页面
│   ├── settings/                 # 设置页面
│   │   └── page.tsx              # API 配置、主题、设备选择
│   └── help/                     # 帮助页面
│       └── page.tsx              # 使用指南、FAQ、API 文档链接
│
├── components/                   # React 组件
│   ├── ui/                       # shadcn/ui 基础组件
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── tabs.tsx
│   │   ├── accordion.tsx
│   │   ├── slider.tsx
│   │   ├── progress.tsx
│   │   └── ...                   # 20+ 个 UI 组件
│   ├── upload/                   # 上传功能组件
│   │   ├── file-upload-zone.tsx  # 拖拽上传区域
│   │   ├── audio-player.tsx      # 音频播放器
│   │   ├── audio-analyzer.tsx    # 音频波形分析
│   │   ├── data-preview.tsx      # 数据预览图表
│   │   ├── processing-status.tsx # 处理进度显示
│   │   └── upload-types.ts       # 上传组件类型定义
│   └── i18n-provider.tsx         # 国际化上下文提供者
│
├── hooks/                        # 自定义 React Hooks
│   ├── useFileUpload.ts          # 文件上传 hook（验证、进度）
│   ├── useModelApi.ts            # 模型 API 调用 hook
│   ├── useAudioPlayer.ts         # 音频播放 hook（Web Audio API）
│   └── index.ts                  # Hook 导出入口
│
├── lib/                          # 共享工具库
│   ├── api/                      # API 客户端
│   │   ├── enhancer-api.ts       # Python 增强 API 客户端
│   │   ├── model-api.ts          # 统一模型 API（Tauri/HTTP/WS/Mock）
│   │   ├── infocom.ts            # InfoCom REST API 封装
│   │   └── index.ts              # API 导出入口
│   ├── utils/                    # 工具函数
│   │   └── data-parser.ts        # 数据解析工具
│   ├── types.ts                  # 全局 TypeScript 类型定义
│   └── utils.ts                  # 通用工具（cn 等）
│
├── i18n/                         # 国际化配置
│   ├── config.ts                 # 语言列表、默认语言
│   └── request.ts                # i18n 请求处理
│
├── messages/                     # 翻译文件
│   ├── zh-CN.json                # 中文翻译
│   └── en.json                   # 英文翻译
│
├── server/                       # Python 后端
│   ├── main.py                   # FastAPI 入口
│   ├── config.py                 # 服务器配置（ServerConfig 数据类）
│   ├── routes.py                 # API 路由定义
│   ├── pipeline.py               # 6 步增强管线（EnhancerPipeline）
│   ├── schemas.py                # Pydantic 请求/响应模型
│   ├── models.py                 # PyTorch 模型定义（Generator, DenoiseNet）
│   ├── build_sidecar.py          # PyInstaller Sidecar 构建脚本
│   ├── pyproject.toml            # Python 项目配置
│   ├── .python-version           # Python 版本锁定 (3.12)
│   └── models/                   # 预训练模型权重（不入仓库）
│       ├── generator_final.pth
│       └── best_model.pth
│
├── src-tauri/                    # Tauri 桌面应用 (Rust)
│   ├── src/
│   │   ├── lib.rs                # Tauri 应用入口（插件注册、Sidecar 管理）
│   │   ├── main.rs               # Rust main 函数
│   │   └── commands/             # Tauri invoke 命令
│   │       └── model.rs          # 模型处理、文件读写命令
│   ├── capabilities/             # Tauri 权限配置
│   │   ├── default.json
│   │   ├── desktop.json          # 桌面 Sidecar 权限
│   │   └── mobile.json
│   ├── icons/                    # 应用图标
│   ├── tauri.conf.json           # Tauri 核心配置
│   ├── Cargo.toml                # Rust 依赖声明
│   └── Cargo.lock
│
├── e2e/                          # Playwright E2E 测试
│   ├── fixtures/                 # 测试数据
│   ├── helpers/                  # 测试工具函数
│   └── *.spec.ts                 # 测试文件
│
├── public/                       # 静态资源
├── docs/                         # MkDocs 文档
│
├── .github/workflows/ci.yml     # CI/CD 配置
├── mkdocs.yml                    # MkDocs 配置
├── next.config.ts                # Next.js 配置
├── tsconfig.json                 # TypeScript 配置
├── eslint.config.mjs             # ESLint 配置
├── jest.config.ts                # Jest 配置
├── playwright.config.ts          # Playwright 配置
├── postcss.config.mjs            # PostCSS 配置
├── components.json               # shadcn/ui 配置
└── package.json                  # 前端依赖与脚本
```

## 模块职责

### 前端模块

| 模块 | 职责 |
| --- | --- |
| `app/` | 路由定义、页面组件、布局 |
| `components/ui/` | 原子级 UI 组件（Button、Card 等） |
| `components/upload/` | 上传相关业务组件 |
| `hooks/` | 可复用逻辑封装 |
| `lib/api/` | API 调用抽象层 |
| `lib/types.ts` | 全局类型定义 |
| `i18n/` + `messages/` | 国际化配置与翻译 |

### 后端模块

| 模块 | 职责 |
| --- | --- |
| `main.py` | FastAPI 应用初始化、CORS、启动事件 |
| `routes.py` | HTTP/WS 路由与请求处理 |
| `pipeline.py` | 核心 6 步增强管线 |
| `config.py` | 运行时配置管理 |
| `schemas.py` | 请求/响应数据模型 |
| `models.py` | PyTorch 神经网络定义 |

### 桌面模块

| 模块 | 职责 |
| --- | --- |
| `lib.rs` | Tauri 应用生命周期管理 |
| `commands/model.rs` | Tauri invoke 命令定义 |
| `capabilities/` | 安全权限声明 |
| `build_sidecar.py` | Python Sidecar 构建自动化 |
