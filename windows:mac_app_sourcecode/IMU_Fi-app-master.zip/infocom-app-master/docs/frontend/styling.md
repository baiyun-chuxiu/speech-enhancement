# 样式系统

## Tailwind CSS v4

项目使用 Tailwind CSS v4 作为核心样式方案，通过 PostCSS 集成。

### 全局样式入口

```css
/* app/globals.css */
@import "tailwindcss";
```

### 暗色模式

项目使用 Tailwind 的 `class` 策略切换暗色模式：

```tsx
// 切换暗色模式
document.documentElement.classList.toggle("dark");
```

在组件中使用暗色变体：

```tsx
<div className="bg-white dark:bg-gray-900 text-black dark:text-white">
  <p className="text-gray-600 dark:text-gray-300">内容</p>
</div>
```

### CSS 变量

shadcn/ui 使用 CSS 自定义属性定义主题色：

```css
:root {
  --background: 0 0% 100%;
  --foreground: 0 0% 3.9%;
  --card: 0 0% 100%;
  --primary: 0 0% 9%;
  --secondary: 0 0% 96.1%;
  --muted: 0 0% 96.1%;
  --accent: 0 0% 96.1%;
  --destructive: 0 84.2% 60.2%;
  --border: 0 0% 89.8%;
  --ring: 0 0% 3.9%;
  --radius: 0.5rem;
}

.dark {
  --background: 0 0% 3.9%;
  --foreground: 0 0% 98%;
  /* ... */
}
```

## shadcn/ui 组件配置

`components.json` 定义了 shadcn/ui 的样式配置：

```json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "tailwind": {
    "config": "",
    "css": "app/globals.css",
    "baseColor": "zinc",
    "cssVariables": true,
    "prefix": ""
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  }
}
```

## 工具函数 `cn()`

项目使用 `cn()` 函数合并 Tailwind 类名，位于 `lib/utils.ts`：

```typescript
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

使用示例：

```tsx
<button
  className={cn(
    "px-4 py-2 rounded-md font-medium",
    isActive && "bg-primary text-primary-foreground",
    disabled && "opacity-50 cursor-not-allowed"
  )}
/>
```

## 响应式设计

项目使用 Tailwind 断点实现响应式布局：

| 断点 | 最小宽度 | 用途 |
| --- | --- | --- |
| `sm` | 640px | 手机横屏 |
| `md` | 768px | 平板 |
| `lg` | 1024px | 笔记本 |
| `xl` | 1280px | 桌面 |

上传页示例：

```tsx
<div className="flex flex-col lg:flex-row gap-6">
  <aside className="w-full lg:w-80">{/* 左侧上传区域 */}</aside>
  <main className="flex-1">{/* 右侧主内容 */}</main>
</div>
```

## 字体

项目使用 Vercel 的 **Geist** 字体家族：

```typescript
// app/layout.tsx
import { Geist, Geist_Mono } from "next/font/google";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});
```

通过 CSS 变量在全局样式中引用：

```css
body {
  font-family: var(--font-geist-sans), system-ui, sans-serif;
}

code {
  font-family: var(--font-geist-mono), monospace;
}
```
