# 前端开发

InfoCom App 前端基于 **Next.js 16 + React 19** 构建，采用 App Router、Tailwind CSS v4 和 shadcn/ui 组件库。

## 核心特性

- **App Router** — Next.js 文件系统路由，支持嵌套布局
- **静态导出** — `output: "export"` 模式，兼容 Tauri 打包
- **服务端无关** — 纯客户端渲染，无 SSR 依赖
- **响应式设计** — 移动端、平板、桌面自适应布局
- **暗色模式** — CSS 变量驱动的主题切换
- **国际化** — 基于 next-intl 的中英文切换

## 章节导航

- [**页面路由**](pages.md) — 4 个核心页面的功能与实现
- [**UI 组件**](components.md) — shadcn/ui 组件与业务组件
- [**状态管理**](state-management.md) — Hooks 与状态流
- [**国际化**](i18n.md) — next-intl 多语言实现
- [**样式系统**](styling.md) — Tailwind CSS 与暗色模式

## 关键文件

| 文件 | 作用 |
| --- | --- |
| `app/layout.tsx` | 根布局（字体、元数据、I18nProvider、Toaster） |
| `app/page.tsx` | 首页（功能介绍、技术栈） |
| `app/upload/page.tsx` | 核心上传与处理页面 |
| `app/settings/page.tsx` | 应用设置（API、主题、设备） |
| `app/help/page.tsx` | 使用帮助与 FAQ |
| `components/i18n-provider.tsx` | 国际化上下文 |
| `next.config.ts` | Next.js 配置（静态导出） |
