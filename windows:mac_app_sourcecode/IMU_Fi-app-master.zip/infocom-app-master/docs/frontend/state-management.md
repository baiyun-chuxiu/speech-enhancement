# 状态管理

InfoCom App 使用 **React Hooks** 管理组件级状态，使用 **localStorage** 持久化用户设置。项目也引入了 **Zustand** 作为全局状态管理备选方案。

## 自定义 Hooks 概览

| Hook | 文件 | 职责 |
| --- | --- | --- |
| `useFileUpload` | `hooks/useFileUpload.ts` | 文件选择、验证、元信息读取 |
| `useTextFileUpload` | `hooks/useFileUpload.ts` | 文本文件专用上传（`.txt`） |
| `useAudioFileUpload` | `hooks/useFileUpload.ts` | 音频文件专用上传（`.wav` 等） |
| `useModelApi` | `hooks/useModelApi.ts` | 模型处理调用、进度追踪 |
| `useAudioPlayer` | `hooks/useAudioPlayer.ts` | 音频播放控制与分析 |
| `useI18n` | `components/i18n-provider.tsx` | 语言切换 |

## useFileUpload

通用文件上传 Hook，提供文件验证、状态管理和生命周期控制。

### useFileUpload 参数

```typescript
interface UseFileUploadOptions {
  maxSize?: number; // 最大文件大小 (bytes)，默认 100MB
  acceptedTypes?: string[]; // 允许的 MIME 类型或扩展名
  onSuccess?: (fileInfo: FileInfo) => void;
  onError?: (error: string) => void;
}
```

### useFileUpload 返回值

```typescript
interface UseFileUploadReturn {
  fileInfo: FileInfo | null; // 上传后的文件信息
  isUploading: boolean; // 上传中状态
  progress: number; // 上传进度 (0-100)
  error: string | null; // 错误信息
  selectFile: (file: File) => Promise<void>; // 选择文件
  removeFile: () => void; // 移除文件
  reset: () => void; // 重置状态
}
```

### 文件验证逻辑

1. 检查文件大小是否超过 `maxSize`
2. 检查文件类型是否在 `acceptedTypes` 列表中
3. 对音频文件额外获取时长（通过 `Audio` 元素）
4. 对文本文件额外读取内容、行数、字数

### 派生 Hooks

```typescript
// 文本文件专用
const { fileInfo, selectFile } = useTextFileUpload();
// 等价于 useFileUpload({ acceptedTypes: ['.txt', 'text/plain'] })

// 音频文件专用
const { fileInfo, selectFile } = useAudioFileUpload();
// 等价于 useFileUpload({ acceptedTypes: ['.mp3', '.wav', '.m4a', ...] })
```

## useModelApi

模型 API 调用 Hook，管理完整的处理生命周期。

### useModelApi 参数

```typescript
interface UseModelApiOptions {
  onStepUpdate?: (step: ProcessStep) => void;
  onProgress?: (progress: number) => void;
  onComplete?: (response: ModelProcessResponse) => void;
  onError?: (error: string) => void;
}
```

### useModelApi 返回值

```typescript
interface UseModelApiReturn {
  isProcessing: boolean;
  progress: number; // 0-100
  steps: ProcessStep[]; // 6 步处理状态
  outputAudio: ProcessedAudio | null;
  error: string | null;
  modelStatus: ModelStatus | null;

  // 通过 Tauri/HTTP 处理
  process: (textFile, audioFile, options?) => Promise<ModelProcessResponse>;
  // 通过 Enhancer API 直接处理（推荐）
  processEnhance: (audioFile, accelFile, gyroFile, device?) => Promise<ModelProcessResponse>;
  cancelProcess: () => Promise<void>;
  checkStatus: () => Promise<ModelStatus>;
  reset: () => void;
}
```

### 处理流程 (`processEnhance`)

1. 初始化 6 步增强步骤状态
2. 调用 `startEnhancement()` 上传三个文件
3. 通过 `pollEnhancerTask()` 轮询任务状态（每 500ms）
4. 实时更新步骤进度和整体进度
5. 完成后构建 `ProcessedAudio` 对象（包含下载 URL）
6. 失败时标记当前步骤为 `failed`

### 模型状态检查

`checkStatus()` 会依次尝试：

1. Enhancer API 就绪检查（`/ready`）
2. Enhancer 系统信息（`/api/v1/system/info`）
3. 回退到通用 `modelApi.checkModelStatus()`

## useAudioPlayer

音频播放 Hook，基于 **Web Audio API** 实现。

### useAudioPlayer 返回值

```typescript
interface UseAudioPlayerReturn {
  state: AudioPlaybackState; // 播放状态
  analysis: AudioAnalysis | null; // 音频分析结果
  audioRef: RefObject<HTMLAudioElement>; // Audio 元素引用
  canvasRef: RefObject<HTMLCanvasElement>; // Canvas 引用

  load: (src: string) => void; // 加载音频
  play: () => Promise<void>; // 播放
  pause: () => void; // 暂停
  toggle: () => Promise<void>; // 切换播放/暂停
  stop: () => void; // 停止
  seek: (time: number) => void; // 跳转
  setVolume: (volume: number) => void; // 设置音量 (0-1)
  toggleMute: () => void; // 静音切换
  setPlaybackRate: (rate: number) => void; // 设置播放速度
  analyzeAudio: () => Promise<AudioAnalysis | null>; // 分析音频
}
```

### 音频分析

`analyzeAudio()` 使用 `OfflineAudioContext` 对音频进行离线分析：

- 解码音频为 `AudioBuffer`
- 提取 200 个归一化波形采样
- 计算峰值振幅、平均振幅
- 计算静音比例（阈值 0.01）
- 返回 `AudioAnalysis` 对象

## 持久化存储

| 键名 | 内容 | 使用位置 |
| --- | --- | --- |
| `infocom-settings` | API URL、主题、设备、质量等 | `settings/page.tsx` |
| `enhancer-settings` | 增强器专用 API URL | `enhancer-api.ts` |
| `infocom-locale` | 语言偏好 (`zh-CN` / `en`) | `i18n-provider.tsx` |
| `theme` | 主题 (`light` / `dark`) | `page.tsx` |
