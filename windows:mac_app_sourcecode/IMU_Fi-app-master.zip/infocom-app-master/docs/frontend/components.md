# UI 组件

## 组件分层

```text
components/
├── ui/           # 基础 UI 组件（shadcn/ui）
├── upload/       # 上传业务组件
└── i18n-provider.tsx  # 国际化提供者
```

## shadcn/ui 基础组件

项目使用 [shadcn/ui](https://ui.shadcn.com/) 作为基础组件库，组件位于 `components/ui/` 目录。

### 已安装组件列表

| 组件 | 文件 | 用途 |
| --- | --- | --- |
| Accordion | `accordion.tsx` | 帮助页 FAQ 折叠面板 |
| Alert | `alert.tsx` | 错误/警告提示 |
| Avatar | `avatar.tsx` | 用户头像 |
| Badge | `badge.tsx` | 状态标签 |
| Button | `button.tsx` | 操作按钮（多种变体） |
| Card | `card.tsx` | 卡片容器 |
| Checkbox | `checkbox.tsx` | 复选框 |
| Dialog | `dialog.tsx` | 模态对话框 |
| Dropdown Menu | `dropdown-menu.tsx` | 下拉菜单 |
| Input | `input.tsx` | 文本输入框 |
| Label | `label.tsx` | 表单标签 |
| Progress | `progress.tsx` | 进度条 |
| Select | `select.tsx` | 下拉选择框 |
| Separator | `separator.tsx` | 分隔线 |
| Slider | `slider.tsx` | 滑块（音量控制等） |
| Sonner | `sonner.tsx` | Toast 通知 |
| Switch | `switch.tsx` | 开关切换 |
| Tabs | `tabs.tsx` | 标签页切换 |
| Textarea | `textarea.tsx` | 多行文本输入 |
| Tooltip | `tooltip.tsx` | 悬浮提示 |

### 添加新组件

```bash
pnpm dlx shadcn@latest add <component-name>
```

组件配置在 `components.json` 中定义了样式系统和别名。

## 上传业务组件

### FileUploadZone

**文件**: `components/upload/file-upload-zone.tsx`

拖拽文件上传区域组件，支持：

- 拖拽上传（Drag & Drop）
- 点击选择文件
- 文件类型过滤
- 上传进度显示
- 文件信息展示（名称、大小、类型）
- 错误状态展示

```tsx
<FileUploadZone
  accept=".txt"
  label="加速度计数据"
  icon={<Activity />}
  fileInfo={accelFileInfo}
  isUploading={isUploading}
  progress={uploadProgress}
  error={uploadError}
  onFileSelect={handleFileSelect}
  onRemove={handleRemove}
/>
```

### AudioPlayer

**文件**: `components/upload/audio-player.tsx`

音频播放器组件，功能包括：

- 播放 / 暂停 / 停止
- 进度条拖拽定位
- 音量控制（滑块 + 静音切换）
- 播放速度调节（0.5x ~ 2x）
- 当前时间 / 总时长显示
- 加载状态指示

### AudioAnalyzer

**文件**: `components/upload/audio-analyzer.tsx`

音频分析组件，展示：

- 波形图（200 个采样点的归一化波形）
- 峰值振幅
- 平均振幅
- 静音比例
- 采样率
- 通道数
- 时长

### DataPreview

**文件**: `components/upload/data-preview.tsx`

数据预览组件，使用 Recharts 绘制：

- 加速度计三轴数据折线图
- 陀螺仪三轴数据折线图
- 数据点数统计

### ProcessingStatus

**文件**: `components/upload/processing-status.tsx`

处理状态组件，展示 6 步管线的实时进度：

- 每步的名称和状态图标
- 每步的进度百分比
- 整体进度条
- 当前步骤高亮
- 失败步骤标红

## I18nProvider

**文件**: `components/i18n-provider.tsx`

国际化上下文提供者，封装 `NextIntlClientProvider`：

```tsx
// 用法
import { I18nProvider, useI18n } from "@/components/i18n-provider";

// 在根布局中包裹
<I18nProvider>{children}</I18nProvider>;

// 在任意组件中切换语言
const { locale, setLocale } = useI18n();
setLocale("en"); // 切换为英文
```

功能：

- 从 `localStorage` 读取用户语言偏好
- 动态加载翻译消息（`messages/zh-CN.json` 或 `messages/en.json`）
- 同步 `<html lang>` 属性
- 提供 `useI18n()` hook 供组件访问语言状态
