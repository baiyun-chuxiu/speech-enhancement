# 页面路由

InfoCom App 包含 4 个核心页面，均位于 `app/` 目录下。

## 路由结构

```text
/             → app/page.tsx          首页
/upload       → app/upload/page.tsx   上传与处理（核心功能页）
/settings     → app/settings/page.tsx 应用设置
/help         → app/help/page.tsx     使用帮助
```

## 首页 (`/`)

**文件**: `app/page.tsx`

首页作为产品展示页，包含以下区块：

- **顶部导航** — Logo、主题切换按钮（亮色/暗色）、GitHub 链接、语言切换
- **Hero 区域** — 产品名称、描述、CTA 按钮（→ 上传页）
- **功能卡片** — 4 个核心功能（音频增强、传感器数据、IMU 视频生成、多模态降噪）
- **工作流程** — 三步流程图（上传数据 → AI 处理 → 获取结果）
- **技术栈** — 展示前后端技术徽章
- **底部导航** — 快速链接

### 主题切换

首页集成了主题切换功能，通过 `document.documentElement.classList.toggle('dark')` 控制 Tailwind 暗色模式：

```typescript
const toggleTheme = () => {
  const html = document.documentElement;
  html.classList.toggle("dark");
  const isDark = html.classList.contains("dark");
  localStorage.setItem("theme", isDark ? "dark" : "light");
};
```

## 上传页 (`/upload`)

**文件**: `app/upload/page.tsx`、`app/upload/layout.tsx`

这是应用的核心功能页面，包含完整的文件上传、处理、结果展示流程。

### 页面布局

```text
┌──────────────────────────────────┐
│         顶部：返回按钮 + 标题       │
├──────────┬───────────────────────┤
│          │                       │
│  左侧栏   │      右侧主内容        │
│ 上传区域  │   数据预览 / 处理状态   │
│          │   输出结果 / 音频播放   │
│          │                       │
└──────────┴───────────────────────┘
```

### 三个上传区域

| 区域 | 文件类型 | Hook | 说明 |
| --- | --- | --- | --- |
| 加速度计数据 | `.txt` | `useTextFileUpload` | 三轴加速度数据 |
| 陀螺仪数据 | `.txt` | `useTextFileUpload` | 三轴角速度数据 |
| 音频文件 | `.wav` `.mp3` 等 | `useAudioFileUpload` | 待增强音频 |

### 处理流程

1. 三个文件全部上传后，「开始增强」按钮可用
2. 调用 `useModelApi.processEnhance(audioFile, accelFile, gyroFile, device)`
3. 实时显示 6 步处理进度（`ProcessingStatus` 组件）
4. 完成后展示输出音频播放器和音频分析

### 关键交互

- **拖拽上传** — `FileUploadZone` 组件支持拖拽和点击选择
- **数据预览** — 上传文本文件后显示 Recharts 折线图
- **处理取消** — 处理中可随时取消
- **结果播放** — 内嵌 `AudioPlayer` 组件播放增强结果
- **波形分析** — `AudioAnalyzer` 展示波形和音频分析数据

### 移动端适配

`upload/layout.tsx` 设置了移动端视口：

```typescript
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};
```

## 设置页 (`/settings`)

**文件**: `app/settings/page.tsx`

设置页提供以下配置项：

### 服务器设置

- **API 地址** — 可编辑的后端 URL 输入框
- **连接测试** — 点击测试按钮检查 API 可用性

### 应用设置

| 设置项 | 类型 | 选项 |
| --- | --- | --- |
| 主题 | 单选 | 亮色 / 暗色 / 跟随系统 |
| 计算设备 | 下拉 | Auto / CPU / CUDA / MPS |
| 处理质量 | 下拉 | 快速 / 平衡 / 高质量 (Coming Soon) |
| 输出格式 | 下拉 | WAV / MP3 / FLAC (Coming Soon) |
| 自动保存 | 开关 | 开 / 关 |
| 通知 | 开关 | 开 / 关 |

### 数据持久化

所有设置存储在 `localStorage`，键名 `infocom-settings`：

```json
{
  "apiUrl": "http://localhost:8000",
  "theme": "system",
  "device": "auto",
  "quality": "balanced",
  "format": "wav",
  "autoSave": true,
  "notifications": true
}
```

## 帮助页 (`/help`)

**文件**: `app/help/page.tsx`

帮助页使用 Tabs 和 Accordion 组织内容：

### 标签页结构

| 标签 | 内容 |
| --- | --- |
| 快速开始 | 三步使用流程图解 |
| 功能说明 | 各功能的详细描述和数据格式要求 |
| 常见问题 | Accordion 形式的 FAQ |
| API 文档 | REST API 端点列表、WebSocket 信息、Swagger/ReDoc 链接 |

### API 文档区域

帮助页列出了后端所有 API 端点：

- `GET /health` — 健康检查
- `GET /ready` — 后端就绪检查
- `GET /api/v1/system/info` — 系统信息
- `POST /api/v1/files/upload` — 文件上传
- `POST /api/v1/enhance` — 开始增强
- `POST /api/v1/enhance/uploaded` — 使用已上传文件启动增强
- `GET /api/v1/tasks/{task_id}` — 查询任务
- `POST /api/v1/tasks/{task_id}/cancel` — 取消任务
- `WS /ws/tasks/{task_id}` — WebSocket 进度
