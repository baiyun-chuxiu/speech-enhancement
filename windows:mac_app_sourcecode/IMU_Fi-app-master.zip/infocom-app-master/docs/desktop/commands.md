# Rust 命令

**文件**: `src-tauri/src/commands/model.rs`

Tauri 命令通过 `#[tauri::command]` 宏定义，前端通过 `invoke()` 调用。

## 数据结构

### ProcessOptions

```rust
pub struct ProcessOptions {
    pub model: Option<String>,
    pub language: Option<String>,
    pub quality: Option<String>,     // "fast" | "balanced" | "high"
    pub output_format: Option<String>,
    pub sample_rate: Option<u32>,
}
```

### ProcessStep

```rust
pub struct ProcessStep {
    pub name: String,
    pub status: String,     // "pending" | "processing" | "completed" | "failed"
    pub progress: f32,      // 0.0 - 100.0
    pub message: Option<String>,
}
```

### ProcessResponse

```rust
pub struct ProcessResponse {
    pub success: bool,
    pub output_audio: Option<ProcessedAudio>,
    pub metadata: Option<ProcessMetadata>,
    pub error: Option<String>,
}
```

### ModelStatus

```rust
pub struct ModelStatus {
    pub is_available: bool,
    pub model_name: String,
    pub model_version: String,
    pub capabilities: Vec<String>,
}
```

### AppState

```rust
pub struct AppState {
    pub tasks: Mutex<HashMap<String, TaskState>>,
}
```

## 命令列表

### process_audio_text

处理音频和文本文件，返回增强结果。

```rust
#[tauri::command]
pub async fn process_audio_text(
    state: State<'_, AppState>,
    text_path: String,
    audio_path: String,
    text_content: Option<String>,
    options: Option<ProcessOptions>,
) -> Result<ProcessResponse, String>
```

**前端调用**:

```typescript
const result = await invoke<ProcessResponse>("process_audio_text", {
  textPath: "/path/to/accel.txt",
  audioPath: "/path/to/audio.wav",
  textContent: "...",
  options: { quality: "balanced" },
});
```

### get_process_progress

查询任务处理进度。

```rust
#[tauri::command]
pub async fn get_process_progress(
    state: State<'_, AppState>,
    task_id: String,
) -> Result<Vec<ProcessStep>, String>
```

### cancel_process

取消正在进行的任务。

```rust
#[tauri::command]
pub async fn cancel_process(
    state: State<'_, AppState>,
    task_id: String,
) -> Result<(), String>
```

### check_model_status

检查模型可用性和能力。

该命令会查询 Python backend 的系统信息接口，并以 readiness 作为“是否可用”的判断依据，而不是仅检查进程是否存活。

```rust
#[tauri::command]
pub async fn check_model_status() -> Result<ModelStatus, String>
```

### 文件操作命令

```rust
// 读取文本文件
#[tauri::command]
pub async fn read_text_file(path: String) -> Result<String, String>

// 读取音频文件（返回字节数组）
#[tauri::command]
pub async fn read_audio_file(path: String) -> Result<Vec<u8>, String>

// 保存音频文件
#[tauri::command]
pub async fn save_audio_file(
    data: Vec<u8>,
    format: String,
) -> Result<String, String>
```

## Sidecar 管理命令

**文件**: `src-tauri/src/commands/sidecar.rs`

```rust
// 启动 Python 后端服务
#[tauri::command]
pub async fn start_server(app: AppHandle) -> Result<(), String>

// 停止 Python 后端服务
#[tauri::command]
pub async fn stop_server() -> Result<(), String>

// 获取 Sidecar 监听端口
#[tauri::command]
pub async fn get_server_port() -> Result<u16, String>
```

## 前端调用方式

### 在 Tauri 环境中

```typescript
import { invoke } from "@tauri-apps/api/core";

// 检查模型状态
const status = await invoke<ModelStatus>("check_model_status");

// 读取文件
const content = await invoke<string>("read_text_file", {
  path: "/path/to/file.txt",
});
```

### 环境检测

```typescript
const isTauri = (): boolean => {
  return typeof window !== "undefined" && "__TAURI__" in window;
};
```

`model-api.ts` 中的 `ModelApi` 类会根据运行环境自动选择 Tauri invoke 或 HTTP API。
