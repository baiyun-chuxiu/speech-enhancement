# 桌面应用

InfoCom App 使用 **Tauri 2.9** 构建跨平台桌面应用，支持 Windows、macOS 和 Linux。

## 核心特性

- **原生窗口** — 使用系统 WebView 渲染前端，体积远小于 Electron
- **Rust 后端** — 高性能的 Tauri IPC 命令
- **Sidecar 模式** — 将 Python 后端打包为独立二进制文件
- **自动启动** — 应用启动时自动拉起 Python Sidecar
- **优雅关机** — 应用退出时通过 stdin 发送关机信号

## 架构图

```text
┌─────────────────────────────────────────────┐
│              Tauri Application               │
│                                              │
│  ┌────────────────┐   ┌──────────────────┐  │
│  │   WebView       │   │   Rust Process    │  │
│  │ (Next.js 静态)  │◄─►│   (lib.rs)       │  │
│  │                 │IPC│                   │  │
│  └────────────────┘   │  ┌─────────────┐  │  │
│                        │  │ AppState     │  │  │
│                        │  │ (tasks map)  │  │  │
│                        │  └─────────────┘  │  │
│                        │                   │  │
│                        │  ┌─────────────┐  │  │
│                        │  │ Sidecar Mgr  │  │  │
│                        │  │ (spawn/kill) │  │  │
│                        │  └──────┬──────┘  │  │
│                        └─────────┼─────────┘  │
│                                  │ stdin/stdout│
│                        ┌─────────▼─────────┐  │
│                        │  Python Sidecar    │  │
│                        │  (PyInstaller)     │  │
│                        │  FastAPI Server    │  │
│                        └───────────────────┘  │
└─────────────────────────────────────────────┘
```

## 章节导航

- [**Tauri 架构**](tauri.md) — 配置、窗口、构建流程
- [**Rust 命令**](commands.md) — Tauri invoke 命令定义
- [**Sidecar 机制**](sidecar.md) — Python 后端打包与管理
- [**权限与安全**](capabilities.md) — Tauri 权限模型
