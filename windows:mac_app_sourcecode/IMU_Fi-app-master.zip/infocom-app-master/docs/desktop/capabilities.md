# 权限与安全

Tauri 2.x 引入了基于 Capability 的细粒度权限系统，确保应用只拥有必要的权限。

## 权限文件

```text
src-tauri/capabilities/
├── default.json    # 默认权限（所有平台）
├── desktop.json    # 桌面平台专用权限
└── mobile.json     # 移动平台专用权限
```

## desktop.json

```json
{
  "$schema": "../gen/schemas/desktop-schema.json",
  "identifier": "desktop-capability",
  "description": "Desktop-specific capabilities for sidecar management",
  "windows": ["main"],
  "permissions": [
    {
      "identifier": "shell:allow-execute",
      "allow": [
        {
          "name": "binaries/audio-enhancer-server",
          "sidecar": true
        }
      ]
    },
    "shell:allow-spawn",
    "shell:allow-stdin-write",
    "shell:allow-kill"
  ]
}
```

### 权限说明

| 权限 | 用途 |
| --- | --- |
| `shell:allow-execute` | 允许执行 Sidecar 二进制文件 |
| `shell:allow-spawn` | 允许启动子进程 |
| `shell:allow-stdin-write` | 允许向子进程 stdin 写入（关机信号） |
| `shell:allow-kill` | 允许终止子进程 |

## 安全设计原则

### 最小权限

- **只允许指定的 Sidecar** — `shell:allow-execute` 限制只能执行 `audio-enhancer-server`
- **无文件系统访问** — 不授予文件系统读写权限
- **无网络权限** — 不授予 HTTP 请求权限（前端直接通过 fetch 连接后端）
- **窗口限制** — 权限仅适用于 `main` 窗口

### CSP（内容安全策略）

Tauri 默认启用严格的 CSP，限制 WebView 中可执行的脚本和资源来源。

### IPC 安全

- 所有 Tauri 命令通过类型安全的 IPC 通信
- 命令参数由 Serde 反序列化验证
- 返回值通过 `Result<T, String>` 处理错误

## 添加新权限

如果需要新的系统能力（如文件选择对话框），需要：

1. 在 `capabilities/*.json` 中声明权限
2. 在 `Cargo.toml` 中启用对应的 Tauri 插件 feature
3. 在 `lib.rs` 中注册插件

```json
{
  "permissions": [
    "dialog:allow-open",
    "dialog:allow-save"
  ]
}
```
