# Sidecar 机制

Sidecar 是 Tauri 将外部二进制文件（如 Python 后端）嵌入桌面应用的机制。

## 工作原理

```text
Tauri 应用启动
  │
  ├── 1. Rust setup() 回调
  │     └── spawn_sidecar("audio-enhancer-server")
  │         └── 启动 PyInstaller 打包的 Python 二进制
  │
  ├── 2. Python Sidecar 启动
  │     └── FastAPI 服务器监听 localhost:8000
  │     └── 加载 PyTorch 模型到内存（成功则 ready，失败则 degraded）
  │
  ├── 3. Rust 轮询 /ready 直到后端真正可处理
  │     └── 只有 is_ready=true 才发出 sidecar-ready 事件
  │
  ├── 4. 前端通过 HTTP 连接 Sidecar
  │     └── http://localhost:8000/api/v1/*
  │
  └── 5. 应用关闭时
        └── Rust 向 Sidecar stdin 写入 "sidecar shutdown\n"
        └── Python 进程优雅退出
```

## 构建 Sidecar

**文件**: `server/build_sidecar.py`

### 构建命令

```bash
# 自动检测平台
pnpm build:sidecar

# 或按平台构建
pnpm build:sidecar-mac    # macOS 宿主机原生构建（Intel / Apple Silicon 自动识别）
pnpm build:sidecar-win    # Windows
pnpm build:sidecar-linux  # Linux
```

!!! warning "macOS 侧仅支持宿主机原生 sidecar"
    `pnpm build:sidecar-mac` 现在和 `pnpm build:sidecar` 一样，会按 `rustc --print host-tuple` 生成当前 Mac 主机对应的 sidecar。当前仓库不支持通过 `TAURI_TARGET=...` 把 PyInstaller sidecar 交叉产生成另一种 macOS 架构的文件名。

### 构建脚本逻辑

```python
# server/build_sidecar.py
def build():
    # 1. 检测 Rust target triple
    target = subprocess.check_output(["rustc", "--print", "host-tuple"])
    # → x86_64-apple-darwin / aarch64-apple-darwin / x86_64-pc-windows-msvc 等

    # 2. 确定输出路径
    output = f"../src-tauri/binaries/audio-enhancer-server-{target}"

    # 3. 运行 PyInstaller
    PyInstaller.__main__.run([
        "main.py",
        "--name", f"audio-enhancer-server-{target}",
        "--onefile",
        "--add-data", f"models{sep}models",
        "--distpath", "../src-tauri/binaries/",
    ])
```

### Sidecar 命名规则

Tauri 要求 Sidecar 二进制文件名包含 Rust target triple：

```text
src-tauri/binaries/
├── audio-enhancer-server-x86_64-apple-darwin       # macOS Intel
├── audio-enhancer-server-aarch64-apple-darwin       # macOS Apple Silicon
├── audio-enhancer-server-x86_64-pc-windows-msvc.exe # Windows x64
└── audio-enhancer-server-x86_64-unknown-linux-gnu   # Linux x64
```

## Tauri 配置

### tauri.conf.json

```json
{
  "bundle": {
    "externalBin": ["binaries/audio-enhancer-server"]
  }
}
```

!!! note "路径不含 target triple"
    `externalBin` 中的路径 **不包含** target triple 后缀。Tauri 会在运行时自动追加当前平台的 triple。

### 权限配置

**文件**: `src-tauri/capabilities/desktop.json`

```json
{
  "permissions": [
    {
      "identifier": "shell:allow-execute",
      "allow": [
        {
          "name": "binaries/audio-enhancer-server",
          "sidecar": true
        }
      ]
    },
    "shell:allow-spawn",
    "shell:allow-stdin-write",
    "shell:allow-kill"
  ]
}
```

## Rust 端管理代码

### 启动 Sidecar

```rust
// src-tauri/src/lib.rs
fn spawn_sidecar(app: &tauri::App) {
    let sidecar = app
        .shell()
        .sidecar("audio-enhancer-server")
        .expect("failed to create sidecar command");

    let (mut rx, child) = sidecar.spawn().expect("failed to spawn sidecar");

    // 保存子进程句柄用于后续关闭
    app.manage(SidecarChild(Mutex::new(Some(child))));

    // 读取 stdout 日志
    tauri::async_runtime::spawn(async move {
        while let Some(event) = rx.recv().await {
            match event {
                CommandEvent::Stdout(line) => log::info!("[sidecar] {}", line),
                CommandEvent::Stderr(line) => log::warn!("[sidecar] {}", line),
                _ => {}
            }
        }
    });
}
```

### 关闭 Sidecar

```rust
fn shutdown_sidecar(app: &tauri::App) {
    if let Some(child) = app.state::<SidecarChild>().0.lock().unwrap().take() {
        // 通过 stdin 发送关机命令
        child.write(b"sidecar shutdown\n").ok();
        // 等待进程退出
        std::thread::sleep(std::time::Duration::from_secs(2));
        // 强制终止（如果仍在运行）
        child.kill().ok();
    }
}
```

### Python 端接收关机信号

```python
# server/main.py
def _stdin_shutdown_listener():
    for line in sys.stdin:
        if line.strip() == "sidecar shutdown":
            logger.info("Received sidecar shutdown command from Tauri")
            os.kill(os.getpid(), signal.SIGINT)
```

## Readiness 约定

- `/health`：仅表示 Python 进程已启动
- `/ready`：表示模型和运行时设备已经满足增强请求条件
- Sidecar 现在轮询 `/ready`，因此“服务已启动但模型缺失”的情况会保持未 ready，而不是误报可用

## 故障排除

### Sidecar 找不到

```text
Error: failed to create sidecar command
```

确保已运行 `pnpm build:sidecar` 且二进制文件在 `src-tauri/binaries/` 目录中，文件名包含正确的 target triple。

### 模型文件缺失

Sidecar 通过 PyInstaller `--add-data` 将模型文件打包。确保在构建前将模型文件放入 `server/models/`。

### 端口冲突

如果默认端口 8000 被占用，可通过 `ENHANCER_PORT` 环境变量更改。
