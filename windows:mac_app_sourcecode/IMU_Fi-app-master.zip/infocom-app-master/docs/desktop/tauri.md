# Tauri 架构

## 核心配置

**文件**: `src-tauri/tauri.conf.json`

```json
{
  "productName": "infocom-app",
  "version": "0.1.0",
  "identifier": "com.infocom.app",
  "build": {
    "frontendDist": "../out",
    "devUrl": "http://localhost:3000",
    "beforeDevCommand": "pnpm dev",
    "beforeBuildCommand": "pnpm build"
  },
  "app": {
    "windows": [
      {
        "title": "InfoCom App",
        "width": 1200,
        "height": 800,
        "minWidth": 800,
        "minHeight": 600,
        "center": true
      }
    ]
  },
  "bundle": {
    "active": true,
    "targets": "all",
    "externalBin": ["binaries/audio-enhancer-server"],
    "icon": ["icons/32x32.png", "icons/128x128.png", "icons/icon.icns", "icons/icon.ico"]
  }
}
```

### 关键配置说明

| 字段 | 值 | 说明 |
| --- | --- | --- |
| `productName` | `infocom-app` | 应用产品名称 |
| `identifier` | `com.infocom.app` | 应用唯一标识符 |
| `frontendDist` | `../out` | Next.js 静态导出目录 |
| `devUrl` | `http://localhost:3000` | 开发时前端地址 |
| `externalBin` | `binaries/audio-enhancer-server` | Sidecar 二进制路径 |

## 前端打包

Next.js 配置为静态导出模式（`output: "export"`），输出到 `out/` 目录：

```typescript
// next.config.ts
const nextConfig: NextConfig = {
  output: "export",
  images: { unoptimized: true },
  assetPrefix: process.env.TAURI_ENV_PLATFORM ? "" : undefined,
};
```

生产构建时，Tauri 会：

1. 执行 `pnpm build`（beforeBuildCommand）
2. 将 `out/` 目录嵌入到 Tauri 二进制文件
3. WebView 加载本地 HTML/JS/CSS 文件

## Rust 项目结构

```text
src-tauri/
├── src/
│   ├── lib.rs          # Tauri 应用入口
│   ├── main.rs         # Rust main 函数
│   └── commands/       # Tauri 命令模块
│       ├── mod.rs
│       ├── model.rs    # 模型处理命令
│       └── sidecar.rs  # Sidecar 管理命令
├── Cargo.toml          # Rust 依赖
└── tauri.conf.json     # Tauri 配置
```

## Rust 依赖

```toml
[dependencies]
serde_json = "1"
serde = { version = "1", features = ["derive"] }
log = "0.4"
tauri = { version = "2", features = [] }
tauri-plugin-log = "2"
tauri-plugin-shell = "2"
tokio = { version = "1", features = ["full"] }
uuid = { version = "1", features = ["v4"] }
```

## 应用生命周期

```text
main() → tauri::Builder
  → plugin(tauri_plugin_shell)     # 注册 Shell 插件
  → plugin(tauri_plugin_log)       # 注册日志插件
  → manage(AppState)               # 注册全局状态
  → setup(|app| {
      spawn_sidecar(app)           # 启动 Python Sidecar
    })
  → invoke_handler([               # 注册 IPC 命令
      process_audio_text,
      get_process_progress,
      cancel_process,
      check_model_status,
      read_text_file,
      read_audio_file,
      save_audio_file,
      sidecar::start_server,
      sidecar::stop_server,
      sidecar::get_server_port,
    ])
  → on_window_event(|event| {
      if closing → shutdown_sidecar()  # 关闭时停止 Sidecar
    })
  → run()
```

## 构建产物

### 构建命令

```bash
pnpm tauri build
```

### 各平台产物

| 平台 | 格式 | 路径 |
| --- | --- | --- |
| Windows | `.msi` / `.exe` (NSIS) | `src-tauri/target/release/bundle/msi/` |
| macOS | `.dmg` / `.app` | `src-tauri/target/release/bundle/dmg/` |
| Linux | `.AppImage` / `.deb` | `src-tauri/target/release/bundle/appimage/` |
