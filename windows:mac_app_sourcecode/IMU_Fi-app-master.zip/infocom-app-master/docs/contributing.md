# 贡献指南

感谢你对 InfoCom App 的贡献兴趣！

## 行为准则

请在参与项目时保持友善、专业和包容。

## 如何贡献

### 报告 Bug

1. 在 [GitHub Issues](https://github.com/AstroAir/infocom-app/issues) 搜索是否已有类似问题
2. 创建新 Issue，选择 Bug 报告模板
3. 包含以下信息：
    - 操作系统和版本
    - Node.js / Rust / Python 版本
    - 复现步骤
    - 预期行为 vs 实际行为
    - 错误日志或截图

### 功能建议

1. 创建 Feature Request Issue
2. 描述功能的使用场景和预期效果
3. 讨论实现方案

### 提交代码

1. **Fork 仓库** — 点击 GitHub 上的 Fork 按钮
2. **创建分支** — `git checkout -b feat/my-feature`
3. **开发** — 修改代码，编写测试
4. **自检** — 运行 lint 和测试

    ```bash
    pnpm lint
    pnpm test
    ```

5. **提交** — 使用 Conventional Commits 规范

    ```bash
    git commit -m "feat: add audio waveform visualization"
    ```

6. **推送** — `git push origin feat/my-feature`
7. **创建 PR** — 在 GitHub 上创建 Pull Request

### PR 要求

- [ ] 标题使用 Conventional Commits 格式
- [ ] 描述变更的目的和实现方式
- [ ] 通过所有 CI 检查（lint、test、build）
- [ ] UI 变更附带截图
- [ ] 新功能包含单元测试
- [ ] 更新相关文档

## Conventional Commits

| 前缀 | 说明 | 示例 |
| --- | --- | --- |
| `feat:` | 新功能 | `feat: add audio analysis panel` |
| `fix:` | Bug 修复 | `fix: resolve WebSocket reconnection issue` |
| `docs:` | 文档更新 | `docs: update API reference` |
| `refactor:` | 代码重构 | `refactor: extract pipeline step logic` |
| `test:` | 测试相关 | `test: add E2E tests for upload page` |
| `chore:` | 工具/构建 | `chore: upgrade Tailwind to v4` |
| `ci:` | CI/CD | `ci: add macOS ARM build` |
| `style:` | 格式调整 | `style: fix code formatting` |
| `perf:` | 性能优化 | `perf: optimize STFT computation` |

## 开发设置

参见 [快速开始](getting-started/index.md) 章节搭建开发环境。

## 项目结构

参见 [项目结构](architecture/project-structure.md) 了解代码组织方式。

## 代码规范

参见 [代码规范](development/code-style.md) 了解编码约定。

## 许可证

本项目采用 MIT 许可证。提交 PR 即表示你同意你的贡献将在此许可证下发布。
