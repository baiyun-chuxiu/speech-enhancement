# 快速开始

本章节帮助你在 10 分钟内搭建 InfoCom App 的完整开发环境并运行项目。

## 前置要求概览

| 工具 | 最低版本 | 用途 |
| --- | --- | --- |
| Node.js | 20.x | 前端运行时 |
| pnpm | 8.x | 前端包管理 |
| Rust | 1.77.2 | Tauri 桌面应用编译 |
| Python | 3.10 | 后端 AI 服务 |
| uv | 最新 | Python 依赖管理 |

## 章节导航

1. [**安装**](installation.md) — 安装所有前置依赖（Node.js、Rust、Python、uv）
2. [**环境配置**](configuration.md) — 配置环境变量、模型文件、开发工具
3. [**第一次运行**](first-run.md) — 启动开发服务器，体验完整功能

## 极速开始（TL;DR）

如果你已经安装好所有依赖，可以直接执行：

```bash
# 克隆项目
git clone https://github.com/AstroAir/infocom-app.git
cd infocom-app

# macOS 推荐：一键初始化仓库依赖与本地配置
pnpm setup:macos

# 放置模型文件到 server/models/（联系项目负责人获取）

# 启动前后端联合开发
pnpm dev:all
```

如果你不在 macOS 上，或希望按步骤手动执行，请改用安装章节里的 `pnpm install` + `cd server && uv sync && cd ..` 流程。

- 前端: [http://localhost:3000](http://localhost:3000)
- 后端 API: [http://localhost:8000](http://localhost:8000)
- Swagger 文档: [http://localhost:8000/docs](http://localhost:8000/docs)
