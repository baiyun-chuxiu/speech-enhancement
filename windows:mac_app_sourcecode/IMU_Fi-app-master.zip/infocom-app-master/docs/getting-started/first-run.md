# 第一次运行

## 启动方式

### 方式一：前后端联合启动（推荐）

```bash
pnpm dev:all
```

该命令同时启动：

- Next.js 开发服务器（端口 3000）
- Python FastAPI 后端（端口 8000）

### 方式二：分别启动

**终端 1 — 前端：**

```bash
pnpm dev
```

**终端 2 — 后端：**

```bash
pnpm dev:server
# 等价于: cd server && uv run python -m uvicorn main:app --reload
```

### 方式三：桌面应用模式

```bash
pnpm tauri dev
```

此命令会：

1. 编译 Rust 代码
2. 启动 Next.js 开发服务器
3. 打开 Tauri 原生窗口
4. 自动启动 Python Sidecar（需先构建 Sidecar）

## 验证服务状态

### 检查前端

打开浏览器访问 [http://localhost:3000](http://localhost:3000)，应看到 InfoCom App 首页。

### 检查后端

```bash
# Liveness
curl http://localhost:8000/health

# 预期响应
# {"status":"ok","version":"1.0.0","timestamp":"...","readiness_status":"degraded","is_ready":false,...}

# Readiness
curl http://localhost:8000/ready

# 预期响应（无模型文件时）
# {"status":"degraded","is_ready":false,"degraded_reason":"missing-model-files",...}
```

### 查看 API 文档

- **Swagger UI**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **ReDoc**: [http://localhost:8000/redoc](http://localhost:8000/redoc)

## 体验完整工作流

1. **打开上传页面** — 导航到 `/upload`
2. **上传加速度计数据** — 选择 `.txt` 格式的加速度计数据文件
3. **上传陀螺仪数据** — 选择 `.txt` 格式的陀螺仪数据文件
4. **上传音频文件** — 选择 `.wav` 格式的音频文件
5. **开始处理** — 点击「开始增强」按钮
6. **查看进度** — 观察 6 步管线的实时进度
7. **播放结果** — 处理完成后试听增强后的音频

### 示例数据

项目 `data/` 目录包含示例数据供测试：

```text
data/
├── segment_1.txt       # 加速度计示例数据
└── segment_1_1.wav     # 音频示例文件
```

!!! tip "数据格式"
    加速度计和陀螺仪的 `.txt` 文件每行包含三轴数据（x, y, z），以空格或制表符分隔。管线会自动读取最后三列数值。

## 常见启动问题

### 后端无法启动

```text
ModuleNotFoundError: No module named 'torch'
```

解决：在 `server/` 目录运行 `uv sync` 安装依赖。

### 模型加载警告

```text
WARNING: Generator model not found at ... – using random weights
```

解决：将模型文件（`generator_final.pth`、`best_model.pth`）放入 `server/models/` 目录。

### 端口被占用

```text
Address already in use: 0.0.0.0:8000
```

解决：通过环境变量更改端口 `ENHANCER_PORT=8001`，或关闭占用端口的进程。

### Tauri 编译错误

确保已安装 Rust 工具链和系统依赖（见 [安装](installation.md)）。首次编译时间较长（约 5-10 分钟），后续增量编译会显著加快。
