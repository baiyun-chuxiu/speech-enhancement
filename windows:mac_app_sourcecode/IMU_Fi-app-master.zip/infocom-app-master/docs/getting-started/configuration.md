# 环境配置

## 环境变量

在项目根目录创建 `.env.local` 文件。macOS 上如果使用 `pnpm setup:macos`，该文件会在缺失时自动基于 `.env.local.example` 创建：

```bash
# ========== Next.js 前端 ==========
NEXT_PUBLIC_ENHANCER_API_URL=http://localhost:8000
NEXT_PUBLIC_API_URL=http://localhost:8000

# ========== Python 后端 ==========
ENHANCER_HOST=0.0.0.0
ENHANCER_PORT=8000
ENHANCER_DEVICE=auto          # auto | cpu | cuda | mps
ENHANCER_MODELS_DIR=./server/models
ENHANCER_GENERATOR_PATH=./server/models/generator_final.pth
ENHANCER_DENOISE_PATH=./server/models/best_model.pth
ENHANCER_CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

### 后端环境变量参考

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `ENHANCER_HOST` | `0.0.0.0` | 服务器监听地址 |
| `ENHANCER_PORT` | `8000` | 服务器端口 |
| `ENHANCER_DEVICE` | 自动检测 | 计算设备：`cpu`、`cuda`（NVIDIA GPU）、`mps`（Apple Silicon） |
| `ENHANCER_MODELS_DIR` | `./server/models` | 模型文件目录 |
| `ENHANCER_GENERATOR_PATH` | `{models_dir}/generator_final.pth` | GAN 生成器模型路径 |
| `ENHANCER_DENOISE_PATH` | `{models_dir}/best_model.pth` | 降噪网络模型路径 |
| `ENHANCER_CORS_ORIGINS` | `http://localhost:3000,...` | CORS 允许来源（逗号分隔） |

### 设备自动检测逻辑

后端会按以下优先级自动检测最佳计算设备：

1. **CUDA** — 如果 NVIDIA GPU 可用且安装了 CUDA
2. **MPS** — 如果运行在 Apple Silicon (M1/M2/M3/M4) 上
3. **CPU** — 兜底方案

## 模型文件

将以下预训练模型放入 `server/models/` 目录：

```text
server/models/
├── generator_final.pth    (~30MB) — GAN 生成器（IMU → 视频位移）
└── best_model.pth         (~4MB)  — 音频降噪网络
```

!!! warning "模型文件不在 Git 仓库中"
    模型文件（`.pth`）被 `.gitignore` 排除。请联系项目负责人获取模型权重文件。

!!! info "macOS 一键初始化边界"
    `pnpm setup:macos` 会自动准备依赖、检查 Tauri 环境并创建缺失的 `.env.local`，但**不会**自动下载模型文件，也不会配置 Apple 签名/公证凭据。

## 前端设置页面

应用内提供了图形化设置界面（`/settings`），可以配置：

- **API 服务器地址** — 后端服务 URL，支持连接测试
- **主题** — 亮色 / 暗色 / 跟随系统
- **计算设备** — auto / CPU / CUDA / MPS
- **处理质量** — 快速 / 平衡 / 高质量（Coming Soon）
- **输出格式** — WAV / MP3 / FLAC（Coming Soon）
- **自动保存** — 自动保存处理结果
- **通知** — 处理完成通知

设置保存在浏览器 `localStorage` 中，键名为 `infocom-settings`。

## Tauri 配置

桌面应用的核心配置文件为 `src-tauri/tauri.conf.json`：

```json
{
  "productName": "infocom-app",
  "version": "0.1.0",
  "identifier": "com.infocom.app",
  "build": {
    "frontendDist": "../out",
    "devUrl": "http://localhost:3000",
    "beforeDevCommand": "pnpm dev",
    "beforeBuildCommand": "pnpm build"
  },
  "bundle": {
    "externalBin": ["binaries/audio-enhancer-server"]
  }
}
```

### 路径别名

项目配置了以下 TypeScript 路径别名（`tsconfig.json`）：

| 别名 | 映射 |
| --- | --- |
| `@/components` | `components/` |
| `@/lib` | `lib/` |
| `@/ui` | `components/ui/` |
| `@/hooks` | `hooks/` |
| `@/utils` | `lib/utils.ts` |

使用方式：

```typescript
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useFileUpload } from "@/hooks/useFileUpload";
```
