# 安装

## Node.js 与 pnpm

=== "macOS"

    ```bash
    # 通过 Homebrew
    brew install node@22
    npm install -g pnpm

    # 或通过 nvm
    brew install nvm
    nvm install 22
    npm install -g pnpm
    ```

=== "Windows"

    ```powershell
    # 通过 winget
    winget install OpenJS.NodeJS.LTS
    npm install -g pnpm

    # 或下载安装包: https://nodejs.org/
    ```

=== "Linux"

    ```bash
    # Ubuntu/Debian
    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
    sudo apt-get install -y nodejs
    npm install -g pnpm
    ```

验证安装：

```bash
node --version   # >= 20.x
pnpm --version   # >= 8.x
```

## Rust 工具链

Tauri 桌面应用需要 Rust 编译器。

=== "macOS / Linux"

    ```bash
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
    source "$HOME/.cargo/env"
    ```

    macOS 还需要 Xcode 命令行工具：

    ```bash
    xcode-select --install
    ```

=== "Windows"

    下载并运行 [rustup-init.exe](https://rustup.rs/)，确保安装了 **Visual Studio C++ Build Tools**。

验证安装：

```bash
rustc --version   # >= 1.77.2
cargo --version
```

## Python 与 uv

后端使用 [uv](https://docs.astral.sh/uv/) 管理 Python 依赖。

=== "macOS"

    ```bash
    curl -LsSf https://astral.sh/uv/install.sh | sh
    # 或
    brew install uv
    ```

=== "Windows"

    ```powershell
    powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
    ```

=== "Linux"

    ```bash
    curl -LsSf https://astral.sh/uv/install.sh | sh
    ```

验证安装：

```bash
uv --version
```

!!! info "Python 版本"
    项目指定 Python 3.12（`server/.python-version`）。`uv sync` 会自动下载对应版本，无需手动安装 Python。

## 系统依赖（仅 Linux）

在 Linux 上构建 Tauri 需要额外的系统包：

```bash
sudo apt-get install -y \
  libgtk-3-dev \
  libwebkit2gtk-4.1-dev \
  libappindicator3-dev \
  librsvg2-dev \
  patchelf \
  libssl-dev
```

## 克隆与初始化

```bash
# 1. 克隆代码
git clone https://github.com/AstroAir/infocom-app.git
cd infocom-app

# 2. macOS 推荐：一键初始化仓库依赖与本地配置
pnpm setup:macos

# 3. 其他平台或手动执行时：
# pnpm install
# cd server && uv sync && cd ..

# 4. 验证 Tauri 环境
pnpm tauri info
```

`pnpm setup:macos` 会检查 Xcode Command Line Tools、`uv` 和 `rustc`，然后依次执行前端依赖安装、后端 `uv sync`、Tauri 环境检查，并在缺少 `.env.local` 时根据 `.env.local.example` 自动创建。模型文件仍需手动放入 `server/models/`。

## PyInstaller（可选）

仅在需要构建桌面应用的 Sidecar 二进制文件时安装：

```bash
cd server
uv pip install pyinstaller
```
