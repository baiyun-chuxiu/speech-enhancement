# WebSocket API

## 任务进度推送

### WS /ws/tasks/{task_id}

建立 WebSocket 连接以实时接收任务进度更新。

**连接 URL**:

```text
ws://localhost:8000/ws/tasks/{task_id}
```

### 连接流程

1. 客户端连接 WebSocket
2. 服务端立即发送当前任务状态
3. 每次进度更新时服务端推送新状态
4. 无活动 30 秒后发送心跳包
5. 任务完成/失败/取消后发送最终状态

### 消息格式

**任务状态消息**:

```json
{
  "task_id": "uuid-string",
  "status": "running",
  "progress": 66,
  "message": "Post-processing spectrogram...",
  "steps": [
    {"index": 0, "name": "IMU Data Preprocessing", "status": "completed", "progress": 100},
    {"index": 1, "name": "GAN Video Displacement Generation", "status": "completed", "progress": 100},
    {"index": 2, "name": "Audio Feature Extraction (STFT)", "status": "completed", "progress": 100},
    {"index": 3, "name": "Joint Denoise Inference", "status": "completed", "progress": 100},
    {"index": 4, "name": "Spectrogram Post-processing", "status": "running", "progress": 50},
    {"index": 5, "name": "Audio Reconstruction (ISTFT)", "status": "pending", "progress": 0}
  ],
  "result": null,
  "error": null,
  "created_at": "2024-01-01T00:00:00",
  "updated_at": "2024-01-01T00:00:05"
}
```

**心跳消息**:

```json
{
  "type": "ping"
}
```

客户端应忽略 `type: "ping"` 消息。

### 前端使用示例

```typescript
import { createEnhancerTaskWebSocket } from "@/lib/api/enhancer-api";

const ws = createEnhancerTaskWebSocket(
  taskId,
  (task) => {
    // 更新进度 UI
    console.log(`Progress: ${task.progress}%`);
    task.steps.forEach((step) => {
      console.log(`  ${step.name}: ${step.status} (${step.progress}%)`);
    });
  },
  (error) => console.error("WS error:", error),
  () => console.log("WS closed")
);

// 关闭连接
ws.close();
```

### 与 HTTP 轮询的对比

| 特性 | WebSocket | HTTP 轮询 |
| --- | --- | --- |
| 延迟 | 实时 | 取决于轮询间隔 |
| 网络开销 | 低（持久连接） | 高（频繁请求） |
| 实现复杂度 | 中 | 低 |
| 断线处理 | 需要重连逻辑 | 自动重试 |
| 当前默认 | 备选 | 主要方式（500ms 间隔） |

!!! info "默认使用轮询"
    前端 `useModelApi` hook 默认使用 HTTP 轮询（`pollEnhancerTask`，500ms 间隔），WebSocket 作为备选方案。可通过 `createEnhancerTaskWebSocket` 手动切换。
