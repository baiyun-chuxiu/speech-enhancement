# Tauri 命令 API

Tauri 命令通过 `invoke()` 在前端调用，由 Rust 后端处理。

## 调用方式

```typescript
import { invoke } from "@tauri-apps/api/core";

const result = await invoke<ReturnType>("command_name", { arg1: value1 });
```

## 模型处理命令

### process_audio_text

处理音频和文本文件。

```typescript
const response = await invoke<ProcessResponse>("process_audio_text", {
  textPath: string,
  audioPath: string,
  textContent?: string,
  options?: ProcessOptions,
});
```

### get_process_progress

获取任务处理进度。

```typescript
const steps = await invoke<ProcessStep[]>("get_process_progress", {
  taskId: string,
});
```

### cancel_process

取消正在进行的处理任务。

```typescript
await invoke<void>("cancel_process", { taskId: string });
```

### check_model_status

检查模型可用性。

该命令会读取 Python 后端的 `/api/v1/system/info`，并基于 `is_ready` 与真实模型加载状态返回结果；如果后端仅仅“活着”但还未 ready，则 `isAvailable` 为 `false`。

```typescript
const status = await invoke<ModelStatus>("check_model_status");
// { isAvailable: false | true, modelName: "...", modelVersion: "...", capabilities: [...] }
```

## 文件操作命令

### read_text_file

读取文本文件内容。

```typescript
const content = await invoke<string>("read_text_file", { path: string });
```

### read_audio_file

读取音频文件为字节数组。

```typescript
const data = await invoke<number[]>("read_audio_file", { path: string });
const uint8 = new Uint8Array(data);
```

### save_audio_file

保存音频数据到文件。

```typescript
const savedPath = await invoke<string>("save_audio_file", {
  data: Array.from(new Uint8Array(audioBuffer)),
  format: "wav",
});
```

## Sidecar 管理命令

### start_server

手动启动 Python Sidecar 服务。

```typescript
await invoke<void>("start_server");
```

### stop_server

手动停止 Python Sidecar 服务。

```typescript
await invoke<void>("stop_server");
```

### get_server_port

获取 Sidecar 监听的端口号。

```typescript
const port = await invoke<number>("get_server_port");
// 通常返回 8000
```

## 环境检测

```typescript
// 检测是否在 Tauri 环境中运行
const isTauri = typeof window !== "undefined" && "__TAURI__" in window;
```

`model-api.ts` 中的 `ModelApi` 类根据运行环境自动切换：

- **Tauri 环境** → 使用 `invoke` 命令
- **Web 环境** → 使用 HTTP API
