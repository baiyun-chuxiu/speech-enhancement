# API 参考

InfoCom App 提供三种 API 通信方式：REST API、WebSocket 和 Tauri 命令。

## API 概览

| 方式 | 协议 | 适用场景 |
| --- | --- | --- |
| REST API | HTTP | Web 模式文件上传、任务管理 |
| WebSocket | WS | 实时进度推送 |
| Tauri 命令 | IPC | 桌面应用本地操作 |

## 基础 URL

- **开发环境**: `http://localhost:8000`
- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`

## 章节导航

- [**REST API**](rest.md) — HTTP 端点完整参考
- [**WebSocket API**](websocket.md) — 实时进度推送协议
- [**Tauri 命令 API**](tauri-commands.md) — 桌面应用 IPC 命令
- [**前端 Hooks API**](hooks.md) — React Hooks 接口
