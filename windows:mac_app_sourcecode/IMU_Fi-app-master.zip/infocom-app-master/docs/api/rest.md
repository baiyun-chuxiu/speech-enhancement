# REST API

## Liveness and Readiness

### GET /health

进程存活检查。即使模型缺失、后端处于降级状态，这个接口仍会返回 `status: "ok"`，用于桌面 sidecar 和基础连通性检测。

**响应**:

```json
{
  "status": "ok",
  "version": "1.0.0",
  "timestamp": "2026-03-13T10:00:00.000000",
  "readiness_status": "degraded",
  "is_ready": false,
  "degraded_reason": "missing-model-files"
}
```

### GET /ready

增强能力就绪检查。前端和桌面端应使用这个接口判断“能否真正开始处理”。

**响应**:

```json
{
  "status": "ready",
  "version": "1.0.0",
  "timestamp": "2026-03-13T10:00:00.000000",
  "is_ready": true,
  "configured_device": "cpu",
  "effective_device": "cpu",
  "supported_devices": ["cpu"],
  "degraded_reason": null
}
```

当模型文件缺失或加载失败时：

```json
{
  "status": "degraded",
  "is_ready": false,
  "degraded_reason": "missing-model-files"
}
```

## 系统信息

### GET /api/v1/system/info

返回运行时设备信息、readiness 状态，以及模型文件/权重加载的真实情况。

**响应**:

```json
{
  "version": "1.0.0",
  "python_version": "3.12.13",
  "platform": "Windows-11-10.0.26200-SP0",
  "cuda_available": false,
  "mps_available": false,
  "configured_device": "cpu",
  "device": "cpu",
  "supported_devices": ["cpu"],
  "status": "degraded",
  "is_ready": false,
  "degraded_reason": "missing-model-files",
  "generator_loaded": false,
  "denoise_loaded": false,
  "generator_model_exists": false,
  "denoise_model_exists": false,
  "generator_error": null,
  "denoise_error": null
}
```

## 文件管理

### POST /api/v1/files/upload

上传单个文件。空文件会被拒绝。

### GET /api/v1/files/download/{file_id}

下载增强结果或之前上传的原始文件。若任务取消或失败导致结果文件被清理，则返回 `404`。

## 音频增强

### POST /api/v1/enhance

上传三元组文件并创建后台任务。

**请求**: `multipart/form-data`

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `audio_file` | File | 是 | 音频文件 |
| `accel_file` | File | 是 | 加速度计数据 |
| `gyro_file` | File | 是 | 陀螺仪数据 |
| `device` | query string | 否 | `auto` / `cpu` / `cuda` / `mps` |

**响应**:

```json
{
  "success": true,
  "task_id": "uuid-string",
  "status": "pending",
  "requested_device": "auto",
  "effective_device": "cpu"
}
```

如果请求了当前主机不支持的设备，返回 `400`。  
如果 backend 处于 degraded / not ready，返回 `503`。

### POST /api/v1/enhance/uploaded

使用已上传文件 ID 创建任务，契约与 `/api/v1/enhance` 一致。

### POST /api/v1/enhance/batch

批量提交多组 `(audio, accel, gyro)` 文件。所有列表长度必须一致，设备校验、readiness 校验、取消语义与单任务接口一致。

## 任务管理

### GET /api/v1/tasks/{task_id}

查询任务状态、步骤进度和终态元数据。

**响应示例**:

```json
{
  "task_id": "uuid-string",
  "status": "completed",
  "progress": 100,
  "message": "Enhancement complete",
  "requested_device": "auto",
  "effective_device": "cpu",
  "steps": [],
  "result": {
    "output_file_id": "uuid-string",
    "output_url": "/api/v1/files/download/uuid-string",
    "requested_device": "auto",
    "effective_device": "cpu",
    "device": "cpu",
    "total_time": 2.5,
    "sample_rate": 44100
  },
  "error": null,
  "created_at": "2026-03-13T10:00:00",
  "updated_at": "2026-03-13T10:00:03"
}
```

### POST /api/v1/tasks/{task_id}/cancel

发送协作式取消请求。任务会在下一个安全检查点进入 `cancelled`，并且不会在之后回写成 `completed`。

## 错误码

| 状态码 | 说明 |
| --- | --- |
| 200 | 请求成功 |
| 400 | 请求参数错误，例如设备不受支持、空文件、批量列表长度不一致 |
| 404 | 任务或文件不存在 |
| 422 | FastAPI 参数验证失败 |
| 503 | backend 已启动但未 ready |
| 500 | 未处理的服务器错误 |
