# 前端 Hooks API

## useFileUpload Hook

```typescript
import { useFileUpload } from "@/hooks/useFileUpload";

const { fileInfo, isUploading, progress, error, selectFile, removeFile, reset } =
  useFileUpload({
    maxSize: 100 * 1024 * 1024, // 100MB
    acceptedTypes: [".wav", ".mp3"],
    onSuccess: (info) => console.log("Uploaded:", info),
    onError: (err) => console.error(err),
  });
```

### 派生 Hooks

```typescript
// 文本文件专用 — 接受 .txt
const upload = useTextFileUpload();

// 音频文件专用 — 接受 .wav .mp3 .m4a .ogg .flac .aac
const upload = useAudioFileUpload();
```

### useFileUpload 返回值

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `fileInfo` | `FileInfo \| null` | 已上传文件的元信息 |
| `isUploading` | `boolean` | 是否正在上传 |
| `progress` | `number` | 上传进度 (0-100) |
| `error` | `string \| null` | 错误信息 |
| `selectFile` | `(file: File) => Promise<void>` | 选择文件并开始上传 |
| `removeFile` | `() => void` | 移除已上传文件 |
| `reset` | `() => void` | 重置所有状态 |

## useModelApi Hook

```typescript
import { useModelApi } from "@/hooks/useModelApi";

const {
  isProcessing,
  progress,
  steps,
  outputAudio,
  error,
  modelStatus,
  processEnhance,
  cancelProcess,
  checkStatus,
  reset,
} = useModelApi({
  onProgress: (p) => console.log(`${p}%`),
  onComplete: (res) => console.log("Done:", res),
  onError: (err) => console.error(err),
});

// 开始增强处理
await processEnhance(audioFile, accelFile, gyroFile, "auto");
```

### useModelApi 返回值

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `isProcessing` | `boolean` | 是否正在处理 |
| `progress` | `number` | 整体进度 (0-100) |
| `steps` | `ProcessStep[]` | 6 步处理状态数组 |
| `outputAudio` | `ProcessedAudio \| null` | 输出音频 |
| `error` | `string \| null` | 错误信息 |
| `modelStatus` | `ModelStatus \| null` | 模型状态 |
| `process` | `Function` | 通过 Tauri/HTTP 处理 |
| `processEnhance` | `Function` | 通过 Enhancer API 处理 |
| `cancelProcess` | `() => Promise<void>` | 取消处理 |
| `checkStatus` | `() => Promise<ModelStatus>` | 检查模型状态 |
| `reset` | `() => void` | 重置所有状态 |

## useAudioPlayer

音频播放控制 Hook，基于 Web Audio API。

```typescript
import { useAudioPlayer } from "@/hooks/useAudioPlayer";

const {
  state,
  analysis,
  load,
  play,
  pause,
  toggle,
  stop,
  seek,
  setVolume,
  toggleMute,
  setPlaybackRate,
  analyzeAudio,
} = useAudioPlayer({
  autoPlay: false,
  onPlay: () => console.log("Playing"),
  onEnded: () => console.log("Ended"),
});

// 加载并播放
load("http://localhost:8000/api/v1/files/download/uuid");
await play();

// 音量控制
setVolume(0.5);
toggleMute();

// 播放速度
setPlaybackRate(1.5);

// 跳转
seek(30); // 跳到 30 秒

// 分析音频
const result = await analyzeAudio();
console.log("Peak amplitude:", result?.peakAmplitude);
```

### AudioPlaybackState

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `isPlaying` | `boolean` | 正在播放 |
| `isPaused` | `boolean` | 已暂停 |
| `currentTime` | `number` | 当前播放位置（秒） |
| `duration` | `number` | 总时长（秒） |
| `volume` | `number` | 音量 (0-1) |
| `isMuted` | `boolean` | 是否静音 |
| `playbackRate` | `number` | 播放速度 |
| `isLoading` | `boolean` | 加载中 |
| `error` | `string?` | 错误信息 |

### AudioAnalysis

| 属性 | 类型 | 说明 |
| --- | --- | --- |
| `duration` | `number` | 时长（秒） |
| `sampleRate` | `number` | 采样率 |
| `channels` | `number` | 通道数 |
| `waveformData` | `number[]` | 归一化波形数据 (200 点) |
| `peakAmplitude` | `number` | 峰值振幅 |
| `averageAmplitude` | `number` | 平均振幅 |
| `silenceRatio` | `number` | 静音比例 (0-1) |

## useI18n

国际化切换 Hook。

```typescript
import { useI18n } from "@/components/i18n-provider";

const { locale, setLocale } = useI18n();
// locale: "zh-CN" | "en"
setLocale("en");
```

## formatTime

时间格式化工具函数。

```typescript
import { formatTime } from "@/hooks/useAudioPlayer";

formatTime(65); // "1:05"
formatTime(0); // "0:00"
```

## formatFileSize

文件大小格式化工具函数。

```typescript
import { formatFileSize } from "@/hooks/useFileUpload";

formatFileSize(1024); // "1 KB"
formatFileSize(1048576); // "1 MB"
```
