# 常见问题

## 通用问题

### InfoCom App 是什么？

InfoCom App 是一款 IMU 辅助音频增强工具，利用手机惯性传感器（加速度计、陀螺仪）数据，通过深度学习模型实现高质量的音频降噪与增强。项目面向 MobiCom 2026 研究论文。

### 支持哪些平台？

- **Web** — 任何现代浏览器（Chrome、Firefox、Safari、Edge）
- **桌面** — Windows 10+、macOS 12+（Intel & Apple Silicon）、Linux（Ubuntu 22.04+）

### 需要 GPU 吗？

不需要。CPU 可以正常运行，但速度较慢。推荐使用：

- **NVIDIA GPU + CUDA** — 推理速度最快
- **Apple Silicon (M1/M2/M3/M4)** — 通过 MPS 加速
- **CPU** — 兼容所有平台，处理时间约 5-15 秒

## 安装问题

### `uv sync` 失败怎么办？

```bash
# 确保 uv 已安装
uv --version

# 清理缓存重试
cd server
rm -rf .venv
uv sync
```

### `pnpm install` 很慢怎么办？

```bash
# 使用国内镜像
pnpm config set registry https://registry.npmmirror.com
pnpm install
```

### Rust 编译失败怎么办？

```bash
# 更新 Rust 工具链
rustup update

# 清理构建缓存
cd src-tauri
cargo clean
```

## 使用问题

### 支持哪些音频格式？

输入支持：WAV、MP3、M4A、OGG、FLAC、AAC

输出格式：WAV（22050 Hz）

### 数据文件格式是什么？

加速度计和陀螺仪数据为 `.txt` 文本文件，每行包含三轴数据：

```text
0.012 -9.81 0.03
0.015 -9.79 0.05
```

管线自动读取每行最后三列数值作为 x、y、z 轴数据。

### 模型文件在哪里获取？

模型权重文件（`generator_final.pth` 和 `best_model.pth`）不包含在 Git 仓库中。请联系项目负责人获取，放置到 `server/models/` 目录。

### 处理速度大概多长时间？

| 设备 | 典型耗时 |
| --- | --- |
| NVIDIA RTX 3080 (CUDA) | 1-2 秒 |
| Apple M2 (MPS) | 2-4 秒 |
| Intel i7 (CPU) | 5-15 秒 |

### 如何切换语言？

点击页面右上角的语言按钮（🌐），可在中文和英文之间切换。语言偏好会保存在浏览器中。

### 如何切换暗色模式？

点击页面右上角的主题切换按钮（☀️/🌙）。也可在设置页面 (`/settings`) 中配置主题为亮色、暗色或跟随系统。

## 开发问题

### 如何只开发前端？

```bash
pnpm dev
# 前端在 http://localhost:3000
# 如果不需要后端，上传页面会使用模拟数据
```

### 如何只开发后端？

```bash
cd server
uv run python -m uvicorn main:app --reload
# API 文档在 http://localhost:8000/docs
```

### 如何添加新的 UI 组件？

```bash
pnpm dlx shadcn@latest add <component-name>
# 例如: pnpm dlx shadcn@latest add dialog
```

### 如何添加新的翻译？

1. 在 `messages/zh-CN.json` 和 `messages/en.json` 中添加翻译键
2. 在组件中使用 `useTranslations('namespace')` 获取翻译

### 测试失败怎么办？

```bash
# 清理并重新运行
pnpm test -- --clearCache
pnpm test

# E2E 测试需要先构建
pnpm build
pnpm test:e2e
```

## 部署问题

### Web 部署后 API 连接失败？

确保：

1. 后端服务已启动并可访问
2. `NEXT_PUBLIC_API_URL` 指向正确的后端地址
3. 后端 `ENHANCER_CORS_ORIGINS` 包含前端域名

### 桌面应用 Sidecar 启动失败？

1. 确认已运行 `pnpm build:sidecar` 且二进制文件存在
2. 检查文件名是否包含正确的 target triple
3. macOS 用户检查 Gatekeeper 是否阻止了执行

### macOS 应用被 Gatekeeper 阻止？

未签名的应用会被 Gatekeeper 阻止。解决方法：

```bash
# 方法 1: 右键点击 → 打开
# 方法 2: 终端运行
xattr -cr /Applications/infocom-app.app
```

生产分发建议进行代码签名和 Apple 公证。
