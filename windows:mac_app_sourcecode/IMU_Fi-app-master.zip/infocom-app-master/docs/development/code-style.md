# 代码规范

## TypeScript / React

### TypeScript 命名约定

| 类型 | 约定 | 示例 |
| --- | --- | --- |
| 组件 | PascalCase | `AudioPlayer`, `FileUploadZone` |
| Hooks | camelCase，`use` 前缀 | `useFileUpload`, `useAudioPlayer` |
| 工具函数 | camelCase | `formatTime`, `formatFileSize` |
| 类型/接口 | PascalCase | `FileInfo`, `ProcessStep` |
| 常量 | SCREAMING_SNAKE_CASE | `DEFAULT_MAX_SIZE`, `API_CONFIG` |
| 文件名（组件） | kebab-case | `audio-player.tsx`, `file-upload-zone.tsx` |
| 文件名（路由） | lowercase | `page.tsx`, `layout.tsx` |

### ESLint 配置

**文件**: `eslint.config.mjs`

项目使用 ESLint 进行代码检查，配置继承自 `next/core-web-vitals` 和 `next/typescript`。

```bash
# 运行 lint
pnpm lint

# 自动修复
pnpm lint --fix
```

### 组件编写规范

```tsx
"use client";

import { useState, useCallback } from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import type { FileInfo } from "@/lib/types";

interface MyComponentProps {
  fileInfo: FileInfo;
  onProcess: () => void;
}

export function MyComponent({ fileInfo, onProcess }: MyComponentProps) {
  const t = useTranslations("upload");
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = useCallback(() => {
    setIsLoading(true);
    onProcess();
  }, [onProcess]);

  return (
    <Button onClick={handleClick} disabled={isLoading}>
      {t("startProcess")}
    </Button>
  );
}
```

### 关键规则

- 所有页面和组件使用 `'use client'` 指令（静态导出模式）
- 使用 `useTranslations` 替代硬编码文本
- 使用 `cn()` 合并 Tailwind 类名
- 导入顺序：React → 第三方库 → 项目内部 → 类型

## Python

### Python 命名约定

| 类型 | 约定 | 示例 |
| --- | --- | --- |
| 类 | PascalCase | `EnhancerPipeline`, `ServerConfig` |
| 函数/方法 | snake_case | `process_imu_data`, `load_models` |
| 常量 | SCREAMING_SNAKE_CASE | `PIPELINE_STEPS` |
| 模块 | snake_case | `pipeline.py`, `config.py` |
| 私有函数 | `_` 前缀 | `_is_number`, `_stdin_shutdown_listener` |

### 类型注解

后端代码使用 Python 类型注解和 Pydantic 模型：

```python
from typing import Optional, Callable

ProgressCallback = Callable[[int, str, int, str], None]

def process_single(
    self,
    wav_path: str,
    acc_path: str,
    gyro_path: str,
    output_wav_path: str,
    on_progress: Optional[ProgressCallback] = None,
) -> dict:
    ...
```

## Rust

### Rust 命名约定

| 类型 | 约定 | 示例 |
| --- | --- | --- |
| 结构体 | PascalCase | `AppState`, `ProcessOptions` |
| 函数 | snake_case | `process_audio_text`, `spawn_sidecar` |
| 常量 | SCREAMING_SNAKE_CASE | — |
| 模块 | snake_case | `model.rs`, `sidecar.rs` |

### Tauri 命令规范

```rust
#[tauri::command]
pub async fn my_command(
    state: State<'_, AppState>,
    arg_name: String,
) -> Result<ReturnType, String> {
    // 实现
}
```

- 所有命令返回 `Result<T, String>`
- 使用 `State<'_, AppState>` 访问共享状态
- 参数名使用 camelCase（与 JS 前端一致）
