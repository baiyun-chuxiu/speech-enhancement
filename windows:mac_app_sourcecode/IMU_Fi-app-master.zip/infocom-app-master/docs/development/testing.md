# 测试

## 测试框架

| 类型 | 框架 | 配置文件 |
| --- | --- | --- |
| 单元测试 | Jest + React Testing Library | `jest.config.ts` |
| E2E 测试 | Playwright | `playwright.config.ts` |

## 单元测试

### 运行测试

```bash
# 运行所有测试
pnpm test

# 监视模式
pnpm test -- --watch

# 生成覆盖率报告
pnpm test:coverage

# 运行特定文件
pnpm test -- hooks/useFileUpload.test.ts
```

### 测试文件位置

测试文件与源文件同目录，使用 `.test.ts` / `.test.tsx` 后缀：

```text
hooks/
├── useFileUpload.ts
├── useFileUpload.test.ts
components/upload/
├── audio-player.tsx
├── audio-player.test.tsx
├── audio-analyzer.tsx
├── audio-analyzer.test.tsx
lib/api/
├── enhancer-api.ts
├── enhancer-api.test.ts
lib/utils/
├── data-parser.ts
├── data-parser.test.ts
app/
├── settings/
│   ├── page.tsx
│   └── page.test.tsx
├── help/
│   ├── page.tsx
│   └── page.test.tsx
```

### Mock 配置

```text
__mocks__/
├── fileMock.js    # 静态文件 mock
└── styleMock.js   # CSS 模块 mock
```

### Jest 配置要点

```typescript
// jest.config.ts
{
  testEnvironment: "jsdom",
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/$1",  // 路径别名
  },
  setupFilesAfterSetup: ["<rootDir>/jest.setup.ts"],
}
```

## E2E 测试

### 运行 E2E 测试

```bash
# 先构建应用
pnpm build

# 运行所有 E2E 测试
pnpm test:e2e

# 仅 Chromium
pnpm test:e2e:chromium

# 查看报告
pnpm exec playwright show-report
```

### E2E 测试结构

```text
e2e/
├── fixtures/               # 测试数据文件
│   ├── real-accel-segment1.txt
│   ├── real-accel-segment2.txt
│   └── invalid-file.pdf
├── helpers/                # 测试工具
│   ├── api-mock.ts         # API mock 工具
│   ├── test-utils.ts       # 通用测试工具
│   └── index.ts
├── accessibility.spec.ts   # 无障碍测试
├── api-integration.spec.ts # API 集成测试
├── audio-player.spec.ts    # 播放器测试
├── file-upload.spec.ts     # 文件上传测试
├── i18n.spec.ts            # 国际化测试
├── navigation.spec.ts      # 导航测试
├── settings.spec.ts        # 设置页测试
└── upload-page.spec.ts     # 上传页测试
```

### 测试覆盖场景

| 测试文件 | 覆盖场景 |
| --- | --- |
| `file-upload.spec.ts` | 文件选择、拖拽上传、类型校验、大小限制 |
| `audio-player.spec.ts` | 播放、暂停、进度、音量 |
| `api-integration.spec.ts` | API 调用、错误处理、超时 |
| `i18n.spec.ts` | 语言切换、翻译完整性 |
| `navigation.spec.ts` | 页面导航、路由跳转 |
| `settings.spec.ts` | 设置保存、API 连接测试 |
| `accessibility.spec.ts` | ARIA 属性、键盘导航 |

## 编写测试最佳实践

### 单元测试示例

```typescript
import { renderHook, act } from "@testing-library/react";
import { useFileUpload } from "./useFileUpload";

describe("useFileUpload", () => {
  it("should validate file size", async () => {
    const { result } = renderHook(() =>
      useFileUpload({ maxSize: 1024 })
    );

    const largeFile = new File(["x".repeat(2048)], "large.txt", {
      type: "text/plain",
    });

    await act(async () => {
      await result.current.selectFile(largeFile);
    });

    expect(result.current.error).toBeTruthy();
    expect(result.current.fileInfo).toBeNull();
  });
});
```

### E2E 测试示例

```typescript
import { test, expect } from "@playwright/test";

test("upload page shows file upload zones", async ({ page }) => {
  await page.goto("/upload");
  await expect(page.getByText("加速度计数据")).toBeVisible();
  await expect(page.getByText("陀螺仪数据")).toBeVisible();
  await expect(page.getByText("音频文件")).toBeVisible();
});
```
