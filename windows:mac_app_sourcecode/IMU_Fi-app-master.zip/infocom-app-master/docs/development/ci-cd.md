# CI/CD

**文件**: `.github/workflows/ci.yml`

项目使用 GitHub Actions 实现自动化 CI/CD。

## 工作流概览

```text
Push / PR → main / develop
│
├── Job 1: quality (代码质量)
│   ├── ESLint 检查
│   ├── TypeScript 类型检查
│   ├── 安全审计
│   └── 依赖更新检查
│
├── Job 2: test (测试套件)
│   ├── Jest 单元测试 + 覆盖率
│   ├── Next.js 构建
│   └── Bundle 大小分析
│
├── Job 3: e2e (E2E 测试) [依赖 quality]
│   ├── Playwright 浏览器安装
│   ├── Next.js 构建
│   └── Chromium E2E 测试
│
├── Job 4: build-tauri (桌面构建) [依赖 quality + test]
│   ├── Ubuntu x86_64
│   ├── Windows x86_64
│   ├── macOS x86_64
│   └── macOS aarch64 (Apple Silicon)
│
└── Job 5: create-release (发布) [仅 tag 触发]
    ├── 下载所有构建产物
    └── 创建 GitHub Release (草稿)
```

## 触发条件

```yaml
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]
```

## 代码质量 (quality)

- **ESLint**: `pnpm lint`（`continue-on-error: true`）
- **TypeScript**: `pnpm exec tsc --noEmit`
- **安全审计**: `pnpm audit --audit-level=moderate`
- **依赖检查**: `pnpm outdated`

## 测试 (test)

- Node.js 20.x，使用 Next.js 缓存加速
- `pnpm test:coverage` 生成覆盖率报告
- 上传 JUnit XML 和覆盖率报告为 Artifacts（保留 30 天）
- PR 中自动发布测试结果评论

## E2E 测试 (e2e)

- 仅安装 Chromium 浏览器（减少时间）
- 先构建 Next.js，再运行 Playwright
- 失败时上传截图和 HTML 报告

## 桌面构建 (build-tauri)

### 构建矩阵

| 平台 | Target Triple | 产物格式 |
| --- | --- | --- |
| Ubuntu | `x86_64-unknown-linux-gnu` | AppImage, .deb |
| Windows | `x86_64-pc-windows-msvc` | .msi, .exe (NSIS) |
| macOS Intel | `x86_64-apple-darwin` | .dmg, .app |
| macOS ARM | `aarch64-apple-darwin` | .dmg, .app |

!!! warning "当前 macOS job 仍是模板状态"
    当前工作流的 macOS job 直接执行 `pnpm tauri build --target ...`，但没有先构建 `src-tauri/binaries/audio-enhancer-server-*`，也不会提供 `server/models/` 中的真实模型文件。因此它还不能直接视为 release-ready 的 InfoCom App macOS 发布流水线。

### 缓存策略

- Rust 编译缓存（`swatinem/rust-cache`）
- pnpm 依赖缓存
- Next.js 构建缓存

## 发布 (create-release)

仅在推送 `v*` 标签时触发：

```bash
git tag v0.1.0
git push origin v0.1.0
```

自动创建 **Draft Release**，包含所有平台的安装包。

## 可选功能（默认禁用）

以下功能需要配置 GitHub Secrets 后启用：

| 功能 | 所需 Secrets |
| --- | --- |
| Codecov 覆盖率 | `CODECOV_TOKEN` |
| Vercel 预览部署 | `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID` |
| macOS 代码签名 | `APPLE_CERTIFICATE`, `APPLE_CERTIFICATE_PASSWORD`, `APPLE_SIGNING_IDENTITY`, `APPLE_ID`, `APPLE_PASSWORD`, `APPLE_TEAM_ID` |
| Windows 代码签名 | `WINDOWS_CERTIFICATE`, `WINDOWS_CERTIFICATE_PASSWORD` |

补充说明：

- `APPLE_SIGNING_IDENTITY` 在提供 `APPLE_CERTIFICATE` 时通常可由 Tauri 推断。
- Tauri 2 也支持 `APPLE_API_KEY`, `APPLE_API_ISSUER`, `APPLE_API_KEY_PATH`，但当前仓库的工作流模板还没有接入这条路径。
- macOS 发布说明以 `docs/deployment/macos.md` 为准；这里主要描述当前 CI 工作流的实际状态。

详见 `CI_CD.md` 获取完整配置指南。
