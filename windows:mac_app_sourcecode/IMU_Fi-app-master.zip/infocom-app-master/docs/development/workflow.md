# 开发工作流

## 可用脚本

| 脚本 | 命令 | 说明 |
| --- | --- | --- |
| `dev` | `pnpm dev` | 启动 Next.js 开发服务器 (port 3000) |
| `build` | `pnpm build` | Next.js 生产构建（静态导出到 `out/`） |
| `start` | `pnpm start` | 启动生产服务器 |
| `lint` | `pnpm lint` | 运行 ESLint |
| `test` | `pnpm test` | 运行 Jest 单元测试 |
| `test:coverage` | `pnpm test:coverage` | 测试并生成覆盖率报告 |
| `test:e2e` | `pnpm test:e2e` | 运行 Playwright E2E 测试 |
| `test:e2e:chromium` | `pnpm test:e2e:chromium` | 仅 Chromium E2E 测试 |
| `dev:server` | `pnpm dev:server` | 启动 Python 后端 |
| `dev:all` | `pnpm dev:all` | 同时启动前后端 |
| `build:sidecar` | `pnpm build:sidecar` | 构建 PyInstaller Sidecar |
| `build:sidecar-win` | `pnpm build:sidecar-win` | Windows Sidecar |
| `build:sidecar-mac` | `pnpm build:sidecar-mac` | macOS Sidecar（宿主机原生 triple） |
| `build:sidecar-linux` | `pnpm build:sidecar-linux` | Linux Sidecar |
| `build:desktop` | `pnpm build:desktop` | 构建 Sidecar + Tauri 桌面应用 |
| `tauri dev` | `pnpm tauri dev` | Tauri 开发模式 |
| `tauri build` | `pnpm tauri build` | Tauri 生产构建 |

## 日常开发流程

### Web 开发

```bash
# 1. 启动前后端
pnpm dev:all

# 2. 打开浏览器
# http://localhost:3000

# 3. 修改代码 → 自动热重载

# 4. 运行测试
pnpm test
pnpm lint
```

### 桌面应用开发

```bash
# 1. 构建 Sidecar（首次或后端代码变更时）
pnpm build:sidecar

# 2. 启动 Tauri 开发模式
pnpm tauri dev

# 3. 修改前端代码 → 自动热重载
# 修改 Rust 代码 → 自动重新编译
```

### 后端开发

```bash
cd server

# 安装/同步依赖
uv sync

# 启动带热重载的开发服务器
uv run python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000

# 查看 API 文档
# http://localhost:8000/docs
```

## Git 工作流

项目使用 **Conventional Commits** 规范：

```bash
feat: 添加音频分析波形图
fix: 修复 WebSocket 断连问题
docs: 更新 API 文档
refactor: 重构管线进度回调
chore: 升级 Tailwind CSS 到 v4
ci: 添加 E2E 测试步骤
```

### 分支策略

| 分支 | 用途 |
| --- | --- |
| `main` | 稳定发布分支 |
| `develop` | 开发集成分支 |
| `feat/*` | 功能开发分支 |
| `fix/*` | 修复分支 |
