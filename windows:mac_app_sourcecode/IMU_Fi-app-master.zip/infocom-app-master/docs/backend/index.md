# 后端开发

InfoCom App 后端基于 **Python FastAPI** 构建，提供 IMU 辅助音频增强的完整处理管线。

## 核心特性

- **FastAPI 异步框架** — 自动生成 OpenAPI 文档，高性能异步处理
- **6 步增强管线** — IMU 预处理 → GAN 推理 → STFT → 联合降噪 → 后处理 → ISTFT
- **多设备支持** — 自动检测 CUDA / MPS / CPU
- **任务管理** — 后台异步处理，支持进度查询和取消
- **WebSocket 实时推送** — 实时推送处理进度到前端
- **Sidecar 模式** — 可打包为独立二进制嵌入 Tauri 桌面应用

## 文件概览

| 文件 | 职责 |
| --- | --- |
| `main.py` | FastAPI 入口、CORS、启动事件、Sidecar 关机监听 |
| `routes.py` | REST API 和 WebSocket 路由 |
| `pipeline.py` | `EnhancerPipeline` 类 — 6 步增强管线 |
| `config.py` | `ServerConfig` 配置类（环境变量、路径、设备） |
| `schemas.py` | Pydantic 请求/响应模型 |
| `models.py` | PyTorch 神经网络定义（Generator、AudioDenoiseNetwork） |
| `build_sidecar.py` | PyInstaller 打包脚本 |
| `pyproject.toml` | Python 项目配置与依赖声明 |

## 章节导航

- [**服务架构**](server.md) — FastAPI 应用结构与启动流程
- [**增强管线**](pipeline.md) — 6 步处理管线详解
- [**配置管理**](configuration.md) — 环境变量与运行时配置
- [**深度学习模型**](models.md) — Generator 和 DenoiseNet 模型架构
