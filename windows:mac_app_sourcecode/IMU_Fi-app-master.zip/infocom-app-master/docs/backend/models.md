# 深度学习模型

**文件**: `server/models.py`

项目使用两个 PyTorch 深度学习模型实现 IMU 辅助音频增强。

## Generator（GAN 生成器）

### Generator 作用

将 IMU 传感器幅值数据转换为视频位移特征，模拟物理世界中 IMU 运动与视频帧位移之间的映射关系。

### Generator 输入输出

| 方向 | 形状 | 说明 |
| --- | --- | --- |
| 输入 | `(B, 1, 150, 6)` | IMU 幅值灰度图（B=batch） |
| 输出 | `(B, 1, H, W)` | 生成的视频位移图 |

### Generator 模型文件

- **文件名**: `generator_final.pth`
- **大小**: ~30MB
- **位置**: `server/models/generator_final.pth`

### Generator 推理过程

```python
# 1. 准备输入
imu_tensor = torch.from_numpy(imu_data).unsqueeze(0).unsqueeze(0)  # (1,1,150,6)
imu_tensor = F.interpolate(imu_tensor, size=(150, 6), mode="bilinear")

# 2. 推理
with torch.no_grad():
    gen_output = generator(imu_tensor)  # (1,1,H,W)

# 3. 后处理 — 缩放到目标尺寸
gen_output = (gen_output + 1) / 2  # [-1,1] → [0,1]
gen_output = F.interpolate(gen_output, size=(150, 40), mode="bilinear")
```

## AudioDenoiseNetwork（音频降噪网络）

### DenoiseNet 作用

接收带噪声的音频频谱图和视频位移特征，输出干净的频谱图。这是一个多模态融合网络，利用视觉信息辅助音频降噪。

### DenoiseNet 输入输出

| 方向 | 形状 | 说明 |
| --- | --- | --- |
| 音频输入 | `(B, 1, T, F)` | 归一化频谱图（T=时间步, F=频率） |
| 视频输入 | `(B, T, D)` | 归一化视频位移（D=位移维度） |
| 输出 | `(B, 1, T, F)` | 干净频谱图 |

### DenoiseNet 模型文件

- **文件名**: `best_model.pth`
- **大小**: ~4MB
- **位置**: `server/models/best_model.pth`

### DenoiseNet 推理过程

```python
# 1. 准备音频输入
audio_tensor = torch.tensor(spec_norm.T).unsqueeze(0).unsqueeze(0)  # (1,1,431,1025)

# 2. 准备视频输入
video_norm = (video_disp - mean) / std
video_tensor = torch.tensor(video_norm).unsqueeze(0)  # (1,150,40)

# 3. 联合推理
with torch.no_grad():
    clean_spec = denoise_net(audio_tensor, video_tensor)
    clean_spec = torch.clamp(clean_spec, 0.0, 1.0)
```

## 模型加载

`EnhancerPipeline.load_models()` 在启动时加载两个模型：

```python
def load_models(self):
    # Generator
    self.generator = Generator().to(self.device)
    self.generator.load_state_dict(
        torch.load(str(gen_path), map_location=self.device, weights_only=True)
    )
    self.generator.eval()

    # DenoiseNet
    self.denoise_net = AudioDenoiseNetwork().to(self.device)
    self.denoise_net.load_state_dict(
        torch.load(str(dn_path), map_location=self.device, weights_only=True)
    )
    self.denoise_net.eval()
```

!!! warning "模型文件缺失"
    如果模型文件不存在，管线会使用随机初始化的权重运行（输出无意义），并在日志中打印警告。

## 设备管理

两个模型始终在同一设备上运行：

- **CUDA** — NVIDIA GPU，推理速度最快
- **MPS** — Apple Silicon GPU，macOS 专用
- **CPU** — 兜底方案，速度较慢

通过 `torch.load(..., map_location=device)` 确保模型权重加载到正确设备。

## 模型获取

模型权重文件不包含在 Git 仓库中（被 `.gitignore` 排除）。获取方式：

1. **联系项目负责人** — 通过内部渠道获取模型文件
2. **从训练脚本生成** — 运行训练脚本生成新的模型权重
3. **从 CI/CD 产物获取** — 如果配置了模型存储，从 CI 产物中下载
