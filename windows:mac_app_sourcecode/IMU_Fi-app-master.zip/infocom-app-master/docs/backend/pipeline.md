# 增强管线

**文件**: `server/pipeline.py`

`EnhancerPipeline` 类实现了完整的 6 步 IMU 辅助音频增强管线。

## 管线概览

```python
PIPELINE_STEPS = [
    "IMU Data Preprocessing",
    "GAN Video Displacement Generation",
    "Audio Feature Extraction (STFT)",
    "Joint Denoise Inference",
    "Spectrogram Post-processing",
    "Audio Reconstruction (ISTFT)",
]
```

## Step 1: IMU 数据预处理

**方法**: `process_imu_data(acc_path, gyro_path) → np.ndarray`

将原始加速度计和陀螺仪文本数据转换为模型输入。

### Step 1 处理流程

1. **读取数据** — 解析 `.txt` 文件，每行提取最后 3 列数值（x, y, z）
2. **截断/填充** — 截断到 125 个采样点，不足则零填充
3. **插值** — 从 125 点线性插值到 150 点（模拟 5 秒数据，30 Hz 采样率）
4. **计算幅值** — 对每轴计算 L2 范数: `√(x² + y² + z²)`
5. **合并** — 输出形状 `(150, 2)` — 加速度幅值 + 陀螺仪幅值

### Step 1 配置参数

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `imu_truncate_len` | 125 | 截断长度 |
| `imu_interp_len` | 150 | 插值目标长度 |

## Step 2: GAN 视频位移生成

**方法**: `generate_video_displacement(imu_data) → np.ndarray`

将 IMU 幅值数据通过 GAN 生成器转换为视频位移特征。

### Step 2 处理流程

1. **归一化** — IMU 数据归一化到 `[0, 255]` 范围
2. **转换为灰度图** — 创建 PIL 灰度图像
3. **归一化到 [-1, 1]** — 标准 GAN 输入范围
4. **Resize** — 调整到 `(150, 6)` 大小
5. **Generator 推理** — 通过 GAN 生成器网络
6. **后处理** — 输出缩放到 `(video_disp_height, video_disp_width)` 尺寸
7. **反归一化** — 还原到原始数据范围

### Step 2 输出

- 形状: `(150, 40)` — 150 个时间步，40 维位移特征
- 数据范围: 由 `video_fixed_min` 和 `video_fixed_max` 确定

## Step 3: 音频 STFT

**方法**: `process_audio_input(wav_path) → (spec_norm, phase, sr)`

对音频文件进行短时傅里叶变换，提取频谱特征。

### Step 3 处理流程

1. **加载音频** — `librosa.load(wav_path, sr=None)` 保持原采样率
2. **STFT** — `librosa.stft(y)` 计算短时傅里叶变换
3. **振幅谱** — 提取振幅谱并转换为分贝（dB）
4. **归一化** — Min-Max 归一化到 `[0, 1]`
5. **翻转** — 频率轴翻转（高频在上）
6. **提取相位** — 保存原始相位用于 ISTFT 重建
7. **Resize** — 如果尺寸不匹配，调整到 `(1025, 431)`

### Step 3 输出

| 输出 | 形状 | 说明 |
| --- | --- | --- |
| `spec_norm` | (1025, 431) | 归一化频谱图 |
| `phase` | 原始大小 | 原始相位信息 |
| `sr` | 标量 | 原始采样率 |

## Step 4: 联合降噪推理

**方法**: `run_denoise_model(audio_spec_norm, video_data_npy) → np.ndarray`

将音频频谱图和视频位移特征联合输入降噪网络。

### Step 4 处理流程

1. **音频准备** — 转置频谱图 → 转为 PyTorch 张量 → `(1, 1, T, F)`
2. **视频准备** — 视频位移归一化（减均值除标准差）→ `(1, T, D)`
3. **推理** — `denoise_net(audio_tensor, video_tensor)` → 干净频谱
4. **截断** — `torch.clamp(output, 0.0, 1.0)` 限制范围
5. **输出** — 返回 numpy 数组

### Step 4 配置参数

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `video_mean` | 0.0 | 视频数据均值 |
| `video_std` | 1.0 | 视频数据标准差 |

## Step 5: 频谱后处理

**方法**: `convert_spec_to_npy(clean_spec_np) → np.ndarray`

对降噪后的频谱图进行后处理。

### Step 5 处理流程

1. **转置** — 从模型输出格式转回频谱图格式
2. **量化** — 乘以 255 转为 uint8 再除以 255，模拟图像量化
3. **翻转** — 频率轴翻转回原始方向

## Step 6: ISTFT 音频重建

**方法**: `reconstruct_audio_istft(norm_mag, phase, output_wav_path) → str`

从干净频谱和原始相位重建时域音频。

### 处理流程

1. **尺寸匹配** — 如果频谱尺寸与相位不同，使用 `cv2.resize` 对齐
2. **反归一化** — `S_db = norm_mag * db_range - db_range`
3. **dB 转振幅** — `librosa.db_to_amplitude(S_db)`
4. **合成复数频谱** — `D = magnitude * exp(j * phase)`
5. **ISTFT** — `librosa.istft(D, hop_length=512, win_length=2048)`
6. **峰值归一化** — 缩放到目标峰值 (`target_peak`)
7. **保存** — `soundfile.write(output_wav_path, y_recon, sample_rate)`

### 配置参数

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `db_range` | 90 | dB 动态范围 |
| `target_peak` | 0.95 | 峰值归一化目标 |
| `sample_rate` | 22050 | 输出采样率 |

## 完整管线调用

```python
pipeline = EnhancerPipeline(config)
pipeline.load_models()

result = pipeline.process_single(
    wav_path="input.wav",
    acc_path="accel.txt",
    gyro_path="gyro.txt",
    output_wav_path="output.wav",
    on_progress=lambda step, name, pct, msg: print(f"[{name}] {pct}%")
)

# result = {
#     "output_path": "output.wav",
#     "total_time": 2.5,
#     "step_times": {"IMU Data Preprocessing": 0.1, ...},
#     "device": "cuda",
#     "sample_rate": 22050,
# }
```
