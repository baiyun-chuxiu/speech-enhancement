# 服务架构

## FastAPI 应用初始化

**文件**: `server/main.py`

```python
app = FastAPI(
    title="Audio Enhancement Server",
    description="IMU-assisted audio enhancement API",
    version="1.0.0",
)
```

### 启动流程

1. 创建 FastAPI 实例
2. 配置 CORS 中间件（允许 `localhost:3000` 等来源）
3. 注册路由（`router` from `routes.py`）
4. 通过 `lifespan` 初始化默认 `PipelineManager`
5. 如果模型权重可用，则进入 `ready`；否则进入 `degraded`
6. 如果作为 Sidecar 运行，启动 stdin 关机监听线程

### CORS 配置

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

默认 `cors_origins` 包含：

- `http://localhost:3000` — Next.js 开发服务器
- `http://localhost:1420` — Tauri 开发窗口
- `tauri://localhost` — Tauri 生产模式
- `https://tauri.localhost` — Tauri HTTPS 模式

### Sidecar 关机机制

当作为 Tauri Sidecar 运行时，后端通过 stdin 接收关机信号：

```python
def _stdin_shutdown_listener():
    """阻塞读取 stdin，当 Tauri 发送关机命令时退出。"""
    line = sys.stdin.readline().strip()
    if line == "sidecar shutdown":
        os.kill(os.getpid(), signal.SIGINT)
```

Tauri Rust 端通过 `stdin.write_all(b"sidecar shutdown\n")` 触发关机。

## 全局状态

`routes.py` 维护以下全局状态：

```python
pipeline_manager: Optional[PipelineManager] = None      # 设备解析与缓存入口
pipeline: Optional[EnhancerPipeline] = None             # 默认设备管线实例
tasks: dict[str, TaskInfo] = {}                         # 活跃任务
task_cancel_events: dict[str, threading.Event] = {}    # 协作式取消令牌
uploaded_files: dict[str, dict] = {}                   # 已上传文件元信息
websocket_connections: dict[str, list[WebSocket]] = {} # WS 连接池
```

### 管线初始化

```python
def init_pipeline() -> dict[str, Any]:
    manager = get_pipeline_manager()
    pipeline = manager.get_pipeline(config.device)[0]
    return _get_runtime_state_payload()
```

启动时会预加载默认设备对应的管线，但 readiness 由真实权重加载结果决定，不再把“模型对象已分配”误报为 ready。

## Health / Ready / System Info

- `/health`：纯 liveness，进程启动后始终返回 `status=ok`
- `/ready`：返回 `ready` / `degraded` / `loading` 以及 `is_ready`
- `/api/v1/system/info`：返回设备、支持的 runtime、模型文件是否存在、权重是否真正加载、降级原因

## 任务管理

后端使用 FastAPI `BackgroundTasks` 异步执行增强任务：

```text
POST /api/v1/enhance
  → 保存上传文件
  → 创建 TaskInfo（状态: pending）
  → 添加后台任务 _run_enhancement()
  → 立即返回 task_id

_run_enhancement() (后台线程)
  → 更新状态为 running
  → 解析 requested_device → effective_device
  → 逐步执行管线（with progress callback + cancel token）
  → 完成后更新状态为 completed / failed / cancelled
  → 通过 WebSocket 广播更新
```

### 任务状态流转

```text
pending → running → completed
                  → failed
                  → cancelled
```

### 进度回调

管线在每个步骤完成时调用 `on_progress` 回调：

```python
def on_progress(step_idx: int, step_name: str, progress: int, message: str):
    # 更新步骤状态
    task.steps[step_idx].progress = progress
    # 计算整体进度
    completed = sum(1 for s in task.steps if s.status == "completed")
    task.progress = int((completed / len(task.steps)) * 100)
    # 从工作线程回投到主事件循环
    asyncio.run_coroutine_threadsafe(_broadcast_task_update(task_id), loop)
```

## WebSocket 实时推送

```text
WS /ws/tasks/{task_id}
  → 连接建立后发送当前任务状态
  → 每次进度更新时广播新状态
  → 30 秒超时发送心跳包 {"type": "ping"}
  → 断连后自动清理连接
```

客户端可以通过 WebSocket 或 HTTP 轮询两种方式获取进度。

## 运行方式

### 开发模式

```bash
cd ..
uv run --project server python -m server.main
```

### 通过 pnpm 脚本

```bash
pnpm dev:server
```

### 验证

```bash
uv run --project server python -m pytest server/tests
uv run --project server python -m server.smoke_check
```

### 作为 Sidecar

由 Tauri Rust 进程自动启动，详见 [Sidecar 机制](../desktop/sidecar.md)。
