# 配置管理

**文件**: `server/config.py`

后端配置通过 Python `dataclass` 实现，支持环境变量覆盖。

## ServerConfig 配置类

```python
@dataclass
class ServerConfig:
    # 服务器
    host: str = "0.0.0.0"
    port: int = 8000
    cors_origins: list[str] = ...

    # 路径
    base_dir: Path = ...          # 自动检测（支持 PyInstaller frozen）
    models_dir: Path = ...
    upload_dir: Path = ...
    output_dir: Path = ...

    # 模型文件
    generator_model_path: Path = ...    # generator_final.pth
    denoise_model_path: Path = ...      # best_model.pth

    # 计算设备
    device: str = "auto"                # auto → cuda / mps / cpu

    # 处理参数
    video_mean: float = 0.0
    video_std: float = 1.0
    sample_rate: int = 22050
    imu_truncate_len: int = 125
    imu_interp_len: int = 150
    spec_freq_bins: int = 1025
    spec_time_steps: int = 431
    video_disp_height: int = 150
    video_disp_width: int = 40
    video_fixed_min: float = ...
    video_fixed_max: float = ...
    db_range: int = 90
    target_peak: float = 0.95
```

## 环境变量覆盖

| 环境变量 | 配置字段 | 说明 |
| --- | --- | --- |
| `ENHANCER_HOST` | `host` | 监听地址 |
| `ENHANCER_PORT` | `port` | 监听端口 |
| `ENHANCER_DEVICE` | `device` | 计算设备 |
| `ENHANCER_MODELS_DIR` | `models_dir` | 模型文件目录 |
| `ENHANCER_GENERATOR_PATH` | `generator_model_path` | GAN 生成器模型 |
| `ENHANCER_DENOISE_PATH` | `denoise_model_path` | 降噪网络模型 |
| `ENHANCER_CORS_ORIGINS` | `cors_origins` | CORS 来源（逗号分隔） |
| `ENHANCER_SAMPLE_RATE` | `sample_rate` | 输出采样率 |
| `ENHANCER_DB_RANGE` | `db_range` | dB 动态范围 |

## 设备自动检测

```python
def _detect_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"
```

优先级：CUDA > MPS > CPU。可通过 `ENHANCER_DEVICE` 强制指定。

## PyInstaller 路径处理

当通过 PyInstaller 打包为 Sidecar 时，`base_dir` 会自动指向冻结可执行文件的目录：

```python
if getattr(sys, "frozen", False):
    base_dir = Path(sys._MEIPASS)
else:
    base_dir = Path(__file__).parent
```

这确保模型文件和其他资源在打包后仍能被正确找到。

## 目录自动创建

配置初始化时会自动创建必要的目录：

```python
def __post_init__(self):
    self.upload_dir.mkdir(parents=True, exist_ok=True)
    self.output_dir.mkdir(parents=True, exist_ok=True)
    self.models_dir.mkdir(parents=True, exist_ok=True)
```
