# InfoCom App

InfoCom App is a cross-platform IMU-assisted audio enhancement application for the MobiCom 2026 demo workflow. The repository combines:

- a Next.js 16 + React 19 frontend
- a FastAPI + PyTorch inference backend in `server/`
- a Tauri 2 desktop shell that can bundle the Python backend as a sidecar

The app is no longer a generic starter template. It is a real product workspace with upload, enhancement, settings, help, backend APIs, desktop packaging, and automated tests.

## Implemented User Flows

- Landing page at `/` with feature overview, theme toggle, and language switcher
- Upload workspace at `/upload` for accelerometer, gyroscope, and audio files
- Sensor data preview with parsed values and charts before processing
- Six-step enhancement progress tracking with WebSocket updates and polling fallback
- Result playback and processed audio session handling
- Settings page at `/settings` for API URL, theme, locale, compute device, quality, and output format
- Help page at `/help` with quick start, FAQ, and backend API reference
- Desktop runtime with Tauri sidecar support for launching a bundled Python backend

## Enhancement Pipeline

The current backend pipeline is built around three uploaded inputs:

1. Accelerometer text data
2. Gyroscope text data
3. Source audio

Processing then runs through these server-side steps:

1. IMU Data Preprocessing
2. GAN Video Displacement Generation
3. Audio Feature Extraction (STFT)
4. Joint Denoise Inference
5. Spectrogram Post-processing
6. Audio Reconstruction (ISTFT)

## Tech Stack

| Area | Current implementation |
| --- | --- |
| Frontend | Next.js 16, React 19, TypeScript |
| UI | Tailwind CSS v4, shadcn/ui, Radix UI, Lucide |
| Internationalization | `next-intl` with `zh-CN` default locale and English support |
| Client state | React hooks plus persisted app settings |
| Desktop | Tauri 2, Rust, `tauri-plugin-shell` sidecar integration |
| Backend | FastAPI, Uvicorn, PyTorch, librosa, soundfile |
| Python tooling | `uv` for dependency and virtual environment management |
| Unit/component tests | Jest + Testing Library |
| End-to-end tests | Playwright |
| Backend tests | `pytest` in `server/tests` |

## Repository Layout

```text
infocom-app/
|- app/                    Next.js App Router pages
|- components/             Reusable UI and upload components
|- hooks/                  Frontend hooks for upload, playback, API integration
|- lib/                    Shared types, settings, and API clients
|- messages/               `next-intl` locale messages
|- server/                 FastAPI backend, PyTorch pipeline, sidecar build scripts
|- src-tauri/              Tauri desktop wrapper and Rust commands
|- e2e/                    Playwright suites
|- docs/                   Project documentation
|- scripts/setup/          Local bootstrap helpers such as `setup-macos.js`
|- TESTING.md              Frontend testing guide
|- mkdocs.yml              Docs site configuration
```

## Prerequisites

### Required for all development

- Node.js 20 or newer
- `pnpm`
- `uv`
- Python 3.10 or newer

### Required for desktop development

- Rust toolchain
- Tauri platform prerequisites
  - Windows: Visual Studio C++ Build Tools
  - macOS: Xcode Command Line Tools
  - Linux: WebKitGTK and other Tauri desktop dependencies

### Required for real enhancement runs

Model weights are not committed to the repository. You need to provide these files in `server/models/`:

- `generator_final.pth`
- `best_model.pth`

If the model files are missing, the backend still starts for diagnostics, but `/ready` reports degraded status and enhancement requests fail with `503`.
Windows desktop packaging is stricter: `pnpm build:sidecar`, `pnpm build:sidecar-win`, and `pnpm build:desktop` now fail fast if either required model file is missing, so the packaged app cannot be shipped without bundled weights.

## Quick Start

### macOS bootstrap

On macOS, the repository includes a helper that checks the required toolchain and installs both frontend and backend dependencies:

```bash
pnpm setup:macos
```

This script:

- runs `pnpm install`
- runs `uv sync` in `server/`
- runs `pnpm tauri info`
- creates `.env.local` from `.env.local.example` if needed

### Manual setup

```bash
pnpm install
cd server
uv sync
cd ..
```

Create local environment variables:

```powershell
Copy-Item .env.local.example .env.local
```

Then place the required model files in `server/models/`.

## Running the Project

### Frontend only

```bash
pnpm dev
```

Runs the Next.js app on `http://localhost:3000`.

### Backend only

```bash
pnpm dev:server
```

Runs the FastAPI backend on `http://localhost:8000`.

### Frontend + backend together

```bash
pnpm dev:all
```

Starts the web UI and the Python backend in parallel.

### Desktop app

```bash
pnpm build:sidecar
pnpm tauri dev
```

For a full local desktop flow, build the Python sidecar first. Once the sidecar binary exists under `src-tauri/binaries/`, the Rust app starts and monitors it automatically in desktop mode.

## Build and Packaging

### Web build

```bash
pnpm build
```

The current Next.js configuration uses `output: "export"`, so the production web bundle is generated into `out/`. That static export is also what Tauri loads in production.

### Desktop build

```bash
pnpm build:desktop
```

This runs:

1. `pnpm build:sidecar`
2. `pnpm tauri build`

For the Windows desktop flow, the packaged installer includes the Python enhancement backend as a bundled sidecar executable. When the desktop app launches, the Rust host starts that sidecar automatically, chooses an available localhost port, and routes frontend API calls to the detected port. Users do not need to start a separate Python server manually.

Platform-specific sidecar helpers are also available:

- `pnpm build:sidecar-win`
- `pnpm build:sidecar-mac`
- `pnpm build:sidecar-linux`

Mobile-oriented Tauri scripts are present as well:

- `pnpm dev:android`
- `pnpm dev:ios`
- `pnpm build:android`
- `pnpm build:ios`

These scripts exist in the repository, but the primary production path today is web plus desktop.

## Useful Commands

| Command | What it does |
| --- | --- |
| `pnpm dev` | Start the Next.js frontend |
| `pnpm dev:server` | Start the FastAPI backend with `uv run` |
| `pnpm dev:all` | Start frontend and backend together |
| `pnpm lint` | Run ESLint |
| `pnpm test` | Run Jest unit and component tests |
| `pnpm test:coverage` | Run Jest with coverage output |
| `pnpm test:e2e` | Run Playwright end-to-end tests |
| `pnpm tauri dev` | Start the desktop app in development |
| `pnpm build` | Export the frontend to `out/` |
| `pnpm build:desktop` | Build sidecar plus Tauri desktop bundle |

## Testing

Frontend and desktop-facing logic already have automated coverage in this repository.

```bash
pnpm test
pnpm test:e2e
uv run --project server python -m pytest server/tests
```

Additional references:

- `TESTING.md` for Jest and Testing Library notes
- `docs/development/testing.md` for project-level testing documentation

## Backend API Surface

The FastAPI backend currently exposes these main endpoints:

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/health` | Liveness check |
| `GET` | `/ready` | Readiness check for enhancement requests |
| `GET` | `/api/v1/system/info` | Runtime device and model status |
| `POST` | `/api/v1/files/upload` | Upload a single file |
| `POST` | `/api/v1/enhance` | Start enhancement with multipart files |
| `POST` | `/api/v1/enhance/uploaded` | Start enhancement from uploaded file IDs |
| `GET` | `/api/v1/tasks/{task_id}` | Query task progress |
| `POST` | `/api/v1/tasks/{task_id}/cancel` | Cancel a running task |
| `GET` | `/api/v1/files/download/{file_id}` | Download the generated audio |
| `WS` | `/ws/tasks/{task_id}` | Real-time progress events |

Interactive API docs are available at:

- `http://localhost:8000/docs`
- `http://localhost:8000/redoc`

## Configuration Notes

The repository ships with `.env.local.example` containing the backend defaults:

- `ENHANCER_HOST`
- `ENHANCER_PORT`
- `ENHANCER_DEVICE`
- `ENHANCER_MODELS_DIR`
- `ENHANCER_GENERATOR_PATH`
- `ENHANCER_DENOISE_PATH`
- `ENHANCER_CORS_ORIGINS`

The frontend currently uses persisted app settings for the API base URL, with `http://localhost:8000` as the default. In Tauri desktop mode, the client can also resolve the sidecar port via Rust commands.

## Documentation

More detailed documentation lives in `docs/`, including:

- architecture notes
- frontend pages and components
- backend pipeline and models
- Tauri commands and sidecar behavior
- deployment guides for web, Windows, macOS, and Linux

If you are working on the Python backend specifically, also see `server/README.md`.
