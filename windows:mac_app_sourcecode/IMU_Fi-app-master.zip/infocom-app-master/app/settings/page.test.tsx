import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import SettingsPage from './page';

const checkEnhancerReadinessMock = jest.fn();
const getEnhancerSystemInfoMock = jest.fn();

jest.mock('@/lib/api/enhancer-api', () => ({
  checkEnhancerReadiness: (...args: unknown[]) => checkEnhancerReadinessMock(...args),
  getEnhancerSystemInfo: (...args: unknown[]) => getEnhancerSystemInfoMock(...args),
}));

// Mock next/link
jest.mock('next/link', () => {
  const MockLink = ({ children, href }: { children: React.ReactNode; href: string }) => (
    <a href={href}>{children}</a>
  );
  MockLink.displayName = 'MockLink';
  return MockLink;
});

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

// Mock fetch
global.fetch = jest.fn();

// Mock matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(),
    removeListener: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

describe('SettingsPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorageMock.getItem.mockReturnValue(null);
    checkEnhancerReadinessMock.mockRejectedValue(new Error('desktop runtime unavailable'));
    getEnhancerSystemInfoMock.mockRejectedValue(new Error('desktop runtime unavailable'));
  });

  it('renders the settings page with title', () => {
    render(<SettingsPage />);
    expect(screen.getByText('设置')).toBeInTheDocument();
  });

  it('renders API server settings', () => {
    render(<SettingsPage />);
    expect(screen.getByText('API 服务器')).toBeInTheDocument();
    expect(screen.getByText('服务器地址')).toBeInTheDocument();
  });

  it('renders appearance settings', () => {
    render(<SettingsPage />);
    expect(screen.getByText('外观')).toBeInTheDocument();
    expect(screen.getByText('主题')).toBeInTheDocument();
  });

  it('renders processing settings', () => {
    render(<SettingsPage />);
    expect(screen.getByText('处理设置')).toBeInTheDocument();
    expect(screen.getByText('计算设备')).toBeInTheDocument();
    expect(screen.getByText('处理质量')).toBeInTheDocument();
    expect(screen.getByText('输出格式')).toBeInTheDocument();
  });

  it('renders language preferences from the shared settings model', () => {
    render(<SettingsPage />);
    expect(screen.getAllByText('语言').length).toBeGreaterThan(0);
  });

  it('shows save button', () => {
    render(<SettingsPage />);
    expect(screen.getByText('保存')).toBeInTheDocument();
  });

  it('shows reset button', () => {
    render(<SettingsPage />);
    expect(screen.getByText('恢复默认设置')).toBeInTheDocument();
  });

  it('loads saved settings from localStorage', () => {
    const savedSettings = {
      apiUrl: 'http://custom:9000',
      theme: 'dark',
    };
    localStorageMock.getItem.mockReturnValue(JSON.stringify(savedSettings));
    
    render(<SettingsPage />);
    
    const input = screen.getByPlaceholderText('http://localhost:8000');
    expect(input).toHaveValue('http://custom:9000');
  });

  it('shows test connection button', () => {
    render(<SettingsPage />);
    expect(screen.getByText('测试')).toBeInTheDocument();
  });

  it('handles API connection test - success', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({ is_ready: true }),
    });
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        device: 'cpu',
        supported_devices: ['auto', 'cpu'],
        supported_qualities: ['balanced'],
        supported_output_formats: ['wav'],
      }),
    });

    render(<SettingsPage />);
    
    const testButton = screen.getByText('测试');
    fireEvent.click(testButton);
    
    await waitFor(() => {
      expect(screen.getByText('服务器连接成功')).toBeInTheDocument();
    });
  });

  it('handles API connection test - failure', async () => {
    (global.fetch as jest.Mock).mockRejectedValueOnce(new Error('Connection failed'));

    render(<SettingsPage />);
    
    const testButton = screen.getByText('测试');
    fireEvent.click(testButton);
    
    await waitFor(() => {
      expect(screen.getByText(/无法连接到服务器/)).toBeInTheDocument();
    });
  });

  it('uses the desktop enhancer client when sidecar is available even if raw URL checks would fail', async () => {
    checkEnhancerReadinessMock.mockResolvedValueOnce({
      is_ready: true,
      status: 'ready',
    });
    getEnhancerSystemInfoMock.mockResolvedValueOnce({
      device: 'cpu',
      supported_devices: ['cpu'],
      supported_qualities: ['balanced'],
      supported_output_formats: ['wav'],
    });
    (global.fetch as jest.Mock).mockRejectedValue(new Error('raw fetch should not be used'));

    render(<SettingsPage />);

    const testButton = screen.getByText('测试');
    fireEvent.click(testButton);

    await waitFor(() => {
      expect(screen.getByText('服务器连接成功')).toBeInTheDocument();
    });

    expect(checkEnhancerReadinessMock).toHaveBeenCalled();
    expect(getEnhancerSystemInfoMock).toHaveBeenCalled();
  });

  it('saves settings to localStorage', async () => {
    render(<SettingsPage />);
    
    // Change a setting to enable save button
    const resetButton = screen.getByText('恢复默认设置');
    fireEvent.click(resetButton);
    
    // Click save
    const saveButton = screen.getByText('保存');
    fireEvent.click(saveButton);
    
    await waitFor(() => {
      expect(localStorageMock.setItem).toHaveBeenCalled();
    });
  });
});
