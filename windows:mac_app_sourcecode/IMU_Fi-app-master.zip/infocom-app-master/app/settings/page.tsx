'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Settings,
  ArrowLeft,
  Server,
  Palette,
  Cpu,
  Save,
  RotateCcw,
  CheckCircle,
  XCircle,
  Loader2,
  Wifi,
  Moon,
  Sun,
} from 'lucide-react';
import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { useI18n } from '@/components/i18n-provider';
import {
  DEFAULT_RUNTIME_CAPABILITIES,
  DEFAULT_APP_SETTINGS,
  getClientCompletionCapabilities,
  getRuntimeCapabilitiesFromSystemInfo,
  getStoredAppSettings,
  normalizeAppSettings,
  persistAppSettings,
  type AppSettings,
} from '@/lib/app-settings';
import {
  checkEnhancerReadiness,
  getEnhancerSystemInfo,
} from '@/lib/api/enhancer-api';
import { localeNames, locales, type Locale } from '@/i18n/config';

export default function SettingsPage() {
  const t = useTranslations('settings');
  const { setLocale } = useI18n();
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const [runtimeCapabilities, setRuntimeCapabilities] = useState(DEFAULT_RUNTIME_CAPABILITIES);
  const [apiStatus, setApiStatus] = useState<'idle' | 'checking' | 'connected' | 'error'>('idle');
  const [isSaving, setIsSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    setSettings(getStoredAppSettings());
  }, []);

  // Check API status
  const checkApiStatus = useCallback(async () => {
    setApiStatus('checking');
    try {
      let readinessBody;
      let systemInfo;

      try {
        [readinessBody, systemInfo] = await Promise.all([
          checkEnhancerReadiness(),
          getEnhancerSystemInfo(),
        ]);
      } catch {
        const [readinessResponse, systemInfoResponse] = await Promise.all([
          fetch(`${settings.apiUrl}/ready`, {
            method: 'GET',
            signal: AbortSignal.timeout(5000),
          }),
          fetch(`${settings.apiUrl}/api/v1/system/info`, {
            method: 'GET',
            signal: AbortSignal.timeout(5000),
          }),
        ]);

        if (!readinessResponse.ok || !systemInfoResponse.ok) {
          setApiStatus('error');
          return;
        }

        readinessBody = await readinessResponse.json();
        systemInfo = await systemInfoResponse.json();
      }

      const nextCapabilities = getRuntimeCapabilitiesFromSystemInfo(
        systemInfo,
        getClientCompletionCapabilities(),
      );

      setRuntimeCapabilities(nextCapabilities);
      setSettings((prev) => normalizeAppSettings(prev, nextCapabilities));

      if (readinessBody.is_ready) {
        setApiStatus('connected');
        return;
      }
      setApiStatus('error');
    } catch {
      setApiStatus('error');
    }
  }, [settings.apiUrl]);

  useEffect(() => {
    setSettings((prev) => normalizeAppSettings(prev, runtimeCapabilities));
  }, [runtimeCapabilities]);

  const getDeviceLabel = (device: AppSettings['device']) => {
    if (device === 'auto') return t('autoSelect');
    if (device === 'cpu') return 'CPU';
    if (device === 'cuda') return 'CUDA (NVIDIA)';
    return 'MPS (Apple)';
  };

  const getQualityLabel = (quality: AppSettings['quality']) => {
    if (quality === 'fast') return t('fast');
    if (quality === 'balanced') return t('balanced');
    return t('highQuality');
  };

  const getOutputFormatLabel = (format: AppSettings['outputFormat']) => {
    if (format === 'wav') return t('wavLossless');
    return format.toUpperCase();
  };

  // Update setting
  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const updateLocale = (locale: Locale) => {
    setSettings((prev) => ({ ...prev, locale }));
    setLocale(locale);
  };

  // Save settings
  const saveSettings = async () => {
    setIsSaving(true);
    try {
      persistAppSettings(settings);
      
      // Apply theme
      if (settings.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else if (settings.theme === 'light') {
        document.documentElement.classList.remove('dark');
      } else {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.classList.toggle('dark', prefersDark);
      }
      
      setHasChanges(false);
      await new Promise((r) => setTimeout(r, 500)); // Visual feedback
    } finally {
      setIsSaving(false);
    }
  };

  // Reset to defaults
  const resetSettings = () => {
    setSettings(normalizeAppSettings(DEFAULT_APP_SETTINGS, runtimeCapabilities));
    setHasChanges(true);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 h-12 flex items-center justify-between max-w-3xl">
          <div className="flex items-center gap-3">
            <Link href="/upload">
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-base font-semibold flex items-center gap-2">
              <Settings className="h-4 w-4 text-primary" />
              {t('title')}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {hasChanges && (
              <Badge variant="secondary" className="text-xs">{t('unsaved')}</Badge>
            )}
            <Button
              size="sm"
              onClick={saveSettings}
              disabled={!hasChanges || isSaving}
              className="gap-1"
            >
              {isSaving ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <Save className="h-3 w-3" />
              )}
              {t('save')}
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-3xl space-y-6">
        {/* API 服务器设置 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Server className="h-4 w-4" />
              {t('apiServer')}
            </CardTitle>
            <CardDescription className="text-xs">
              {t('apiServerDesc')}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiUrl" className="text-sm">{t('serverAddress')}</Label>
              <div className="flex gap-2">
                <Input
                  id="apiUrl"
                  value={settings.apiUrl}
                  onChange={(e) => updateSetting('apiUrl', e.target.value)}
                  placeholder="http://localhost:8000"
                  className="flex-1"
                />
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      onClick={checkApiStatus}
                      disabled={apiStatus === 'checking'}
                      className="gap-1 shrink-0"
                    >
                      {apiStatus === 'checking' ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Wifi className="h-4 w-4" />
                      )}
                      {t('test')}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>{t('testConnection')}</TooltipContent>
                </Tooltip>
              </div>
            </div>

            {apiStatus === 'connected' && (
              <Alert className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 border-green-200 dark:border-green-800">
                <CheckCircle className="h-4 w-4" />
                <AlertTitle>{t('connectionSuccess')}</AlertTitle>
                <AlertDescription>{t('serverConnected')}</AlertDescription>
              </Alert>
            )}
            {apiStatus === 'error' && (
              <Alert variant="destructive">
                <XCircle className="h-4 w-4" />
                <AlertTitle>{t('connectionFailed')}</AlertTitle>
                <AlertDescription>{t('connectionFailedDesc')}</AlertDescription>
              </Alert>
            )}
            {apiStatus === 'checking' && (
              <Alert className="bg-muted">
                <Loader2 className="h-4 w-4 animate-spin" />
                <AlertTitle>{t('checking')}</AlertTitle>
                <AlertDescription>{t('checkingConnection')}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* 外观设置 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Palette className="h-4 w-4" />
              {t('appearance')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('theme')}</Label>
                <p className="text-xs text-muted-foreground">{t('selectTheme')}</p>
              </div>
              <Select
                value={settings.theme}
                onValueChange={(v) => updateSetting('theme', v as AppSettings['theme'])}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">
                    <div className="flex items-center gap-2">
                      <Sun className="h-4 w-4" />
                      {t('light')}
                    </div>
                  </SelectItem>
                  <SelectItem value="dark">
                    <div className="flex items-center gap-2">
                      <Moon className="h-4 w-4" />
                      {t('dark')}
                    </div>
                  </SelectItem>
                  <SelectItem value="system">{t('system')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t('language')}</CardTitle>
            <CardDescription className="text-xs">{t('selectLanguage')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('language')}</Label>
                <p className="text-xs text-muted-foreground">{t('selectLanguage')}</p>
              </div>
              <Select value={settings.locale} onValueChange={(value) => updateLocale(value as Locale)}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {locales.map((locale) => (
                    <SelectItem key={locale} value={locale}>
                      {localeNames[locale]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* 处理设置 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Cpu className="h-4 w-4" />
              {t('processingSettings')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('computeDevice')}</Label>
                <p className="text-xs text-muted-foreground">{t('selectDevice')}</p>
              </div>
              <Select
                value={settings.device}
                onValueChange={(v) => updateSetting('device', v as AppSettings['device'])}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {runtimeCapabilities.supportedDevices.map((device) => (
                    <SelectItem key={device} value={device}>
                      {getDeviceLabel(device)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('processingQuality')}</Label>
                <p className="text-xs text-muted-foreground">{t('qualityBalance')}</p>
              </div>
              <Select
                value={settings.quality}
                onValueChange={(v) => updateSetting('quality', v as AppSettings['quality'])}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {runtimeCapabilities.supportedQualities.map((quality) => (
                    <SelectItem key={quality} value={quality}>
                      {getQualityLabel(quality)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('outputFormat')}</Label>
                <p className="text-xs text-muted-foreground">{t('outputFormatDesc')}</p>
              </div>
              <Select
                value={settings.outputFormat}
                onValueChange={(v) => updateSetting('outputFormat', v as AppSettings['outputFormat'])}
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {runtimeCapabilities.supportedOutputFormats.map((format) => (
                    <SelectItem key={format} value={format}>
                      {getOutputFormatLabel(format)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* 其他设置 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t('others')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('autoSave')}</Label>
                <p className="text-xs text-muted-foreground">{t('autoSaveDesc')}</p>
              </div>
              <Switch
                checked={settings.autoSave}
                onCheckedChange={(v) => updateSetting('autoSave', v)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm">{t('notifications')}</Label>
                <p className="text-xs text-muted-foreground">{t('notificationsDesc')}</p>
              </div>
              <Switch
                checked={settings.notifications}
                onCheckedChange={(v) => updateSetting('notifications', v)}
              />
            </div>
          </CardContent>
        </Card>

        {/* 重置按钮 */}
        <div className="flex justify-center">
          <Button
            variant="outline"
            onClick={resetSettings}
            className="gap-2 text-muted-foreground"
          >
            <RotateCcw className="h-4 w-4" />
            {t('restoreDefaults')}
          </Button>
        </div>
      </main>
    </div>
  );
}
