import { render, screen } from '@testing-library/react';
import Home from './page';

describe('Home Page', () => {
  it('renders the localized header and hero content', () => {
    render(<Home />);

    expect(screen.getByText('音频处理工具')).toBeInTheDocument();
    expect(screen.getByText('Beta')).toBeInTheDocument();
    expect(screen.getByRole('heading', { level: 1, name: '智能音频增强' })).toBeInTheDocument();
    expect(screen.getByText(/结合 IMU 传感器数据与深度学习/)).toBeInTheDocument();
  });

  it('renders the primary call-to-action links', () => {
    render(<Home />);

    expect(screen.getByRole('link', { name: '开始使用' })).toHaveAttribute('href', '/upload');
    expect(screen.getByRole('link', { name: '了解更多' })).toHaveAttribute('href', '/help');
  });

  it('renders the feature and workflow sections', () => {
    render(<Home />);

    expect(screen.getByRole('heading', { name: '音频相位增强' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: '多模态降噪' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: '工作流程' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: '上传数据' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: '获取结果' })).toBeInTheDocument();
  });

  it('renders the tech stack and footer metadata', () => {
    render(<Home />);

    expect(screen.getByText('React 19')).toBeInTheDocument();
    expect(screen.getByText('PyTorch')).toBeInTheDocument();
    expect(screen.getByText('版本 1.0.0-beta')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'GitHub' })).toHaveAttribute('href', 'https://github.com');
  });

  it('keeps the landing page wrapper structure intact', () => {
    const { container } = render(<Home />);

    expect(container.firstChild).toHaveClass('min-h-screen', 'bg-gradient-subtle');
    expect(container.querySelector('main')).toBeInTheDocument();
  });
});
