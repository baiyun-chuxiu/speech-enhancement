'use client';

import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Waves,
  Sparkles,
  AudioWaveform,
  Activity,
  MonitorSmartphone,
  Upload,
  Cpu,
  Download,
  ArrowRight,
  Github,
  ExternalLink,
  Moon,
  Sun,
} from 'lucide-react';
import { useState } from 'react';
import { LanguageSwitcher } from '@/components/ui/language-switcher';

export default function Home() {
  const t = useTranslations('home');
  const ht = useTranslations('header');
  const ct = useTranslations('common');

  const [isDark, setIsDark] = useState(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return false;
  });

  const toggleTheme = () => {
    const newValue = !isDark;
    setIsDark(newValue);
    document.documentElement.classList.toggle('dark', newValue);
  };

  const features = [
    {
      icon: AudioWaveform,
      title: t('feature1Title'),
      desc: t('feature1Desc'),
      color: 'text-blue-600 dark:text-blue-400',
      bg: 'bg-blue-500/10',
    },
    {
      icon: Activity,
      title: t('feature2Title'),
      desc: t('feature2Desc'),
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-500/10',
    },
    {
      icon: Sparkles,
      title: t('feature3Title'),
      desc: t('feature3Desc'),
      color: 'text-purple-600 dark:text-purple-400',
      bg: 'bg-purple-500/10',
    },
    {
      icon: MonitorSmartphone,
      title: t('feature4Title'),
      desc: t('feature4Desc'),
      color: 'text-orange-600 dark:text-orange-400',
      bg: 'bg-orange-500/10',
    },
  ];

  const steps = [
    { icon: Upload, title: t('step1Title'), desc: t('step1Desc'), num: '1' },
    { icon: Cpu, title: t('step2Title'), desc: t('step2Desc'), num: '2' },
    { icon: Download, title: t('step3Title'), desc: t('step3Desc'), num: '3' },
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between max-w-6xl">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-primary flex items-center justify-center shadow-soft-sm">
              <Waves className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold">{ht('title')}</span>
            <Badge className="hidden sm:inline-flex text-[9px] px-1.5 py-0.5 bg-primary/10 text-primary border-0 font-medium">
              {ht('beta')}
            </Badge>
          </div>
          <div className="flex items-center gap-1.5">
            <LanguageSwitcher className="h-8 text-xs" />
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-lg" onClick={toggleTheme}>
              {isDark ? <Sun className="h-4 w-4 text-yellow-500" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-lg" asChild>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                <Github className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl pt-16 sm:pt-24 pb-16 sm:pb-20">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto animate-fade-in">
            <Badge variant="secondary" className="mb-6 gap-1.5 px-3 py-1 text-xs font-medium">
              <Sparkles className="h-3 w-3" />
              {t('heroTitleAccent')}
            </Badge>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight leading-tight mb-6">
              {t('heroTitle')}
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground max-w-xl mb-8 leading-relaxed">
              {t('heroDescription')}
            </p>
            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              <Button size="lg" className="gap-2 press-effect shadow-soft-sm bg-gradient-primary border-0 h-12 px-8 rounded-xl text-sm font-medium" asChild>
                <Link href="/upload">
                  {t('getStarted')}
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="gap-2 h-12 px-8 rounded-xl text-sm font-medium border-border/60" asChild>
                <Link href="/help">
                  {t('learnMore')}
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl pb-16 sm:pb-20">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f) => (
              <Card key={f.title} className="group border-border/50 bg-card/80 backdrop-blur-sm hover-lift shadow-soft-sm">
                <CardContent className="pt-6 pb-5 px-5">
                  <div className={`w-10 h-10 rounded-xl ${f.bg} flex items-center justify-center mb-4`}>
                    <f.icon className={`h-5 w-5 ${f.color}`} />
                  </div>
                  <h3 className="text-sm font-semibold mb-2">{f.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* How It Works Section */}
        <section className="border-y border-border/40 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl py-16 sm:py-20">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-3">{t('howItWorksTitle')}</h2>
              <p className="text-sm text-muted-foreground">{t('howItWorksDesc')}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
              {steps.map((s, i) => (
                <div key={s.num} className="relative flex flex-col items-center text-center animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
                  <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center mb-4 shadow-soft-sm">
                    <s.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="absolute top-6 left-1/2 w-full h-px bg-border/40 hidden md:block -z-10" style={{ display: i === steps.length - 1 ? 'none' : undefined }} />
                  <span className="text-[10px] font-medium text-primary mb-2 px-2 py-0.5 rounded-full bg-primary/10">
                    {s.num}
                  </span>
                  <h3 className="text-sm font-semibold mb-1.5">{s.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed max-w-xs">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Tech Stack */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl py-12 sm:py-16">
          <div className="text-center">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">{t('techTitle')}</h3>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {['React 19', 'Next.js 16', 'Tailwind v4', 'Tauri 2.x', 'shadcn/ui', 'PyTorch'].map((tech) => (
                <Badge key={tech} variant="outline" className="text-xs px-3 py-1 font-normal border-border/60">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Waves className="h-3.5 w-3.5 text-primary" />
            <span>{t('footerDesc')}</span>
          </div>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span>&copy; 2025 {t('copyright')}</span>
            <Separator orientation="vertical" className="h-3" />
            <span>{ct('version', { version: '1.0.0-beta' })}</span>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-foreground transition-colors">
              GitHub <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
