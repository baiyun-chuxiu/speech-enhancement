import { render, screen } from '@testing-library/react';
import HelpPage from './page';

// Mock next/link
jest.mock('next/link', () => {
  const MockLink = ({ children, href }: { children: React.ReactNode; href: string }) => (
    <a href={href}>{children}</a>
  );
  MockLink.displayName = 'MockLink';
  return MockLink;
});

describe('HelpPage', () => {
  it('renders the help page with title', () => {
    render(<HelpPage />);
    expect(screen.getByText('帮助中心')).toBeInTheDocument();
  });

  it('renders all tabs', () => {
    render(<HelpPage />);
    expect(screen.getByText('快速开始')).toBeInTheDocument();
    expect(screen.getByText('功能说明')).toBeInTheDocument();
    expect(screen.getByText('常见问题')).toBeInTheDocument();
    expect(screen.getByText('API 文档')).toBeInTheDocument();
  });

  it('renders quick start steps', () => {
    render(<HelpPage />);
    expect(screen.getByText('上传加速度计数据')).toBeInTheDocument();
    expect(screen.getByText('上传陀螺仪数据')).toBeInTheDocument();
    expect(screen.getByText('上传音频文件')).toBeInTheDocument();
  });

  it('renders back navigation link', () => {
    render(<HelpPage />);
    const backLink = screen.getByRole('link', { name: '' });
    expect(backLink).toHaveAttribute('href', '/upload');
  });

  it('renders version badge', () => {
    render(<HelpPage />);
    expect(screen.getByText('v1.0.0')).toBeInTheDocument();
  });
});
