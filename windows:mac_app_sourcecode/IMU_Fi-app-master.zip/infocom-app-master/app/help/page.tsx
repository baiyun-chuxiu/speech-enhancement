'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  HelpCircle,
  BookOpen,
  Zap,
  Settings,
  FileText,
  Music,
  BarChart3,
  ArrowLeft,
  ExternalLink,
  CheckCircle,
} from 'lucide-react';
import Link from 'next/link';
import { useTranslations } from 'next-intl';

export default function HelpPage() {
  const t = useTranslations('help');
  return (
    <div className="min-h-screen bg-background">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 h-12 flex items-center justify-between max-w-5xl">
          <div className="flex items-center gap-3">
            <Link href="/upload">
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-base font-semibold flex items-center gap-2">
              <HelpCircle className="h-4 w-4 text-primary" />
              {t('title')}
            </h1>
          </div>
          <Badge variant="secondary" className="text-xs">v1.0.0</Badge>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-5xl">
        <Tabs defaultValue="quickstart" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 h-10">
            <TabsTrigger value="quickstart" className="text-xs sm:text-sm gap-1">
              <Zap className="h-3 w-3 hidden sm:block" />
              {t('quickStart')}
            </TabsTrigger>
            <TabsTrigger value="features" className="text-xs sm:text-sm gap-1">
              <BookOpen className="h-3 w-3 hidden sm:block" />
              {t('features')}
            </TabsTrigger>
            <TabsTrigger value="faq" className="text-xs sm:text-sm gap-1">
              <HelpCircle className="h-3 w-3 hidden sm:block" />
              {t('faq')}
            </TabsTrigger>
            <TabsTrigger value="api" className="text-xs sm:text-sm gap-1">
              <Settings className="h-3 w-3 hidden sm:block" />
              {t('apiDocs')}
            </TabsTrigger>
          </TabsList>

          {/* 快速开始 */}
          <TabsContent value="quickstart" className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  {t('quickStartGuide')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <StepCard
                    step={1}
                    title={t('step1Title')}
                    description={t('step1Desc')}
                    icon={<FileText className="h-5 w-5" />}
                  />
                  <StepCard
                    step={2}
                    title={t('step2Title')}
                    description={t('step2Desc')}
                    icon={<FileText className="h-5 w-5" />}
                  />
                  <StepCard
                    step={3}
                    title={t('step3Title')}
                    description={t('step3Desc')}
                    icon={<Music className="h-5 w-5" />}
                  />
                  <StepCard
                    step={4}
                    title={t('step4Title')}
                    description={t('step4Desc')}
                    icon={<Zap className="h-5 w-5" />}
                  />
                  <StepCard
                    step={5}
                    title={t('step5Title')}
                    description={t('step5Desc')}
                    icon={<BarChart3 className="h-5 w-5" />}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">{t('dataFormatRequirements')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-muted rounded-lg p-4 font-mono text-xs overflow-x-auto">
                  <pre>{`# 传感器数据格式 (.txt)
# 时间戳(ms), X轴, Y轴, Z轴
0, 0.012345, -0.987654, 9.812345
10, 0.013456, -0.976543, 9.823456
20, 0.014567, -0.965432, 9.834567
...`}</pre>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 功能说明 */}
          <TabsContent value="features" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <FeatureCard
                title={t('audioPhaseEnhance')}
                description={t('audioPhaseEnhanceDesc')}
                features={[t('audioPhaseFeature1'), t('audioPhaseFeature2'), t('audioPhaseFeature3')]}
              />
              <FeatureCard
                title={t('sensorDataProcessing')}
                description={t('sensorDataProcessingDesc')}
                features={[t('sensorFeature1'), t('sensorFeature2'), t('sensorFeature3')]}
              />
              <FeatureCard
                title={t('imuVideoGeneration')}
                description={t('imuVideoGenerationDesc')}
                features={[t('imuFeature1'), t('imuFeature2'), t('imuFeature3')]}
              />
              <FeatureCard
                title={t('multimodalDenoise')}
                description={t('multimodalDenoiseDesc')}
                features={[t('denoiseFeature1'), t('denoiseFeature2'), t('denoiseFeature3')]}
              />
            </div>
          </TabsContent>

          {/* 常见问题 */}
          <TabsContent value="faq" className="space-y-4">
            <Card>
              <CardContent className="pt-4">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="faq-1">
                    <AccordionTrigger>{t('faq1q')}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{t('faq1a')}</p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="faq-2">
                    <AccordionTrigger>{t('faq2q')}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{t('faq2a')}</p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="faq-3">
                    <AccordionTrigger>{t('faq3q')}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{t('faq3a')}</p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="faq-4">
                    <AccordionTrigger>{t('faq4q')}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{t('faq4a')}</p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="faq-5">
                    <AccordionTrigger>{t('faq5q')}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{t('faq5a')}</p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="faq-6">
                    <AccordionTrigger>{t('faq6q')}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{t('faq6a')}</p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>

          {/* API 文档 */}
          <TabsContent value="api" className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  INFOCOM REST API
                  <Badge variant="outline">v1</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">{t('apiEndpoints')}</h4>
                  <div className="bg-muted rounded-lg p-3 font-mono text-xs space-y-1">
                    <p><span className="text-green-600">GET</span> /health - {t('healthCheck')}</p>
                    <p><span className="text-green-600">GET</span> /ready - Backend readiness</p>
                    <p><span className="text-green-600">GET</span> /api/v1/system/info - {t('systemInfo')}</p>
                    <p><span className="text-blue-600">POST</span> /api/v1/files/upload - {t('fileUpload')}</p>
                    <p><span className="text-blue-600">POST</span> /api/v1/enhance - {t('audioEnhance')}</p>
                    <p><span className="text-blue-600">POST</span> /api/v1/enhance/uploaded - Uploaded file enhance</p>
                    <p><span className="text-green-600">GET</span> /api/v1/tasks/&#123;task_id&#125; - Task status</p>
                    <p><span className="text-blue-600">POST</span> /api/v1/tasks/&#123;task_id&#125;/cancel - Cancel task</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-1" asChild>
                    <a href="http://localhost:8000/docs" target="_blank" rel="noopener noreferrer">
                      Swagger UI
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1" asChild>
                    <a href="http://localhost:8000/redoc" target="_blank" rel="noopener noreferrer">
                      ReDoc
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">{t('wsRealtime')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-muted rounded-lg p-3 font-mono text-xs">
                  <p className="text-muted-foreground mb-2"># {t('wsConnectComment')}</p>
                  <p>ws://localhost:8000/ws/tasks/&#123;task_id&#125;</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function StepCard({ step, title, description, icon }: {
  step: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="flex gap-4 p-4 bg-muted/50 rounded-lg">
      <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold shrink-0">
        {step}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          {icon}
          <h3 className="font-medium">{title}</h3>
        </div>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

function FeatureCard({ title, description, features }: {
  title: string;
  description: string;
  features: string[];
}) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-3">{description}</p>
        <div className="flex flex-wrap gap-1.5">
          {features.map((f) => (
            <Badge key={f} variant="secondary" className="text-xs">
              <CheckCircle className="h-3 w-3 mr-1" />
              {f}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

