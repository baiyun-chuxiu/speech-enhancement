import type { Metadata, Viewport } from 'next';

export const metadata: Metadata = {
  title: 'Audio Processing Tool - InfoCom',
  description: 'Mobile audio and text upload processing tool with local model inference',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'InfoCom',
  },
  formatDetection: {
    telephone: false,
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
};

export default function UploadLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen overflow-x-clip bg-background antialiased [--upload-header-offset:5rem]">
      {children}
    </div>
  );
}
