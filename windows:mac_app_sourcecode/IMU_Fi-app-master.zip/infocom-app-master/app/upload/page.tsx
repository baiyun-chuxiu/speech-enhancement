'use client';

import { useState, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { 
  FileUploader, 
  AudioPlayer, 
  AudioAnalyzer, 
  ProcessingStatus,
  DataPreview,
  DataChart,
  MobileHeader,
} from '@/components/upload';
import { 
  useTextFileUpload, 
  useAudioFileUpload 
} from '@/hooks/useFileUpload';
import { useModelApi } from '@/hooks/useModelApi';
import { useProcessedAudioSession } from '@/hooks/useProcessedAudioSession';
import {
  getClientCompletionCapabilities,
  getStoredAppSettings,
  normalizeAppSettings,
  type AppSettings,
} from '@/lib/app-settings';
import { 
  Sparkles, 
  Info,
  Upload,
  BarChart3,
  Headphones,
  Wand2,
} from 'lucide-react';
import type { TextFileInfo } from '@/lib/types';

export default function UploadPage() {
  const t = useTranslations();
  const [showResults, setShowResults] = useState(false);
  const [activeSettings, setActiveSettings] = useState<AppSettings | null>(null);

  // 加速度计数据上传
  const accelUpload = useTextFileUpload({
    maxSize: 10 * 1024 * 1024, // 10MB
    onSuccess: () => console.log('加速度计数据上传成功'),
    onError: (error) => console.error('加速度计上传错误:', error),
  });

  // 陀螺仪数据上传
  const gyroUpload = useTextFileUpload({
    maxSize: 10 * 1024 * 1024, // 10MB
    onSuccess: () => console.log('陀螺仪数据上传成功'),
    onError: (error) => console.error('陀螺仪上传错误:', error),
  });

  const audioUpload = useAudioFileUpload({
    maxSize: 100 * 1024 * 1024, // 100MB
    onSuccess: () => console.log('音频文件上传成功'),
    onError: (error) => console.error('音频上传错误:', error),
  });

  // 模型处理
  const modelApi = useModelApi({
    onComplete: (response) => {
      if (response.success) {
        setShowResults(true);
      }
    },
    onError: (error) => console.error('处理错误:', error),
  });

  const outputSession = useProcessedAudioSession({
    audio: modelApi.outputAudio,
    preferences: activeSettings
      ? {
          autoSave: activeSettings.autoSave,
          notifications: activeSettings.notifications,
        }
      : null,
  });

  const canProcess = 
    accelUpload.fileInfo?.status === 'success' && 
    gyroUpload.fileInfo?.status === 'success' &&
    audioUpload.fileInfo?.status === 'success' &&
    !modelApi.isProcessing;

  const handleProcess = useCallback(async () => {
    if (!accelUpload.fileInfo || !gyroUpload.fileInfo || !audioUpload.fileInfo) return;

    const accelFile = accelUpload.fileInfo.file;
    const gyroFile = gyroUpload.fileInfo.file;
    const audioFile = audioUpload.fileInfo.file;

    if (!accelFile || !gyroFile || !audioFile) return;

    const currentSettings = normalizeAppSettings(getStoredAppSettings(), {
      completionCapabilities: getClientCompletionCapabilities(),
    });
    setActiveSettings(currentSettings);
    await modelApi.processEnhance(audioFile, accelFile, gyroFile, currentSettings);
  }, [accelUpload.fileInfo, gyroUpload.fileInfo, audioUpload.fileInfo, modelApi]);

  const handleReset = useCallback(() => {
    accelUpload.reset();
    gyroUpload.reset();
    audioUpload.reset();
    modelApi.reset();
    setShowResults(false);
    setActiveSettings(null);
  }, [accelUpload, gyroUpload, audioUpload, modelApi]);

  const hasDataPreview = accelUpload.fileInfo?.status === 'success' || gyroUpload.fileInfo?.status === 'success';
  const hasResults = showResults && modelApi.outputAudio;
  const workflowSteps = [
    t('upload.step1'),
    t('upload.step2'),
    t('upload.step3'),
    t('upload.step4'),
    t('upload.step5'),
  ];

  return (
    <div className="min-h-screen overflow-x-clip bg-gradient-subtle">
      {/* 顶部导航 */}
      <MobileHeader 
        onReset={handleReset}
        isProcessing={modelApi.isProcessing}
      />

      <main className="container-responsive mx-auto max-w-7xl py-4 lg:py-6 pb-safe-area">
        <section
          data-testid="upload-step-guide"
          className="upload-step-guide animate-fade-in"
          aria-label={t('upload.usageSteps')}
        >
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                <Info className="h-4 w-4 text-primary" />
              </div>
              <div className="space-y-0.5">
                <p className="text-xs font-semibold tracking-wide text-foreground">
                  {t('upload.stepsLabel')}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {t('upload.waitingUploadDesc')}
                </p>
              </div>
            </div>

            <ol className="upload-step-list">
              {workflowSteps.map((step, index) => (
                <li
                  key={step}
                  className="upload-step-chip"
                >
                  <span className="font-semibold text-primary">{index + 1}.</span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <div
          data-testid="upload-workspace"
          className="upload-workspace mt-4 lg:mt-5"
        >
          <aside
            data-testid="upload-control-region"
            className="upload-control-rail"
          >
            <section className="space-y-3" id="upload">
              <div className="hidden lg:flex items-center gap-2 mb-1">
                <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Upload className="h-3.5 w-3.5 text-primary" />
                </div>
                <h2 className="text-sm font-semibold">{t('upload.uploadFiles')}</h2>
              </div>
              
              {/* 加速度计数据 */}
              <FileUploader
                type="text"
                title={t('upload.accelData')}
                description={t('upload.accelDesc')}
                fileInfo={accelUpload.fileInfo}
                isUploading={accelUpload.isUploading}
                progress={accelUpload.progress}
                error={accelUpload.error}
                onFileSelect={accelUpload.selectFile}
                onRemove={accelUpload.removeFile}
                disabled={modelApi.isProcessing}
              />

              {/* 陀螺仪数据 */}
              <FileUploader
                type="text"
                title={t('upload.gyroData')}
                description={t('upload.gyroDesc')}
                fileInfo={gyroUpload.fileInfo}
                isUploading={gyroUpload.isUploading}
                progress={gyroUpload.progress}
                error={gyroUpload.error}
                onFileSelect={gyroUpload.selectFile}
                onRemove={gyroUpload.removeFile}
                disabled={modelApi.isProcessing}
              />

              {/* 音频文件 */}
              <FileUploader
                type="audio"
                fileInfo={audioUpload.fileInfo}
                isUploading={audioUpload.isUploading}
                progress={audioUpload.progress}
                error={audioUpload.error}
                onFileSelect={audioUpload.selectFile}
                onRemove={audioUpload.removeFile}
                disabled={modelApi.isProcessing}
              />

              {/* 处理按钮 */}
              <Button
                id="process"
                className="w-full h-11 lg:h-10 text-sm gap-2 font-medium press-effect shadow-soft-sm hover:shadow-soft-md transition-all duration-200 bg-gradient-primary border-0"
                disabled={!canProcess}
                onClick={handleProcess}
              >
                {modelApi.isProcessing ? (
                  <>
                    <Wand2 className="h-4 w-4 animate-spin" />
                    <span>{t('upload.processing')}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    <span>{t('upload.startProcessing')}</span>
                  </>
                )}
              </Button>

              {/* 处理状态 */}
              {(modelApi.isProcessing || modelApi.error) && (
                <ProcessingStatus
                  isProcessing={modelApi.isProcessing}
                  progress={modelApi.progress}
                  steps={modelApi.steps}
                  error={modelApi.error}
                  onCancel={modelApi.cancelProcess}
                  className="min-w-0"
                />
              )}
            </section>

            {/* 技术说明 - 桌面端紧凑显示 */}
            <div className="hidden lg:flex items-center gap-1.5 text-[10px] text-muted-foreground/60 px-1 pt-3 border-t border-border/40">
              <span className="px-1.5 py-0.5 rounded bg-muted/50">React 19</span>
              <span className="px-1.5 py-0.5 rounded bg-muted/50">Next.js 16</span>
              <span className="px-1.5 py-0.5 rounded bg-muted/50">Tailwind v4</span>
              <span className="px-1.5 py-0.5 rounded bg-muted/50">Tauri 2.x</span>
            </div>
          </aside>

          <section
            data-testid="upload-content-region"
            className="upload-content-flow"
          >
            {/* 数据预览区域 */}
            {hasDataPreview && (
              <section className="space-y-3 animate-fade-in">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
                    <BarChart3 className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <h2 className="text-sm font-semibold">{t('upload.dataPreview')}</h2>
                </div>

                {/* 加速度计数据预览 */}
                {accelUpload.fileInfo?.status === 'success' && (
                  <div className="upload-panel-grid">
                    <DataPreview textFile={accelUpload.fileInfo as TextFileInfo} sensorType="accelerometer" />
                    <DataChart textFile={accelUpload.fileInfo as TextFileInfo} sensorType="accelerometer" />
                  </div>
                )}

                {/* 陀螺仪数据预览 */}
                {gyroUpload.fileInfo?.status === 'success' && (
                  <div className="upload-panel-grid">
                    <DataPreview textFile={gyroUpload.fileInfo as TextFileInfo} sensorType="gyroscope" />
                    <DataChart textFile={gyroUpload.fileInfo as TextFileInfo} sensorType="gyroscope" />
                  </div>
                )}
              </section>
            )}

            {/* 处理结果 */}
            {hasResults && (
              <section className="space-y-3 animate-slide-in-up">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-green-500/10 flex items-center justify-center">
                    <Headphones className="h-3.5 w-3.5 text-green-600 dark:text-green-400" />
                  </div>
                  <h2 className="text-sm font-semibold">{t('upload.processingResult')}</h2>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-green-500/10 text-green-600 dark:text-green-400 font-medium">{t('upload.resultComplete')}</span>
                </div>
                
                <div className="upload-results-grid">
                  <AudioPlayer
                    audio={modelApi.outputAudio}
                    session={outputSession}
                    title={t('upload.generatedAudio')}
                  />

                  <AudioAnalyzer
                    audio={modelApi.outputAudio}
                    session={outputSession}
                    analysis={outputSession.analysis}
                    currentTime={outputSession.state.currentTime}
                  />
                </div>
              </section>
            )}

            {/* 空状态提示 */}
            {!hasDataPreview && !hasResults && (
              <div className="flex flex-col items-center justify-center py-12 lg:py-16 text-center animate-fade-in">
                <div className="relative mb-4">
                  <div className="w-14 h-14 lg:w-16 lg:h-16 rounded-2xl bg-muted/30 flex items-center justify-center">
                    <BarChart3 className="h-7 w-7 lg:h-8 lg:w-8 text-muted-foreground/40" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                    <Upload className="h-3 w-3 text-primary" />
                  </div>
                </div>
                <h3 className="text-sm lg:text-base font-semibold text-foreground mb-1.5">{t('upload.waitingUpload')}</h3>
                <p className="text-xs text-muted-foreground max-w-xs">
                  {t('upload.waitingUploadDesc')}
                </p>
                <div className="mt-3 flex items-center gap-2 text-[10px] text-muted-foreground/60">
                  <span className="px-2 py-1 rounded-md bg-muted/50">{t('upload.supportTxtFiles')}</span>
                  <span className="px-2 py-1 rounded-md bg-muted/50">{t('upload.supportAudioFormats')}</span>
                </div>
              </div>
            )}
          </section>
        </div>

      </main>

      {/* 底部安全区域 */}
      <div className="h-safe-area-inset-bottom" />
    </div>
  );
}
