import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import UploadPage from './page';

type MockUploadFileInfo = {
  status: 'success';
  file: File;
} | null;

interface MockUploadState {
  fileInfo: MockUploadFileInfo;
  isUploading: boolean;
  progress: number;
  error: string | null;
  selectFile: jest.Mock;
  removeFile: jest.Mock;
  reset: jest.Mock;
}

const processEnhanceMock = jest.fn();
type MockProcessedAudioSessionOptions = {
  audio: unknown;
  preferences?: {
    autoSave?: boolean;
    notifications?: boolean;
  } | null;
};

const useProcessedAudioSessionMock = jest.fn(
  (_options: MockProcessedAudioSessionOptions) => {
    void _options;
    return {
      analysis: null,
      state: {
        currentTime: 0,
      },
    };
  },
);
const getStoredAppSettingsMock = jest.fn(() => ({
  apiUrl: 'http://localhost:8000',
  theme: 'system',
  device: 'cpu',
  quality: 'balanced',
  outputFormat: 'wav',
  autoSave: true,
  notifications: true,
  locale: 'zh-CN',
}));

let accelUploadState: MockUploadState = {
  fileInfo: null,
  isUploading: false,
  progress: 0,
  error: null,
  selectFile: jest.fn(),
  removeFile: jest.fn(),
  reset: jest.fn(),
};

let gyroUploadState: MockUploadState = {
  fileInfo: null,
  isUploading: false,
  progress: 0,
  error: null,
  selectFile: jest.fn(),
  removeFile: jest.fn(),
  reset: jest.fn(),
};

let audioUploadState: MockUploadState = {
  fileInfo: null,
  isUploading: false,
  progress: 0,
  error: null,
  selectFile: jest.fn(),
  removeFile: jest.fn(),
  reset: jest.fn(),
};

let textUploadCallCount = 0;

jest.mock('next-intl', () => ({
  useTranslations: () => (key: string) => {
    const messages: Record<string, string> = {
      'upload.stepsLabel': '步骤：',
      'upload.usageSteps': '使用步骤',
      'upload.step1': '上传加速度计',
      'upload.step2': '上传陀螺仪',
      'upload.step3': '上传音频',
      'upload.step4': '开始处理',
      'upload.step5': '查看结果',
      'upload.uploadFiles': '上传文件',
      'upload.accelData': '加速度计数据',
      'upload.accelDesc': '支持 .txt 格式 (X/Y/Z 轴加速度)',
      'upload.gyroData': '陀螺仪数据',
      'upload.gyroDesc': '支持 .txt 格式 (X/Y/Z 轴角速度)',
      'upload.processing': '处理中...',
      'upload.startProcessing': '开始处理',
      'upload.dataPreview': '数据预览',
      'upload.processingResult': '处理结果',
      'upload.resultComplete': '完成',
      'upload.generatedAudio': '生成音频',
      'upload.waitingUpload': '等待数据上传',
      'upload.waitingUploadDesc': '请先在左侧上传传感器数据和音频文件，然后开始处理',
      'upload.supportTxtFiles': '支持 .txt 数据文件',
      'upload.supportAudioFormats': '支持多种音频格式',
      'common.reset': '重置',
    };

    return messages[key] ?? key;
  },
}));

jest.mock('@/hooks/useFileUpload', () => ({
  useTextFileUpload: jest.fn(() => {
    textUploadCallCount += 1;
    return textUploadCallCount === 1 ? accelUploadState : gyroUploadState;
  }),
  useAudioFileUpload: jest.fn(() => audioUploadState),
}));

jest.mock('@/hooks/useModelApi', () => ({
  useModelApi: jest.fn(() => ({
    isProcessing: false,
    progress: 0,
    steps: [],
    error: null,
    outputAudio: null,
    processEnhance: processEnhanceMock,
    cancelProcess: jest.fn(),
    reset: jest.fn(),
  })),
}));

jest.mock('@/lib/app-settings', () => {
  const actual = jest.requireActual('@/lib/app-settings');
  return {
    ...actual,
    getStoredAppSettings: () => getStoredAppSettingsMock(),
  };
});

jest.mock('@/hooks/useProcessedAudioSession', () => ({
  useProcessedAudioSession: (options: MockProcessedAudioSessionOptions) =>
    useProcessedAudioSessionMock(options),
}));

jest.mock('@/hooks/useAudioPlayer', () => ({
  useAudioPlayer: jest.fn(() => ({
    analysis: null,
    state: {
      currentTime: 0,
    },
  })),
}));

jest.mock('@/components/upload', () => ({
  FileUploader: ({ title, type }: { title?: string; type?: string }) => (
    <div data-testid="file-uploader">{title ?? type}</div>
  ),
  AudioPlayer: () => <div data-testid="audio-player">audio-player</div>,
  AudioAnalyzer: () => <div data-testid="audio-analyzer">audio-analyzer</div>,
  ProcessingStatus: () => <div data-testid="processing-status">processing-status</div>,
  DataPreview: () => <div data-testid="data-preview">data-preview</div>,
  DataChart: () => <div data-testid="data-chart">data-chart</div>,
  MobileHeader: ({ isProcessing }: { isProcessing?: boolean }) => (
    <div data-testid="mobile-header">{isProcessing ? 'processing' : 'idle'}</div>
  ),
}));

describe('Upload Page', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    textUploadCallCount = 0;
    accelUploadState = {
      fileInfo: null,
      isUploading: false,
      progress: 0,
      error: null,
      selectFile: jest.fn(),
      removeFile: jest.fn(),
      reset: jest.fn(),
    };
    gyroUploadState = {
      fileInfo: null,
      isUploading: false,
      progress: 0,
      error: null,
      selectFile: jest.fn(),
      removeFile: jest.fn(),
      reset: jest.fn(),
    };
    audioUploadState = {
      fileInfo: null,
      isUploading: false,
      progress: 0,
      error: null,
      selectFile: jest.fn(),
      removeFile: jest.fn(),
      reset: jest.fn(),
    };
  });

  it('renders one adaptive step guide instead of duplicate mobile and desktop guides', () => {
    render(<UploadPage />);

    expect(screen.getAllByTestId('upload-step-guide')).toHaveLength(1);
    expect(screen.getByText('步骤：')).toBeInTheDocument();
    expect(screen.getByTestId('upload-step-guide')).toHaveTextContent('1.上传加速度计');
    expect(screen.getByTestId('upload-step-guide')).toHaveTextContent('5.查看结果');
  });

  it('renders dedicated control and content regions for the responsive workspace', () => {
    render(<UploadPage />);

    expect(screen.getByTestId('upload-workspace')).toBeInTheDocument();
    expect(screen.getByTestId('upload-control-region')).toBeInTheDocument();
    expect(screen.getByTestId('upload-content-region')).toBeInTheDocument();
  });

  it('keeps the waiting state inside the content region before uploads begin', () => {
    render(<UploadPage />);

    const contentRegion = screen.getByTestId('upload-content-region');
    expect(contentRegion).toHaveTextContent('等待数据上传');
    expect(contentRegion).toHaveTextContent('支持 .txt 数据文件');
    expect(contentRegion).toHaveTextContent('支持多种音频格式');
  });

  it('starts enhancement with the shared settings model instead of reading raw localStorage', async () => {
    const user = userEvent.setup();
    accelUploadState = {
      ...accelUploadState,
      fileInfo: {
        status: 'success',
        file: new File(['accel'], 'accel.txt', { type: 'text/plain' }),
      },
    };
    gyroUploadState = {
      ...gyroUploadState,
      fileInfo: {
        status: 'success',
        file: new File(['gyro'], 'gyro.txt', { type: 'text/plain' }),
      },
    };
    audioUploadState = {
      ...audioUploadState,
      fileInfo: {
        status: 'success',
        file: new File(['audio'], 'audio.wav', { type: 'audio/wav' }),
      },
    };

    render(<UploadPage />);

    await user.click(screen.getByRole('button', { name: '开始处理' }));

    expect(getStoredAppSettingsMock).toHaveBeenCalled();
    expect(processEnhanceMock).toHaveBeenCalled();
  });

  it('normalizes session completion preferences before wiring the processed-audio session', async () => {
    const user = userEvent.setup();
    accelUploadState = {
      ...accelUploadState,
      fileInfo: {
        status: 'success',
        file: new File(['accel'], 'accel.txt', { type: 'text/plain' }),
      },
    };
    gyroUploadState = {
      ...gyroUploadState,
      fileInfo: {
        status: 'success',
        file: new File(['gyro'], 'gyro.txt', { type: 'text/plain' }),
      },
    };
    audioUploadState = {
      ...audioUploadState,
      fileInfo: {
        status: 'success',
        file: new File(['audio'], 'audio.wav', { type: 'audio/wav' }),
      },
    };

    render(<UploadPage />);

    await user.click(screen.getByRole('button', { name: '开始处理' }));

    expect(useProcessedAudioSessionMock).toHaveBeenLastCalledWith(
      expect.objectContaining({
        preferences: expect.objectContaining({
          autoSave: false,
          notifications: true,
        }),
      }),
    );
  });
});
