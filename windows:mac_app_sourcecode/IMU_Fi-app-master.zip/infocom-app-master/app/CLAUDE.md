# Pages Module

[根目录](../CLAUDE.md) > **app/**

## Module Overview

Next.js 16 App Router pages and layouts for the InfoCom application. This module contains all route-level components, layouts, and global styles.

## Module Structure

```
app/
├── layout.tsx              # Root layout with fonts and metadata
├── page.tsx                # Home page
├── page.test.tsx           # Home page tests
├── globals.css             # Global styles and Tailwind config
├── upload/
│   ├── layout.tsx          # Upload section layout
│   └── page.tsx            # Main upload/processing page
├── help/
│   └── page.tsx            # Help/documentation page
│   └── page.test.tsx       # Help page tests
└── settings/
    └── page.tsx            # Settings page
    └── page.test.tsx       # Settings page tests
```

## Key Files

### Root Layout (`layout.tsx`)

- Sets up Geist Sans and Mono fonts via `next/font/google`
- Configures root metadata and viewport
- Wraps application with theme provider
- Imports global styles

### Home Page (`page.tsx`)

Landing page with:
- Navigation to main features
- Project overview
- Quick start guide

### Upload Page (`upload/page.tsx`)

Main application page that:
- Orchestrates three custom hooks (`useTextFileUpload`, `useAudioFileUpload`, `useModelApi`)
- Manages file upload workflow (accelerometer → gyroscope → audio → process)
- Displays data previews and processing results
- Coordinates between upload components and audio player

**Key Components Used**:
- `FileUploader` - For each of the three file types
- `DataPreview` / `DataChart` - For sensor data visualization
- `AudioPlayer` / `AudioAnalyzer` - For audio playback
- `ProcessingStatus` - For progress tracking

### Global Styles (`globals.css`)

- Tailwind CSS v4 configuration with `@theme` directive
- CSS variables for theming (colors, borders, radii)
- Custom animations (fade-in, slide-in, press-effect)
- Responsive utility classes (safe-area for mobile)

## Related Hooks

| Hook | Usage |
|------|-------|
| `useTextFileUpload` | Accelerometer and gyroscope file uploads |
| `useAudioFileUpload` | Audio file upload with duration detection |
| `useModelApi` | Processing workflow orchestration |
| `useAudioPlayer` | Output audio playback |

## Testing

- **Unit Tests**: 3/9 files covered (33%)
- **Test Files**:
  - `page.test.tsx` - Home page tests
  - `help/page.test.tsx` - Help page tests
  - `settings/page.test.tsx` - Settings page tests
- **Missing Tests**: `upload/page.tsx` (main feature page)

## Data Flow Diagram

```mermaid
graph TD
    Page[upload/page.tsx]
    Accel[useTextFileUpload<br/>Accelerometer]
    Gyro[useTextFileUpload<br/>Gyroscope]
    Audio[useAudioFileUpload<br/>Audio]
    Model[useModelApi<br/>Processing]

    Page --> Accel
    Page --> Gyro
    Page --> Audio
    Page --> Model

    Accel --> DataPreview[DataPreview]
    Accel --> DataChart[DataChart]
    Gyro --> DataPreview
    Gyro --> DataChart

    Model --> ProcessingStatus[ProcessingStatus]
    Model --> OutputPlayer[useAudioPlayer]

    OutputPlayer --> AudioPlayer[AudioPlayer]
    OutputPlayer --> AudioAnalyzer[AudioAnalyzer]
```

## Known Issues

1. `upload/page.tsx` lacks unit tests (tested via E2E instead)
2. Help and settings pages are placeholders
3. No error boundary implementation

## Dependencies

- `next/font/google` - Geist fonts
- `@/components/upload` - Feature components
- `@/hooks` - Custom hooks
- `@/lib/types` - TypeScript types
- `lucide-react` - Icons
