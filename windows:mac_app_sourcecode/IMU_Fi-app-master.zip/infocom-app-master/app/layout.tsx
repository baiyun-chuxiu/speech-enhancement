import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { Toaster } from "@/components/ui/sonner";
import { I18nProvider } from "@/components/i18n-provider";
import { defaultLocale } from "@/i18n/config";
import { getMessagesForLocale } from "@/i18n/messages";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const staticLocale = defaultLocale;
const staticMessages = getMessagesForLocale(staticLocale);

export async function generateMetadata(): Promise<Metadata> {
  const messages = staticMessages as {
    metadata?: { title?: string; description?: string };
  };

  return {
    title: messages.metadata?.title ?? "InfoCom - 智能音频处理工具",
    description:
      messages.metadata?.description ??
      "基于多模态融合的跨平台音频增强工具，结合 IMU 传感器数据与深度学习实现高质量音频降噪",
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang={staticLocale} suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <I18nProvider initialLocale={staticLocale} initialMessages={staticMessages}>
          {children}
          <Toaster />
        </I18nProvider>
      </body>
    </html>
  );
}
