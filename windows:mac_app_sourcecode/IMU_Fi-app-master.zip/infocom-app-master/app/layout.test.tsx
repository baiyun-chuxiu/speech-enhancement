const cookiesMock = jest.fn();
jest.mock('next/headers', () => ({
  cookies: () => cookiesMock(),
}));

jest.mock('next/font/google', () => ({
  Geist: () => ({ variable: 'geist-sans' }),
  Geist_Mono: () => ({ variable: 'geist-mono' }),
}));

jest.mock('@/components/ui/sonner', () => ({
  Toaster: () => <div data-testid="toaster" />,
}));

jest.mock('@/components/i18n-provider', () => ({
  I18nProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

describe('RootLayout', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('uses a static default locale without reading request cookies', async () => {
    const { default: RootLayout, generateMetadata } = await import('./layout');

    const metadata = await generateMetadata();
    const element = await RootLayout({ children: <div>content</div> });

    expect(cookiesMock).not.toHaveBeenCalled();
    expect(metadata).toMatchObject({
      title: '音频处理工具 - InfoCom',
    });
    expect(element.props.lang).toBe('zh-CN');
    expect(element.props.children.props.children.props.initialLocale).toBe('zh-CN');
  });
});
