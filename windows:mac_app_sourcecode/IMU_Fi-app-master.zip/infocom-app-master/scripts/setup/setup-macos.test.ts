/** @jest-environment node */
/* eslint-disable @typescript-eslint/no-require-imports */

import path from "node:path";

const { runSetup } = require("./setup-macos.js");

type CommandInvocation = {
  command: string;
  args: string[];
  cwd: string;
};

function createDeps(options?: {
  platform?: string;
  existingPaths?: string[];
  missingCommands?: string[];
  xcodeReady?: boolean;
  failingCommands?: string[];
}) {
  const cwd = "/repo";
  const existing = new Set(
    options?.existingPaths ?? [
      path.join(cwd, ".env.local.example"),
      path.join(cwd, "server", "models", "generator_final.pth"),
      path.join(cwd, "server", "models", "best_model.pth"),
    ],
  );
  const executed: CommandInvocation[] = [];
  const copied: Array<{ from: string; to: string }> = [];
  const missingCommands = new Set(options?.missingCommands ?? []);
  const failingCommands = new Set(options?.failingCommands ?? []);
  const logger = {
    info: jest.fn(),
    error: jest.fn(),
  };

  const deps = {
    cwd,
    platform: options?.platform ?? "darwin",
    fs: {
      existsSync(filePath: string) {
        return existing.has(filePath);
      },
      copyFileSync(from: string, to: string) {
        copied.push({ from, to });
        existing.add(to);
      },
    },
    path,
    logger,
    hasXcodeClt() {
      return options?.xcodeReady ?? true;
    },
    hasCommand(command: string) {
      return !missingCommands.has(command);
    },
    runCommand(command: string, args: string[], runOptions: { cwd?: string } = {}) {
      const invocation = {
        command,
        args,
        cwd: runOptions.cwd ?? cwd,
      };

      executed.push(invocation);

      const commandLine = [command, ...args].join(" ");
      if (failingCommands.has(commandLine)) {
        return {
          ok: false,
          code: 1,
          stdout: "",
          stderr: `failed: ${commandLine}`,
          commandLine,
        };
      }

      return {
        ok: true,
        code: 0,
        stdout: `ok: ${commandLine}`,
        stderr: "",
        commandLine,
      };
    },
  };

  return { cwd, deps, executed, copied, logger };
}

describe("setup-macos", () => {
  it("blocks unsupported host platforms before making changes", () => {
    const { deps, executed, copied } = createDeps({ platform: "win32" });

    const result = runSetup({}, deps);

    expect(result.status).toBe("blocked");
    expect(result.blockers.join("\n")).toMatch(/macOS-only/i);
    expect(executed).toEqual([]);
    expect(copied).toEqual([]);
  });

  it("stops before dependency installation when a required prerequisite is missing", () => {
    const { deps, executed } = createDeps({ missingCommands: ["uv"] });

    const result = runSetup({}, deps);

    expect(result.status).toBe("blocked");
    expect(result.blockers.join("\n")).toMatch(/uv/i);
    expect(executed).toEqual([]);
  });

  it("installs dependencies, creates .env.local, and warns when model files are missing", () => {
    const { cwd, deps, executed, copied } = createDeps({
      existingPaths: [path.join("/repo", ".env.local.example")],
    });

    const result = runSetup({}, deps);

    expect(result.status).toBe("partial");
    expect(executed).toEqual([
      { command: "pnpm", args: ["install"], cwd },
      { command: "uv", args: ["sync"], cwd: path.join(cwd, "server") },
      { command: "pnpm", args: ["tauri", "info"], cwd },
    ]);
    expect(copied).toEqual([
      {
        from: path.join(cwd, ".env.local.example"),
        to: path.join(cwd, ".env.local"),
      },
    ]);
    expect(result.warnings.join("\n")).toMatch(/generator_final\.pth/i);
    expect(result.warnings.join("\n")).toMatch(/best_model\.pth/i);
    expect(result.nextSteps).toContain("pnpm dev:all");
    expect(result.nextSteps).toContain("pnpm tauri dev");
  });

  it("preserves an existing .env.local and reports a ready environment when model files exist", () => {
    const repoRoot = "/repo";
    const { deps, copied } = createDeps({
      existingPaths: [
        path.join(repoRoot, ".env.local.example"),
        path.join(repoRoot, ".env.local"),
        path.join(repoRoot, "server", "models", "generator_final.pth"),
        path.join(repoRoot, "server", "models", "best_model.pth"),
      ],
    });

    const result = runSetup({}, deps);

    expect(result.status).toBe("ready");
    expect(copied).toEqual([]);
    expect(result.successes.join("\n")).toMatch(/reused the existing \.env\.local/i);
    expect(result.blockers).toEqual([]);
  });
});
