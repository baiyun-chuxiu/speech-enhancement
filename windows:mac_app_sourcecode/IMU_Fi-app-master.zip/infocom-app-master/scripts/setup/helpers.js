function formatCommand(command, args = []) {
  return [command, ...args].join(" ");
}

function printSection(logger, title) {
  logger.info(`\n== ${title} ==`);
}

function runStep(deps, command, args = [], options = {}) {
  const commandLine = formatCommand(command, args);
  deps.logger.info(`$ ${commandLine}`);

  return deps.runCommand(command, args, {
    cwd: options.cwd,
  });
}

function printSummary(logger, summary) {
  logger.info("\n== Summary ==");
  logger.info(`Status: ${summary.status.toUpperCase()}`);

  if (summary.successes.length > 0) {
    logger.info("Completed:");
    for (const item of summary.successes) {
      logger.info(`- ${item}`);
    }
  }

  if (summary.warnings.length > 0) {
    logger.info("Warnings:");
    for (const item of summary.warnings) {
      logger.info(`- ${item}`);
    }
  }

  if (summary.blockers.length > 0) {
    logger.info("Blockers:");
    for (const item of summary.blockers) {
      logger.info(`- ${item}`);
    }
  }

  if (summary.nextSteps.length > 0) {
    logger.info("Next steps:");
    for (const item of summary.nextSteps) {
      logger.info(`- ${item}`);
    }
  }
}

module.exports = {
  formatCommand,
  printSection,
  printSummary,
  runStep,
};
