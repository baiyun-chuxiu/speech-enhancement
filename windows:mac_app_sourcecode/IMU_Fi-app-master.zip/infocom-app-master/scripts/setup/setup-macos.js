/* eslint-disable @typescript-eslint/no-require-imports */

const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const { printSection, printSummary, runStep } = require("./helpers.js");

const REQUIRED_MODEL_FILES = ["generator_final.pth", "best_model.pth"];

function createDefaultDeps() {
  return {
    cwd: process.cwd(),
    platform: process.platform,
    fs,
    path,
    logger: console,
    hasCommand(command) {
      const result = spawnSync("which", [command], {
        encoding: "utf8",
      });

      return result.status === 0;
    },
    hasXcodeClt() {
      const result = spawnSync("xcode-select", ["-p"], {
        encoding: "utf8",
      });

      return result.status === 0;
    },
    runCommand(command, args, options = {}) {
      const result = spawnSync(command, args, {
        cwd: options.cwd,
        encoding: "utf8",
        stdio: "pipe",
      });

      return {
        ok: result.status === 0,
        code: result.status ?? 1,
        stdout: result.stdout ?? "",
        stderr: result.stderr ?? "",
        commandLine: [command, ...args].join(" "),
      };
    },
  };
}

function createSummary() {
  return {
    status: "ready",
    successes: [],
    warnings: [],
    blockers: [],
    nextSteps: [],
  };
}

function setStatus(summary, nextStatus) {
  const priorities = {
    ready: 0,
    partial: 1,
    blocked: 2,
  };

  if (priorities[nextStatus] > priorities[summary.status]) {
    summary.status = nextStatus;
  }
}

function getRepoPaths(cwd, pathModule) {
  return {
    repoRoot: cwd,
    serverDir: pathModule.join(cwd, "server"),
    envExamplePath: pathModule.join(cwd, ".env.local.example"),
    envLocalPath: pathModule.join(cwd, ".env.local"),
    modelDir: pathModule.join(cwd, "server", "models"),
  };
}

function collectMissingPrerequisites(deps) {
  const missing = [];

  if (!deps.hasXcodeClt()) {
    missing.push(
      "Xcode Command Line Tools are not ready. Run `xcode-select --install` and re-run `pnpm setup:macos`.",
    );
  }

  if (!deps.hasCommand("uv")) {
    missing.push(
      "`uv` is not installed or not on PATH. Install it first, then re-run `pnpm setup:macos`.",
    );
  }

  if (!deps.hasCommand("rustc")) {
    missing.push(
      "`rustc` is not installed or not on PATH. Install Rust via rustup, then re-run `pnpm setup:macos`.",
    );
  }

  return missing;
}

function syncEnvFile(summary, deps, repoPaths) {
  if (!deps.fs.existsSync(repoPaths.envExamplePath)) {
    summary.blockers.push(
      "The repository is missing `.env.local.example`, so local configuration could not be bootstrapped.",
    );
    setStatus(summary, "blocked");
    return;
  }

  if (deps.fs.existsSync(repoPaths.envLocalPath)) {
    summary.successes.push("The setup flow reused the existing .env.local file.");
    return;
  }

  deps.fs.copyFileSync(repoPaths.envExamplePath, repoPaths.envLocalPath);
  summary.successes.push("Created .env.local from .env.local.example.");
}

function checkModelFiles(summary, deps, repoPaths) {
  const missingModelFiles = REQUIRED_MODEL_FILES.filter((fileName) => {
    const modelPath = deps.path.join(repoPaths.modelDir, fileName);
    return !deps.fs.existsSync(modelPath);
  });

  if (missingModelFiles.length === 0) {
    summary.successes.push("Required model weights are present under `server/models/`.");
    return;
  }

  setStatus(summary, "partial");
  summary.warnings.push(
    `Audio enhancement is not fully runnable yet. Add the missing model files under \`server/models/\`: ${missingModelFiles.join(", ")}.`,
  );
  summary.nextSteps.push(
    "Add the required model weights to `server/models/` before testing audio enhancement end to end.",
  );
}

function addDefaultNextSteps(summary) {
  const nextSteps = [
    "pnpm dev:all",
    "pnpm tauri dev",
  ];

  for (const nextStep of nextSteps) {
    if (!summary.nextSteps.includes(nextStep)) {
      summary.nextSteps.push(nextStep);
    }
  }
}

function runSetup(options = {}, rawDeps = createDefaultDeps()) {
  void options;
  const deps = rawDeps;
  const summary = createSummary();
  const repoPaths = getRepoPaths(deps.cwd, deps.path);

  deps.logger.info(`[setup:macos] Starting macOS setup in ${deps.cwd}`);

  printSection(deps.logger, "Preflight");
  if (deps.platform !== "darwin") {
    summary.blockers.push(
      "This bootstrap command is macOS-only. Run `pnpm setup:macos` from a macOS machine.",
    );
    setStatus(summary, "blocked");
    summary.nextSteps.push(
      "Use the regular manual setup docs for your current platform, or switch to macOS and re-run `pnpm setup:macos`.",
    );
    return summary;
  }

  summary.successes.push("Confirmed a macOS host environment.");

  const missingPrerequisites = collectMissingPrerequisites(deps);
  if (missingPrerequisites.length > 0) {
    summary.blockers.push(...missingPrerequisites);
    setStatus(summary, "blocked");
    summary.nextSteps.push("Install the missing prerequisites and re-run `pnpm setup:macos`.");
    return summary;
  }

  summary.successes.push("Required macOS prerequisites are available.");

  printSection(deps.logger, "Install");
  const pnpmInstallResult = runStep(deps, "pnpm", ["install"], {
    cwd: repoPaths.repoRoot,
  });

  if (!pnpmInstallResult.ok) {
    summary.blockers.push(
      `Failed to install frontend dependencies with \`${pnpmInstallResult.commandLine}\`. ${pnpmInstallResult.stderr || pnpmInstallResult.stdout}`.trim(),
    );
    setStatus(summary, "blocked");
    summary.nextSteps.push("Fix the frontend dependency install failure and re-run `pnpm setup:macos`.");
    return summary;
  }

  summary.successes.push("Installed frontend dependencies with `pnpm install`.");

  const uvSyncResult = runStep(deps, "uv", ["sync"], {
    cwd: repoPaths.serverDir,
  });

  if (!uvSyncResult.ok) {
    summary.blockers.push(
      `Failed to sync the backend environment with \`${uvSyncResult.commandLine}\`. ${uvSyncResult.stderr || uvSyncResult.stdout}`.trim(),
    );
    setStatus(summary, "blocked");
    summary.nextSteps.push("Fix the backend dependency sync failure and re-run `pnpm setup:macos`.");
    return summary;
  }

  summary.successes.push("Synced backend dependencies with `uv sync`.");

  const tauriInfoResult = runStep(deps, "pnpm", ["tauri", "info"], {
    cwd: repoPaths.repoRoot,
  });

  if (!tauriInfoResult.ok) {
    setStatus(summary, "partial");
    summary.warnings.push(
      `Tauri readiness check did not complete cleanly with \`${tauriInfoResult.commandLine}\`. ${tauriInfoResult.stderr || tauriInfoResult.stdout}`.trim(),
    );
  } else {
    summary.successes.push("Verified Tauri readiness with `pnpm tauri info`.");
  }

  printSection(deps.logger, "Configuration");
  syncEnvFile(summary, deps, repoPaths);
  if (summary.status === "blocked") {
    summary.nextSteps.push("Restore `.env.local.example` and re-run `pnpm setup:macos`.");
    return summary;
  }

  checkModelFiles(summary, deps, repoPaths);
  addDefaultNextSteps(summary);

  return summary;
}

function main() {
  const deps = createDefaultDeps();
  const summary = runSetup({}, deps);
  printSummary(deps.logger, summary);

  process.exitCode = summary.status === "blocked" ? 1 : 0;
}

if (require.main === module) {
  main();
}

module.exports = {
  REQUIRED_MODEL_FILES,
  createDefaultDeps,
  runSetup,
};
