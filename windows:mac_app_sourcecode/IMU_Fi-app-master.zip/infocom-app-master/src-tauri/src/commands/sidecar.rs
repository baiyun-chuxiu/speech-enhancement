use std::net::TcpListener;
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tauri::{Emitter, Manager};
use tauri_plugin_shell::process::{CommandChild, CommandEvent};
use tauri_plugin_shell::ShellExt;

const DEFAULT_SERVER_PORT: u16 = 8000;
const SIDECAR_EXTERNAL_BIN: &str = "binaries/audio-enhancer-server";

/// Thread-safe state holding the sidecar child process.
pub type SidecarState = Arc<Mutex<Option<CommandChild>>>;

/// Thread-safe state holding the detected server port.
pub type ServerPortState = Arc<Mutex<u16>>;

fn localhost_url(port: u16) -> String {
    format!("http://127.0.0.1:{}", port)
}

fn readiness_url(port: u16) -> String {
    format!("{}/ready", localhost_url(port))
}

fn sidecar_program_name(external_bin: &str) -> String {
    let file_name = std::path::Path::new(external_bin)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(external_bin);

    file_name
        .strip_suffix(".exe")
        .unwrap_or(file_name)
        .to_string()
}

fn pick_available_port() -> Result<u16, String> {
    let listener = TcpListener::bind(("127.0.0.1", 0))
        .map_err(|err| format!("failed to bind a temporary localhost port: {}", err))?;
    let port = listener
        .local_addr()
        .map_err(|err| format!("failed to read temporary localhost port: {}", err))?
        .port();
    drop(listener);
    Ok(port)
}

fn select_server_port(preferred_port: u16) -> Result<u16, String> {
    match TcpListener::bind(("127.0.0.1", preferred_port)) {
        Ok(listener) => {
            drop(listener);
            Ok(preferred_port)
        }
        Err(_) => pick_available_port(),
    }
}

fn store_server_port(app_handle: &tauri::AppHandle, port: u16) -> Result<(), String> {
    if let Some(state) = app_handle.try_state::<ServerPortState>() {
        *state.lock().map_err(|e| e.to_string())? = port;
        Ok(())
    } else {
        Err("Server port state not found in app".to_string())
    }
}

fn prepare_server_port(app_handle: &tauri::AppHandle) -> Result<u16, String> {
    let preferred_port = app_handle
        .try_state::<ServerPortState>()
        .map(|state| *state.lock().unwrap_or_else(|e| e.into_inner()))
        .unwrap_or(DEFAULT_SERVER_PORT);

    let selected_port = select_server_port(preferred_port)?;
    store_server_port(app_handle, selected_port)?;
    Ok(selected_port)
}

/// Spawn the Python sidecar and monitor its stdout/stderr.
///
/// The sidecar binary is expected at `src-tauri/binaries/audio-enhancer-server-{target_triple}`.
/// Tauri automatically resolves the correct binary for the current platform.
pub fn spawn_sidecar(app_handle: &tauri::AppHandle) -> Result<(), String> {
    // Prevent duplicate spawns
    if let Some(state) = app_handle.try_state::<SidecarState>() {
        let child_process = state.lock().map_err(|e| e.to_string())?;
        if child_process.is_some() {
            log::info!("[sidecar] Already running, skipping spawn");
            return Ok(());
        }
    }

    let server_port = prepare_server_port(app_handle)?;
    let sidecar_program = sidecar_program_name(SIDECAR_EXTERNAL_BIN);
    let sidecar_command = app_handle
        .shell()
        .sidecar(sidecar_program)
        .map_err(|e| format!("Failed to create sidecar command: {}", e))?
        .env("ENHANCER_PORT", server_port.to_string())
        .env("NUMBA_THREADING_LAYER", "workqueue")
        .env("NUMBA_DISABLE_COVERAGE", "1");

    let (mut rx, child) = sidecar_command
        .spawn()
        .map_err(|e| format!("Failed to spawn sidecar: {}", e))?;

    // Store the child process reference
    if let Some(state) = app_handle.try_state::<SidecarState>() {
        *state.lock().map_err(|e| e.to_string())? = Some(child);
    } else {
        return Err("Sidecar state not found in app".to_string());
    }

    // Spawn async task to forward stdout/stderr to logs and frontend events
    let handle = app_handle.clone();
    tauri::async_runtime::spawn(async move {
        while let Some(event) = rx.recv().await {
            match event {
                CommandEvent::Stdout(line_bytes) => {
                    let line = String::from_utf8_lossy(&line_bytes);
                    log::info!("[sidecar] {}", line);
                    let _ = handle.emit("sidecar-stdout", line.to_string());
                }
                CommandEvent::Stderr(line_bytes) => {
                    let line = String::from_utf8_lossy(&line_bytes);
                    log::error!("[sidecar] {}", line);
                    let _ = handle.emit("sidecar-stderr", line.to_string());
                }
                _ => {}
            }
        }
    });

    log::info!(
        "[sidecar] Python server spawned on {}, starting readiness polling...",
        localhost_url(server_port)
    );

    // Readiness check: poll /ready until the backend can accept enhancement requests (max 30s)
    let health_handle = app_handle.clone();
    tauri::async_runtime::spawn(async move {
        let url = readiness_url(server_port);
        let client = reqwest::Client::builder()
            .timeout(Duration::from_secs(2))
            .build()
            .unwrap_or_default();

        for attempt in 1..=30 {
            tokio::time::sleep(Duration::from_secs(1)).await;
            match client.get(&url).send().await {
                Ok(resp) if resp.status().is_success() => {
                    match resp.json::<serde_json::Value>().await {
                        Ok(body) if body["is_ready"].as_bool().unwrap_or(false) => {
                            log::info!("[sidecar] Readiness check passed on attempt {}", attempt);
                            let _ = health_handle.emit("sidecar-ready", true);
                            return;
                        }
                        Ok(body) => {
                            let reason = body["degraded_reason"]
                                .as_str()
                                .unwrap_or("backend-not-ready");
                            log::debug!(
                                "[sidecar] Readiness attempt {} not ready: {}",
                                attempt,
                                reason
                            );
                        }
                        Err(err) => {
                            log::debug!(
                                "[sidecar] Readiness attempt {} returned invalid JSON: {}",
                                attempt,
                                err
                            );
                        }
                    }
                }
                Ok(resp) => {
                    log::debug!(
                        "[sidecar] Readiness attempt {} returned {}",
                        attempt,
                        resp.status()
                    );
                }
                Err(e) => {
                    log::debug!("[sidecar] Readiness attempt {} failed: {}", attempt, e);
                }
            }
        }
        log::warn!("[sidecar] Readiness check timed out after 30 attempts");
        let _ = health_handle.emit("sidecar-ready", false);
    });

    Ok(())
}

/// Send shutdown command to the sidecar via stdin.
///
/// For PyInstaller one-file executables, `process.kill()` only terminates the
/// bootloader process, NOT the actual Python child. We must send a stdin command
/// so the Python process can self-terminate via `os.kill(os.getpid(), SIGINT)`.
pub fn shutdown_sidecar(app_handle: &tauri::AppHandle) -> Result<(), String> {
    if let Some(state) = app_handle.try_state::<SidecarState>() {
        let mut child = state.lock().map_err(|e| e.to_string())?;
        if let Some(process) = child.as_mut() {
            let command = "sidecar shutdown\n";
            if let Err(err) = process.write(command.as_bytes()) {
                log::error!("[sidecar] Failed to write shutdown to stdin: {}", err);
                return Err(format!("Failed to write to sidecar stdin: {}", err));
            }
            log::info!("[sidecar] Sent 'sidecar shutdown' command via stdin");
        } else {
            log::warn!("[sidecar] No active sidecar process to shutdown");
        }
    }
    Ok(())
}

#[tauri::command]
pub async fn start_server(app_handle: tauri::AppHandle) -> Result<String, String> {
    spawn_sidecar(&app_handle)?;
    Ok("Sidecar started".to_string())
}

#[tauri::command]
pub async fn stop_server(app_handle: tauri::AppHandle) -> Result<String, String> {
    shutdown_sidecar(&app_handle)?;
    Ok("Shutdown command sent".to_string())
}

#[tauri::command]
pub async fn get_server_port(app_handle: tauri::AppHandle) -> Result<u16, String> {
    if let Some(state) = app_handle.try_state::<ServerPortState>() {
        Ok(*state.lock().map_err(|e| e.to_string())?)
    } else {
        Ok(DEFAULT_SERVER_PORT)
    }
}

#[cfg(test)]
mod tests {
    use super::{
        localhost_url, pick_available_port, readiness_url, select_server_port, sidecar_program_name,
    };
    use std::net::TcpListener;

    #[test]
    fn localhost_url_uses_loopback_host() {
        assert_eq!(localhost_url(4312), "http://127.0.0.1:4312");
    }

    #[test]
    fn readiness_url_appends_ready_path() {
        assert_eq!(readiness_url(4312), "http://127.0.0.1:4312/ready");
    }

    #[test]
    fn pick_available_port_returns_bindable_loopback_port() {
        let port = pick_available_port().expect("expected to find an available localhost port");
        let listener = TcpListener::bind(("127.0.0.1", port))
            .expect("returned port should still be bindable immediately after selection");

        drop(listener);
    }

    #[test]
    fn select_server_port_prefers_requested_port_when_available() {
        let preferred = pick_available_port().expect("expected a bindable preferred port");
        assert_eq!(select_server_port(preferred).unwrap(), preferred);
    }

    #[test]
    fn select_server_port_falls_back_when_requested_port_is_busy() {
        let occupied = TcpListener::bind(("127.0.0.1", 0)).expect("expected to occupy a port");
        let occupied_port = occupied.local_addr().unwrap().port();

        let selected =
            select_server_port(occupied_port).expect("expected to choose a fallback port");

        assert_ne!(selected, occupied_port);
        let rebound = TcpListener::bind(("127.0.0.1", selected))
            .expect("fallback port should be immediately bindable after selection");

        drop(rebound);
        drop(occupied);
    }

    #[test]
    fn sidecar_program_name_uses_binary_basename() {
        assert_eq!(
            sidecar_program_name("binaries/audio-enhancer-server"),
            "audio-enhancer-server"
        );
    }

    #[test]
    fn sidecar_program_name_strips_windows_extension() {
        assert_eq!(
            sidecar_program_name("binaries/audio-enhancer-server.exe"),
            "audio-enhancer-server"
        );
    }
}
