pub mod model;
#[cfg(desktop)]
pub mod sidecar;

pub use model::*;
