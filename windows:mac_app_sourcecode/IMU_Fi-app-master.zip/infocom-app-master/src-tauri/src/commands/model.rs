/**
 * 本地模型处理命令模块
 *
 * ============ 技术栈说明 ============
 *
 * 本模块预留了与本地 AI 模型对接的接口，支持以下技术栈：
 *
 * ## 跨平台模型框架 (通过 Rust FFI 调用)
 *
 * 1. whisper.cpp - 语音识别
 *    - Cargo: whisper-rs 或直接 FFI 绑定
 *    - 支持多种模型大小 (tiny, base, small, medium, large)
 *    - 支持 GPU 加速 (CUDA, Metal, OpenCL)
 *
 * 2. llama.cpp - 文本生成
 *    - Cargo: llama-cpp-rs 或 llama-cpp-2
 *    - 支持量化模型 (GGML, GGUF)
 *    - 内存优化，适合移动端
 *
 * 3. Coqui TTS / bark.cpp - 语音合成
 *    - 高质量语音生成
 *    - 支持多语言和声音克隆
 *
 * ## iOS 平台特定
 *
 * 1. Core ML
 *    - 通过 objc crate 调用 Objective-C API
 *    - 最佳 Apple Silicon 优化
 *
 * 2. MLX (Apple Machine Learning Framework)
 *    - 专为 Apple Silicon 设计
 *    - 通过 Swift 桥接调用
 *
 * ## Android 平台特定
 *
 * 1. TensorFlow Lite
 *    - 通过 JNI 调用 Java API
 *    - 广泛的模型支持
 *
 * 2. ONNX Runtime Mobile
 *    - 跨框架模型支持
 *    - 优化的推理性能
 *
 * ============ 实现建议 ============
 *
 * 1. 使用 tokio 进行异步处理，避免阻塞 UI
 * 2. 实现进度回调，通过 Tauri 事件系统通知前端
 * 3. 使用内存映射文件处理大型音频数据
 * 4. 实现模型缓存和预加载机制
 * 5. 添加错误恢复和重试逻辑
 */
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::Duration;
use tauri::{Manager, State};

#[cfg(desktop)]
use super::sidecar::ServerPortState;

// ============ 数据结构 ============

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessOptions {
    pub model: Option<String>,
    pub language: Option<String>,
    pub quality: Option<String>, // "fast", "balanced", "high"
    pub output_format: Option<String>,
    pub sample_rate: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessStep {
    pub name: String,
    pub status: String, // "pending", "processing", "completed", "failed"
    pub progress: u32,
    pub message: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessMetadata {
    pub processing_time: u64,
    pub model_used: String,
    pub input_text_length: usize,
    pub input_audio_duration: f64,
    pub output_audio_duration: f64,
    pub steps: Vec<ProcessStep>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessedAudio {
    pub id: String,
    pub path: String,
    pub format: String,
    pub duration: f64,
    pub sample_rate: u32,
    pub size: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessResponse {
    pub success: bool,
    pub output_audio: Option<ProcessedAudio>,
    pub metadata: Option<ProcessMetadata>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RuntimeCompletionCapabilities {
    pub auto_save: bool,
    pub notifications: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RuntimeCapabilities {
    pub supported_devices: Vec<String>,
    pub supported_qualities: Vec<String>,
    pub supported_output_formats: Vec<String>,
    pub completion_capabilities: RuntimeCompletionCapabilities,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelStatus {
    pub is_available: bool,
    pub model_name: String,
    pub model_version: String,
    pub capabilities: Vec<String>,
    pub memory_usage: Option<u64>,
    pub gpu_available: Option<bool>,
    pub runtime_capabilities: Option<RuntimeCapabilities>,
}

// ============ 状态管理 ============

pub struct AppState {
    pub tasks: Mutex<HashMap<String, ProcessStep>>,
}

impl Default for AppState {
    fn default() -> Self {
        Self {
            tasks: Mutex::new(HashMap::new()),
        }
    }
}

// ============ Tauri 命令 ============

/// Helper to get the Python server base URL from managed state.
#[cfg(desktop)]
fn get_server_url(app_handle: &tauri::AppHandle) -> String {
    let port = app_handle
        .try_state::<ServerPortState>()
        .map(|s| *s.lock().unwrap_or_else(|e| e.into_inner()))
        .unwrap_or(8000);
    format!("http://localhost:{}", port)
}

#[cfg(not(desktop))]
fn get_server_url(_app_handle: &tauri::AppHandle) -> String {
    "http://localhost:8000".to_string()
}

#[tauri::command]
pub async fn process_audio_text(
    _text_path: Option<String>,
    _audio_path: Option<String>,
    text_content: Option<String>,
    _options: Option<ProcessOptions>,
    state: State<'_, AppState>,
    app_handle: tauri::AppHandle,
) -> Result<ProcessResponse, String> {
    let task_id = uuid::Uuid::new_v4().to_string();

    // 记录任务状态
    {
        let mut tasks = state.tasks.lock().map_err(|e| e.to_string())?;
        tasks.insert(
            task_id.clone(),
            ProcessStep {
                name: "初始化".to_string(),
                status: "processing".to_string(),
                progress: 0,
                message: None,
            },
        );
    }

    // Query the Python server readiness endpoint to verify enhancement is usable
    let base_url = get_server_url(&app_handle);
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(5))
        .build()
        .map_err(|e| format!("Failed to create HTTP client: {}", e))?;

    let readiness_url = format!("{}/ready", base_url);
    match client.get(&readiness_url).send().await {
        Ok(resp) if resp.status().is_success() => {
            let body: serde_json::Value = resp
                .json()
                .await
                .map_err(|e| format!("Failed to parse readiness response: {}", e))?;

            if !body["is_ready"].as_bool().unwrap_or(false) {
                let reason = body["degraded_reason"]
                    .as_str()
                    .unwrap_or("backend-not-ready");
                return Err(format!(
                    "Python server is running but not ready: {}",
                    reason
                ));
            }

            log::info!("[model] Python server is ready, delegating processing");
        }
        Ok(resp) => {
            return Err(format!("Python server returned status {}", resp.status()));
        }
        Err(e) => {
            return Err(format!("Python server is not reachable: {}", e));
        }
    }

    // Build response pointing to the Python API for actual processing.
    // The frontend uses the enhancer-api.ts client to call the Python server
    // directly for file uploads and enhancement. This command serves as a
    // readiness-gate and returns server connectivity info.
    let metadata = ProcessMetadata {
        processing_time: 0,
        model_used: "enhancer-pipeline".to_string(),
        input_text_length: text_content.map(|t| t.len()).unwrap_or(0),
        input_audio_duration: 0.0,
        output_audio_duration: 0.0,
        steps: vec![ProcessStep {
            name: "Server Readiness Check".to_string(),
            status: "completed".to_string(),
            progress: 100,
            message: Some("Python server is ready".to_string()),
        }],
    };

    // 清理任务状态
    {
        let mut tasks = state.tasks.lock().map_err(|e| e.to_string())?;
        tasks.remove(&task_id);
    }

    Ok(ProcessResponse {
        success: true,
        output_audio: None,
        metadata: Some(metadata),
        error: None,
    })
}

/// 获取处理进度
#[tauri::command]
pub async fn get_process_progress(
    task_id: String,
    state: State<'_, AppState>,
) -> Result<Vec<ProcessStep>, String> {
    let tasks = state.tasks.lock().map_err(|e| e.to_string())?;

    if let Some(step) = tasks.get(&task_id) {
        Ok(vec![step.clone()])
    } else {
        Ok(vec![])
    }
}

/// 取消处理任务
#[tauri::command]
pub async fn cancel_process(task_id: String, state: State<'_, AppState>) -> Result<(), String> {
    let mut tasks = state.tasks.lock().map_err(|e| e.to_string())?;
    tasks.remove(&task_id);

    // TODO: 实现实际的任务取消逻辑
    // 需要使用 tokio::sync::broadcast 或 CancellationToken

    Ok(())
}

/// 检查模型状态
///
/// # 返回
/// 模型可用性和能力信息
///
/// # 技术实现建议
/// 1. 检查模型文件是否存在
/// 2. 验证模型完整性
/// 3. 检测可用的硬件加速
#[tauri::command]
pub async fn check_model_status(app_handle: tauri::AppHandle) -> Result<ModelStatus, String> {
    let base_url = get_server_url(&app_handle);
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(5))
        .build()
        .map_err(|e| format!("Failed to create HTTP client: {}", e))?;

    let info_url = format!("{}/api/v1/system/info", base_url);
    match client.get(&info_url).send().await {
        Ok(resp) if resp.status().is_success() => {
            let body: serde_json::Value = resp
                .json()
                .await
                .map_err(|e| format!("Failed to parse system info: {}", e))?;

            let cuda = body["cuda_available"].as_bool().unwrap_or(false);
            let mps = body["mps_available"].as_bool().unwrap_or(false);
            let is_ready = body["is_ready"].as_bool().unwrap_or(false);
            let gen_loaded = body["generator_loaded"].as_bool().unwrap_or(false);
            let dn_loaded = body["denoise_loaded"].as_bool().unwrap_or(false);
            let supported_devices = body["supported_devices"]
                .as_array()
                .map(|items| {
                    items
                        .iter()
                        .filter_map(|item| item.as_str().map(|value| value.to_string()))
                        .collect::<Vec<_>>()
                })
                .unwrap_or_else(|| vec!["auto".to_string()]);
            let supported_qualities = body["supported_qualities"]
                .as_array()
                .map(|items| {
                    items
                        .iter()
                        .filter_map(|item| item.as_str().map(|value| value.to_string()))
                        .collect::<Vec<_>>()
                })
                .unwrap_or_else(|| vec!["balanced".to_string()]);
            let supported_output_formats = body["supported_output_formats"]
                .as_array()
                .map(|items| {
                    items
                        .iter()
                        .filter_map(|item| item.as_str().map(|value| value.to_string()))
                        .collect::<Vec<_>>()
                })
                .unwrap_or_else(|| vec!["wav".to_string()]);

            Ok(ModelStatus {
                is_available: is_ready && gen_loaded && dn_loaded,
                model_name: "enhancer-pipeline".to_string(),
                model_version: body["version"].as_str().unwrap_or("1.0.0").to_string(),
                capabilities: vec![
                    "audio-enhance".to_string(),
                    "imu-process".to_string(),
                    "multimodal-denoise".to_string(),
                ],
                memory_usage: None,
                gpu_available: Some(cuda || mps),
                runtime_capabilities: Some(RuntimeCapabilities {
                    supported_devices,
                    supported_qualities,
                    supported_output_formats,
                    completion_capabilities: RuntimeCompletionCapabilities {
                        auto_save: true,
                        notifications: true,
                    },
                }),
            })
        }
        Ok(resp) => Err(format!("Python server returned status {}", resp.status())),
        Err(_) => Ok(ModelStatus {
            is_available: false,
            model_name: "enhancer-pipeline".to_string(),
            model_version: "unknown".to_string(),
            capabilities: vec![],
            memory_usage: None,
            gpu_available: None,
            runtime_capabilities: None,
        }),
    }
}

/// 读取文本文件
#[tauri::command]
pub async fn read_text_file(path: String) -> Result<String, String> {
    std::fs::read_to_string(&path).map_err(|e| format!("读取文件失败: {}", e))
}

/// 读取音频文件
#[tauri::command]
pub async fn read_audio_file(path: String) -> Result<Vec<u8>, String> {
    std::fs::read(&path).map_err(|e| format!("读取音频失败: {}", e))
}

/// 保存音频文件
#[tauri::command]
pub async fn save_audio_file(data: Vec<u8>, format: String) -> Result<String, String> {
    let temp_dir = std::env::temp_dir();
    let file_name = format!("output_{}.{}", uuid::Uuid::new_v4(), format);
    let file_path = temp_dir.join(file_name);

    std::fs::write(&file_path, data).map_err(|e| format!("保存音频失败: {}", e))?;

    Ok(file_path.to_string_lossy().to_string())
}
