mod commands;

use std::sync::{Arc, Mutex};

use tauri::Manager;

use commands::{
    cancel_process, check_model_status, get_process_progress, process_audio_text, read_audio_file,
    read_text_file, save_audio_file, AppState,
};

#[cfg(desktop)]
use commands::sidecar;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let mut builder = tauri::Builder::default();

    // Desktop: initialize shell plugin for sidecar support
    #[cfg(desktop)]
    {
        builder = builder.plugin(tauri_plugin_shell::init());
    }

    builder
        .manage(AppState::default())
        .setup(|app| {
            if cfg!(debug_assertions) {
                app.handle().plugin(
                    tauri_plugin_log::Builder::default()
                        .level(log::LevelFilter::Info)
                        .build(),
                )?;
            }

            // Desktop: manage sidecar state and spawn Python server
            #[cfg(desktop)]
            {
                app.manage(Arc::new(Mutex::new(
                    None::<tauri_plugin_shell::process::CommandChild>,
                )) as sidecar::SidecarState);
                app.manage(Arc::new(Mutex::new(8000u16)) as sidecar::ServerPortState);
                let handle = app.handle().clone();
                log::info!("Starting Python sidecar...");
                if let Err(e) = sidecar::spawn_sidecar(&handle) {
                    log::error!("Failed to spawn sidecar: {}", e);
                }
            }

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            process_audio_text,
            get_process_progress,
            cancel_process,
            check_model_status,
            read_text_file,
            read_audio_file,
            save_audio_file,
            #[cfg(desktop)]
            sidecar::start_server,
            #[cfg(desktop)]
            sidecar::stop_server,
            #[cfg(desktop)]
            sidecar::get_server_port,
        ])
        .build(tauri::generate_context!())
        .expect("error while building tauri application")
        .run(|app_handle, event| {
            // Desktop: shutdown sidecar via stdin when app exits
            #[cfg(desktop)]
            if let tauri::RunEvent::ExitRequested { .. } = event {
                if let Err(e) = sidecar::shutdown_sidecar(app_handle) {
                    log::error!("Failed to shutdown sidecar: {}", e);
                }
            }

            #[cfg(not(desktop))]
            {
                let _ = (&app_handle, &event);
            }
        });
}
