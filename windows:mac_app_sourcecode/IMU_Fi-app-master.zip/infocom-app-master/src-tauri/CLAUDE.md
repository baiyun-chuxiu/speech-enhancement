# Desktop Module

[根目录](../CLAUDE.md) > **src-tauri/**

## Module Overview

Tauri 2.9 desktop application backend written in Rust. Provides native desktop capabilities and local model processing interface for the InfoCom application.

## Module Structure

```
src-tauri/
├── src/
│   ├── main.rs              # Application entry point
│   ├── lib.rs               # Library code with setup
│   └── commands/
│       ├── mod.rs           # Command module exports
│       └── model.rs         # Model processing commands
├── capabilities/
│   └── default.json         # Tauri capability permissions
├── icons/                   # Application icons
├── target/                  # Rust build output (generated)
├── tauri.conf.json          # Tauri configuration
├── Cargo.toml               # Rust dependencies
└── build.rs                 # Build script
```

## Architecture

```mermaid
graph TB
    Frontend[Frontend<br/>Next.js React]
    Tauri[Tauri Bridge]
    Commands[Commands Layer]
    AppState[Application State]

    Frontend -->|invoke| Tauri
    Tauri --> Commands
    Commands --> AppState

    Commands --> Cmd1[process_audio_text]
    Commands --> Cmd2[get_process_progress]
    Commands --> Cmd3[cancel_process]
    Commands --> Cmd4[check_model_status]
    Commands --> Cmd5[read_text_file]
    Commands --> Cmd6[read_audio_file]
    Commands --> Cmd7[save_audio_file]

    style Commands fill:#fff3e0
    style AppState fill:#e8f5e9
```

## Key Files

### `src/main.rs`

Application entry point that delegates to the library.

```rust
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
  app_lib::run();
}
```

**Note**: The `windows_subsystem = "windows"` attribute prevents a console window from appearing in release builds.

### `src/lib.rs`

Main library setup with Tauri builder pattern.

**Responsibilities**:
- Initialize Tauri app with commands
- Set up logging plugin (debug only)
- Manage application state
- Register all Tauri commands

**Registered Commands**:
- `process_audio_text`
- `get_process_progress`
- `cancel_process`
- `check_model_status`
- `read_text_file`
- `read_audio_file`
- `save_audio_file`

### `src/commands/model.rs`

Model processing command implementations with local AI model integration points.

## Tauri Commands

### process_audio_text

Main processing command that orchestrates audio and text processing.

**Parameters**:
```rust
pub async fn process_audio_text(
    text_path: Option<String>,
    audio_path: Option<String>,
    text_content: Option<String>,
    options: Option<ProcessOptions>,
    state: State<'_, AppState>,
) -> Result<ProcessResponse, String>
```

**Process Options**:
```rust
pub struct ProcessOptions {
    pub model: Option<String>,        // Model name
    pub language: Option<String>,     // Processing language
    pub quality: Option<String>,      // "fast", "balanced", "high"
    pub output_format: Option<String>, // Output audio format
    pub sample_rate: Option<u32>,     // Output sample rate
}
```

**Returns**:
```rust
pub struct ProcessResponse {
    pub success: bool,
    pub output_audio: Option<ProcessedAudio>,
    pub metadata: Option<ProcessMetadata>,
    pub error: Option<String>,
}
```

**Current Implementation**: Returns simulated data with 2-second delay.

**TODO Integration Points** (for local AI models):
1. Read text file from `text_path` or use `text_content`
2. Read audio file from `audio_path`
3. Call local model (whisper.cpp, llama.cpp, etc.)
4. Save output audio to temp directory
5. Return processed audio metadata

### get_process_progress

Retrieve progress for a running task.

```rust
pub async fn get_process_progress(
    task_id: String,
    state: State<'_, AppState>,
) -> Result<Vec<ProcessStep>, String>
```

### cancel_process

Cancel a running processing task.

```rust
pub async fn cancel_process(
    task_id: String,
    state: State<'_, AppState>,
) -> Result<(), String>
```

### check_model_status

Check if local models are available and their capabilities.

```rust
pub async fn check_model_status() -> Result<ModelStatus, String>
```

**Returns**:
```rust
pub struct ModelStatus {
    pub is_available: bool,
    pub model_name: String,
    pub model_version: String,
    pub capabilities: Vec<String>,
    pub memory_usage: Option<u64>,
    pub gpu_available: Option<bool>,
}
```

### File I/O Commands

**read_text_file**: Read file contents as string
```rust
pub async fn read_text_file(path: String) -> Result<String, String>
```

**read_audio_file**: Read file as byte vector
```rust
pub async fn read_audio_file(path: String) -> Result<Vec<u8>, String>
```

**save_audio_file**: Save audio data to disk
```rust
pub async fn save_audio_file(
    data: Vec<u8>,
    format: String,
) -> Result<String, String>  // Returns file path
```

## Application State

```rust
pub struct AppState {
    pub tasks: Mutex<HashMap<String, ProcessStep>>,
}
```

Tracks active processing tasks by UUID task ID.

## Configuration

### `tauri.conf.json`

Main Tauri configuration file.

**Build Settings**:
```json
{
  "build": {
    "frontendDist": "../out",           // Next.js static export
    "devUrl": "http://localhost:3000",  // Next.js dev server
    "beforeDevCommand": "pnpm dev",
    "beforeBuildCommand": "pnpm build"
  }
}
```

**App Window**:
```json
{
  "app": {
    "windows": [{
      "title": "react-quick-starter",
      "width": 800,
      "height": 600,
      "resizable": true,
      "fullscreen": false
    }]
  }
}
```

**Security**:
```json
{
  "app": {
    "security": {
      "csp": null  // No Content Security Policy (desktop app)
    }
  }
}
```

### `capabilities/default.json`

Defines what frontend code can invoke.

### `Cargo.toml`

Rust dependencies:

```toml
[dependencies]
serde_json = "1.0"
serde = { version = "1.0", features = ["derive"] }
log = "0.4"
tauri = { version = "2.9.0", features = [] }
tauri-plugin-log = "2"
tokio = { version = "1", features = ["full"] }
uuid = { version = "1", features = ["v4"] }
```

## Local AI Model Integration (Reserved)

The codebase includes comments and placeholders for integrating local AI models:

### Recommended Tech Stack

**Cross-Platform (via Rust FFI)**:
- `whisper.cpp` - Speech recognition
- `llama.cpp` - Text generation
- `bark.cpp` - High-quality TTS
- `Coqui TTS` - Text-to-speech

**iOS Specific**:
- Core ML - Apple's ML framework
- MLX - Apple Silicon optimization

**Android Specific**:
- TensorFlow Lite - Google's mobile ML
- ONNX Runtime Mobile - Cross-framework models

### Reserved Dependencies (Commented Out)

```toml
# whisper-rs = "0.10"           # Whisper 语音识别
# llama-cpp-2 = "0.1"           # LLaMA 文本生成
# hound = "3.5"                 # WAV 音频处理
# symphonia = "0.5"             # 多格式音频解码
# rubato = "0.14"               # 音频重采样
```

## Development Workflow

### Desktop Development

```bash
pnpm tauri dev    # Start with hot reload
```

This command:
1. Runs `pnpm dev` to start Next.js
2. Launches the Tauri desktop window
3. Enables hot reload for both frontend and Rust

### Building for Production

```bash
pnpm tauri build  # Build desktop app
```

**Output Locations**:
- Windows: `src-tauri/target/release/bundle/msi/`
- macOS: `src-tauri/target/release/bundle/dmg/`
- Linux: `src-tauri/target/release/bundle/appimage/`

### Tauri CLI Commands

```bash
pnpm tauri info        # Show environment info
pnpm tauri icon        # Generate icons
pnpm tauri --help      # Show all commands
```

## Testing

**Current State**: No Rust unit tests implemented.

**Recommended Testing Strategy**:
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_process_audio_text() {
        let result = process_audio_text(
            Some("test.txt".to_string()),
            Some("test.wav".to_string()),
            Some("Test content".to_string()),
            None,
            State::default(),
        ).await;

        assert!(result.is_ok());
    }
}
```

## Known Issues

1. **No actual model processing** - Commands return mock data
2. **No progress updates** - Task tracking exists but not used
3. **No cancellation logic** - Tasks are removed from state but not actually cancelled
4. **No error recovery** - Failures don't trigger retries
5. **No file validation** - Paths aren't validated before reading

## Future Enhancements

1. **Implement actual model calls** - Integrate whisper.cpp/llama.cpp
2. **Progress events** - Use `tauri::Window::emit` for real-time updates
3. **Cancellation tokens** - Use `tokio::sync::CancellationToken`
4. **Model caching** - Cache loaded models in memory
5. **GPU detection** - Detect and use CUDA/Metal/OpenCL
6. **Async task queue** - Queue multiple processing requests
7. **File validation** - Validate file existence and format before processing

## Troubleshooting

### Build Fails

```bash
# Check Rust toolchain
rustc --version
cargo --version

# Update Rust
rustup update

# Clean build cache
cd src-tauri
cargo clean
```

### Tauri Dev Won't Start

```bash
# Check Next.js is running
curl http://localhost:3000

# Verify port availability
netstat -an | grep 3000

# Check Tauri environment
pnpm tauri info
```

### Missing System Dependencies

**Windows**: Install Microsoft Visual Studio C++ Build Tools

**macOS**: Install Xcode Command Line Tools
```bash
xcode-select --install
```

**Linux** (Ubuntu/Debian):
```bash
sudo apt update
sudo apt install libwebkit2gtk-4.1-dev \
  build-essential \
  curl \
  wget \
  file \
  libxdo-dev \
  libssl-dev \
  libayatana-appindicator3-dev \
  librsvg2-dev
```

## Resources

- [Tauri Documentation](https://tauri.app/)
- [Tauri Commands](https://tauri.app/v1/api/js/)
- [Rust Async Book](https://rust-lang.github.io/async-book/)
- [Serde Documentation](https://serde.rs/)
- [Tokio Documentation](https://tokio.rs/)
