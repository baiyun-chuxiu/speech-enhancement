import json
import subprocess
import time
from pathlib import Path
import requests

repo = Path(r'd:/Project/infocom-app')
exe = repo / 'src-tauri/binaries/audio-enhancer-server-x86_64-pc-windows-msvc.exe'
env = dict(**__import__('os').environ)
env['ENHANCER_HOST']='127.0.0.1'
env['ENHANCER_PORT']='8891'
proc = subprocess.Popen([str(exe)], cwd=repo, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

try:
    base = 'http://127.0.0.1:8891'
    for _ in range(120):
        try:
            r = requests.get(base + '/ready', timeout=2)
            if r.ok:
                break
        except Exception:
            pass
        time.sleep(0.5)

    files = {
        'audio_file': ('segment_1_1.wav', open(repo / 'data/segment_1_1.wav', 'rb'), 'audio/wav'),
        'accel_file': ('sample-accel.txt', open(repo / 'e2e/fixtures/sample-accel.txt', 'rb'), 'text/plain'),
        'gyro_file': ('sample-gyro.txt', open(repo / 'e2e/fixtures/sample-gyro.txt', 'rb'), 'text/plain'),
    }
    resp = requests.post(base + '/api/v1/enhance', files=files, timeout=30)
    print('enhance_status', resp.status_code)
    print('enhance_body', resp.text)
    if resp.ok:
        task_id = resp.json()['task_id']
        for _ in range(120):
            s = requests.get(base + f'/api/v1/tasks/{task_id}', timeout=5)
            if s.ok:
                body = s.json()
                print('task', body.get('status'), body.get('message'))
                if body.get('status') in ('completed','failed','cancelled'):
                    print(json.dumps(body, ensure_ascii=False))
                    break
            time.sleep(0.5)

finally:
    if proc.stdin:
        try:
            proc.stdin.write('sidecar shutdown\\n')
            proc.stdin.flush()
        except Exception:
            pass
    try:
        out = proc.communicate(timeout=10)[0]
    except Exception:
        proc.kill()
        out = proc.communicate(timeout=5)[0]
    print('--- sidecar log tail ---')
    print('\n'.join(out.splitlines()[-120:]))
