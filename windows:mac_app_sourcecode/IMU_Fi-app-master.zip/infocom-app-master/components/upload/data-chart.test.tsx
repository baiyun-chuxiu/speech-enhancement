import { render, screen, fireEvent } from '@testing-library/react';
import { DataChart } from './data-chart';
import type { TextFileInfo } from '@/lib/types';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

// Mock canvas context
const mockGetContext = jest.fn(() => ({
  clearRect: jest.fn(),
  fillRect: jest.fn(),
  scale: jest.fn(),
  beginPath: jest.fn(),
  moveTo: jest.fn(),
  lineTo: jest.fn(),
  stroke: jest.fn(),
  createLinearGradient: jest.fn(() => ({
    addColorStop: jest.fn(),
  })),
  fillStyle: '',
  strokeStyle: '',
  lineWidth: 1,
  setLineDash: jest.fn(),
  fillText: jest.fn(),
  font: '',
  textAlign: '',
}));

HTMLCanvasElement.prototype.getContext = mockGetContext as unknown as typeof HTMLCanvasElement.prototype.getContext;
HTMLCanvasElement.prototype.getBoundingClientRect = jest.fn(() => ({
  width: 400,
  height: 160,
  top: 0,
  left: 0,
  bottom: 160,
  right: 400,
  x: 0,
  y: 0,
  toJSON: () => {},
}));

// Mock data-parser module
jest.mock('@/lib/utils/data-parser', () => ({
  getColumnsForSensorType: jest.fn((sensorType: 'accelerometer' | 'gyroscope') =>
    sensorType === 'gyroscope'
      ? ['dataParser.timestamp', 'dataParser.gyroX', 'dataParser.gyroY', 'dataParser.gyroZ']
      : ['dataParser.timestamp', 'dataParser.accelX', 'dataParser.accelY', 'dataParser.accelZ']
  ),
  parseDataFile: jest.fn((content: string, customColumns?: string[]) => {
    if (!content || content.trim() === '') return null;
    const columns = customColumns ?? ['dataParser.timestamp', 'dataParser.accelX', 'dataParser.accelY', 'dataParser.accelZ'];
    return {
      columns,
      rows: [
        { index: 0, timestamp: '00:00:00.000', values: [0.1, 0.2, 0.3] },
        { index: 1, timestamp: '00:00:00.100', values: [0.2, 0.3, 0.4] },
        { index: 2, timestamp: '00:00:00.200', values: [0.3, 0.4, 0.5] },
      ],
      stats: {
        totalRows: 3,
        timeRange: { start: '00:00:00.000', end: '00:00:00.200', durationMs: 200 },
        valueRanges: [
          { column: columns[1], min: 0.1, max: 0.3, avg: 0.2, stdDev: 0.1 },
          { column: columns[2], min: 0.2, max: 0.4, avg: 0.3, stdDev: 0.1 },
          { column: columns[3], min: 0.3, max: 0.5, avg: 0.4, stdDev: 0.1 },
        ],
      },
      errors: [],
    };
  }),
  getChartData: jest.fn((parsedData) => ({
    timestamps: [0, 100, 200],
    series: [
      { name: parsedData.columns[1], data: [0.1, 0.2, 0.3] },
      { name: parsedData.columns[2], data: [0.2, 0.3, 0.4] },
      { name: parsedData.columns[3], data: [0.3, 0.4, 0.5] },
    ],
  })),
  formatTimestamp: jest.fn((ts: number) => {
    const ms = ts % 1000;
    const s = Math.floor(ts / 1000) % 60;
    const m = Math.floor(ts / 60000);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')}`;
  }),
}));

const mockTextFile: TextFileInfo = {
  id: 'test-file-1',
  name: 'sensor_data.txt',
  size: 1024,
  type: 'text/plain',
  lastModified: Date.now(),
  uploadedAt: new Date(),
  status: 'success',
  progress: 100,
  content: `00:00:00.000,0.1,0.2,0.3
00:00:00.100,0.2,0.3,0.4
00:00:00.200,0.3,0.4,0.5`,
  lineCount: 3,
  wordCount: 9,
};

describe('DataChart', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Empty State', () => {
    it('renders empty state when no textFile provided', () => {
      render(<DataChart textFile={null} />);
      expect(screen.getByText('数据趋势图')).toBeInTheDocument();
      expect(screen.getByText('上传数据后显示趋势图')).toBeInTheDocument();
    });

    it('applies custom className in empty state', () => {
      const { container } = render(
        <DataChart textFile={null} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });
  });

  describe('With Data', () => {
    it('renders title with data', () => {
      render(<DataChart textFile={mockTextFile} />);
      expect(screen.getByText('数据图表')).toBeInTheDocument();
    });

    it('renders legend labels', () => {
      render(<DataChart textFile={mockTextFile} />);
      expect(screen.getByText('X轴 (m/s²)')).toBeInTheDocument();
      expect(screen.getByText('Y轴 (m/s²)')).toBeInTheDocument();
      expect(screen.getByText('Z轴 (m/s²)')).toBeInTheDocument();
    });

    it('renders zoom controls', () => {
      render(<DataChart textFile={mockTextFile} />);
      const buttons = screen.getAllByRole('button');
      expect(buttons.length).toBeGreaterThanOrEqual(3);
    });

    it('renders the chart in a bounded responsive surface', () => {
      render(<DataChart textFile={mockTextFile} />);

      expect(screen.getByTestId('data-chart-surface')).toHaveClass('overflow-hidden', 'min-h-[160px]', 'min-w-0');
    });

    it('applies custom className', () => {
      const { container } = render(
        <DataChart textFile={mockTextFile} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });

    it('renders english chart labels when locale is en', () => {
      renderWithI18n(<DataChart textFile={mockTextFile} />, { locale: 'en' });

      expect(screen.getByText('Data Chart')).toBeInTheDocument();
      expect(screen.getByText('X (m/s²)')).toBeInTheDocument();
      expect(screen.getByText('Y (m/s²)')).toBeInTheDocument();
    });
  });

  describe('Zoom Controls', () => {
    it('zoom in increases zoom level', () => {
      render(<DataChart textFile={mockTextFile} />);
      const buttons = screen.getAllByRole('button');
      const zoomInButton = buttons[0];
      
      fireEvent.click(zoomInButton);
      // Zoom should increase (no direct way to check state, but button click should work)
      expect(zoomInButton).toBeEnabled();
    });

    it('zoom out decreases zoom level', () => {
      render(<DataChart textFile={mockTextFile} />);
      const buttons = screen.getAllByRole('button');
      const zoomOutButton = buttons[1];
      
      // Initially at zoom 1, zoom out should be disabled
      expect(zoomOutButton).toBeDisabled();
    });

    it('reset button resets zoom', () => {
      render(<DataChart textFile={mockTextFile} />);
      const buttons = screen.getAllByRole('button');
      const resetButton = buttons[2];
      
      fireEvent.click(resetButton);
      expect(resetButton).toBeEnabled();
    });

    it('shows slider when zoomed in', () => {
      render(<DataChart textFile={mockTextFile} />);
      const buttons = screen.getAllByRole('button');
      const zoomInButton = buttons[0];
      
      // Zoom in to show the slider
      fireEvent.click(zoomInButton);
      
      // After zooming, the slider might appear
      // The slider appears when zoom > 1
      expect(zoomInButton).toBeEnabled();
    });
  });

  describe('Mouse Interactions', () => {
    it('renders canvas element', () => {
      const { container } = render(<DataChart textFile={mockTextFile} />);
      const canvas = container.querySelector('canvas');
      expect(canvas).toBeInTheDocument();
    });

    it('handles mouse move on canvas', () => {
      const { container } = render(<DataChart textFile={mockTextFile} />);
      const canvas = container.querySelector('canvas');
      
      if (canvas) {
        fireEvent.mouseMove(canvas, { clientX: 100, clientY: 50 });
        // Tooltip might appear
      }
    });

    it('handles mouse leave on canvas', () => {
      const { container } = render(<DataChart textFile={mockTextFile} />);
      const canvas = container.querySelector('canvas');
      
      if (canvas) {
        fireEvent.mouseLeave(canvas);
        // Tooltip should disappear
      }
    });
  });

  describe('Sensor Type', () => {
    it('accepts accelerometer sensor type', () => {
      render(<DataChart textFile={mockTextFile} sensorType="accelerometer" />);
      expect(screen.getByText('数据图表')).toBeInTheDocument();
    });

    it('accepts gyroscope sensor type', () => {
      render(<DataChart textFile={mockTextFile} sensorType="gyroscope" />);
      expect(screen.getByText('数据图表')).toBeInTheDocument();
    });

    it('renders gyroscope-specific localized legend labels', () => {
      render(<DataChart textFile={mockTextFile} sensorType="gyroscope" />);

      expect(screen.getByText('X轴 (rad/s)')).toBeInTheDocument();
      expect(screen.getByText('Y轴 (rad/s)')).toBeInTheDocument();
      expect(screen.getByText('Z轴 (rad/s)')).toBeInTheDocument();
    });
  });

  describe('Edge Cases', () => {
    it('handles empty content', () => {
      const emptyFile: TextFileInfo = {
        ...mockTextFile,
        content: '',
      };
      
      render(<DataChart textFile={emptyFile} />);
      expect(screen.getByText('数据趋势图')).toBeInTheDocument();
    });

    it('handles file with no content property', () => {
      const noContentFile: TextFileInfo = {
        ...mockTextFile,
        content: undefined,
      };
      
      render(<DataChart textFile={noContentFile} />);
      expect(screen.getByText('数据趋势图')).toBeInTheDocument();
    });
  });
});
