import { render, screen, waitFor } from '@testing-library/react';
import { AudioPlayer } from './audio-player';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

const loadMock = jest.fn();
const analyzeAudioMock = jest.fn();

// Mock the useAudioPlayer hook completely
jest.mock('@/hooks/useAudioPlayer', () => ({
  useAudioPlayer: () => ({
    state: {
      isPlaying: false,
      isPaused: true,
      currentTime: 0,
      duration: 10,
      volume: 1,
      isMuted: false,
      playbackRate: 1,
      isLoading: false,
    },
    analysis: null,
    audioRef: { current: null },
    canvasRef: { current: null },
    load: loadMock,
    pause: jest.fn(),
    toggle: jest.fn(),
    stop: jest.fn(),
    seek: jest.fn(),
    setVolume: jest.fn(),
    toggleMute: jest.fn(),
    setPlaybackRate: jest.fn(),
    analyzeAudio: analyzeAudioMock,
  }),
  formatTime: (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  },
}));

describe('AudioPlayer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    analyzeAudioMock.mockResolvedValue(null);
  });

  describe('Empty State', () => {
    it('renders empty state when no audio provided', () => {
      render(<AudioPlayer audio={null} />);
      expect(screen.getByText('输出音频')).toBeInTheDocument();
      expect(screen.getByText('等待处理结果...')).toBeInTheDocument();
      expect(screen.getByText('处理完成后将自动显示')).toBeInTheDocument();
    });

    it('renders custom title in empty state', () => {
      render(<AudioPlayer audio={null} title="自定义标题" />);
      expect(screen.getByText('自定义标题')).toBeInTheDocument();
    });

    it('applies custom className in empty state', () => {
      const { container } = render(
        <AudioPlayer audio={null} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });

    it('renders english empty-state copy when locale is en', () => {
      renderWithI18n(<AudioPlayer audio={null} />, { locale: 'en' });

      expect(screen.getByText('Output Audio')).toBeInTheDocument();
      expect(screen.queryByText('Waiting for audio data...')).not.toBeInTheDocument();
      expect(screen.getByText('Waiting for processing result...')).toBeInTheDocument();
    });
  });

  // Note: Tests with audio prop are skipped due to React 19 strict mode
  // compatibility issues with useEffect in the component.
  // Keep focused integration checks around the load/analyze bridge.

  it('binds a real audio element and loads the provided source', async () => {
    render(
      <AudioPlayer
        audio={{
          id: 'audio-1',
          data: new ArrayBuffer(0),
          url: 'http://localhost:8000/api/v1/files/download/audio-1',
          fileName: 'enhanced.wav',
          format: 'wav',
          duration: 12,
          sampleRate: 44100,
          size: 1024,
          createdAt: new Date('2026-03-14T00:00:00Z'),
        }}
      />,
    );

    expect(document.querySelector('audio')).toBeInTheDocument();

    await waitFor(() => {
      expect(loadMock).toHaveBeenCalledWith('http://localhost:8000/api/v1/files/download/audio-1');
      expect(analyzeAudioMock).toHaveBeenCalled();
    });
  });
});
