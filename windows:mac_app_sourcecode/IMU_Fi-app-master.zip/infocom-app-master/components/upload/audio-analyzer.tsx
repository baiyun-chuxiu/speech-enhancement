'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import type { ProcessedAudioSession } from '@/hooks/useProcessedAudioSession';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, BarChart3, Info } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import type { AudioAnalysis, ProcessedAudio } from '@/lib/types';
import {
  formatClockTimeLabel,
  formatDecibelLabel,
  formatFileSizeLabel,
  formatSampleRateLabel,
} from '@/lib/utils/upload-formatters';

const FALLBACK_PRIMARY_COLOR = 'oklch(0.55 0.25 260)';
const FALLBACK_MUTED_FOREGROUND_COLOR = 'oklch(0.5 0.02 260)';

function resolveCanvasThemeColor(
  cssVariable: string,
  fallbackColor: string,
  alpha?: number,
): string {
  const rawColor =
    typeof window === 'undefined'
      ? fallbackColor
      : getComputedStyle(document.documentElement).getPropertyValue(cssVariable).trim() || fallbackColor;

  if (alpha === undefined) {
    return rawColor;
  }

  if (rawColor.endsWith(')')) {
    return rawColor.replace(/\)\s*$/, ` / ${alpha})`);
  }

  return `hsl(${rawColor} / ${alpha})`;
}

interface AudioAnalyzerProps {
  audio: ProcessedAudio | null;
  session?: ProcessedAudioSession;
  analysis: AudioAnalysis | null;
  currentTime?: number;
  className?: string;
}

export function AudioAnalyzer({
  audio,
  session,
  analysis,
  currentTime = 0,
  className,
}: AudioAnalyzerProps) {
  const t = useTranslations();
  const locale = useLocale();
  const waveformCanvasRef = useRef<HTMLCanvasElement>(null);
  const frequencyCanvasRef = useRef<HTMLCanvasElement>(null);
  const [activeTab, setActiveTab] = useState('waveform');
  const activeAudio = session?.resolvedAudio ?? audio;
  const activeAnalysis = session?.analysis ?? analysis;
  const activeCurrentTime = session?.state.currentTime ?? currentTime;
  const analysisError = session?.analysisError ?? null;

  const drawWaveform = useCallback(() => {
    const canvas = waveformCanvasRef.current;
    if (!canvas || !activeAnalysis?.waveformData) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const data = activeAnalysis.waveformData;
    const barWidth = width / data.length;
    const playProgress = activeAnalysis.duration > 0 ? activeCurrentTime / activeAnalysis.duration : 0;
    const playedColor = resolveCanvasThemeColor('--primary', FALLBACK_PRIMARY_COLOR);
    const unplayedColor = resolveCanvasThemeColor('--muted-foreground', FALLBACK_MUTED_FOREGROUND_COLOR, 0.3);

    ctx.clearRect(0, 0, width, height);

    data.forEach((value, index) => {
      const x = index * barWidth;
      const barHeight = value * height * 0.9;
      const y = (height - barHeight) / 2;

      const isPlayed = index / data.length < playProgress;
      
      ctx.fillStyle = isPlayed 
        ? playedColor
        : unplayedColor;
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    });
  }, [activeAnalysis, activeCurrentTime]);

  const drawFrequency = useCallback(() => {
    const canvas = frequencyCanvasRef.current;
    if (!canvas || !activeAnalysis?.waveformData) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    
    // 模拟频谱数据（实际应使用 FFT 分析）
    const bars = 32;
    const barWidth = width / bars;
    const primaryColor = resolveCanvasThemeColor('--primary', FALLBACK_PRIMARY_COLOR);
    const fadedPrimaryColor = resolveCanvasThemeColor('--primary', FALLBACK_PRIMARY_COLOR, 0.5);

    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < bars; i++) {
      // 基于波形数据生成模拟频谱
      const dataIndex = Math.floor((i / bars) * activeAnalysis.waveformData.length);
      const value = activeAnalysis.waveformData[dataIndex] || 0;
      
      const barHeight = value * height * 0.8;
      const x = i * barWidth;
      const y = height - barHeight;

      // 创建渐变色
      const gradient = ctx.createLinearGradient(x, height, x, y);
      gradient.addColorStop(0, primaryColor);
      gradient.addColorStop(1, fadedPrimaryColor);

      ctx.fillStyle = gradient;
      ctx.fillRect(x + 2, y, barWidth - 4, barHeight);
    }
  }, [activeAnalysis]);

  useEffect(() => {
    if (activeTab === 'waveform') {
      drawWaveform();
    } else if (activeTab === 'frequency') {
      drawFrequency();
    }
  }, [activeTab, drawWaveform, drawFrequency]);

  useEffect(() => {
    if (activeTab === 'waveform') {
      drawWaveform();
    }
  }, [activeCurrentTime, activeTab, drawWaveform]);

  const dynamicRangeValue =
    activeAnalysis && activeAnalysis.peakAmplitude > 0 && activeAnalysis.averageAmplitude > 0
      ? 20 * Math.log10(activeAnalysis.peakAmplitude / activeAnalysis.averageAmplitude)
      : null;

  if (!activeAudio && !activeAnalysis) {
    return (
      <Card className={cn("min-w-0 w-full transition-all duration-200 border-border/60 bg-card/95 backdrop-blur-sm", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="h-3.5 w-3.5 text-primary" />
            </div>
            {t('audioAnalyzer.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
            <div className="w-16 h-16 rounded-2xl bg-muted/30 flex items-center justify-center mb-4">
              <BarChart3 className="h-8 w-8 text-muted-foreground/40 animate-pulse" />
            </div>
            <p className="text-sm font-medium">{t('audioAnalyzer.waitingAudio')}</p>
            <p className="text-xs text-muted-foreground/60 mt-1">{t('audioAnalyzer.autoAnalyze')}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("min-w-0 w-full transition-all duration-200 hover:shadow-soft-md border-border/60 bg-card/95 backdrop-blur-sm", className)}>
      <CardHeader className="pb-2 lg:pb-3">
        <CardTitle className="flex items-center gap-2 text-sm lg:text-base">
          <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
            <Activity className="h-3.5 w-3.5 text-primary" />
          </div>
          <span className="font-medium">{t('audioAnalyzer.title')}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 lg:space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full grid grid-cols-3 h-10 p-1 bg-muted/50 rounded-xl">
            <TabsTrigger value="waveform" className="text-xs px-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              {t('audioAnalyzer.waveform')}
            </TabsTrigger>
            <TabsTrigger value="frequency" className="text-xs px-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              {t('audioAnalyzer.frequency')}
            </TabsTrigger>
            <TabsTrigger value="info" className="text-xs px-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              {t('audioAnalyzer.info')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="waveform" className="mt-3 lg:mt-4">
            {activeAnalysis ? (
              <>
                <div className="bg-muted/20 rounded-xl p-2.5 lg:p-3 border border-border/40">
                  <canvas
                    ref={waveformCanvasRef}
                    className="w-full h-20 min-h-[80px] lg:h-24"
                    style={{ display: 'block' }}
                  />
                </div>
                <p className="text-[10px] lg:text-xs text-muted-foreground mt-2 text-center font-medium">
                  {t('audioAnalyzer.waveformVisualization')}
                </p>
              </>
            ) : (
              <FallbackMessage message={analysisError ? t(analysisError) : t('audioAnalyzer.analysisUnavailable')} />
            )}
          </TabsContent>

          <TabsContent value="frequency" className="mt-3 lg:mt-4">
            {activeAnalysis ? (
              <>
                <div className="bg-muted/20 rounded-xl p-2.5 lg:p-3 border border-border/40">
                  <canvas
                    ref={frequencyCanvasRef}
                    className="w-full h-20 min-h-[80px] lg:h-24"
                    style={{ display: 'block' }}
                  />
                </div>
                <p className="text-[10px] lg:text-xs text-muted-foreground mt-2 text-center font-medium">
                  {t('audioAnalyzer.frequencyVisualization')}
                </p>
              </>
            ) : (
              <FallbackMessage message={analysisError ? t(analysisError) : t('audioAnalyzer.analysisUnavailable')} />
            )}
          </TabsContent>

          <TabsContent value="info" forceMount className="mt-3 lg:mt-4">
            {activeAnalysis && (
              <div className="space-y-2 lg:space-y-3">
                <div
                  data-testid="analysis-primary-metrics"
                  className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:gap-3"
                >
                  <InfoItem 
                    label={t('audioAnalyzer.duration')} 
                    value={`${activeAnalysis.duration.toFixed(2)} ${t('audioAnalyzer.seconds')}`} 
                  />
                  <InfoItem 
                    label={t('audioAnalyzer.sampleRateLabel')} 
                    value={formatSampleRateLabel(activeAnalysis.sampleRate, locale, t)}
                  />
                  <InfoItem 
                    label={t('audioAnalyzer.channels')} 
                    value={`${activeAnalysis.channels} ${t('audioAnalyzer.channelUnit')}`} 
                  />
                  <InfoItem 
                    label={t('audioAnalyzer.formatLabel')} 
                    value={activeAnalysis.format.toUpperCase()} 
                  />
                </div>

                <div className="pt-2 lg:pt-3 space-y-2">
                  <Separator className="mb-2 lg:mb-3" />
                  <h4 className="text-[10px] lg:text-xs font-medium flex items-center gap-1">
                    <Info className="h-3 w-3" />
                    {t('audioAnalyzer.amplitudeAnalysis')}
                  </h4>
                  <div
                    data-testid="analysis-amplitude-metrics"
                    className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:gap-3"
                  >
                    <InfoItem 
                      label={t('audioAnalyzer.peak')} 
                      value={`${(activeAnalysis.peakAmplitude * 100).toFixed(1)}%`} 
                    />
                    <InfoItem 
                      label={t('audioAnalyzer.average')} 
                      value={`${(activeAnalysis.averageAmplitude * 100).toFixed(1)}%`} 
                    />
                    <InfoItem 
                      label={t('audioAnalyzer.silence')} 
                      value={`${(activeAnalysis.silenceRatio * 100).toFixed(1)}%`} 
                    />
                    <InfoItem 
                      label={t('audioAnalyzer.dynamic')} 
                      value={formatDecibelLabel(dynamicRangeValue, locale, t)}
                    />
                  </div>
                </div>

                {activeAudio && (
                  <div className="pt-2 lg:pt-3 space-y-2">
                    <Separator className="mb-2 lg:mb-3" />
                    <h4 className="text-[10px] lg:text-xs font-medium">{t('audioAnalyzer.outputInfo')}</h4>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:gap-3">
                      <InfoItem 
                        label={t('audioAnalyzer.size')} 
                        value={formatFileSizeLabel(activeAudio.size, locale, t)}
                      />
                      <InfoItem 
                        label={t('audioAnalyzer.time')} 
                        value={formatClockTimeLabel(activeAudio.createdAt, locale)}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
            {!activeAnalysis && (
              <FallbackMessage message={analysisError ? t(analysisError) : t('audioAnalyzer.analysisUnavailable')} />
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-muted/30 rounded-xl p-2.5 lg:p-3 border border-border/40">
      <p className="text-[10px] lg:text-xs text-muted-foreground/70 font-medium">{label}</p>
      <p className="text-xs lg:text-sm font-semibold mt-0.5 text-foreground">{value}</p>
    </div>
  );
}

function FallbackMessage({ message }: { message: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border/60 bg-muted/20 px-4 py-6 text-center">
      <p className="text-xs font-medium text-muted-foreground">{message}</p>
    </div>
  );
}
