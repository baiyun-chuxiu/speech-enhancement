'use client';

import { useEffect } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import {
  Disc3,
  Download,
  Loader2,
  Music,
  Pause,
  Play,
  RotateCcw,
  SkipBack,
  SkipForward,
  Square,
  Volume1,
  Volume2,
  VolumeX,
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { formatTime, useAudioPlayer } from '@/hooks/useAudioPlayer';
import type { ProcessedAudioSession } from '@/hooks/useProcessedAudioSession';
import type { ProcessedAudio } from '@/lib/types';
import { formatFileSizeLabel, formatSampleRateLabel } from '@/lib/utils/upload-formatters';

interface AudioPlayerProps {
  audio: ProcessedAudio | null;
  session?: ProcessedAudioSession;
  title?: string;
  onDownload?: () => void;
  className?: string;
}

export function AudioPlayer({
  audio,
  session,
  title,
  onDownload,
  className,
}: AudioPlayerProps) {
  const t = useTranslations();
  const locale = useLocale();
  const resolvedTitle = title ?? t('audioPlayer.outputAudio');
  const internalPlayer = useAudioPlayer();
  const { load: internalLoad, analyzeAudio: internalAnalyzeAudio } = internalPlayer;
  const activeAudio = session?.resolvedAudio ?? audio;
  const activeAudioRef = session?.audioRef ?? internalPlayer.audioRef;
  const activeState = session?.state ?? internalPlayer.state;
  const activeAnalysis = session?.analysis ?? internalPlayer.analysis;
  const activeToggle = session?.toggle ?? internalPlayer.toggle;
  const activeStop = session?.stop ?? internalPlayer.stop;
  const activePause = session?.pause ?? internalPlayer.pause;
  const activeSeek = session?.seek ?? internalPlayer.seek;
  const activeSetVolume = session?.setVolume ?? internalPlayer.setVolume;
  const activeToggleMute = session?.toggleMute ?? internalPlayer.toggleMute;
  const activeSetPlaybackRate = session?.setPlaybackRate ?? internalPlayer.setPlaybackRate;

  useEffect(() => {
    if (!session && audio?.url) {
      internalLoad(audio.url);
      internalAnalyzeAudio();
    }
  }, [audio?.url, internalAnalyzeAudio, internalLoad, session]);

  const handleSeek = (value: number[]) => {
    activeSeek(value[0]);
  };

  const handleVolumeChange = (value: number[]) => {
    activeSetVolume(value[0]);
  };

  const handleDownload = async () => {
    if (session) {
      await session.download();
    } else if (activeAudio?.url) {
      const anchor = document.createElement('a');
      anchor.href = activeAudio.url;
      anchor.download = activeAudio.fileName ?? `output.${activeAudio.format}`;
      anchor.click();
    }
    onDownload?.();
  };

  const playbackRates = [0.5, 0.75, 1, 1.25, 1.5, 2];

  const handleWaveformClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (!activeAnalysis || activeState.isLoading) return;

    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * activeState.duration;
    activeSeek(newTime);
  };

  const skipBackward = () => {
    activeSeek(Math.max(0, activeState.currentTime - 5));
  };

  const skipForward = () => {
    activeSeek(Math.min(activeState.duration, activeState.currentTime + 5));
  };

  const VolumeIcon =
    activeState.isMuted || activeState.volume === 0
      ? VolumeX
      : activeState.volume < 0.5
        ? Volume1
        : Volume2;

  if (!activeAudio) {
    return (
      <Card className={cn('min-w-0 w-full transition-all duration-200 border-border/60 bg-card/95 backdrop-blur-sm', className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
              <Music className="h-3.5 w-3.5 text-primary" />
            </div>
            {resolvedTitle}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
            <div className="w-16 h-16 rounded-2xl bg-muted/30 flex items-center justify-center mb-4">
              <Disc3 className="h-8 w-8 text-muted-foreground/40 animate-pulse" />
            </div>
            <p className="text-sm font-medium">{t('audioPlayer.waitingResult')}</p>
            <p className="text-xs text-muted-foreground/60 mt-1">{t('audioPlayer.autoShowAfterProcess')}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn('min-w-0 w-full transition-all duration-200 hover:shadow-soft-md border-border/60 bg-card/95 backdrop-blur-sm', className)}>
      <audio ref={activeAudioRef} preload="metadata" crossOrigin="anonymous" playsInline className="hidden" />
      <CardHeader className="pb-2 lg:pb-3">
        <CardTitle className="flex items-center justify-between text-sm lg:text-base">
          <div className="flex items-center gap-2">
            <div
              className={cn(
                'w-6 h-6 rounded-lg flex items-center justify-center transition-colors',
                activeState.isPlaying ? 'bg-green-500/10' : 'bg-primary/10',
              )}
            >
              {activeState.isPlaying ? (
                <Disc3 className="h-3.5 w-3.5 text-green-600 dark:text-green-400 animate-spin" style={{ animationDuration: '3s' }} />
              ) : (
                <Music className="h-3.5 w-3.5 text-primary" />
              )}
            </div>
            <span className="font-medium">{resolvedTitle}</span>
          </div>
          <Badge variant="secondary" className="text-[10px] lg:text-xs uppercase font-medium px-2 py-0.5">
            {activeAudio.format}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 lg:space-y-4">
        <div
          className={cn(
            'h-20 lg:h-24 bg-muted/20 rounded-xl p-2 lg:p-3 flex items-center gap-0.5 relative overflow-hidden',
            'min-h-24',
            'cursor-pointer transition-all duration-200 border border-border/40',
            'hover:bg-muted/30 hover:border-border/60',
            activeState.isLoading && 'pointer-events-none opacity-60',
          )}
          onClick={handleWaveformClick}
        >
          {activeAnalysis ? (
            <>
              <div
                className="absolute top-0 bottom-0 left-0 bg-linear-to-r from-primary/15 to-primary/5 transition-all duration-75"
                style={{ width: `${(activeState.currentTime / activeState.duration) * 100}%` }}
              />
              {activeAnalysis.waveformData.map((value, index) => {
                const isPlayed = activeState.currentTime / activeState.duration > index / activeAnalysis.waveformData.length;
                const barHeight = Math.max(value * 100, 8);

                return (
                  <div key={index} className="flex-1 flex flex-col items-center justify-center gap-0.5 group">
                    <div
                      className={cn(
                        'w-full rounded-t transition-all duration-100',
                        isPlayed ? 'bg-primary shadow-sm' : 'bg-muted-foreground/25 group-hover:bg-muted-foreground/35',
                      )}
                      style={{ height: `${barHeight / 2}%`, minHeight: '3px' }}
                    />
                    <div
                      className={cn(
                        'w-full rounded-b transition-all duration-100',
                        isPlayed ? 'bg-primary shadow-sm' : 'bg-muted-foreground/25 group-hover:bg-muted-foreground/35',
                      )}
                      style={{ height: `${barHeight / 2}%`, minHeight: '3px' }}
                    />
                  </div>
                );
              })}
              <div
                className="absolute top-1 bottom-1 w-0.5 bg-primary rounded-full shadow-lg shadow-primary/30 transition-all duration-75"
                style={{ left: `calc(${(activeState.currentTime / activeState.duration) * 100}% - 1px)` }}
              />
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-2">
              <div className="flex items-center gap-1">
                {[25, 35, 20, 40, 30, 45, 22, 38].map((height, index) => (
                  <div
                    key={index}
                    className="w-1.5 bg-muted-foreground/30 rounded-full animate-waveform-bar"
                    style={{
                      height: `${height}px`,
                      animationDelay: `${index * 0.1}s`,
                    }}
                  />
                ))}
              </div>
              <span className="text-xs">{t('audioPlayer.loadingWaveform')}</span>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <Slider
            value={[activeState.currentTime]}
            max={activeState.duration || 100}
            step={0.1}
            onValueChange={handleSeek}
            disabled={activeState.isLoading}
            className="cursor-pointer"
          />
          <div className="flex justify-between text-[10px] lg:text-xs text-muted-foreground font-medium">
            <span className="tabular-nums">{formatTime(activeState.currentTime)}</span>
            <span className="text-muted-foreground/60">/ {formatTime(activeState.duration)}</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-1.5 lg:gap-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 lg:h-9 lg:w-9 rounded-lg hover:bg-muted"
                onClick={activeStop}
                disabled={activeState.isLoading}
              >
                <RotateCcw className="h-3.5 w-3.5 lg:h-4 lg:w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('common.reset')}</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 lg:h-9 lg:w-9 rounded-lg hover:bg-muted"
                onClick={skipBackward}
                disabled={activeState.isLoading}
              >
                <SkipBack className="h-3.5 w-3.5 lg:h-4 lg:w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('audioPlayer.rewind5s')}</TooltipContent>
          </Tooltip>

          <Button
            variant="default"
            size="icon"
            className={cn(
              'h-11 w-11 lg:h-12 lg:w-12 rounded-xl shadow-soft-md transition-all duration-200',
              'bg-gradient-primary hover:opacity-90',
            )}
            onClick={activeToggle}
            disabled={activeState.isLoading}
          >
            {activeState.isLoading ? (
              <Loader2 className="h-5 w-5 lg:h-6 lg:w-6 animate-spin" />
            ) : activeState.isPlaying ? (
              <Pause className="h-5 w-5 lg:h-6 lg:w-6" />
            ) : (
              <Play className="h-5 w-5 lg:h-6 lg:w-6 ml-0.5" />
            )}
          </Button>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 lg:h-9 lg:w-9 rounded-lg hover:bg-muted"
                onClick={skipForward}
                disabled={activeState.isLoading}
              >
                <SkipForward className="h-3.5 w-3.5 lg:h-4 lg:w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('audioPlayer.forward5s')}</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 lg:h-9 lg:w-9 rounded-lg hover:bg-muted"
                onClick={() => {
                  activePause();
                  activeSeek(0);
                }}
                disabled={activeState.isLoading}
              >
                <Square className="h-3.5 w-3.5 lg:h-4 lg:w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('audioPlayer.stop')}</TooltipContent>
          </Tooltip>
        </div>

        <div className="space-y-3 pt-1">
          <div className="flex items-center gap-2 lg:gap-3 bg-muted/30 rounded-xl p-2 lg:p-2.5">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 shrink-0 rounded-lg hover:bg-background/80"
                  onClick={activeToggleMute}
                >
                  <VolumeIcon className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>{activeState.isMuted ? t('audioPlayer.unmute') : t('audioPlayer.mute')}</TooltipContent>
            </Tooltip>
            <Slider
              value={[activeState.isMuted ? 0 : activeState.volume]}
              max={1}
              step={0.01}
              onValueChange={handleVolumeChange}
              className="flex-1"
            />
            <span className="text-[10px] lg:text-xs text-muted-foreground w-8 text-right font-medium tabular-nums">
              {Math.round((activeState.isMuted ? 0 : activeState.volume) * 100)}%
            </span>
          </div>

          <div className="flex items-center gap-1.5 lg:gap-2 overflow-x-auto pb-1 mobile-scroll">
            <span className="text-[10px] lg:text-xs text-muted-foreground shrink-0 font-medium">{t('audioPlayer.speed')}</span>
            <div className="flex items-center gap-1 bg-muted/30 rounded-lg p-1">
              {playbackRates.map((rate) => (
                <Button
                  key={rate}
                  variant="ghost"
                  size="sm"
                  className={cn(
                    'h-6 lg:h-7 px-2 lg:px-2.5 text-[10px] lg:text-xs shrink-0 rounded-md transition-all',
                    activeState.playbackRate === rate
                      ? 'bg-primary text-primary-foreground shadow-sm hover:bg-primary/90'
                      : 'hover:bg-background/80',
                  )}
                  onClick={() => activeSetPlaybackRate(rate)}
                >
                  {rate}x
                </Button>
              ))}
            </div>
          </div>
        </div>

        <Separator className="mt-1" />
        <div className="flex flex-col gap-3 pt-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-[10px] lg:text-xs text-muted-foreground flex flex-wrap gap-x-3 gap-y-1">
            <span className="flex items-center gap-1">
              <span className="text-muted-foreground/60">{t('audioPlayer.durationLabel')}</span>
              <span className="font-medium text-foreground">{formatTime(activeAudio.duration)}</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="text-muted-foreground/60">{t('audioPlayer.sampleRate')}</span>
              <span className="font-medium text-foreground">{formatSampleRateLabel(activeAudio.sampleRate, locale, t)}</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="text-muted-foreground/60">{t('audioPlayer.size')}</span>
              <span className="font-medium text-foreground">{formatFileSizeLabel(activeAudio.size, locale, t)}</span>
            </span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              void handleDownload();
            }}
            className="gap-1.5 h-8 w-full text-xs rounded-lg border-border/60 hover:bg-primary/5 hover:border-primary/50 hover:text-primary transition-all sm:w-auto"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">{t('audioPlayer.download')}</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
