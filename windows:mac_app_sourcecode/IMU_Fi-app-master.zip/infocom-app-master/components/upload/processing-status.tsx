'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import {
  Loader2,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  AlertTriangle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTranslations } from 'next-intl';
import type { ProcessStep, ProcessStatus } from '@/lib/types';

interface ProcessingStatusProps {
  isProcessing: boolean;
  progress: number;
  steps: ProcessStep[];
  error: string | null;
  onCancel?: () => void;
  className?: string;
}

const statusConfig: Record<ProcessStatus, {
  icon: React.ElementType;
  color: string;
  bgColor: string;
}> = {
  pending: {
    icon: Clock,
    color: 'text-muted-foreground',
    bgColor: 'bg-muted',
  },
  processing: {
    icon: Loader2,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  completed: {
    icon: CheckCircle,
    color: 'text-green-600 dark:text-green-400',
    bgColor: 'bg-green-100 dark:bg-green-900/30',
  },
  failed: {
    icon: XCircle,
    color: 'text-destructive',
    bgColor: 'bg-destructive/10',
  },
  skipped: {
    icon: AlertTriangle,
    color: 'text-yellow-600 dark:text-yellow-400',
    bgColor: 'bg-yellow-100 dark:bg-yellow-900/30',
  },
};

export function ProcessingStatus({
  isProcessing,
  progress,
  steps,
  error,
  onCancel,
  className,
}: ProcessingStatusProps) {
  const t = useTranslations();
  const completedSteps = steps.filter(s => s.status === 'completed').length;
  const totalSteps = steps.length;

  return (
    <Card className={cn("min-w-0 w-full transition-all duration-200 border-border/60 bg-card/95 backdrop-blur-sm animate-fade-in", className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className={cn(
              "w-6 h-6 rounded-lg flex items-center justify-center",
              isProcessing ? "bg-primary/10" : error ? "bg-destructive/10" : "bg-green-500/10"
            )}>
              <Zap className={cn(
                "h-3.5 w-3.5",
                isProcessing ? "text-primary animate-pulse" : error ? "text-destructive" : "text-green-600 dark:text-green-400"
              )} />
            </div>
            <span className="font-medium">{t('processing.status')}</span>
          </CardTitle>
          {isProcessing && (
            <Badge variant="secondary" className="text-xs font-medium px-2 py-0.5">
              {completedSteps}/{totalSteps} {t('processing.steps')}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 总体进度 */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground font-medium">{t('processing.overallProgress')}</span>
            <span className="font-semibold text-primary tabular-nums">{Math.round(progress)}%</span>
          </div>
          <div className="relative">
            <Progress value={progress} className="h-2.5 rounded-full" />
            {isProcessing && (
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent progress-indeterminate rounded-full" />
            )}
          </div>
        </div>

        {/* 步骤列表 */}
        <div className="space-y-2">
          {steps.map((step, index) => {
            const config = statusConfig[step.status];
            const Icon = config.icon;
            const isActive = step.status === 'processing';

            return (
              <div
                key={index}
                className={cn(
                  "flex items-center gap-3 p-3 rounded-xl transition-all duration-200 border",
                  config.bgColor,
                  isActive ? "border-primary/30 shadow-sm" : "border-transparent"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                  step.status === 'completed' ? "bg-green-500/20" :
                  step.status === 'processing' ? "bg-primary/20" :
                  step.status === 'failed' ? "bg-destructive/20" : "bg-muted"
                )}>
                  <Icon className={cn(
                    "h-4 w-4",
                    config.color,
                    isActive && "animate-spin"
                  )} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                    <p className={cn(
                      "text-sm font-medium",
                      step.status === 'pending' && "text-muted-foreground"
                    )}>
                      {step.name}
                    </p>
                    {step.status === 'processing' && (
                      <span className="text-xs font-medium text-primary tabular-nums">
                        {step.progress}%
                      </span>
                    )}
                  </div>
                  {step.message && (
                    <p className="text-[10px] text-muted-foreground mt-0.5 truncate">
                      {step.message}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* 错误信息 */}
        {error && (
          <Alert variant="destructive" className="rounded-xl animate-fade-in">
            <XCircle className="h-4 w-4" />
            <AlertTitle>{t('processing.failed')}</AlertTitle>
            <AlertDescription className="text-xs">{error}</AlertDescription>
          </Alert>
        )}

        {/* 取消按钮 */}
        {isProcessing && onCancel && (
          <Button
            variant="outline"
            size="sm"
            onClick={onCancel}
            className="w-full rounded-lg border-border/60 hover:bg-destructive/5 hover:text-destructive hover:border-destructive/50 transition-all"
          >
            {t('processing.cancel')}
          </Button>
        )}

        {/* 完成状态 */}
        {!isProcessing && !error && completedSteps === totalSteps && totalSteps > 0 && (
          <Alert className="rounded-xl animate-fade-in bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
            <CheckCircle className="h-4 w-4" />
            <AlertTitle>{t('processing.completed')}</AlertTitle>
            <AlertDescription className="text-[10px]">{t('processing.allStepsCompleted')}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
