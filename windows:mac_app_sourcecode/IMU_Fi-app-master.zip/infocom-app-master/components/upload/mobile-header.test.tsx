import { render, screen, fireEvent } from '@testing-library/react';
import { MobileHeader } from './mobile-header';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

// Mock next/link
jest.mock('next/link', () => {
  const MockLink = ({ children, href, onClick }: { 
    children: React.ReactNode; 
    href: string;
    onClick?: () => void;
  }) => (
    <a href={href} onClick={onClick}>{children}</a>
  );
  MockLink.displayName = 'MockLink';
  return MockLink;
});

// Mock document.querySelector for scroll
const mockScrollIntoView = jest.fn();
document.querySelector = jest.fn().mockReturnValue({
  scrollIntoView: mockScrollIntoView,
});

describe('MobileHeader', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders the header with title', () => {
    render(<MobileHeader />);
    expect(screen.getByText('音频处理工具')).toBeInTheDocument();
  });

  it('renders InfoCom App subtitle', () => {
    render(<MobileHeader />);
    expect(screen.getByText('InfoCom App')).toBeInTheDocument();
  });

  it('renders Beta badge', () => {
    render(<MobileHeader />);
    expect(screen.getByText('Beta')).toBeInTheDocument();
  });

  it('renders theme toggle button', () => {
    render(<MobileHeader />);
    // Find buttons with Moon or Sun icon
    const buttons = screen.getAllByRole('button');
    expect(buttons.length).toBeGreaterThan(0);
  });

  it('calls onReset when reset button is clicked', () => {
    const mockOnReset = jest.fn();
    render(<MobileHeader onReset={mockOnReset} />);
    
    // Find reset button (with RotateCcw icon or "重置" text)
    const resetButton = screen.getByText('重置');
    fireEvent.click(resetButton);
    
    expect(mockOnReset).toHaveBeenCalledTimes(1);
  });

  it('disables reset button when processing', () => {
    const mockOnReset = jest.fn();
    render(<MobileHeader onReset={mockOnReset} isProcessing={true} />);
    
    const resetButton = screen.getByText('重置');
    expect(resetButton.closest('button')).toBeDisabled();
  });

  it('renders desktop navigation links', () => {
    render(<MobileHeader />);
    expect(screen.getByText('上传')).toBeInTheDocument();
    expect(screen.getByText('帮助')).toBeInTheDocument();
    expect(screen.getByText('设置')).toBeInTheDocument();
  });

  it('has help link pointing to /help', () => {
    render(<MobileHeader />);
    const helpLink = screen.getByText('帮助').closest('a');
    expect(helpLink).toHaveAttribute('href', '/help');
  });

  it('has settings link pointing to /settings', () => {
    render(<MobileHeader />);
    const settingsLink = screen.getByText('设置').closest('a');
    expect(settingsLink).toHaveAttribute('href', '/settings');
  });

  it('toggles theme when theme button is clicked', () => {
    render(<MobileHeader />);
    
    // Find the theme toggle button (should have Moon or Sun icon)
    const buttons = screen.getAllByRole('button');
    const themeButton = buttons.find(btn => 
      btn.querySelector('svg') && 
      !btn.textContent?.includes('重置') &&
      !btn.textContent?.includes('测试')
    );
    
    expect(themeButton).toBeDefined();
    if (themeButton) {
      fireEvent.click(themeButton);
      // Theme should toggle
      expect(document.documentElement.classList.contains('dark') || 
             !document.documentElement.classList.contains('dark')).toBe(true);
    }
  });

  it('applies custom className', () => {
    const { container } = render(<MobileHeader className="custom-class" />);
    const header = container.querySelector('header');
    expect(header).toHaveClass('custom-class');
  });

  it('renders english header copy when locale is en', () => {
    renderWithI18n(<MobileHeader />, { locale: 'en' });

    expect(screen.getByText('Audio Processor')).toBeInTheDocument();
    expect(screen.getByText('Upload')).toBeInTheDocument();
    expect(screen.getByText('Settings')).toBeInTheDocument();
  });
});
