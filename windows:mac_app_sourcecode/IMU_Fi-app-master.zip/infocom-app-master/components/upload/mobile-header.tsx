'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  Menu,
  RotateCcw,
  Upload,
  Music,
  Settings,
  Info,
  Moon,
  Sun,
  HelpCircle,
  Monitor,
  Github,
  ExternalLink,
  Waves,
  Sparkles,
} from 'lucide-react';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { LanguageSwitcher } from '@/components/ui/language-switcher';

interface MobileHeaderProps {
  onReset?: () => void;
  isProcessing?: boolean;
  className?: string;
}

export function MobileHeader({
  onReset,
  isProcessing = false,
  className,
}: MobileHeaderProps) {
  const t = useTranslations();
  const [open, setOpen] = useState(false);
  const [isDark, setIsDark] = useState(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return false;
  });

  const toggleTheme = () => {
    const newValue = !isDark;
    setIsDark(newValue);
    document.documentElement.classList.toggle('dark', newValue);
  };

  const menuItems = [
    { icon: Upload, label: t('header.uploadFiles'), href: '#upload', isAnchor: true },
    { icon: Music, label: t('header.audioProcessing'), href: '#process', isAnchor: true },
    { icon: HelpCircle, label: t('header.useHelp'), href: '/help', isAnchor: false },
    { icon: Settings, label: t('header.settings'), href: '/settings', isAnchor: false },
  ];

  const desktopNavItems = [
    { label: t('header.upload'), href: '#upload', isAnchor: true },
    { label: t('header.help'), href: '/help', isAnchor: false },
    { label: t('header.settings'), href: '/settings', isAnchor: false },
  ];

  const handleAnchorNavigation = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setOpen(false);
  };

  return (
    <header className={cn(
      "sticky top-0 z-50 border-b border-border/40 pt-safe",
      "bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/70",
      "overflow-x-clip transition-all duration-200",
      className
    )}>
      <div className="container-responsive mx-auto flex h-14 max-w-7xl items-center justify-between gap-2 lg:h-12">
        {/* Logo 和标题 */}
        <div className="flex min-w-0 items-center gap-2.5 lg:gap-3">
          <div className="w-9 h-9 lg:w-10 lg:h-10 rounded-xl bg-gradient-primary flex items-center justify-center shadow-soft-sm">
            <Waves className="h-4 w-4 lg:h-5 lg:w-5 text-primary-foreground" />
          </div>
          <div className="min-w-0">
            <h1 className="flex items-center gap-1.5 truncate text-sm font-bold leading-none lg:text-base">
              {t('header.title')}
              <Badge className="hidden sm:inline-flex text-[9px] px-1.5 py-0.5 bg-primary/10 text-primary border-0 font-medium">
                {t('header.beta')}
              </Badge>
            </h1>
            <p className="mt-0.5 truncate text-[10px] font-medium text-muted-foreground lg:text-[11px]">{t('header.subtitle')}</p>
          </div>
        </div>

        {/* 桌面端导航 */}
        <nav className="hidden min-w-0 items-center gap-1 xl:flex">
          {desktopNavItems.map((item) => (
            item.isAnchor ? (
              <Button
                key={item.href}
                variant="ghost"
                size="sm"
                className="text-sm"
                onClick={() => handleAnchorNavigation(item.href)}
              >
                {item.label}
              </Button>
            ) : (
              <Link key={item.href} href={item.href}>
                <Button variant="ghost" size="sm" className="text-sm">
                  {item.label}
                </Button>
              </Link>
            )
          ))}
        </nav>

        {/* 右侧操作区 */}
        <div className="flex shrink-0 items-center gap-1.5 lg:gap-2">
          {/* 桌面端显示更多按钮 */}
          <Button
            variant="outline"
            size="sm"
            className="hidden lg:inline-flex gap-1.5 text-xs h-8 px-3 rounded-lg border-border/60 hover:bg-muted/80 press-effect"
            onClick={onReset}
            disabled={isProcessing}
          >
            <RotateCcw className="h-3.5 w-3.5" />
            {t('common.reset')}
          </Button>

          {/* 移动端重置按钮 */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 lg:hidden rounded-lg hover:bg-muted/80"
                onClick={onReset}
                disabled={isProcessing}
                aria-label={t('common.reset')}
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{t('common.reset')}</TooltipContent>
          </Tooltip>

          {/* 主题切换 */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-lg hover:bg-muted/80 transition-colors"
                onClick={toggleTheme}
                aria-label={isDark ? t('header.switchLight') : t('header.switchDark')}
              >
                {isDark ? (
                  <Sun className="h-4 w-4 text-yellow-500" />
                ) : (
                  <Moon className="h-4 w-4" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>{isDark ? t('header.switchLight') : t('header.switchDark')}</TooltipContent>
          </Tooltip>

          {/* 桌面端下拉菜单 */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="hidden lg:inline-flex h-9 w-9 rounded-lg hover:bg-muted/80"
                aria-label="menu"
              >
                <Menu className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 p-1.5 rounded-xl border-border/60 shadow-soft-lg">
              <DropdownMenuItem className="gap-2.5 rounded-lg h-9 px-2.5">
                <Monitor className="h-4 w-4 text-muted-foreground" />
                {t('header.desktopVersion')}
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2.5 rounded-lg h-9 px-2.5">
                <Github className="h-4 w-4 text-muted-foreground" />
                {t('header.githubRepo')}
                <ExternalLink className="h-3 w-3 ml-auto opacity-50" />
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <DropdownMenuItem className="gap-2.5 rounded-lg h-9 px-2.5">
                <Info className="h-4 w-4 text-muted-foreground" />
                {t('header.about')}
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2.5 rounded-lg h-9 px-2.5">
                <Settings className="h-4 w-4 text-muted-foreground" />
                {t('header.settings')}
              </DropdownMenuItem>
              <DropdownMenuSeparator className="my-1" />
              <div className="px-2.5 py-2 space-y-2">
                <LanguageSwitcher className="w-full h-8 text-xs" />
                <p className="text-[10px] text-muted-foreground flex items-center gap-1.5">
                  <Sparkles className="h-3 w-3" />
                  {t('common.version', { version: '1.0.0-beta' })}
                </p>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* 移动端菜单 */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9 lg:hidden rounded-lg hover:bg-muted/80"
                aria-label="menu"
              >
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[340px] p-0">
              <div className="p-5 border-b border-border/40">
                <SheetHeader>
                  <SheetTitle className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center shadow-soft-sm">
                      <Waves className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <div>
                      <span className="font-bold">{t('header.title')}</span>
                      <p className="text-xs text-muted-foreground font-normal mt-0.5">{t('header.subtitle')}</p>
                    </div>
                  </SheetTitle>
                </SheetHeader>
              </div>
              
              <div className="p-3 space-y-1">
                {menuItems.map((item) => (
                  item.isAnchor ? (
                    <Button
                      key={item.label}
                      variant="ghost"
                      className="w-full justify-start h-12 px-3 text-sm rounded-xl hover:bg-muted/80"
                      onClick={() => {
                        handleAnchorNavigation(item.href);
                      }}
                    >
                      <div className="w-8 h-8 rounded-lg bg-muted/80 flex items-center justify-center mr-3">
                        <item.icon className="h-4 w-4 text-muted-foreground" />
                      </div>
                      {item.label}
                    </Button>
                  ) : (
                    <Link key={item.label} href={item.href} onClick={() => setOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start h-12 px-3 text-sm rounded-xl hover:bg-muted/80">
                        <div className="w-8 h-8 rounded-lg bg-muted/80 flex items-center justify-center mr-3">
                          <item.icon className="h-4 w-4 text-muted-foreground" />
                        </div>
                        {item.label}
                      </Button>
                    </Link>
                  )
                ))}
              </div>

              <Separator className="mx-3" />

              <div className="p-3">
                <Button
                  variant="outline"
                  className="w-full justify-start gap-3 h-11 rounded-xl border-border/60 hover:bg-muted/50"
                  onClick={() => window.open('https://github.com', '_blank')}
                >
                  <Github className="h-4 w-4" />
                  {t('header.githubRepo')}
                  <ExternalLink className="h-3 w-3 ml-auto opacity-50" />
                </Button>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-border/40 bg-muted/30">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                  <span className="font-medium">{t('common.version', { version: '1.0.0-beta' })}</span>
                </div>
                <p className="text-[10px] text-muted-foreground/70 mt-1.5 leading-relaxed">
                  {t('header.crossPlatformTool')}
                </p>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
