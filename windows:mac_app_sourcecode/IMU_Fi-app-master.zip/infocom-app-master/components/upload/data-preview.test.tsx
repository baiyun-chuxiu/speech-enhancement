import { render, screen, fireEvent } from '@testing-library/react';
import { DataPreview } from './data-preview';
import type { TextFileInfo } from '@/lib/types';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

// Mock data-parser module
jest.mock('@/lib/utils/data-parser', () => ({
  getColumnsForSensorType: jest.fn((sensorType: 'accelerometer' | 'gyroscope') =>
    sensorType === 'gyroscope'
      ? ['dataParser.timestamp', 'dataParser.gyroX', 'dataParser.gyroY', 'dataParser.gyroZ']
      : ['dataParser.timestamp', 'dataParser.accelX', 'dataParser.accelY', 'dataParser.accelZ']
  ),
  parseDataFile: jest.fn((content: string, customColumns?: string[]) => {
    if (!content || content.trim() === '') return null;
    if (content === 'invalid') return { rows: [], columns: [], stats: { totalRows: 0 }, errors: [] };
    const columns = customColumns ?? ['dataParser.timestamp', 'dataParser.accelX', 'dataParser.accelY', 'dataParser.accelZ'];
    return {
      columns,
      rows: Array.from({ length: 50 }, (_, i) => ({
        index: i,
        timestamp: `00:00:${(i * 0.1).toFixed(3)}`,
        values: [0.1 + i * 0.01, 0.2 + i * 0.01, 0.3 + i * 0.01],
      })),
      stats: {
        totalRows: 50,
        timeRange: { start: '00:00:00.000', end: '00:00:04.900', durationMs: 4900 },
        valueRanges: [
          { column: columns[1], min: 0.1, max: 0.59, avg: 0.345, stdDev: 0.15 },
          { column: columns[2], min: 0.2, max: 0.69, avg: 0.445, stdDev: 0.15 },
          { column: columns[3], min: 0.3, max: 0.79, avg: 0.545, stdDev: 0.15 },
        ],
      },
      errors: [],
    };
  }),
  getPagedData: jest.fn((parsedData, page: number, pageSize: number) => {
    if (!parsedData) return [];
    const start = page * pageSize;
    return parsedData.rows.slice(start, start + pageSize);
  }),
  formatValue: jest.fn((val: number) => val.toFixed(4)),
  formatDuration: jest.fn((ms: number) => {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    return `${m}分${s % 60}秒`;
  }),
}));

const mockTextFile: TextFileInfo = {
  id: 'test-file-1',
  name: 'sensor_data.txt',
  size: 2048,
  type: 'text/plain',
  lastModified: Date.now(),
  uploadedAt: new Date(),
  status: 'success',
  progress: 100,
  content: `00:00:00.000,0.1,0.2,0.3
00:00:00.100,0.11,0.21,0.31`,
  lineCount: 50,
  wordCount: 200,
};

describe('DataPreview', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Empty State', () => {
    it('renders empty state when no textFile provided', () => {
      render(<DataPreview textFile={null} />);
      expect(screen.getByText('数据预览')).toBeInTheDocument();
      expect(screen.getByText('上传 TXT 文件后显示数据预览')).toBeInTheDocument();
    });

    it('renders empty state when textFile has no content', () => {
      const emptyFile: TextFileInfo = {
        ...mockTextFile,
        content: undefined,
      };
      render(<DataPreview textFile={emptyFile} />);
      expect(screen.getByText('上传 TXT 文件后显示数据预览')).toBeInTheDocument();
    });

    it('applies custom className in empty state', () => {
      const { container } = render(
        <DataPreview textFile={null} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });
  });

  describe('Parse Error State', () => {
    it('renders error state when data cannot be parsed', () => {
      const invalidFile: TextFileInfo = {
        ...mockTextFile,
        content: 'invalid',
      };
      render(<DataPreview textFile={invalidFile} />);
      expect(screen.getByText('无法解析数据文件')).toBeInTheDocument();
    });
  });

  describe('With Valid Data', () => {
    it('renders title and row count', () => {
      render(<DataPreview textFile={mockTextFile} />);
      expect(screen.getByText('数据预览')).toBeInTheDocument();
      expect(screen.getByText('50 行')).toBeInTheDocument();
    });

    it('renders tabs for table, stats, and errors', () => {
      render(<DataPreview textFile={mockTextFile} />);
      expect(screen.getByText('表格')).toBeInTheDocument();
      expect(screen.getByText('统计')).toBeInTheDocument();
      expect(screen.getByText(/错误/)).toBeInTheDocument();
    });

    it('shows table view by default', () => {
      render(<DataPreview textFile={mockTextFile} />);
      // Column headers should be visible
      expect(screen.getByText('时间戳')).toBeInTheDocument();
      expect(screen.getByText('X轴 (m/s²)')).toBeInTheDocument();
      expect(screen.getByText('Y轴 (m/s²)')).toBeInTheDocument();
      expect(screen.getByText('Z轴 (m/s²)')).toBeInTheDocument();
    });

    it('contains table overflow inside a bounded preview panel', () => {
      render(<DataPreview textFile={mockTextFile} />);

      expect(screen.getByTestId('data-preview-table-panel')).toHaveClass('overflow-hidden', 'min-w-0');
    });

    it('applies custom className', () => {
      const { container } = render(
        <DataPreview textFile={mockTextFile} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });

    it('renders english preview labels when locale is en', () => {
      renderWithI18n(<DataPreview textFile={mockTextFile} />, { locale: 'en' });

      expect(screen.getByText('Data Preview')).toBeInTheDocument();
      expect(screen.getByText('Timestamp')).toBeInTheDocument();
      expect(screen.getByText('X (m/s²)')).toBeInTheDocument();
    });
  });

  describe('Tab Navigation', () => {
    it('renders stats tab trigger', () => {
      render(<DataPreview textFile={mockTextFile} />);
      const statsTab = screen.getByRole('tab', { name: '统计' });
      expect(statsTab).toBeInTheDocument();
    });

    it('renders errors tab trigger', () => {
      render(<DataPreview textFile={mockTextFile} />);
      const tabs = screen.getAllByRole('tab');
      const errorsTab = tabs.find(tab => tab.textContent?.includes('错误'));
      expect(errorsTab).toBeInTheDocument();
    });

    it('table tab is active by default', () => {
      render(<DataPreview textFile={mockTextFile} />);
      const tableTab = screen.getByRole('tab', { name: /表格/ });
      expect(tableTab).toHaveAttribute('data-state', 'active');
    });
  });

  describe('Pagination', () => {
    it('shows pagination controls when more than one page', () => {
      render(<DataPreview textFile={mockTextFile} />);
      
      // Should show page info
      expect(screen.getByText('1 / 3')).toBeInTheDocument();
    });

    it('navigates to next page', () => {
      render(<DataPreview textFile={mockTextFile} />);
      
      // Find next page button
      const buttons = screen.getAllByRole('button');
      const nextButton = buttons.find(btn => {
        const svg = btn.querySelector('svg');
        return svg && btn.className.includes('h-6');
      });
      
      if (nextButton) {
        fireEvent.click(nextButton);
      }
    });

    it('disables previous button on first page', () => {
      render(<DataPreview textFile={mockTextFile} />);
      
      // Find first page button (ChevronsLeft)
      const buttons = screen.getAllByRole('button');
      const firstDisabledBtn = buttons.find(btn => btn.hasAttribute('disabled'));
      
      expect(firstDisabledBtn).toBeDefined();
    });
  });

  describe('Sensor Type', () => {
    it('accepts accelerometer sensor type', () => {
      render(<DataPreview textFile={mockTextFile} sensorType="accelerometer" />);
      expect(screen.getByText('数据预览')).toBeInTheDocument();
    });

    it('accepts gyroscope sensor type', () => {
      render(<DataPreview textFile={mockTextFile} sensorType="gyroscope" />);
      expect(screen.getByText('数据预览')).toBeInTheDocument();
    });

    it('renders gyroscope-specific localized column labels', () => {
      render(<DataPreview textFile={mockTextFile} sensorType="gyroscope" />);

      expect(screen.getByText('X轴 (rad/s)')).toBeInTheDocument();
      expect(screen.getByText('Y轴 (rad/s)')).toBeInTheDocument();
      expect(screen.getByText('Z轴 (rad/s)')).toBeInTheDocument();
    });
  });

  describe('Error Display', () => {
    it('displays error count in tab', () => {
      render(<DataPreview textFile={mockTextFile} />);
      // The errors tab should show the count
      const tabs = screen.getAllByRole('tab');
      const errorsTab = tabs.find(tab => tab.textContent?.includes('错误'));
      expect(errorsTab).toBeInTheDocument();
    });
  });
});
