import { render, screen, fireEvent } from '@testing-library/react';
import { AudioAnalyzer } from './audio-analyzer';
import type { AudioAnalysis, ProcessedAudio } from '@/lib/types';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

const fillStyleAssignments: string[] = [];
const mockGradient = {
  addColorStop: jest.fn(),
};

const mockCanvasContext = {
  clearRect: jest.fn(),
  fillRect: jest.fn(),
  scale: jest.fn(),
  beginPath: jest.fn(),
  moveTo: jest.fn(),
  lineTo: jest.fn(),
  stroke: jest.fn(),
  createLinearGradient: jest.fn(() => mockGradient),
  strokeStyle: '',
  lineWidth: 1,
  setLineDash: jest.fn(),
  fillText: jest.fn(),
  font: '',
  textAlign: '',
};

let currentFillStyle = '';

Object.defineProperty(mockCanvasContext, 'fillStyle', {
  configurable: true,
  get: () => currentFillStyle,
  set: (value: string) => {
    currentFillStyle = value;
    fillStyleAssignments.push(value);
  },
});

// Mock canvas context
const mockGetContext = jest.fn(() => mockCanvasContext);

HTMLCanvasElement.prototype.getContext = mockGetContext as unknown as typeof HTMLCanvasElement.prototype.getContext;
HTMLCanvasElement.prototype.getBoundingClientRect = jest.fn(() => ({
  width: 300,
  height: 100,
  top: 0,
  left: 0,
  bottom: 100,
  right: 300,
  x: 0,
  y: 0,
  toJSON: () => {},
}));

const mockAudio: ProcessedAudio = {
  id: 'test-audio-1',
  data: new ArrayBuffer(1024),
  url: 'blob:test-url',
  format: 'wav',
  duration: 10.5,
  sampleRate: 44100,
  size: 1024,
  createdAt: new Date('2024-01-01'),
};

const mockAnalysis: AudioAnalysis = {
  duration: 10.5,
  sampleRate: 44100,
  channels: 2,
  bitRate: 128000,
  format: 'wav',
  waveformData: [0.1, 0.3, 0.5, 0.7, 0.9, 0.6, 0.4, 0.2],
  peakAmplitude: 0.9,
  averageAmplitude: 0.5,
  silenceRatio: 0.1,
};

describe('AudioAnalyzer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    currentFillStyle = '';
    fillStyleAssignments.length = 0;
    document.documentElement.style.setProperty('--primary', 'oklch(0.55 0.25 260)');
    document.documentElement.style.setProperty('--muted-foreground', 'oklch(0.5 0.02 260)');
  });

  describe('Empty State', () => {
    it('renders empty state when no audio and no analysis', () => {
      render(<AudioAnalyzer audio={null} analysis={null} />);
      expect(screen.getByText('音频分析')).toBeInTheDocument();
      expect(screen.getByText('等待音频数据...')).toBeInTheDocument();
      expect(screen.getByText('处理完成后将自动分析')).toBeInTheDocument();
    });

    it('applies custom className in empty state', () => {
      const { container } = render(
        <AudioAnalyzer audio={null} analysis={null} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });
  });

  describe('With Data', () => {
    it('renders title when audio is provided', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);
      expect(screen.getByText('音频分析')).toBeInTheDocument();
    });

    it('renders tabs for waveform, frequency, and info', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);
      expect(screen.getByText('波形')).toBeInTheDocument();
      expect(screen.getByText('频谱')).toBeInTheDocument();
      expect(screen.getByText('信息')).toBeInTheDocument();
    });

    it('shows waveform tab content by default', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);
      expect(screen.getByText('音频波形可视化')).toBeInTheDocument();
    });

    it('renders frequency tab trigger', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);
      const frequencyTab = screen.getByRole('tab', { name: '频谱' });
      expect(frequencyTab).toBeInTheDocument();
    });

    it('renders info tab trigger', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);
      const infoTab = screen.getByRole('tab', { name: '信息' });
      expect(infoTab).toBeInTheDocument();
    });

    it('has canvas element for visualization', () => {
      const { container } = render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);
      const canvas = container.querySelector('canvas');
      expect(canvas).toBeInTheDocument();
    });

    it('applies custom className with data', () => {
      const { container } = render(
        <AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} className="custom-class" />
      );
      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });

    it('reflows info metrics into a narrow-friendly grid', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} />);

      const infoTab = screen.getByRole('tab', { name: '信息' });
      fireEvent.mouseDown(infoTab);
      fireEvent.click(infoTab);

      expect(screen.getByTestId('analysis-primary-metrics')).toHaveClass('grid-cols-1', 'sm:grid-cols-2');
      expect(screen.getByTestId('analysis-amplitude-metrics')).toHaveClass('grid-cols-1', 'sm:grid-cols-2');
    });

    it('resolves theme colors before drawing the waveform canvas', () => {
      render(<AudioAnalyzer audio={mockAudio} analysis={mockAnalysis} currentTime={5.25} />);

      expect(fillStyleAssignments).toContain('oklch(0.55 0.25 260)');
      expect(fillStyleAssignments).toContain('oklch(0.5 0.02 260 / 0.3)');
    });
  });

  describe('Current Time Progress', () => {
    it('accepts currentTime prop for playback progress', () => {
      render(
        <AudioAnalyzer
          audio={mockAudio}
          analysis={mockAnalysis}
          currentTime={5.25}
        />
      );
      expect(screen.getByText('音频分析')).toBeInTheDocument();
    });
  });

  describe('Edge Cases', () => {
    it('renders with analysis only (no audio)', () => {
      render(<AudioAnalyzer audio={null} analysis={mockAnalysis} />);
      expect(screen.getByText('音频分析')).toBeInTheDocument();
      expect(screen.getByText('波形')).toBeInTheDocument();
    });

    it('handles zero duration in analysis', () => {
      const zeroAnalysis = { ...mockAnalysis, duration: 0 };
      render(<AudioAnalyzer audio={mockAudio} analysis={zeroAnalysis} />);
      // Component should render without errors
      expect(screen.getByText('音频分析')).toBeInTheDocument();
    });

    it('handles zero peak amplitude in analysis', () => {
      const zeroAmplitude = { ...mockAnalysis, peakAmplitude: 0 };
      render(<AudioAnalyzer audio={mockAudio} analysis={zeroAmplitude} />);
      // Component should render without errors
      expect(screen.getByText('音频分析')).toBeInTheDocument();
    });

    it('shows translated unavailable text instead of raw N/A in English locale', () => {
      const unavailableAnalysis = { ...mockAnalysis, peakAmplitude: 0 };

      renderWithI18n(<AudioAnalyzer audio={mockAudio} analysis={unavailableAnalysis} />, {
        locale: 'en',
      });

      fireEvent.click(screen.getByRole('tab', { name: 'Info' }));

      expect(screen.getByText('Unavailable')).toBeInTheDocument();
      expect(screen.queryByText('N/A')).not.toBeInTheDocument();
    });
  });
});
