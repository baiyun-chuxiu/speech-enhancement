import { render, screen, fireEvent } from '@testing-library/react';
import { FileUploader } from './file-uploader';
import type { TextFileInfo, AudioFileInfo } from '@/lib/types';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

// Mock formatFileSize
jest.mock('@/hooks/useFileUpload', () => ({
  formatFileSize: (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  },
}));

const mockTextFile: TextFileInfo = {
  id: 'test-file-1',
  name: 'test.txt',
  size: 1024,
  type: 'text/plain',
  lastModified: Date.now(),
  uploadedAt: new Date('2024-01-15T10:30:00'),
  status: 'success',
  progress: 100,
  content: 'test content',
  lineCount: 10,
  wordCount: 50,
};

const mockAudioFile: AudioFileInfo = {
  id: 'test-audio-1',
  name: 'test.mp3',
  size: 5242880,
  type: 'audio/mpeg',
  lastModified: Date.now(),
  uploadedAt: new Date('2024-01-15T10:30:00'),
  status: 'success',
  progress: 100,
  duration: 180,
  sampleRate: 44100,
  channels: 2,
  format: 'mp3',
};

describe('FileUploader', () => {
  const mockOnFileSelect = jest.fn();
  const mockOnRemove = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Text File Uploader - Empty State', () => {
    it('renders upload area for text files', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('文本文件')).toBeInTheDocument();
      expect(screen.getByText('点击或拖拽上传')).toBeInTheDocument();
      expect(screen.getByText('支持 .txt 格式')).toBeInTheDocument();
    });

    it('renders custom title and description', () => {
      render(
        <FileUploader
          type="text"
          title="自定义标题"
          description="自定义描述"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('自定义标题')).toBeInTheDocument();
      expect(screen.getByText('自定义描述')).toBeInTheDocument();
    });
  });

  describe('Audio File Uploader - Empty State', () => {
    it('renders upload area for audio files', () => {
      render(
        <FileUploader
          type="audio"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('音频文件')).toBeInTheDocument();
      expect(screen.getByText('点击或拖拽上传')).toBeInTheDocument();
      expect(screen.getByText('支持 MP3, WAV, M4A, OGG, FLAC, AAC')).toBeInTheDocument();
    });

    it('renders english upload copy when locale is en', () => {
      renderWithI18n(
        <FileUploader
          type="audio"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />,
        { locale: 'en' }
      );

      expect(screen.getByText('Audio File')).toBeInTheDocument();
      expect(screen.getByText('Click or drag to upload')).toBeInTheDocument();
    });
  });

  describe('File Selection', () => {
    it('calls onFileSelect when file is selected via click', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      const uploadArea = screen.getByRole('button');
      fireEvent.click(uploadArea);

      // The input should trigger, but we can't easily test file selection
      // without more complex mocking
    });

    it('handles file drop', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      const uploadArea = screen.getByRole('button');
      const file = new File(['test content'], 'test.txt', { type: 'text/plain' });

      fireEvent.drop(uploadArea, {
        dataTransfer: {
          files: [file],
        },
      });

      expect(mockOnFileSelect).toHaveBeenCalledWith(file);
    });

    it('handles drag over', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      const uploadArea = screen.getByRole('button');
      fireEvent.dragOver(uploadArea);

      // Should not throw error
    });

    it('handles keyboard Enter to trigger upload', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      const uploadArea = screen.getByRole('button');
      fireEvent.keyDown(uploadArea, { key: 'Enter' });

      // Should trigger click behavior
    });
  });

  describe('Uploading State', () => {
    it('shows upload progress', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={true}
          progress={45}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('上传中...')).toBeInTheDocument();
      expect(screen.getByText('45%')).toBeInTheDocument();
    });

    it('shows progress bar during upload', () => {
      const { container } = render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={true}
          progress={75}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      // Progress component should be rendered
      const progressBar = container.querySelector('[role="progressbar"]');
      expect(progressBar).toBeInTheDocument();
    });
  });

  describe('File Uploaded State - Text', () => {
    it('displays file info for text file', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={mockTextFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('test.txt')).toBeInTheDocument();
      expect(screen.getByText('1.0 KB')).toBeInTheDocument();
      expect(screen.getByText('已上传')).toBeInTheDocument();
    });

    it('displays line count for text file', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={mockTextFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('行数')).toBeInTheDocument();
      expect(screen.getByText('10')).toBeInTheDocument();
      expect(screen.getByText('字数')).toBeInTheDocument();
      expect(screen.getByText('50')).toBeInTheDocument();
    });

    it('calls onRemove when remove button is clicked', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={mockTextFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      const removeButton = screen.getByRole('button');
      fireEvent.click(removeButton);

      expect(mockOnRemove).toHaveBeenCalled();
    });
  });

  describe('File Uploaded State - Audio', () => {
    it('displays file info for audio file', () => {
      render(
        <FileUploader
          type="audio"
          fileInfo={mockAudioFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('test.mp3')).toBeInTheDocument();
      expect(screen.getByText('5.0 MB')).toBeInTheDocument();
    });

    it('displays duration for audio file', () => {
      render(
        <FileUploader
          type="audio"
          fileInfo={mockAudioFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('时长')).toBeInTheDocument();
      expect(screen.getByText('3:00')).toBeInTheDocument();
    });

    it('displays format for audio file', () => {
      render(
        <FileUploader
          type="audio"
          fileInfo={mockAudioFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('格式')).toBeInTheDocument();
      // The format is displayed in uppercase via CSS class, but the actual text is lowercase
      expect(screen.getByText('mp3')).toBeInTheDocument();
    });
  });

  describe('Error State', () => {
    it('displays error message', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error="文件大小超出限制"
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      expect(screen.getByText('文件大小超出限制')).toBeInTheDocument();
    });

    it('shows error styling on upload area', () => {
      const { container } = render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error="上传失败"
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      const uploadArea = container.querySelector('.border-destructive');
      expect(uploadArea).toBeInTheDocument();
    });
  });

  describe('Disabled State', () => {
    it('disables upload area when disabled prop is true', () => {
      const { container } = render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
          disabled={true}
        />
      );

      const uploadArea = container.querySelector('.opacity-50');
      expect(uploadArea).toBeInTheDocument();
    });

    it('does not call onFileSelect when disabled and file dropped', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={null}
          isUploading={false}
          progress={0}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
          disabled={true}
        />
      );

      const uploadArea = screen.getByRole('button');
      const file = new File(['test'], 'test.txt', { type: 'text/plain' });

      fireEvent.drop(uploadArea, {
        dataTransfer: {
          files: [file],
        },
      });

      expect(mockOnFileSelect).not.toHaveBeenCalled();
    });

    it('disables remove button when disabled and file uploaded', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={mockTextFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
          disabled={true}
        />
      );

      const removeButton = screen.getByRole('button');
      expect(removeButton).toBeDisabled();
    });
  });

  describe('File Already Selected', () => {
    it('does not trigger file selection when file is already uploaded', () => {
      render(
        <FileUploader
          type="text"
          fileInfo={mockTextFile}
          isUploading={false}
          progress={100}
          error={null}
          onFileSelect={mockOnFileSelect}
          onRemove={mockOnRemove}
        />
      );

      // Upload area should not be visible when file is uploaded
      expect(screen.queryByText('点击或拖拽上传')).not.toBeInTheDocument();
    });
  });
});
