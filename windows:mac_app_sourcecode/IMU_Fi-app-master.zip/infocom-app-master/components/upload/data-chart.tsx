'use client';

import { useMemo, useRef, useEffect, useCallback, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { TrendingUp, ZoomIn, ZoomOut, RotateCcw, LineChart } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTranslations } from 'next-intl';
import {
  parseDataFile,
  getChartData,
  formatTimestamp,
  getColumnsForSensorType,
  type ParsedData,
} from '@/lib/utils/data-parser';
import type { TextFileInfo } from '@/lib/types';
import type { SensorType } from '@/lib/utils/data-parser';
import { localizeDataColumnLabel } from '@/lib/utils/upload-formatters';

interface DataChartProps {
  textFile: TextFileInfo | null;
  sensorType?: SensorType;
  className?: string;
}

const COLORS = [
  'hsl(220, 70%, 50%)', // 蓝色 - X轴
  'hsl(142, 70%, 45%)', // 绿色 - Y轴
  'hsl(0, 70%, 50%)',   // 红色 - Z轴
];

// Legend labels are set dynamically via i18n in the component

export function DataChart({ textFile, sensorType, className }: DataChartProps) {
  const t = useTranslations();
  const resolvedSensorType = sensorType ?? 'accelerometer';
  const sensorColumns = useMemo(
    () => getColumnsForSensorType(resolvedSensorType),
    [resolvedSensorType]
  );
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState(0);
  const [hoveredPoint, setHoveredPoint] = useState<{
    localX: number;
    time: string;
    values: { name: string; value: number; color: string }[];
  } | null>(null);

  const textContent = textFile?.content;
  const parsedData = useMemo<ParsedData | null>(() => {
    if (!textContent) return null;
    return parseDataFile(textContent, sensorColumns);
  }, [sensorColumns, textContent]);

  const chartData = useMemo(() => {
    if (!parsedData) return null;
    return getChartData(parsedData, 1000);
  }, [parsedData]);

  const drawChart = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container || !chartData) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = container.getBoundingClientRect();
    const width = rect.width;
    const height = 160;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.scale(dpr, dpr);

    const padding = { top: 20, right: 20, bottom: 30, left: 50 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // 清空画布
    ctx.clearRect(0, 0, width, height);

    // 背景
    ctx.fillStyle = 'hsl(var(--muted) / 0.3)';
    ctx.fillRect(padding.left, padding.top, chartWidth, chartHeight);

    const { timestamps, series } = chartData;
    if (timestamps.length === 0) return;

    // 计算可见范围
    const visibleCount = Math.floor(timestamps.length / zoom);
    const startIdx = Math.floor(offset * (timestamps.length - visibleCount));
    const endIdx = Math.min(startIdx + visibleCount, timestamps.length);

    const visibleTimestamps = timestamps.slice(startIdx, endIdx);
    const visibleSeries = series.map(s => ({
      ...s,
      data: s.data.slice(startIdx, endIdx),
    }));

    // 计算数据范围
    const allValues = visibleSeries.flatMap(s => s.data);
    const minValue = Math.min(...allValues);
    const maxValue = Math.max(...allValues);
    const valueRange = maxValue - minValue || 1;
    const valuePadding = valueRange * 0.1;

    const yMin = minValue - valuePadding;
    const yMax = maxValue + valuePadding;
    const yRange = yMax - yMin;

    // 绘制网格线
    ctx.strokeStyle = 'hsl(var(--border))';
    ctx.lineWidth = 0.5;
    ctx.setLineDash([2, 2]);

    // 水平网格线
    const yGridCount = 5;
    for (let i = 0; i <= yGridCount; i++) {
      const y = padding.top + (chartHeight / yGridCount) * i;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();

      // Y轴标签
      const value = yMax - (yRange / yGridCount) * i;
      ctx.fillStyle = 'hsl(var(--muted-foreground))';
      ctx.font = '10px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(value.toFixed(4), padding.left - 5, y + 3);
    }

    ctx.setLineDash([]);

    // 绘制零线
    if (yMin < 0 && yMax > 0) {
      const zeroY = padding.top + chartHeight * (yMax / yRange);
      ctx.strokeStyle = 'hsl(var(--foreground) / 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(padding.left, zeroY);
      ctx.lineTo(width - padding.right, zeroY);
      ctx.stroke();
    }

    // 绘制数据线
    visibleSeries.forEach((s, seriesIdx) => {
      ctx.strokeStyle = COLORS[seriesIdx] || COLORS[0];
      ctx.lineWidth = 1.5;
      ctx.beginPath();

      s.data.forEach((value, i) => {
        const x = padding.left + (i / (s.data.length - 1)) * chartWidth;
        const y = padding.top + chartHeight * (1 - (value - yMin) / yRange);

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });

      ctx.stroke();
    });

    // 绘制时间轴标签
    ctx.fillStyle = 'hsl(var(--muted-foreground))';
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    
    const timeLabels = 5;
    for (let i = 0; i <= timeLabels; i++) {
      const idx = Math.floor((visibleTimestamps.length - 1) * (i / timeLabels));
      const x = padding.left + (idx / (visibleTimestamps.length - 1)) * chartWidth;
      const time = formatTimestamp(visibleTimestamps[idx] || 0);
      ctx.fillText(time.substring(0, 8), x, height - 8);
    }
  }, [chartData, zoom, offset]);

  useEffect(() => {
    drawChart();

    const handleResize = () => drawChart();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [drawChart]);

  const handleZoomIn = () => setZoom(z => Math.min(z * 1.5, 10));
  const handleZoomOut = () => setZoom(z => Math.max(z / 1.5, 1));
  const handleReset = () => {
    setZoom(1);
    setOffset(0);
  };

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!chartData || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const padding = { left: 50, right: 20 };
    const chartWidth = rect.width - padding.left - padding.right;

    if (x < padding.left || x > rect.width - padding.right) {
      setHoveredPoint(null);
      return;
    }

    const ratio = (x - padding.left) / chartWidth;
    const visibleCount = Math.floor(chartData.timestamps.length / zoom);
    const startIdx = Math.floor(offset * (chartData.timestamps.length - visibleCount));
    const idx = Math.floor(startIdx + ratio * visibleCount);

    if (idx >= 0 && idx < chartData.timestamps.length) {
      const containerWidth = rect.width;
      const localX = Math.min(x, containerWidth - 130);
      setHoveredPoint({
        localX,
        time: formatTimestamp(chartData.timestamps[idx]),
        values: chartData.series.map((s, i) => ({
          name: localizeDataColumnLabel(s.name, t),
          value: s.data[idx - startIdx] || 0,
          color: COLORS[i],
        })),
      });
    }
  }, [chartData, zoom, offset, t]);

  const handleMouseLeave = () => setHoveredPoint(null);

  if (!textFile || !parsedData || !chartData || parsedData.rows.length === 0) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="h-4 w-4" />
            {t('dataChart.trendChart')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
            <TrendingUp className="h-12 w-12 mb-3 opacity-50" />
            <p className="text-sm">{t('dataChart.uploadToShowChart')}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("min-w-0 w-full transition-all duration-200 hover:shadow-soft-md border-border/60 bg-card/95 backdrop-blur-sm", className)}>
      <CardHeader className="pb-2 lg:pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm lg:text-base">
            <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
              <LineChart className="h-3.5 w-3.5 text-primary" />
            </div>
            <span className="font-medium">{t('dataChart.title')}</span>
          </CardTitle>
          <div className="flex items-center gap-0.5 lg:gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-6 w-6 lg:h-7 lg:w-7"
                  onClick={handleZoomIn}
                >
                  <ZoomIn className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>{t('dataChart.zoomIn')}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-6 w-6 lg:h-7 lg:w-7"
                  onClick={handleZoomOut}
                  disabled={zoom <= 1}
                >
                  <ZoomOut className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>{t('dataChart.zoomOut')}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-6 w-6 lg:h-7 lg:w-7"
                  onClick={handleReset}
                >
                  <RotateCcw className="h-3 w-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>{t('common.reset')}</TooltipContent>
            </Tooltip>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 lg:space-y-4">
        {/* 图例 */}
        <div className="flex flex-wrap items-center justify-center gap-3 bg-muted/30 rounded-lg py-2 px-3 lg:gap-4">
          {chartData.series.map((series, i) => (
            <div key={`${series.name}-${i}`} className="flex items-center gap-1.5">
              <div
                className="w-2.5 h-2.5 lg:w-3 lg:h-3 rounded-full shadow-sm"
                style={{ backgroundColor: COLORS[i] }}
              />
              <span className="text-[10px] lg:text-xs font-medium">{localizeDataColumnLabel(series.name, t)}</span>
            </div>
          ))}
        </div>

        {/* 图表 */}
        <div
          ref={containerRef}
          data-testid="data-chart-surface"
          className="relative min-h-[160px] min-w-0 touch-pan-x rounded-xl overflow-hidden border border-border/40 bg-muted/10"
        >
          <canvas
            ref={canvasRef}
            className="w-full cursor-crosshair"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            onTouchStart={handleMouseLeave}
          />
          
          {/* 悬停提示 */}
          {hoveredPoint && (
            <div
              className="absolute z-10 bg-popover border rounded-lg shadow-lg p-1.5 lg:p-2 pointer-events-none"
              style={{
                left: hoveredPoint.localX,
                top: 10,
              }}
            >
              <p className="text-[10px] lg:text-xs font-mono mb-1">{hoveredPoint.time}</p>
              {hoveredPoint.values.map((v, i) => (
                <div key={i} className="flex items-center gap-1.5 lg:gap-2 text-[10px] lg:text-xs">
                  <div
                    className="w-1.5 h-1.5 lg:w-2 lg:h-2 rounded-sm"
                    style={{ backgroundColor: v.color }}
                  />
                  <span className="text-muted-foreground">{v.name}:</span>
                  <span className="font-mono">{v.value.toFixed(4)}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 缩放滑块 */}
        {zoom > 1 && (
          <div className="px-1 lg:px-2 space-y-1">
            <Slider
              value={[offset]}
              min={0}
              max={1}
              step={0.01}
              onValueChange={(value) => setOffset(value[0])}
              className="cursor-pointer"
            />
            <p className="text-[10px] lg:text-xs text-center text-muted-foreground mt-1">
              {t('dataChart.dragToView', { zoom: zoom.toFixed(1) })}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
