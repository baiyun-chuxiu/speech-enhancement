'use client';

import { useState, useMemo, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Table as ShadcnTable,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import {
  Table,
  FileText,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  AlertCircle,
  TrendingUp,
  Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useLocale, useTranslations } from 'next-intl';
import {
  parseDataFile,
  getPagedData,
  formatValue,
  formatDuration,
  getColumnsForSensorType,
  type ParsedData,
  type DataRow,
} from '@/lib/utils/data-parser';
import type { TextFileInfo } from '@/lib/types';
import type { SensorType } from '@/lib/utils/data-parser';
import { formatLocaleNumber, localizeDataColumnLabel } from '@/lib/utils/upload-formatters';

interface DataPreviewProps {
  textFile: TextFileInfo | null;
  sensorType?: SensorType;
  className?: string;
}

const PAGE_SIZE = 20;

export function DataPreview({ textFile, sensorType, className }: DataPreviewProps) {
  const t = useTranslations();
  const locale = useLocale();
  const [activeTab, setActiveTab] = useState('table');
  const [currentPage, setCurrentPage] = useState(0);
  const resolvedSensorType = sensorType ?? 'accelerometer';
  const columnsForSensorType = getColumnsForSensorType(resolvedSensorType);

  const textContent = textFile?.content;
  const parsedData = useMemo<ParsedData | null>(() => {
    if (!textContent) return null;
    return parseDataFile(textContent, columnsForSensorType);
  }, [columnsForSensorType, textContent]);

  const pagedRows = useMemo<DataRow[]>(() => {
    if (!parsedData) return [];
    return getPagedData(parsedData, currentPage, PAGE_SIZE);
  }, [parsedData, currentPage]);

  const totalPages = useMemo(() => {
    if (!parsedData) return 0;
    return Math.ceil(parsedData.rows.length / PAGE_SIZE);
  }, [parsedData]);

  const goToPage = useCallback((page: number) => {
    setCurrentPage(Math.max(0, Math.min(page, totalPages - 1)));
  }, [totalPages]);

  if (!textFile || !textFile.content) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" />
            {t('dataPreview.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
            <Table className="h-12 w-12 mb-3 opacity-50" />
            <p className="text-sm">{t('dataPreview.uploadToPreview')}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!parsedData || parsedData.rows.length === 0) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" />
            {t('dataPreview.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive" className="rounded-lg">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{t('dataPreview.cannotParse')}</AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  const { stats, errors, columns } = parsedData;

  return (
      <Card className={cn("min-w-0 w-full transition-all duration-200 hover:shadow-soft-md border-border/60 bg-card/95 backdrop-blur-sm", className)}>
      <CardHeader className="pb-2 lg:pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm lg:text-base">
            <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-3.5 w-3.5 text-primary" />
            </div>
            <span className="font-medium">{t('dataPreview.title')}</span>
          </CardTitle>
          <Badge variant="secondary" className="text-[10px] lg:text-xs font-medium px-2 py-0.5">
            {t('common.rows', { count: formatLocaleNumber(locale, stats.totalRows) })}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 lg:space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full grid grid-cols-3 h-10 p-1 bg-muted/50 rounded-xl">
            <TabsTrigger value="table" className="text-xs gap-1.5 px-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Table className="h-3.5 w-3.5" />
              {t('dataPreview.table')}
            </TabsTrigger>
            <TabsTrigger value="stats" className="text-xs gap-1.5 px-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <BarChart3 className="h-3.5 w-3.5" />
              {t('dataPreview.stats')}
            </TabsTrigger>
            <TabsTrigger value="errors" className="text-xs gap-1 px-2">
              <AlertCircle className="h-3 w-3 hidden sm:block" />
              {t('dataPreview.errors')} ({errors.length})
            </TabsTrigger>
          </TabsList>

          {/* 表格视图 */}
          <TabsContent value="table" className="mt-2 lg:mt-3">
            <ScrollArea
              data-testid="data-preview-table-panel"
              className="h-[200px] lg:h-[220px] min-w-0 overflow-hidden rounded-lg border"
            >
              <ShadcnTable className="min-w-[360px]">
                <TableHeader className="sticky top-0 z-10 bg-muted/90 backdrop-blur">
                  <TableRow>
                    <TableHead className="w-10 lg:w-12 text-[10px] lg:text-xs text-center">
                      #
                    </TableHead>
                    {columns.map((col, i) => (
                      <TableHead
                        key={i}
                        className={cn(
                          "text-[10px] lg:text-xs text-center",
                          i === 0 ? "min-w-[80px] lg:min-w-[100px]" : "min-w-[60px] lg:min-w-[80px]"
                        )}
                      >
                        {localizeDataColumnLabel(col, t)}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pagedRows.map((row, rowIdx) => (
                    <TableRow
                      key={row.index}
                      className={cn(
                        rowIdx % 2 === 0 ? "bg-transparent" : "bg-muted/20",
                        "hover:bg-primary/5"
                      )}
                    >
                      <TableCell className="w-10 lg:w-12 text-[10px] lg:text-xs text-muted-foreground text-center font-medium">
                        {row.index + 1}
                      </TableCell>
                      <TableCell className="text-[10px] lg:text-xs font-mono text-center min-w-[80px] lg:min-w-[100px] text-muted-foreground">
                        {row.timestamp}
                      </TableCell>
                      {row.values.map((val, i) => (
                        <TableCell
                          key={i}
                          className={cn(
                            "text-[10px] lg:text-xs font-mono text-center min-w-[60px] lg:min-w-[80px] font-medium tabular-nums",
                            val < 0 ? "text-red-500 dark:text-red-400" : val > 0 ? "text-green-600 dark:text-green-400" : "text-foreground"
                          )}
                        >
                          {formatValue(val)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </ShadcnTable>
            </ScrollArea>

            {/* 分页控制 */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between mt-2 lg:mt-3">
                <p className="text-[10px] lg:text-xs text-muted-foreground">
                  {currentPage + 1} / {totalPages}
                </p>
                <div className="flex items-center gap-0.5 lg:gap-1">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-6 w-6 lg:h-7 lg:w-7"
                        onClick={() => goToPage(0)}
                        disabled={currentPage === 0}
                      >
                        <ChevronsLeft className="h-3 w-3" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>{t('dataPreview.firstPage')}</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-6 w-6 lg:h-7 lg:w-7"
                        onClick={() => goToPage(currentPage - 1)}
                        disabled={currentPage === 0}
                      >
                        <ChevronLeft className="h-3 w-3" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>{t('dataPreview.prevPage')}</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-6 w-6 lg:h-7 lg:w-7"
                        onClick={() => goToPage(currentPage + 1)}
                        disabled={currentPage >= totalPages - 1}
                      >
                        <ChevronRight className="h-3 w-3" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>{t('dataPreview.nextPage')}</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-6 w-6 lg:h-7 lg:w-7"
                        onClick={() => goToPage(totalPages - 1)}
                        disabled={currentPage >= totalPages - 1}
                      >
                        <ChevronsRight className="h-3 w-3" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>{t('dataPreview.lastPage')}</TooltipContent>
                  </Tooltip>
                </div>
              </div>
            )}
          </TabsContent>

          {/* 统计视图 */}
          <TabsContent value="stats" className="mt-3 lg:mt-4 space-y-3">
            {/* 时间范围 */}
            <div className="bg-muted/50 rounded-lg p-2.5 lg:p-3 space-y-2">
              <h4 className="text-[10px] lg:text-xs font-medium flex items-center gap-1.5">
                <Clock className="h-3 w-3 lg:h-3.5 lg:w-3.5" />
                {t('dataPreview.timeRange')}
              </h4>
              <div className="grid grid-cols-1 gap-2 text-[10px] lg:text-xs sm:grid-cols-2">
                <div>
                  <p className="text-muted-foreground">{t('dataPreview.start')}</p>
                  <p className="font-mono truncate">{stats.timeRange.start}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">{t('dataPreview.end')}</p>
                  <p className="font-mono truncate">{stats.timeRange.end}</p>
                </div>
              </div>
              <div className="text-[10px] lg:text-xs">
                <p className="text-muted-foreground">{t('dataPreview.durationLabel')}</p>
                <p className="font-medium">{formatDuration(stats.timeRange.durationMs, locale, t)}</p>
              </div>
            </div>

            <Separator />

            {/* 数值统计 */}
            <div className="space-y-2 lg:space-y-3">
              <h4 className="text-[10px] lg:text-xs font-medium flex items-center gap-1.5">
                <TrendingUp className="h-3 w-3 lg:h-3.5 lg:w-3.5" />
                {t('dataPreview.valueStats')}
              </h4>
              {stats.valueRanges.map((range, i) => (
                <div key={i} className="bg-muted/50 rounded-lg p-2.5 lg:p-3 space-y-1.5 lg:space-y-2">
                  <Badge variant="outline" className="text-[10px] lg:text-xs">
                    {localizeDataColumnLabel(range.column, t)}
                  </Badge>
                  <div className="grid grid-cols-1 gap-2 text-[10px] lg:text-xs sm:grid-cols-2 xl:grid-cols-4">
                    <div>
                      <p className="text-muted-foreground">{t('dataPreview.min')}</p>
                      <p className={cn("font-mono", range.min < 0 && "text-red-500")}>
                        {formatValue(range.min)}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{t('dataPreview.max')}</p>
                      <p className={cn("font-mono", range.max > 0 && "text-green-600")}>
                        {formatValue(range.max)}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{t('dataPreview.avg')}</p>
                      <p className="font-mono">{formatValue(range.avg)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{t('dataPreview.stdDev')}</p>
                      <p className="font-mono">{formatValue(range.stdDev)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* 错误视图 */}
          <TabsContent value="errors" className="mt-3 lg:mt-4">
            {errors.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 lg:py-8 text-muted-foreground">
                <AlertCircle className="h-6 w-6 lg:h-8 lg:w-8 mb-2 opacity-50" />
                <p className="text-xs lg:text-sm">{t('dataPreview.noErrors')}</p>
              </div>
            ) : (
              <ScrollArea className="h-[180px] lg:h-[200px]">
                <div className="space-y-2">
                  {errors.map((error, i) => (
                    <div
                      key={i}
                      className="p-2 bg-destructive/10 rounded-lg text-[10px] lg:text-xs space-y-1"
                    >
                      <div className="flex items-center gap-2">
                        <Badge variant="destructive" className="text-[10px]">
                          {t('dataPreview.line', { line: error.line })}
                        </Badge>
                        <span className="text-destructive">{error.message.startsWith('errors.') ? t(error.message) : error.message}</span>
                      </div>
                      <p className="font-mono text-muted-foreground truncate">
                        {error.raw}
                      </p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
