'use client';

import { useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Upload, 
  FileText, 
  Music, 
  X, 
  CheckCircle, 
  AlertCircle,
  Loader2,
  Sparkles,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatFileSize } from '@/hooks/useFileUpload';
import { useLocale, useTranslations } from 'next-intl';
import type { FileInfo, TextFileInfo, AudioFileInfo } from '@/lib/types';
import { formatShortDateTimeLabel } from '@/lib/utils/upload-formatters';

interface FileUploaderProps {
  type: 'text' | 'audio';
  title?: string;
  description?: string;
  fileInfo: FileInfo | null;
  isUploading: boolean;
  progress: number;
  error: string | null;
  onFileSelect: (file: File) => void;
  onRemove: () => void;
  disabled?: boolean;
}

export function FileUploader({
  type,
  title: customTitle,
  description: customDescription,
  fileInfo,
  isUploading,
  progress,
  error,
  onFileSelect,
  onRemove,
  disabled = false,
}: FileUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const t = useTranslations();
  const locale = useLocale();

  const accept = type === 'text' ? '.txt,text/plain' : '.mp3,.wav,.m4a,.ogg,.flac,.aac,audio/*';
  const Icon = type === 'text' ? FileText : Music;
  const title = customTitle || (type === 'text' ? t('fileUploader.textFile') : t('fileUploader.audioFile'));
  const description = customDescription || (type === 'text' 
    ? t('fileUploader.supportTxt') 
    : t('fileUploader.supportAudio'));

  const handleClick = useCallback(() => {
    if (!disabled && !fileInfo) {
      inputRef.current?.click();
    }
  }, [disabled, fileInfo]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  }, [onFileSelect]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (disabled || fileInfo) return;
    
    const file = e.dataTransfer.files[0];
    if (file) {
      onFileSelect(file);
    }
  }, [disabled, fileInfo, onFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const formatDate = (date: Date) => {
    return formatShortDateTimeLabel(date, locale);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="min-w-0 w-full transition-all duration-200 hover:shadow-soft-md border-border/60 bg-card/95 backdrop-blur-sm">
      <CardHeader className="pb-1.5 lg:pb-2 pt-3 lg:pt-4">
        <CardTitle className="flex items-center gap-2 text-xs lg:text-sm">
          <div className={cn(
            "w-5 h-5 lg:w-6 lg:h-6 rounded-md flex items-center justify-center transition-colors",
            fileInfo?.status === 'success' 
              ? "bg-green-500/10" 
              : "bg-primary/10"
          )}>
            <Icon className={cn(
              "h-3 w-3 lg:h-3.5 lg:w-3.5",
              fileInfo?.status === 'success' 
                ? "text-green-600 dark:text-green-400" 
                : "text-primary"
            )} />
          </div>
          <span className="font-medium">{title}</span>
          {fileInfo?.status === 'success' && (
            <Sparkles className="h-3 w-3 text-green-500 animate-pulse" />
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0 pb-3 lg:pb-4">
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          onChange={handleChange}
          className="hidden"
          disabled={disabled}
        />

        {!fileInfo && !isUploading && (
          <div
            onClick={handleClick}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && handleClick()}
            className={cn(
              "border-2 border-dashed rounded-xl p-4 lg:p-5 text-center cursor-pointer",
              "transition-all duration-200 ease-out",
              "hover:border-primary hover:bg-primary/5 hover:shadow-soft-sm",
              "active:scale-[0.98] active:bg-primary/10",
              "focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2",
              "min-h-[88px] lg:min-h-[100px] flex flex-col items-center justify-center",
              "group",
              disabled && "opacity-50 cursor-not-allowed pointer-events-none",
              error && "border-destructive bg-destructive/5"
            )}
          >
            <div className={cn(
              "w-10 h-10 lg:w-12 lg:h-12 rounded-xl flex items-center justify-center mb-2 lg:mb-3",
              "bg-muted/80 group-hover:bg-primary/10 transition-colors duration-200"
            )}>
              <Upload className={cn(
                "h-4 w-4 lg:h-5 lg:w-5 text-muted-foreground",
                "group-hover:text-primary transition-colors duration-200"
              )} />
            </div>
            <p className="text-xs lg:text-sm font-medium text-foreground">{t('fileUploader.clickOrDrag')}</p>
            <p className="text-[10px] lg:text-xs text-muted-foreground mt-1 px-2 max-w-[200px]">{description}</p>
          </div>
        )}

        {isUploading && (
          <div className="space-y-3 py-4 px-1 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
              </div>
              <div className="flex-1">
                <span className="text-sm font-medium">{t('fileUploader.uploading')}</span>
                <p className="text-[10px] text-muted-foreground">{t('fileUploader.pleaseWait')}</p>
              </div>
              <span className="text-sm font-semibold text-primary animate-count">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2 rounded-full" />
          </div>
        )}

        {fileInfo && !isUploading && (
          <div className="space-y-2.5 animate-fade-in-scale">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2.5 min-w-0">
                <div className={cn(
                  "p-2 lg:p-2.5 rounded-xl shrink-0 transition-colors",
                  fileInfo.status === 'success' 
                    ? "bg-gradient-to-br from-green-500/20 to-green-500/10" 
                    : "bg-muted"
                )}>
                  <Icon className={cn(
                    "h-4 w-4 lg:h-5 lg:w-5",
                    fileInfo.status === 'success' ? "text-green-600 dark:text-green-400" : "text-muted-foreground"
                  )} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{fileInfo.name}</p>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1">
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0.5 font-medium">
                      {formatFileSize(fileInfo.size, locale)}
                    </Badge>
                    {fileInfo.status === 'success' && (
                      <Badge className="text-[10px] px-1.5 py-0.5 bg-green-500/10 text-green-600 dark:text-green-400 border-0 hover:bg-green-500/20">
                        <CheckCircle className="h-2.5 w-2.5 mr-1" />
                        {t('fileUploader.uploaded')}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors"
                onClick={onRemove}
                disabled={disabled}
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>

            {/* 文件详细信息 - 紧凑布局 */}
            <div className="bg-muted/30 rounded-xl p-2.5 lg:p-3 text-xs border border-border/40">
              <div className="grid grid-cols-1 gap-x-3 gap-y-1 sm:grid-cols-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('fileUploader.type')}</span>
                  <span className="truncate ml-1">{fileInfo.type?.split('/')[1] || t('common.unknown')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('fileUploader.time')}</span>
                  <span>{formatDate(fileInfo.uploadedAt)}</span>
                </div>
              
                {/* 文本文件特有信息 */}
                {type === 'text' && (fileInfo as TextFileInfo).lineCount !== undefined && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t('fileUploader.lineCount')}</span>
                      <span>{(fileInfo as TextFileInfo).lineCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t('fileUploader.wordCount')}</span>
                      <span>{(fileInfo as TextFileInfo).wordCount}</span>
                    </div>
                  </>
                )}

                {/* 音频文件特有信息 */}
                {type === 'audio' && (fileInfo as AudioFileInfo).duration !== undefined && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t('fileUploader.duration')}</span>
                      <span>{formatDuration((fileInfo as AudioFileInfo).duration || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t('fileUploader.format')}</span>
                      <span className="uppercase">{(fileInfo as AudioFileInfo).format || t('common.unknown')}</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {error && (
          <Alert variant="destructive" className="mt-2 rounded-xl border-destructive/20 animate-fade-in">
            <AlertCircle className="h-3.5 w-3.5" />
            <AlertDescription className="text-xs font-medium">
              {error}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
