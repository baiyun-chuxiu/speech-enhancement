import { render, screen, fireEvent } from '@testing-library/react';
import { ProcessingStatus } from './processing-status';
import type { ProcessStep } from '@/lib/types';
import { renderWithI18n } from '@/test-utils/render-with-i18n';

const createSteps = (statuses: Array<'pending' | 'processing' | 'completed' | 'failed' | 'skipped'>): ProcessStep[] => {
  const names = ['读取文件', '解析数据', '处理音频', '生成输出'];
  return statuses.map((status, index) => ({
    name: names[index] || `步骤 ${index + 1}`,
    status,
    progress: status === 'completed' ? 100 : status === 'processing' ? 50 : 0,
    message: status === 'processing' ? '正在处理...' : undefined,
  }));
};

describe('ProcessingStatus', () => {
  const mockOnCancel = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Initial State', () => {
    it('renders with pending steps', () => {
      const steps = createSteps(['pending', 'pending', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={0}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('处理状态')).toBeInTheDocument();
      expect(screen.getByText('总体进度')).toBeInTheDocument();
      expect(screen.getByText('0%')).toBeInTheDocument();
    });

    it('renders all step names', () => {
      const steps = createSteps(['pending', 'pending', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={0}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('读取文件')).toBeInTheDocument();
      expect(screen.getByText('解析数据')).toBeInTheDocument();
      expect(screen.getByText('处理音频')).toBeInTheDocument();
      expect(screen.getByText('生成输出')).toBeInTheDocument();
    });

    it('renders translated english status copy when locale is en', () => {
      const steps = createSteps(['pending', 'pending', 'pending', 'pending']);

      renderWithI18n(
        <ProcessingStatus
          isProcessing={false}
          progress={0}
          steps={steps}
          error={null}
        />,
        { locale: 'en' }
      );

      expect(screen.getByText('Processing Status')).toBeInTheDocument();
      expect(screen.getByText('Overall Progress')).toBeInTheDocument();
    });
  });

  describe('Processing State', () => {
    it('shows step badge when processing', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={30}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('1/4 步骤')).toBeInTheDocument();
    });

    it('shows progress percentage', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={45}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('45%')).toBeInTheDocument();
    });

    it('shows step progress for active step', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={30}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('50%')).toBeInTheDocument(); // From the processing step
    });

    it('shows step message when processing', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={30}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('正在处理...')).toBeInTheDocument();
    });

    it('renders cancel button when processing with onCancel', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={30}
          steps={steps}
          error={null}
          onCancel={mockOnCancel}
        />
      );

      expect(screen.getByText('取消处理')).toBeInTheDocument();
    });

    it('calls onCancel when cancel button is clicked', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={30}
          steps={steps}
          error={null}
          onCancel={mockOnCancel}
        />
      );

      fireEvent.click(screen.getByText('取消处理'));
      expect(mockOnCancel).toHaveBeenCalled();
    });

    it('does not show cancel button without onCancel prop', () => {
      const steps = createSteps(['completed', 'processing', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={30}
          steps={steps}
          error={null}
        />
      );

      expect(screen.queryByText('取消处理')).not.toBeInTheDocument();
    });
  });

  describe('Completed State', () => {
    it('shows completion message when all steps completed', () => {
      const steps = createSteps(['completed', 'completed', 'completed', 'completed']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={100}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('处理完成')).toBeInTheDocument();
      expect(screen.getByText('所有步骤已成功执行')).toBeInTheDocument();
    });

    it('shows 100% progress when completed', () => {
      const steps = createSteps(['completed', 'completed', 'completed', 'completed']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={100}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('100%')).toBeInTheDocument();
    });

    it('does not show cancel button when completed', () => {
      const steps = createSteps(['completed', 'completed', 'completed', 'completed']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={100}
          steps={steps}
          error={null}
          onCancel={mockOnCancel}
        />
      );

      expect(screen.queryByText('取消处理')).not.toBeInTheDocument();
    });
  });

  describe('Error State', () => {
    it('displays error message', () => {
      const steps = createSteps(['completed', 'failed', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={25}
          steps={steps}
          error="处理过程中发生错误"
        />
      );

      expect(screen.getByText('处理失败')).toBeInTheDocument();
      expect(screen.getByText('处理过程中发生错误')).toBeInTheDocument();
    });

    it('shows failed step status', () => {
      const steps = createSteps(['completed', 'failed', 'pending', 'pending']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={25}
          steps={steps}
          error="错误"
        />
      );

      expect(screen.getByText('解析数据')).toBeInTheDocument();
    });
  });

  describe('Skipped State', () => {
    it('handles skipped steps', () => {
      const steps = createSteps(['completed', 'completed', 'skipped', 'completed']);
      
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={100}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('处理音频')).toBeInTheDocument();
    });
  });

  describe('Styling', () => {
    it('applies custom className', () => {
      const steps = createSteps(['pending']);
      
      const { container } = render(
        <ProcessingStatus
          isProcessing={false}
          progress={0}
          steps={steps}
          error={null}
          className="custom-class"
        />
      );

      const card = container.firstChild;
      expect(card).toHaveClass('custom-class');
    });
  });

  describe('Edge Cases', () => {
    it('handles empty steps array', () => {
      render(
        <ProcessingStatus
          isProcessing={false}
          progress={0}
          steps={[]}
          error={null}
        />
      );

      expect(screen.getByText('处理状态')).toBeInTheDocument();
      expect(screen.getByText('0%')).toBeInTheDocument();
    });

    it('handles single step', () => {
      const steps = createSteps(['processing']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={50}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('0/1 步骤')).toBeInTheDocument();
    });

    it('rounds progress percentage', () => {
      const steps = createSteps(['processing']);
      
      render(
        <ProcessingStatus
          isProcessing={true}
          progress={33.333}
          steps={steps}
          error={null}
        />
      );

      expect(screen.getByText('33%')).toBeInTheDocument();
    });
  });
});
