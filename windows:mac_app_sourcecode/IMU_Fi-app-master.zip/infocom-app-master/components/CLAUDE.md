# Components Module

[根目录](../CLAUDE.md) > **components/**

## Module Overview

React component library organized into two categories: reusable shadcn/ui primitive components and feature-specific upload components.

## Module Structure

```
components/
├── ui/                     # shadcn/ui primitive components (22 components)
│   ├── button.tsx
│   ├── card.tsx
│   ├── input.tsx
│   ├── progress.tsx
│   ├── slider.tsx
│   ├── tabs.tsx
│   ├── sonner.tsx
│   ├── dialog.tsx
│   ├── badge.tsx
│   ├── separator.tsx
│   ├── scroll-area.tsx
│   ├── sheet.tsx
│   ├── dropdown-menu.tsx
│   ├── toggle.tsx
│   ├── tooltip.tsx
│   ├── avatar.tsx
│   ├── alert.tsx
│   ├── collapsible.tsx
│   ├── label.tsx
│   ├── switch.tsx
│   └── select.tsx
│
└── upload/                 # Feature components for upload workflow
    ├── file-uploader.tsx
    ├── file-uploader.test.tsx
    ├── audio-player.tsx
    ├── audio-player.test.tsx
    ├── audio-analyzer.tsx
    ├── audio-analyzer.test.tsx
    ├── processing-status.tsx
    ├── processing-status.test.tsx
    ├── data-preview.tsx
    ├── data-preview.test.tsx
    ├── data-chart.tsx
    ├── data-chart.test.tsx
    ├── mobile-header.tsx
    ├── mobile-header.test.tsx
    └── index.ts
```

## UI Components (`ui/`)

shadcn/ui components built on Radix UI primitives with Tailwind CSS styling.

### Key Components

| Component | Purpose | Radix Primitive |
|-----------|---------|-----------------|
| Button | Primary/secondary actions | - |
| Card | Content containers | - |
| Dialog | Modal dialogs | Radix Dialog |
| Dropdown Menu | Context menus | Radix Dropdown |
| Progress | Progress bars | Radix Progress |
| Slider | Range input | Radix Slider |
| Tabs | Tabbed navigation | Radix Tabs |
| Tooltip | Hover tooltips | Radix Tooltip |
| Scroll Area | Custom scrollbars | Radix ScrollArea |
| Sheet | Side panels | Radix Sheet (Dialog) |

### Adding New UI Components

```bash
pnpm dlx shadcn@latest add <component-name>
```

## Upload Components (`upload/`)

Feature-specific components for the upload/processing workflow.

### Component Overview

| Component | Props | Responsibility | Test Coverage |
|-----------|-------|----------------|---------------|
| `FileUploader` | `type`, `title`, `description`, `fileInfo`, `onFileSelect`, `onRemove` | Drag-drop file upload with validation | ✅ |
| `AudioPlayer` | `audio`, `title` | Audio playback with waveform visualization | ✅ |
| `AudioAnalyzer` | `audio`, `analysis`, `currentTime` | Real-time frequency analysis | ✅ |
| `ProcessingStatus` | `isProcessing`, `progress`, `steps`, `error`, `onCancel` | Multi-step progress indicator | ✅ |
| `DataPreview` | `textFile`, `sensorType` | Tabular sensor data preview | ✅ |
| `DataChart` | `textFile`, `sensorType` | Time-series chart visualization | ✅ |
| `MobileHeader` | `onReset`, `isProcessing` | Mobile-optimized header | ✅ |

### FileUploader

Handles file selection via:
- Drag and drop zone
- Click to browse
- File validation (size, type)
- Upload progress display

**Supported Types**:
- Text: `.txt` files for sensor data
- Audio: `.mp3`, `.wav`, `.m4a`, `.ogg`, `.flac`, `.aac`

### AudioPlayer

Features:
- Play/pause/stop controls
- Seek bar with time display
- Volume control
- Playback rate adjustment
- Waveform visualization overlay
- Responsive design (mobile + desktop)

### AudioAnalyzer

Real-time audio analysis using Web Audio API:
- Frequency spectrum analyzer
- Waveform display
- Peak amplitude indicator
- Canvas-based rendering

### ProcessingStatus

Multi-step progress indicator showing:
- Current step being processed
- Overall progress percentage
- Individual step status (pending/processing/completed/failed)
- Step-specific messages
- Cancel button

### DataPreview

Displays sensor data in tabular format:
- First 100 rows of data
- X/Y/Z axis columns
- Scrollable container
- Responsive table layout

### DataChart

Time-series visualization of sensor data:
- Line chart with 3 axes (X, Y, Z)
- Auto-scaling Y-axis
- Sample index on X-axis
- Color-coded channels
- Responsive canvas

## State Management

Components receive state via props from parent hooks:
- `useFileUpload` → `FileUploader`
- `useAudioPlayer` → `AudioPlayer`, `AudioAnalyzer`
- `useModelApi` → `ProcessingStatus`

## Styling

All components use:
- `cn()` utility for class merging
- Tailwind CSS utility classes
- CSS variables for theming
- Responsive prefixes (`sm:`, `lg:`, `xl:`)
- Custom animations from `globals.css`

## Testing

- **Test Files**: 7/14 files (50%)
- **Framework**: React Testing Library + Jest
- **Coverage**:
  - All upload components have tests
  - UI components tested via Radix (not duplicated here)

## Dependencies

```typescript
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { FileInfo, AudioFileInfo } from "@/lib/types"
```

## Known Issues

1. Some UI components lack dedicated tests (rely on Radix tests)
2. DataChart doesn't handle large datasets efficiently (>10k points)
3. AudioAnalyzer animation can cause performance issues on low-end devices

## Future Enhancements

1. Virtual scrolling for `DataPreview` with large files
2. Export chart as image feature for `DataChart`
3. Audio recording capability in `AudioPlayer`
4. Batch file upload in `FileUploader`
