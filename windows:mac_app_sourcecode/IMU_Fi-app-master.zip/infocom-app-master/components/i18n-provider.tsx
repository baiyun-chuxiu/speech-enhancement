'use client';

import { useState, useEffect, useCallback, createContext, useContext, useSyncExternalStore } from 'react';
import type { AbstractIntlMessages } from 'next-intl';
import { NextIntlClientProvider } from 'next-intl';
import { type Locale, defaultLocale } from '@/i18n/config';
import { getMessagesForLocale } from '@/i18n/messages';
import { getStoredAppSettings, persistAppSettings } from '@/lib/app-settings';

interface I18nContextValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
}

const I18nContext = createContext<I18nContextValue>({
  locale: defaultLocale,
  setLocale: () => {},
});

export function useI18n() {
  return useContext(I18nContext);
}

function subscribeToClientSnapshot(): () => void {
  return () => {};
}

function resolveClientLocale(initialLocale: Locale): Locale {
  if (typeof window === 'undefined' || initialLocale !== defaultLocale) {
    return initialLocale;
  }

  return getStoredAppSettings().locale;
}

interface I18nProviderProps {
  children: React.ReactNode;
  initialLocale?: Locale;
  initialMessages?: AbstractIntlMessages;
}

export function I18nProvider({
  children,
  initialLocale = defaultLocale,
  initialMessages,
}: I18nProviderProps) {
  const [selectedLocale, setSelectedLocale] = useState<Locale | null>(null);
  const isHydrated = useSyncExternalStore(
    subscribeToClientSnapshot,
    () => true,
    () => false,
  );
  const syncedStoredLocale = useSyncExternalStore(
    subscribeToClientSnapshot,
    () => resolveClientLocale(initialLocale),
    () => initialLocale,
  );
  const locale = selectedLocale ?? syncedStoredLocale;

  useEffect(() => {
    if (!isHydrated) {
      return;
    }

    const storedSettings = getStoredAppSettings();
    document.documentElement.lang = locale;
    persistAppSettings({
      ...storedSettings,
      locale,
    });
  }, [isHydrated, locale]);

  const setLocale = useCallback((newLocale: Locale) => {
    setSelectedLocale(newLocale);
  }, []);

  const messages =
    locale === initialLocale && initialMessages
      ? initialMessages
      : getMessagesForLocale(locale);

  return (
    <I18nContext.Provider value={{ locale, setLocale }}>
      <NextIntlClientProvider locale={locale} messages={messages} timeZone="UTC">
        {children}
      </NextIntlClientProvider>
    </I18nContext.Provider>
  );
}
