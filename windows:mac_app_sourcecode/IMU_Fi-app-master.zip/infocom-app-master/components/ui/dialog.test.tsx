import { fireEvent, render, screen, waitFor } from '@testing-library/react';

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './dialog';

describe('Dialog', () => {
  it('opens through the trigger and renders the composed dialog slots', async () => {
    render(
      <Dialog>
        <DialogTrigger>Open settings</DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>Adjust the processing options.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose>Done</DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Open settings' }));

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveAttribute('data-slot', 'dialog-content');
    expect(screen.getByText('Settings')).toHaveAttribute('data-slot', 'dialog-title');
    expect(screen.getByText('Adjust the processing options.')).toHaveAttribute(
      'data-slot',
      'dialog-description',
    );
    expect(screen.getByRole('button', { name: 'Done' })).toHaveAttribute('data-slot', 'dialog-close');
    expect(document.querySelector('[data-slot="dialog-overlay"]')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Done' }));

    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  it('can omit the close icon button when requested', () => {
    render(
      <Dialog defaultOpen>
        <DialogContent showCloseButton={false}>
          <DialogTitle>Hidden close button</DialogTitle>
          <DialogDescription>Close icon intentionally hidden.</DialogDescription>
        </DialogContent>
      </Dialog>,
    );

    expect(screen.getByRole('dialog')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Close' })).not.toBeInTheDocument();
  });
});
