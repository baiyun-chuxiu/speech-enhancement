import { render } from '@testing-library/react';

import { Avatar, AvatarFallback, AvatarImage } from './avatar';

describe('Avatar', () => {
  it('renders the root, image, and fallback slots with merged classes', () => {
    const { container } = render(
      <Avatar className="custom-avatar" data-testid="avatar-root">
        <AvatarImage
          alt="Jane Doe"
          src="https://example.com/avatar.png"
          className="custom-image"
        />
        <AvatarFallback className="custom-fallback">JD</AvatarFallback>
      </Avatar>,
    );

    expect(container.querySelector('[data-slot="avatar"]')).toHaveClass('custom-avatar');
    expect(container.querySelector('[data-slot="avatar-fallback"]')).toHaveClass('custom-fallback');
    expect(container).toHaveTextContent('JD');
  });
});
