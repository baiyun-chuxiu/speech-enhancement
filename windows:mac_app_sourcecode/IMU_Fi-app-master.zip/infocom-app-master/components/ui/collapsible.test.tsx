import { fireEvent, render, screen } from '@testing-library/react';

import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './collapsible';

describe('Collapsible', () => {
  it('renders the slots and toggles the expanded state through the trigger', () => {
    render(
      <Collapsible defaultOpen data-testid="collapsible-root">
        <CollapsibleTrigger>Toggle details</CollapsibleTrigger>
        <CollapsibleContent>Hidden details</CollapsibleContent>
      </Collapsible>,
    );

    const trigger = screen.getByRole('button', { name: 'Toggle details' });

    expect(screen.getByTestId('collapsible-root')).toHaveAttribute('data-slot', 'collapsible');
    expect(trigger).toHaveAttribute('data-slot', 'collapsible-trigger');
    expect(trigger).toHaveAttribute('aria-expanded', 'true');
    expect(screen.getByText('Hidden details')).toHaveAttribute('data-slot', 'collapsible-content');

    fireEvent.click(trigger);

    expect(trigger).toHaveAttribute('aria-expanded', 'false');
  });
});
