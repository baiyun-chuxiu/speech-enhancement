import { fireEvent, render, screen } from '@testing-library/react';

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './accordion';

describe('Accordion', () => {
  it('renders the composed slots and toggles item expansion', () => {
    render(
      <Accordion type="single" collapsible defaultValue="item-1" data-testid="accordion-root">
        <AccordionItem value="item-1" className="custom-item">
          <AccordionTrigger className="custom-trigger">Section title</AccordionTrigger>
          <AccordionContent className="custom-content">Section body</AccordionContent>
        </AccordionItem>
      </Accordion>,
    );

    const trigger = screen.getByRole('button', { name: 'Section title' });
    const content = screen.getByText('Section body');

    expect(screen.getByTestId('accordion-root')).toHaveAttribute('data-slot', 'accordion');
    expect(trigger).toHaveAttribute('data-slot', 'accordion-trigger');
    expect(trigger).toHaveClass('custom-trigger');
    expect(trigger).toHaveAttribute('aria-expanded', 'true');
    expect(content.parentElement).toHaveAttribute('data-slot', 'accordion-content');
    expect(content).toHaveClass('custom-content');

    fireEvent.click(trigger);

    expect(trigger).toHaveAttribute('aria-expanded', 'false');
  });
});
