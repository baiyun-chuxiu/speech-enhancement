import { render, screen } from '@testing-library/react';
import type { ReactNode } from 'react';

import { Toaster } from './sonner';

const mockUseTheme = jest.fn();
const mockSonner = jest.fn();

jest.mock('next-themes', () => ({
  useTheme: () => mockUseTheme(),
}));

jest.mock('sonner', () => ({
  Toaster: (props: Record<string, unknown>) => {
    mockSonner(props);
    return <div data-testid="sonner-toaster" />;
  },
}));

describe('Toaster', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockUseTheme.mockReturnValue({ theme: 'dark' });
  });

  it('forwards the active theme, icons, and design tokens to sonner', () => {
    render(<Toaster closeButton richColors />);

    expect(screen.getByTestId('sonner-toaster')).toBeInTheDocument();
    expect(mockSonner).toHaveBeenCalledWith(
      expect.objectContaining({
        theme: 'dark',
        closeButton: true,
        richColors: true,
        className: 'toaster group',
        style: expect.objectContaining({
          '--normal-bg': 'var(--popover)',
          '--normal-text': 'var(--popover-foreground)',
          '--normal-border': 'var(--border)',
          '--border-radius': 'var(--radius)',
        }),
      }),
    );

    const props = mockSonner.mock.calls[0][0] as { icons: Record<string, ReactNode> };
    expect(props.icons.success).toBeTruthy();
    expect(props.icons.info).toBeTruthy();
    expect(props.icons.warning).toBeTruthy();
    expect(props.icons.error).toBeTruthy();
    expect(props.icons.loading).toBeTruthy();
  });
});
