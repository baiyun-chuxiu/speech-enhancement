import { fireEvent, render, screen } from '@testing-library/react';

import { Toggle } from './toggle';

describe('Toggle', () => {
  it('applies variant classes and updates the pressed state when clicked', () => {
    render(
      <Toggle variant="outline" size="lg" aria-label="Mute audio">
        Mute
      </Toggle>,
    );

    const toggle = screen.getByRole('button', { name: 'Mute audio' });

    expect(toggle).toHaveAttribute('data-slot', 'toggle');
    expect(toggle).toHaveClass('border', 'h-10', 'min-w-10');
    expect(toggle).toHaveAttribute('aria-pressed', 'false');

    fireEvent.click(toggle);

    expect(toggle).toHaveAttribute('aria-pressed', 'true');
  });
});
