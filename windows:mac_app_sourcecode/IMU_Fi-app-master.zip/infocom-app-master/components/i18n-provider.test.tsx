import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { hydrateRoot } from 'react-dom/client';
import { I18nProvider, useI18n } from './i18n-provider';

jest.mock('next-intl', () => ({
  NextIntlClientProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
  writable: true,
});

function LocaleConsumer() {
  const { locale, setLocale } = useI18n();

  return (
    <div>
      <span data-testid="active-locale">{locale}</span>
      <button type="button" onClick={() => setLocale('zh-CN')}>
        Switch
      </button>
    </div>
  );
}

describe('I18nProvider', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    document.documentElement.lang = 'en';
  });

  it('uses the server-provided initial locale and syncs locale changes to storage and document state', () => {
    render(
      <I18nProvider initialLocale="en" initialMessages={{}}>
        <LocaleConsumer />
      </I18nProvider>,
    );

    expect(screen.getByTestId('active-locale')).toHaveTextContent('en');
    expect(document.documentElement.lang).toBe('en');

    fireEvent.click(screen.getByRole('button', { name: 'Switch' }));

    expect(screen.getByTestId('active-locale')).toHaveTextContent('zh-CN');
    expect(localStorageMock.setItem).toHaveBeenCalled();
    expect(document.documentElement.lang).toBe('zh-CN');
  });

  it('matches the server locale during hydration before syncing the stored locale', async () => {
    localStorageMock.getItem.mockImplementation((key: string) => {
      if (key === 'infocom-settings') {
        return JSON.stringify({ locale: 'en' });
      }

      return null;
    });

    const element = (
      <I18nProvider initialLocale="zh-CN" initialMessages={{}}>
        <LocaleConsumer />
      </I18nProvider>
    );
    const container = document.createElement('div');
    container.innerHTML = '<div><span data-testid="active-locale">zh-CN</span><button type="button">Switch</button></div>';
    document.body.appendChild(container);

    expect(container).toHaveTextContent('zh-CN');

    const recoverableErrors: unknown[] = [];
    let root: ReturnType<typeof hydrateRoot> | null = null;

    await act(async () => {
      root = hydrateRoot(container, element, {
        onRecoverableError: (error) => {
          recoverableErrors.push(error);
        },
      });
    });

    expect(recoverableErrors).toHaveLength(0);

    await waitFor(() => {
      expect(container).toHaveTextContent('en');
    });
    expect(document.documentElement.lang).toBe('en');

    await act(async () => {
      root?.unmount();
    });
    container.remove();
  });
});
