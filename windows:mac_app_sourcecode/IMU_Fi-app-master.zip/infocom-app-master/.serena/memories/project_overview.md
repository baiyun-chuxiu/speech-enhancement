# Infocom-App Project Overview

## Purpose
A React + Tauri desktop application starter with Next.js 16 and React 19.

## Tech Stack
- **Frontend**: Next.js 16 (App Router) with React 19, TypeScript
- **Desktop**: Tauri 2.9 for cross-platform desktop capabilities
- **UI Library**: shadcn/ui (Radix UI primitives + Lucide icons)
- **Styling**: Tailwind CSS v4 with PostCSS
- **State Management**: Zustand
- **Testing**: Jest with Testing Library
- **Package Manager**: pnpm (preferred)

## Codebase Structure
```
infocom-app/
├── app/              # Next.js App Router (pages, layouts, globals.css)
├── components/       # Reusable React components
│   └── ui/          # shadcn/ui components
├── lib/             # Utilities (cn class merger from tailwind-merge)
├── hooks/           # Custom React hooks
├── src-tauri/       # Rust backend (main.rs, lib.rs, tauri.conf.json)
├── public/          # Static assets
└── __mocks__/       # Jest test mocks (styleMock.js, fileMock.js)
```

## Path Aliases
- `@/components` → `components/`
- `@/lib` → `lib/`
- `@/utils` → `lib/utils.ts`
- `@/ui` → `components/ui`
- `@/hooks` → `hooks/`
- `@/*` → `./*` (root)

## Key Files
- `components.json` - shadcn/ui config
- `next.config.ts` - Next.js configuration
- `tsconfig.json` - TypeScript config (strict mode enabled)
- `jest.config.ts` - Jest testing config
- `eslint.config.mjs` - ESLint with Next.js preset
