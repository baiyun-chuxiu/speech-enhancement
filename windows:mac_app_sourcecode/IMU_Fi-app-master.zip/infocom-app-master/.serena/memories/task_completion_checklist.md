# Task Completion Checklist

## Before Marking a Task Complete

### Code Quality
- [ ] Run `pnpm lint` - fix any linting errors
- [ ] Run `pnpm test` - ensure all tests pass
- [ ] Run `pnpm build` - verify production build succeeds

### Testing
- [ ] Write tests for new components/features
- [ ] Test files named with `.test.tsx` suffix
- [ ] Use `@testing-library/react` for component testing
- [ ] Mock CSS and file imports using `__mocks__/`

### Code Style
- [ ] Follow TypeScript strict mode conventions
- [ ] Use `@/` path aliases for imports
- [ ] Use `cn()` utility for class merging
- [ ] Components use PascalCase, files use kebab-case

### Browser/Desktop Testing
- [ ] Test in browser (`pnpm dev`)
- [ ] Test in Tauri desktop app (`pnpm tauri dev`)
- [ ] Verify dark mode works if applicable
- [ ] Test responsive behavior (mobile/desktop)

### Documentation
- [ ] Update CLAUDE.md if architecture changed
- [ ] Add comments for complex logic
- [ ] Ensure types are properly exported
