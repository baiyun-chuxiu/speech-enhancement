# Suggested Commands

## Windows Shell Commands (PowerShell/CMD)
```powershell
# List files
ls
dir

# Change directory
cd path\to\directory

# Find files
Get-ChildItem -Recurse -Filter "*.ts"

# Search in files
Select-String -Pattern "searchTerm" -Path "*.ts*"

# Git commands
git status
git log
git diff
```

## Development Commands (pnpm preferred)
```bash
# Start Next.js dev server
pnpm dev

# Build for production
pnpm build

# Start production server
pnpm start

# Lint code
pnpm lint

# Run tests
pnpm test

# Watch tests
pnpm test:watch

# Test coverage
pnpm test:coverage
```

## Tauri Commands
```bash
# Run Tauri development (frontend + desktop)
pnpm tauri dev

# Build Tauri desktop app
pnpm tauri build

# More Tauri commands
pnpm tauri --help
```

## Testing Workflow
1. Run `pnpm test` to execute all tests
2. Use `pnpm test:watch` for TDD workflow
3. Use `pnpm test:coverage` for coverage report
4. Coverage reports in `coverage/` directory

## Build/Deploy Workflow
1. Run `pnpm lint` before committing
2. Run `pnpm test` to verify tests pass
3. Run `pnpm build` to verify production build
4. Tauri builds to `out/` directory (not `.next/`)
