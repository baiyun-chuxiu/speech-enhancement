# Code Style and Conventions

## TypeScript
- **Strict mode enabled**: `strict: true` in tsconfig.json
- Target: ES2017
- Module resolution: bundler mode

## Naming Conventions
- **Components**: PascalCase (e.g., `FileUploader.tsx`, `MobileHeader.tsx`)
- **Files**: kebab-case for multi-word components (e.g., `audio-analyzer.tsx`)
- **Test files**: Same name as source with `.test.tsx` suffix (e.g., `file-uploader.test.tsx`)

## Import Style
- Use `@/` path aliases for internal imports
- Radix UI imports: `@radix-ui/react-*`
- Test imports use `@testing-library/*`

## React/Next.js Conventions
- Use App Router (not Pages Router)
- `layout.tsx` for root layout with fonts
- `page.tsx` for route pages
- Client components: `"use client"` directive at top

## Styling Conventions
- Tailwind CSS v4 with CSS variables
- shadcn/ui "new-york" style
- Dark mode support via next-themes
- Class merging: use `cn()` utility from `lib/utils.ts` (combines clsx + tailwind-merge)
- Components use `class-variance-authority` (cva) for variant styles

## Testing Conventions
- Test files co-located with source (`.test.tsx` suffix)
- Tests in `__tests__/` directories also supported
- Test pattern: `**/?(*.)+(spec|test).?([mc])[jt]s?(x)`
- jsdom environment for React component testing
- Coverage thresholds: 60% branches/functions, 70% lines/statements
