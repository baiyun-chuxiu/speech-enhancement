import json
import subprocess
import time
from pathlib import Path
import requests
import os

repo = Path(r'd:/Project/infocom-app')
exe = repo / 'src-tauri/binaries/audio-enhancer-server-x86_64-pc-windows-msvc.exe'
env = dict(os.environ)
env['ENHANCER_HOST']='127.0.0.1'
env['ENHANCER_PORT']='8892'
proc = subprocess.Popen([str(exe)], cwd=repo, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

base='http://127.0.0.1:8892'
try:
    for _ in range(180):
        try:
            r=requests.get(base+'/ready', timeout=2)
            if r.ok:
                break
        except Exception:
            pass
        time.sleep(0.5)

    with open(repo/'data/segment_1_1.wav','rb') as aw, open(repo/'e2e/fixtures/real-accel-segment1.txt','rb') as af, open(repo/'e2e/fixtures/real-gyro-segment1.txt','rb') as gf:
        files={
          'audio_file':('segment_1_1.wav',aw,'audio/wav'),
          'accel_file':('real-accel-segment1.txt',af,'text/plain'),
          'gyro_file':('real-gyro-segment1.txt',gf,'text/plain')
        }
        resp=requests.post(base+'/api/v1/enhance',files=files,timeout=60)
        print('enhance_status',resp.status_code)
        print('enhance_body',resp.text)
    if resp.ok:
        task_id=resp.json()['task_id']
        for _ in range(300):
            s=requests.get(base+f'/api/v1/tasks/{task_id}',timeout=5)
            if s.ok:
                body=s.json()
                st=body.get('status')
                msg=body.get('message')
                if st in ('completed','failed','cancelled'):
                    print('final',st,msg)
                    print(json.dumps(body, ensure_ascii=False))
                    break
            time.sleep(0.5)
finally:
    if proc.stdin:
        try:
            proc.stdin.write('sidecar shutdown\\n'); proc.stdin.flush()
        except Exception:
            pass
    time.sleep(1)
    proc.kill()
    out=proc.communicate(timeout=5)[0]
    print('---tail---')
    print('\n'.join(out.splitlines()[-160:]))
