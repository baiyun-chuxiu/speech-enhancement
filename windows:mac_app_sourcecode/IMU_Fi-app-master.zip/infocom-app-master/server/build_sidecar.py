"""
PyInstaller build script — freeze FastAPI server into a Tauri sidecar binary.
Output: src-tauri/binaries/audio-enhancer-server-{target_triple}[.exe]

Usage:
    uv run --project server python server/build_sidecar.py
"""

import subprocess
import sys
import os
from pathlib import Path

REQUIRED_MODEL_FILES = (
    "generator_final.pth",
    "best_model.pth",
)

COLLECT_SUBMODULES = [
    "torch.cuda",
    "librosa",
    "numba",
    "llvmlite",
    "resampy",
]

COLLECT_BINARIES = [
    "torch",
    "llvmlite",
    "numba",
    "tbb",
]

COLLECT_DATA = [
    "librosa",
    "numba",
    "soundfile",
]


def get_target_triple() -> str:
    """Get the Rust target triple for the current platform."""
    result = subprocess.run(
        ["rustc", "--print", "host-tuple"],
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip()


# Hidden imports that PyInstaller cannot auto-detect for FastAPI/uvicorn/torch stack
HIDDEN_IMPORTS = [
    # FastAPI / Starlette / Uvicorn internals
    "uvicorn.logging",
    "uvicorn.loops",
    "uvicorn.loops.auto",
    "uvicorn.protocols",
    "uvicorn.protocols.http",
    "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl",
    "uvicorn.protocols.websockets",
    "uvicorn.protocols.websockets.auto",
    "uvicorn.protocols.websockets.wsproto_impl",
    "uvicorn.lifespan",
    "uvicorn.lifespan.on",
    "uvicorn.lifespan.off",
    "multipart",
    "multipart.multipart",
    "python_multipart",
    # Our own server package modules
    "server",
    "server.__init__",
    "server.config",
    "server.models",
    "server.pipeline",
    "server.routes",
    "server.schemas",
    "server.main",
    # Core ML / scientific libraries
    "torch",
    "torch.nn",
    "torch.nn.functional",
    "numpy",
    "pandas",
    "soundfile",
    "librosa",
    "audioread",
    "cv2",
    "PIL",
    "PIL.Image",
    # Pydantic v2
    "pydantic",
    "pydantic.deprecated",
    "pydantic.deprecated.decorator",
    # Other
    "websockets",
    "anyio",
    "anyio._backends",
    "anyio._backends._asyncio",
    "starlette",
    "starlette.routing",
    "starlette.responses",
    "starlette.middleware",
    "starlette.middleware.cors",
    "httptools",
    "dotenv",
    "email_validator",
]

# Large modules to exclude to reduce binary size
# NOTE: Do NOT exclude setuptools/distutils — PyInstaller hooks depend on them
EXCLUDES = [
    "matplotlib",
    "tkinter",
    "IPython",
    "jupyter",
    "notebook",
    "pytest",
    "coverage",
    "pytest_cov",
    "sphinx",
    "docutils",
]


def validate_required_models(models_dir: Path) -> None:
    missing_models = [
        filename for filename in REQUIRED_MODEL_FILES if not (models_dir / filename).is_file()
    ]
    if missing_models:
        missing_list = ", ".join(missing_models)
        raise FileNotFoundError(
            f"Missing required model file(s) in {models_dir}: {missing_list}"
        )


def build_pyinstaller_command(
    *,
    python_executable: str,
    triple: str,
    project_root: Path,
    script_dir: Path,
    dist_path: Path,
    entrypoint: Path,
    platform_name: str,
) -> list[str]:
    models_dir = script_dir / "models"
    validate_required_models(models_dir)

    sep = ";" if platform_name == "win32" else ":"
    command = [
        python_executable,
        "-m",
        "PyInstaller",
        "--onefile",
        "--console",
        "--clean",
        "--name",
        f"audio-enhancer-server-{triple}",
        "--distpath",
        str(dist_path),
        "--paths",
        str(project_root),
        "--paths",
        str(script_dir),
    ]

    for package_name in COLLECT_BINARIES:
        command.extend(["--collect-binaries", package_name])

    for package_name in COLLECT_SUBMODULES:
        command.extend(["--collect-submodules", package_name])

    for package_name in COLLECT_DATA:
        command.extend(["--collect-data", package_name])

    for mod in HIDDEN_IMPORTS:
        command.extend(["--hidden-import", mod])

    for mod in EXCLUDES:
        command.extend(["--exclude-module", mod])

    # Explicitly include runtime-native DLLs that are not always discovered via hooks.
    explicit_binaries = [
        Path(sys.prefix) / "Library" / "bin" / "tbb12.dll",
        Path(sys.prefix) / "Lib" / "site-packages" / "_soundfile_data" / "libsndfile_x64.dll",
    ]
    for binary_path in explicit_binaries:
        if binary_path.is_file():
            command.extend(["--add-binary", f"{binary_path}{sep}."])

    command.extend(["--add-data", f"{models_dir}{sep}models"])
    command.append(str(entrypoint))
    return command


def verify_built_sidecar(*, python_executable: str, project_root: Path, sidecar_path: Path) -> None:
    smoke_check = project_root / "server" / "smoke_check.py"
    default_timeout = "180" if sys.platform == "darwin" else "90"
    smoke_timeout = os.environ.get("SIDECAR_SMOKE_TIMEOUT", default_timeout)
    smoke_port = os.environ.get("SIDECAR_SMOKE_PORT", "8765")
    command = [
        python_executable,
        str(smoke_check),
        "--command",
        str(sidecar_path),
        "--expect-ready",
        "--timeout",
        smoke_timeout,
        "--port",
        smoke_port,
    ]
    print(f"[build_sidecar] Verifying built sidecar: {' '.join(command)}")
    subprocess.run(command, check=True, cwd=project_root)


def build():
    """Build the Python sidecar using PyInstaller."""
    triple = get_target_triple()
    name = f"audio-enhancer-server-{triple}"

    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    final_dist_path = project_root / "src-tauri" / "binaries"
    staging_dist_path = project_root / "build" / "sidecar-dist"
    main_py = script_dir / "sidecar_entry.py"

    final_dist_path.mkdir(parents=True, exist_ok=True)
    staging_dist_path.mkdir(parents=True, exist_ok=True)

    cmd = build_pyinstaller_command(
        python_executable=sys.executable,
        triple=triple,
        project_root=project_root,
        script_dir=script_dir,
        dist_path=staging_dist_path,
        entrypoint=main_py,
        platform_name=sys.platform,
    )

    print(f"[build_sidecar] Building: {name}")
    print(f"[build_sidecar] Target triple: {triple}")
    print(f"[build_sidecar] Output dir: {final_dist_path}")
    print(f"[build_sidecar] Staging dir: {staging_dist_path}")
    print(f"[build_sidecar] Hidden imports: {len(HIDDEN_IMPORTS)}")
    print(f"[build_sidecar] Command: {' '.join(cmd)}")

    subprocess.run(cmd, check=True)

    output_file = staging_dist_path / name
    if sys.platform == "win32":
        output_file = output_file.with_suffix(".exe")
    if output_file.exists():
        size_mb = output_file.stat().st_size / (1024 * 1024)
        print(f"[build_sidecar] Built staging output: {output_file} ({size_mb:.1f} MB)")
        verify_built_sidecar(
            python_executable=sys.executable,
            project_root=project_root,
            sidecar_path=output_file,
        )

        final_output_file = final_dist_path / output_file.name
        if final_output_file.exists():
            final_output_file.unlink()
        output_file.replace(final_output_file)
        print(f"[build_sidecar] Final sidecar ready: {final_output_file}")
    else:
        print(f"[build_sidecar] Build completed but output not found at {output_file}")


if __name__ == "__main__":
    build()
