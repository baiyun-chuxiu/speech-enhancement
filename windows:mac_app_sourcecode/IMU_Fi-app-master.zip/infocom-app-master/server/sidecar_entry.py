"""PyInstaller-safe sidecar entrypoint.

This module imports the server CLI through the package namespace so frozen
executables do not rely on relative imports from a top-level script.
"""

import os

# Keep numba behavior stable across dev/frozen runtimes and avoid importing
# incompatible coverage implementations in packaged mode.
os.environ["NUMBA_DISABLE_COVERAGE"] = "1"

from server.main import _cli


if __name__ == "__main__":
    _cli()
