"""
API routes for the Audio Enhancement server.

Endpoints:
  GET  /health                     - Liveness check
  GET  /ready                      - Enhancement readiness check
  GET  /api/v1/system/info         - System information
  POST /api/v1/files/upload        - Upload a file
  GET  /api/v1/files/download/{id} - Download a result file
  POST /api/v1/enhance             - Start enhancement (multipart form)
  GET  /api/v1/tasks/{task_id}     - Get task status
  POST /api/v1/tasks/{task_id}/cancel - Cancel a task
  WS   /ws/tasks/{task_id}         - WebSocket for real-time progress
"""

import asyncio
import logging
import platform
import sys
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import torch
from fastapi import APIRouter, BackgroundTasks, File, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse

from .config import config
from .pipeline import PIPELINE_STEPS, EnhancerPipeline, PipelineManager
from .schemas import (
    BatchEnhanceResponse,
    DeviceType,
    EnhanceResponse,
    FileUploadResponse,
    HealthResponse,
    ProcessingStep,
    ReadinessResponse,
    ReadinessStatus,
    SystemInfo,
    TaskInfo,
    TaskStatus,
)

logger = logging.getLogger(__name__)

router = APIRouter()

# Global state
pipeline: Optional[EnhancerPipeline] = None
pipeline_manager: Optional[PipelineManager] = None
tasks: dict[str, TaskInfo] = {}
uploaded_files: dict[str, dict[str, Any]] = {}
websocket_connections: dict[str, list[WebSocket]] = {}
task_cancel_events: dict[str, threading.Event] = {}


def get_pipeline_manager() -> PipelineManager:
    global pipeline_manager, pipeline
    if pipeline_manager is None:
        pipeline_manager = PipelineManager(config)
        pipeline = pipeline_manager.get_pipeline(config.device)[0]
    return pipeline_manager


def get_pipeline(requested_device: str | DeviceType | None = None) -> EnhancerPipeline:
    global pipeline
    pipeline, _ = get_pipeline_manager().get_pipeline(requested_device)
    return pipeline


def init_pipeline() -> dict[str, Any]:
    """Pre-initialize the default pipeline at startup."""
    global pipeline
    manager = get_pipeline_manager()
    pipeline = manager.get_pipeline(config.device)[0]
    return _get_runtime_state_payload()


def _get_runtime_state_payload() -> dict[str, Any]:
    manager = pipeline_manager or get_pipeline_manager()
    state = manager.get_runtime_state()

    if hasattr(state, "as_api_dict"):
        return state.as_api_dict()
    if isinstance(state, dict):
        return dict(state)
    return dict(getattr(state, "__dict__", {}))


def _readiness_status_from_payload(payload: dict[str, Any]) -> ReadinessStatus:
    status = payload.get("status", ReadinessStatus.loading.value)
    if isinstance(status, ReadinessStatus):
        return status
    return ReadinessStatus(status)


def _get_ready_pipeline(
    requested_device: DeviceType | str | None,
) -> tuple[EnhancerPipeline, str, str]:
    manager = pipeline_manager or get_pipeline_manager()
    requested_value = (
        requested_device.value
        if isinstance(requested_device, DeviceType)
        else requested_device or DeviceType.auto.value
    )

    try:
        resolved_device = manager.resolve_device(requested_value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    resolved_pipeline, effective_device = manager.get_pipeline(resolved_device)
    runtime = (
        resolved_pipeline.get_runtime_state().as_api_dict()
        if hasattr(resolved_pipeline, "get_runtime_state")
        else _get_runtime_state_payload()
    )
    if not runtime.get("is_ready", False):
        reason = runtime.get("degraded_reason") or "models-not-ready"
        raise HTTPException(
            status_code=503,
            detail=f"Enhancer backend is not ready: {reason}",
        )

    return resolved_pipeline, requested_value, effective_device


def _validate_uploaded_content(content: bytes, label: str) -> None:
    if not content:
        raise HTTPException(status_code=400, detail=f"{label} file is empty")


def _create_task(
    task_id: str,
    steps: list[ProcessingStep],
    requested_device: str,
    effective_device: str,
) -> TaskInfo:
    task = TaskInfo(
        task_id=task_id,
        status=TaskStatus.pending,
        message="Queued",
        steps=steps,
        requested_device=requested_device,
        effective_device=effective_device,
    )
    tasks[task_id] = task
    task_cancel_events[task_id] = threading.Event()
    return task


def _cleanup_task_output(output_path: str) -> None:
    output_file = Path(output_path)
    if output_file.exists():
        output_file.unlink(missing_ok=True)


def _mark_incomplete_steps_cancelled(task: TaskInfo) -> None:
    for step in task.steps:
        if step.status != TaskStatus.completed:
            step.status = TaskStatus.cancelled


def _get_cancel_event(task_id: str) -> threading.Event:
    return task_cancel_events.setdefault(task_id, threading.Event())


def _broadcast_task_update_from_thread(task_id: str, loop: asyncio.AbstractEventLoop) -> None:
    asyncio.run_coroutine_threadsafe(_broadcast_task_update(task_id), loop)


# ------------------------------------------------------------------
# Health & System
# ------------------------------------------------------------------

@router.get("/health", response_model=HealthResponse)
async def health_check():
    runtime = _get_runtime_state_payload()
    return HealthResponse(
        status="ok",
        timestamp=datetime.now().isoformat(),
        readiness_status=_readiness_status_from_payload(runtime),
        is_ready=runtime.get("is_ready", False),
        degraded_reason=runtime.get("degraded_reason"),
    )


@router.get("/ready", response_model=ReadinessResponse)
async def readiness_check():
    runtime = _get_runtime_state_payload()
    return ReadinessResponse(
        status=_readiness_status_from_payload(runtime),
        timestamp=datetime.now().isoformat(),
        is_ready=runtime.get("is_ready", False),
        configured_device=runtime.get("configured_device", config.device),
        effective_device=runtime.get("effective_device", config.device),
        supported_devices=runtime.get("supported_devices", []),
        degraded_reason=runtime.get("degraded_reason"),
    )


@router.get("/api/v1/system/info", response_model=SystemInfo)
async def system_info():
    runtime = _get_runtime_state_payload()
    return SystemInfo(
        python_version=sys.version,
        platform=platform.platform(),
        cuda_available=torch.cuda.is_available(),
        mps_available=hasattr(torch.backends, "mps") and torch.backends.mps.is_available(),
        configured_device=runtime.get("configured_device", config.device),
        device=runtime.get("effective_device", config.device),
        supported_devices=runtime.get("supported_devices", []),
        status=_readiness_status_from_payload(runtime),
        is_ready=runtime.get("is_ready", False),
        degraded_reason=runtime.get("degraded_reason"),
        generator_loaded=runtime.get("generator_loaded", False),
        denoise_loaded=runtime.get("denoise_loaded", False),
        generator_model_exists=runtime.get("generator_model_exists", False),
        denoise_model_exists=runtime.get("denoise_model_exists", False),
        generator_error=runtime.get("generator_error"),
        denoise_error=runtime.get("denoise_error"),
    )


# ------------------------------------------------------------------
# File Upload / Download
# ------------------------------------------------------------------

@router.post("/api/v1/files/upload", response_model=FileUploadResponse)
async def upload_file(file: UploadFile = File(...)):
    file_id = str(uuid.uuid4())
    ext = Path(file.filename or "file").suffix
    save_path = config.upload_dir / f"{file_id}{ext}"

    content = await file.read()
    _validate_uploaded_content(content, "Uploaded")
    save_path.write_bytes(content)

    info = {
        "file_id": file_id,
        "filename": file.filename or "unknown",
        "size": len(content),
        "content_type": file.content_type or "application/octet-stream",
        "path": str(save_path),
        "ext": ext,
    }
    uploaded_files[file_id] = info

    return FileUploadResponse(success=True, **{k: v for k, v in info.items() if k != "ext"})


@router.get("/api/v1/files/download/{file_id}")
async def download_file(file_id: str):
    output_path = config.output_dir / f"{file_id}.wav"
    if output_path.exists():
        return FileResponse(
            path=str(output_path),
            filename=f"enhanced_{file_id}.wav",
            media_type="audio/wav",
        )

    if file_id in uploaded_files:
        path = uploaded_files[file_id]["path"]
        if Path(path).exists():
            return FileResponse(path=path, filename=uploaded_files[file_id]["filename"])

    raise HTTPException(status_code=404, detail="File not found")


# ------------------------------------------------------------------
# Enhancement
# ------------------------------------------------------------------

@router.post("/api/v1/enhance", response_model=EnhanceResponse)
async def enhance_audio(
    background_tasks: BackgroundTasks,
    audio_file: UploadFile = File(...),
    accel_file: UploadFile = File(...),
    gyro_file: UploadFile = File(...),
    device: DeviceType = DeviceType.auto,
):
    """
    Start audio enhancement. Accepts multipart form with three files.
    Returns immediately with a task_id for progress tracking.
    """
    _, requested_device, effective_device = _get_ready_pipeline(device)

    task_id = str(uuid.uuid4())
    output_file_id = str(uuid.uuid4())

    audio_content = await audio_file.read()
    accel_content = await accel_file.read()
    gyro_content = await gyro_file.read()
    _validate_uploaded_content(audio_content, "Audio")
    _validate_uploaded_content(accel_content, "Accelerometer")
    _validate_uploaded_content(gyro_content, "Gyroscope")

    audio_path = config.upload_dir / f"{task_id}_audio{Path(audio_file.filename or '.wav').suffix}"
    accel_path = config.upload_dir / f"{task_id}_accel.txt"
    gyro_path = config.upload_dir / f"{task_id}_gyro.txt"

    audio_path.write_bytes(audio_content)
    accel_path.write_bytes(accel_content)
    gyro_path.write_bytes(gyro_content)

    output_path = config.output_dir / f"{output_file_id}.wav"

    task_steps = [ProcessingStep(index=i, name=name) for i, name in enumerate(PIPELINE_STEPS)]
    _create_task(task_id, task_steps, requested_device, effective_device)

    background_tasks.add_task(
        _run_enhancement,
        task_id,
        str(audio_path),
        str(accel_path),
        str(gyro_path),
        str(output_path),
        output_file_id,
        requested_device,
        effective_device,
    )

    return EnhanceResponse(
        success=True,
        task_id=task_id,
        status=TaskStatus.pending,
        requested_device=requested_device,
        effective_device=effective_device,
    )


@router.post("/api/v1/enhance/uploaded", response_model=EnhanceResponse)
async def enhance_uploaded(
    background_tasks: BackgroundTasks,
    audio_file_id: str,
    accel_file_id: str,
    gyro_file_id: str,
    device: DeviceType = DeviceType.auto,
):
    """Start enhancement using previously uploaded file IDs."""
    _, requested_device, effective_device = _get_ready_pipeline(device)

    for fid, label in [
        (audio_file_id, "audio"),
        (accel_file_id, "accelerometer"),
        (gyro_file_id, "gyroscope"),
    ]:
        if fid not in uploaded_files:
            raise HTTPException(status_code=404, detail=f"{label} file not found: {fid}")
        if not Path(uploaded_files[fid]["path"]).exists():
            raise HTTPException(status_code=404, detail=f"{label} file path is missing: {fid}")

    task_id = str(uuid.uuid4())
    output_file_id = str(uuid.uuid4())
    output_path = config.output_dir / f"{output_file_id}.wav"

    task_steps = [ProcessingStep(index=i, name=name) for i, name in enumerate(PIPELINE_STEPS)]
    _create_task(task_id, task_steps, requested_device, effective_device)

    background_tasks.add_task(
        _run_enhancement,
        task_id,
        uploaded_files[audio_file_id]["path"],
        uploaded_files[accel_file_id]["path"],
        uploaded_files[gyro_file_id]["path"],
        str(output_path),
        output_file_id,
        requested_device,
        effective_device,
    )

    return EnhanceResponse(
        success=True,
        task_id=task_id,
        status=TaskStatus.pending,
        requested_device=requested_device,
        effective_device=effective_device,
    )


async def _run_enhancement(
    task_id: str,
    audio_path: str,
    accel_path: str,
    gyro_path: str,
    output_path: str,
    output_file_id: str,
    requested_device: str,
    effective_device: str,
):
    """Background task that runs the enhancement pipeline."""
    task = tasks.get(task_id)
    if not task:
        return

    cancel_event = _get_cancel_event(task_id)
    loop = asyncio.get_running_loop()

    task.status = TaskStatus.running
    task.message = "Enhancement started"
    task.updated_at = datetime.now().isoformat()

    def on_progress(step_idx: int, step_name: str, progress: int, message: str):
        if task_id not in tasks:
            return
        t = tasks[task_id]
        if cancel_event.is_set() or t.status == TaskStatus.cancelled:
            raise InterruptedError("Task cancelled")

        if step_idx < len(t.steps):
            step = t.steps[step_idx]
            step.progress = progress
            step.message = message
            if progress >= 100:
                step.status = TaskStatus.completed
            elif progress > 0:
                step.status = TaskStatus.running

        completed = sum(1 for s in t.steps if s.status == TaskStatus.completed)
        t.progress = int((completed / len(t.steps)) * 100)
        t.message = message
        t.updated_at = datetime.now().isoformat()
        _broadcast_task_update_from_thread(task_id, loop)

    try:
        p = get_pipeline(effective_device)
        result = await loop.run_in_executor(
            None,
            lambda: p.process_single(
                audio_path,
                accel_path,
                gyro_path,
                output_path,
                on_progress=on_progress,
                should_cancel=cancel_event.is_set,
            ),
        )

        if cancel_event.is_set() or task.status == TaskStatus.cancelled:
            raise InterruptedError("Task cancelled")

        task.status = TaskStatus.completed
        task.progress = 100
        task.message = "Enhancement complete"
        task.requested_device = requested_device
        task.effective_device = effective_device
        task.result = {
            "output_file_id": output_file_id,
            "output_url": f"/api/v1/files/download/{output_file_id}",
            "requested_device": requested_device,
            "effective_device": effective_device,
            **result,
        }
        for step in task.steps:
            step.status = TaskStatus.completed
            step.progress = 100
            step.message = step.message or "Completed"

    except InterruptedError:
        task.status = TaskStatus.cancelled
        task.message = "Task was cancelled"
        task.result = None
        _mark_incomplete_steps_cancelled(task)
        _cleanup_task_output(output_path)
    except Exception as exc:
        logger.exception("Enhancement failed for task %s", task_id)
        task.status = TaskStatus.failed
        task.error = str(exc)
        task.message = f"Error: {exc}"
        task.result = None
        for step in task.steps:
            if step.status == TaskStatus.running:
                step.status = TaskStatus.failed
        _cleanup_task_output(output_path)
    finally:
        task.updated_at = datetime.now().isoformat()
        task_cancel_events.pop(task_id, None)
        await _broadcast_task_update(task_id)


# ------------------------------------------------------------------
# Batch Enhancement
# ------------------------------------------------------------------

@router.post("/api/v1/enhance/batch", response_model=BatchEnhanceResponse)
async def enhance_batch(
    background_tasks: BackgroundTasks,
    audio_files: list[UploadFile] = File(...),
    accel_files: list[UploadFile] = File(...),
    gyro_files: list[UploadFile] = File(...),
    device: DeviceType = DeviceType.auto,
):
    """
    Batch enhancement: process multiple file triplets.
    Files must be provided in matching order.
    """
    _, requested_device, effective_device = _get_ready_pipeline(device)

    n = len(audio_files)
    if len(accel_files) != n or len(gyro_files) != n:
        raise HTTPException(status_code=400, detail="All file lists must have the same length")
    if n == 0:
        raise HTTPException(status_code=400, detail="At least one file triplet required")

    task_id = str(uuid.uuid4())
    samples = []

    for i in range(n):
        audio_bytes = await audio_files[i].read()
        accel_bytes = await accel_files[i].read()
        gyro_bytes = await gyro_files[i].read()
        _validate_uploaded_content(audio_bytes, "Audio")
        _validate_uploaded_content(accel_bytes, "Accelerometer")
        _validate_uploaded_content(gyro_bytes, "Gyroscope")

        sample_id = str(uuid.uuid4())
        audio_path = config.upload_dir / f"{task_id}_batch{i}_audio{Path(audio_files[i].filename or '.wav').suffix}"
        accel_path = config.upload_dir / f"{task_id}_batch{i}_accel.txt"
        gyro_path = config.upload_dir / f"{task_id}_batch{i}_gyro.txt"
        output_path = config.output_dir / f"{sample_id}.wav"

        audio_path.write_bytes(audio_bytes)
        accel_path.write_bytes(accel_bytes)
        gyro_path.write_bytes(gyro_bytes)

        samples.append(
            {
                "wav_path": str(audio_path),
                "acc_path": str(accel_path),
                "gyro_path": str(gyro_path),
                "output_wav_path": str(output_path),
                "output_file_id": sample_id,
            }
        )

    task_steps = [ProcessingStep(index=0, name=f"Batch processing ({n} samples)")]
    _create_task(task_id, task_steps, requested_device, effective_device)

    background_tasks.add_task(
        _run_batch_enhancement,
        task_id,
        samples,
        requested_device,
        effective_device,
    )

    return BatchEnhanceResponse(
        success=True,
        task_id=task_id,
        status=TaskStatus.pending,
        total_samples=n,
        requested_device=requested_device,
        effective_device=effective_device,
    )


async def _run_batch_enhancement(
    task_id: str,
    samples: list[dict[str, Any]],
    requested_device: str,
    effective_device: str,
):
    """Background task for batch processing."""
    task = tasks.get(task_id)
    if not task:
        return

    cancel_event = _get_cancel_event(task_id)
    loop = asyncio.get_running_loop()

    task.status = TaskStatus.running
    task.message = "Batch enhancement started"
    task.updated_at = datetime.now().isoformat()

    try:
        p = get_pipeline(effective_device)

        def on_batch_progress(completed: int, total: int, message: str):
            if task_id not in tasks:
                return
            t = tasks[task_id]
            if cancel_event.is_set() or t.status == TaskStatus.cancelled:
                raise InterruptedError("Task cancelled")
            t.progress = int((completed / total) * 100) if total else 0
            t.message = message
            t.updated_at = datetime.now().isoformat()
            _broadcast_task_update_from_thread(task_id, loop)

        results = await loop.run_in_executor(
            None,
            lambda: p.process_batch(
                samples,
                on_progress=on_batch_progress,
                should_cancel=cancel_event.is_set,
            ),
        )

        if cancel_event.is_set() or task.status == TaskStatus.cancelled:
            raise InterruptedError("Task cancelled")

        batch_results = []
        for sample, result in zip(samples, results):
            if result.get("success"):
                batch_results.append(
                    {
                        "success": True,
                        "output_file_id": sample["output_file_id"],
                        "output_url": f"/api/v1/files/download/{sample['output_file_id']}",
                        "total_time": result.get("total_time"),
                        "requested_device": requested_device,
                        "effective_device": effective_device,
                    }
                )
            else:
                batch_results.append(
                    {
                        "success": False,
                        "requested_device": requested_device,
                        "effective_device": effective_device,
                        "error": result.get("error", "Unknown error"),
                    }
                )

        task.status = TaskStatus.completed
        task.progress = 100
        task.message = "Batch processing complete"
        task.requested_device = requested_device
        task.effective_device = effective_device
        task.result = {
            "requested_device": requested_device,
            "effective_device": effective_device,
            "batch_results": batch_results,
        }
        for step in task.steps:
            step.status = TaskStatus.completed
            step.progress = 100
            step.message = step.message or "Completed"

    except InterruptedError:
        task.status = TaskStatus.cancelled
        task.message = "Task was cancelled"
        task.result = None
        _mark_incomplete_steps_cancelled(task)
        for sample in samples:
            _cleanup_task_output(sample["output_wav_path"])
    except Exception as exc:
        logger.exception("Batch enhancement failed for task %s", task_id)
        task.status = TaskStatus.failed
        task.error = str(exc)
        task.message = f"Error: {exc}"
        task.result = None
        for sample in samples:
            _cleanup_task_output(sample["output_wav_path"])
    finally:
        task.updated_at = datetime.now().isoformat()
        task_cancel_events.pop(task_id, None)
        await _broadcast_task_update(task_id)


# ------------------------------------------------------------------
# Task Management
# ------------------------------------------------------------------

@router.get("/api/v1/tasks/{task_id}", response_model=TaskInfo)
async def get_task_status(task_id: str):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    return tasks[task_id]


@router.post("/api/v1/tasks/{task_id}/cancel")
async def cancel_task(task_id: str):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")

    task = tasks[task_id]
    cancel_event = _get_cancel_event(task_id)
    cancel_event.set()

    if task.status not in {TaskStatus.completed, TaskStatus.failed, TaskStatus.cancelled}:
        task.status = TaskStatus.cancelled
        task.message = "Cancellation requested"
        _mark_incomplete_steps_cancelled(task)

    task.updated_at = datetime.now().isoformat()
    await _broadcast_task_update(task_id)
    return {"success": True}


# ------------------------------------------------------------------
# WebSocket for real-time progress
# ------------------------------------------------------------------

@router.websocket("/ws/tasks/{task_id}")
async def websocket_task_progress(websocket: WebSocket, task_id: str):
    await websocket.accept()

    if task_id not in websocket_connections:
        websocket_connections[task_id] = []
    websocket_connections[task_id].append(websocket)

    try:
        if task_id in tasks:
            await websocket.send_json(tasks[task_id].model_dump())

        while True:
            try:
                await asyncio.wait_for(websocket.receive_text(), timeout=30)
            except asyncio.TimeoutError:
                await websocket.send_json({"type": "ping"})
    except WebSocketDisconnect:
        pass
    finally:
        if task_id in websocket_connections:
            websocket_connections[task_id] = [
                ws for ws in websocket_connections[task_id] if ws != websocket
            ]


async def _broadcast_task_update(task_id: str):
    """Send task update to all connected WebSocket clients."""
    if task_id not in websocket_connections or task_id not in tasks:
        return
    task_data = tasks[task_id].model_dump()
    dead_connections = []
    for ws in websocket_connections[task_id]:
        try:
            await ws.send_json(task_data)
        except Exception:
            dead_connections.append(ws)
    for ws in dead_connections:
        websocket_connections[task_id].remove(ws)
