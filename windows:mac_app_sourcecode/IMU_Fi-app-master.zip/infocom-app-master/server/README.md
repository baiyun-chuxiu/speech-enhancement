# Audio Enhancement Server

Python FastAPI backend for the IMU-assisted audio enhancement pipeline (MobiCom 2026).

Uses **[uv](https://docs.astral.sh/uv/)** for fast, reproducible Python environment management.

## Prerequisites

- [uv](https://docs.astral.sh/uv/) (install: `curl -LsSf https://astral.sh/uv/install.sh | sh` or `powershell -c "irm https://astral.sh/uv/install.ps1 | iex"`)
- Python 3.10+ (uv will auto-install if needed)

## Setup

```bash
cd server

# Install all dependencies (creates .venv automatically)
uv sync

# Or install with CUDA PyTorch variant
uv sync --extra-index-url https://download.pytorch.org/whl/cu121
```

## Model Files

Place the following model files in `server/models/`:

- `generator_final.pth` (~30MB) — GAN Generator (IMU → video displacement)
- `best_model.pth` (~4MB) — Audio Denoise Network

## Run

```bash
# Or from project root
uv run --project server python -m server.main

# Or from server/
cd server
uv run python -m server.main

# Or with uvicorn directly
uv run uvicorn server.main:app --host 0.0.0.0 --port 8000 --reload

# Or after `uv sync`, use the installed CLI command
uv run audio-enhancer
```

## Packaging & Distribution

```bash
cd server

# Build a wheel (output in dist/)
uv build

# Install the built package
uv pip install dist/audio_enhancer_server-1.0.0-py3-none-any.whl

# After installation, run directly
audio-enhancer
```

## Environment Variables

| Variable | Default | Description |
| -------- | ------- | ----------- |
| `ENHANCER_HOST` | `0.0.0.0` | Server bind host |
| `ENHANCER_PORT` | `8000` | Server port |
| `ENHANCER_DEVICE` | auto-detect | `cpu`, `cuda`, or `mps` |
| `ENHANCER_MODELS_DIR` | `./server/models` | Models directory |
| `ENHANCER_GENERATOR_PATH` | `{models_dir}/generator_final.pth` | Generator model path |
| `ENHANCER_DENOISE_PATH` | `{models_dir}/best_model.pth` | Denoise model path |
| `ENHANCER_CORS_ORIGINS` | `http://localhost:3000,...` | Comma-separated CORS origins |

## API Endpoints

| Method | Endpoint | Description |
| ------ | -------- | ----------- |
| GET | `/health` | Process liveness check |
| GET | `/ready` | Enhancement readiness check |
| GET | `/api/v1/system/info` | System information |
| POST | `/api/v1/files/upload` | Upload a file |
| GET | `/api/v1/files/download/{id}` | Download result file |
| POST | `/api/v1/enhance` | Start enhancement (multipart) |
| POST | `/api/v1/enhance/uploaded` | Start enhancement (pre-uploaded files) |
| POST | `/api/v1/enhance/batch` | Start batch enhancement |
| GET | `/api/v1/tasks/{task_id}` | Task status |
| POST | `/api/v1/tasks/{task_id}/cancel` | Cancel task |
| WS | `/ws/tasks/{task_id}` | Real-time progress |

## Health vs. Readiness

- `/health` only answers whether the FastAPI process is up.
- `/ready` answers whether enhancement requests can actually run.
- If model files are missing, the backend still starts so diagnostics and desktop startup can work, but `/ready` reports degraded state and enhancement requests return `503`.

## API Docs

Visit `http://localhost:8000/docs` for interactive Swagger UI.

## Development

```bash
# Install with dev dependencies
uv sync --project server --group dev

# Run backend contract tests from the repository root
uv run --project server python -m pytest server/tests

# Smoke check degraded startup (expects missing model files)
uv run --project server python -m server.smoke_check

# Smoke check a fully ready backend
uv run --project server python -m server.smoke_check --expect-ready

# Lock dependencies (auto-generated on sync, commit this file)
uv lock
```
