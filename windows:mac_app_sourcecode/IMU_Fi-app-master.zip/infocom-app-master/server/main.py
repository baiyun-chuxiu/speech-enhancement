"""
Audio Enhancement Server - FastAPI Application Entry Point.

Provides REST API and WebSocket endpoints for the IMU-assisted
audio enhancement pipeline (MobiCom 2026).

Usage:
    python -m server.main
    # or
    uvicorn server.main:app --host 0.0.0.0 --port 8000 --reload
"""

import logging
import os
import signal
import sys
import threading
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import config
from .routes import init_pipeline, router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Modern lifespan handler replacing deprecated on_event('startup')."""
    logger.info("Starting Audio Enhancer server on %s:%d", config.host, config.port)
    logger.info("Device: %s", config.device)
    logger.info("Models dir: %s", config.models_dir)
    logger.info("Loading models at startup...")
    try:
        runtime = init_pipeline()
        if runtime.get("is_ready"):
            logger.info("Models loaded successfully on %s", runtime.get("effective_device"))
        else:
            logger.warning(
                "Server started in degraded mode: %s",
                runtime.get("degraded_reason", "unknown"),
            )
    except Exception as e:
        logger.error("Failed to load models: %s", e)
        logger.warning("Server will start but enhancement will fail until models are available")
    yield
    logger.info("Shutting down Audio Enhancer server")


app = FastAPI(
    title="Audio Enhancer API",
    description="IMU-assisted audio enhancement service (MobiCom 2026)",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes
app.include_router(router)


def _stdin_shutdown_listener():
    """Listen for shutdown command from Tauri via stdin.

    When running as a PyInstaller one-file sidecar, Tauri's process.kill()
    only terminates the bootloader process, not the actual Python child.
    We must listen for a stdin command and self-terminate.
    """
    while True:
        try:
            line = sys.stdin.readline().strip()
            if line == "sidecar shutdown":
                logger.info("Received 'sidecar shutdown' command via stdin")
                os.kill(os.getpid(), signal.SIGINT)
                break
        except Exception:
            break


def _cli():
    """CLI entry point for `audio-enhancer` command (via pyproject.toml scripts)."""
    import uvicorn

    # Start stdin listener thread for Tauri sidecar mode
    stdin_thread = threading.Thread(target=_stdin_shutdown_listener, daemon=True)
    stdin_thread.start()

    uvicorn.run(
        "server.main:app",
        host=config.host,
        port=config.port,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    _cli()
