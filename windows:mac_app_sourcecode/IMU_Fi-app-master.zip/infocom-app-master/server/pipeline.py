"""
Audio Enhancement Pipeline.

Complete 6-step processing pipeline:
1. IMU data preprocessing (acc + gyro)
2. GAN video displacement generation
3. Audio STFT preprocessing
4. Joint audio-video denoising
5. Spectrogram post-processing
6. ISTFT audio reconstruction

Ported from test_单个.py (single-file fast version).
"""

import logging
import importlib
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Optional, cast
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import soundfile as sf
import torch
import torch.nn.functional as F
from PIL import Image
from scipy import signal

from .config import ServerConfig, config as default_config
from .models import AudioDenoiseNetwork, Generator
from .schemas import DeviceType, ReadinessStatus

# Shared thread pool for I/O-bound parallel work
_io_executor = ThreadPoolExecutor(max_workers=4)

logger = logging.getLogger(__name__)

# Type alias for progress callback: (step_index, step_name, progress_pct, message)
ProgressCallback = Callable[[int, str, int, str], None]
ShouldCancelCallback = Callable[[], bool]

PIPELINE_STEPS = [
    "IMU Data Preprocessing",
    "GAN Video Displacement Generation",
    "Audio Feature Extraction (STFT)",
    "Joint Denoise Inference",
    "Spectrogram Post-processing",
    "Audio Reconstruction (ISTFT)",
]

_STFT_WIN_LENGTH = 2048
_STFT_HOP_LENGTH = 512
_STFT_NOVERLAP = _STFT_WIN_LENGTH - _STFT_HOP_LENGTH
_DB_AMIN = 1e-10
_DB_RANGE_FIXED = 90


def _is_packaged_runtime() -> bool:
    return bool(getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"))


def _fallback_forbidden() -> bool:
    # In packaged sidecar, keep processing path identical to dev/runtime expectations.
    if _is_packaged_runtime():
        return True
    return os.environ.get("ENHANCER_STRICT_NO_FALLBACK", "0").lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _amplitude_to_db(magnitude: np.ndarray) -> np.ndarray:
    ref = float(np.max(magnitude))
    ref = max(ref, _DB_AMIN)
    return 20.0 * np.log10(np.maximum(_DB_AMIN, magnitude)) - 20.0 * np.log10(ref)


def _db_to_amplitude(db_values: np.ndarray) -> np.ndarray:
    return np.power(10.0, db_values / 20.0, dtype=np.float64)


def _try_import_librosa():
    # Ensure consistent numba behavior in frozen/runtime environments.
    # This must be set before librosa lazily imports numba modules.
    os.environ["NUMBA_DISABLE_COVERAGE"] = "1"

    def _validate_api(librosa_module):
        # librosa lazily imports core modules; touching these members validates runtime availability.
        _ = librosa_module.load
        _ = librosa_module.stft
        _ = librosa_module.db_to_amplitude
        _ = librosa_module.istft

    def _sanitize_shadowing_paths() -> list[str]:
        original = list(sys.path)
        sanitized: list[str] = []
        for entry in original:
            if entry in ("", "."):
                continue
            try:
                p = Path(entry)
            except Exception:
                sanitized.append(entry)
                continue

            coverage_dir = p / "coverage"
            if coverage_dir.is_dir() and "site-packages" not in str(p).lower():
                continue
            sanitized.append(entry)
        return sanitized

    strict_no_fallback = _fallback_forbidden()

    try:
        import librosa  # type: ignore

        _validate_api(librosa)
        return librosa
    except Exception as first_exc:
        logger.warning("Initial librosa import/validation failed, retrying with sanitized sys.path: %s", first_exc)

        original_path = list(sys.path)
        try:
            sys.path = _sanitize_shadowing_paths()
            for mod_name in list(sys.modules.keys()):
                if mod_name == "librosa" or mod_name.startswith("librosa."):
                    sys.modules.pop(mod_name, None)
                if mod_name == "numba" or mod_name.startswith("numba."):
                    sys.modules.pop(mod_name, None)
                if mod_name == "coverage" or mod_name.startswith("coverage."):
                    sys.modules.pop(mod_name, None)
            importlib.invalidate_caches()
            import librosa  # type: ignore

            _validate_api(librosa)
            logger.info("librosa imported successfully after sanitized sys.path retry")
            return librosa
        except Exception as second_exc:
            if strict_no_fallback:
                raise RuntimeError(
                    "librosa import unavailable in strict mode; fallback is disabled"
                ) from second_exc
            logger.warning("librosa import unavailable after retry, using fallback pipeline: %s", second_exc)
            return None
        finally:
            sys.path = original_path


def detect_supported_devices() -> list[str]:
    """Return the runtime devices that this host can actually execute."""
    supported = ["cpu"]
    if torch.cuda.is_available():
        supported.append("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        supported.append("mps")
    return supported


@dataclass
class ModelLoadState:
    path: str
    exists: bool = False
    loaded: bool = False
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "exists": self.exists,
            "loaded": self.loaded,
            "error": self.error,
        }


@dataclass
class PipelineRuntimeState:
    status: ReadinessStatus = ReadinessStatus.loading
    is_ready: bool = False
    configured_device: str = "cpu"
    effective_device: str = "cpu"
    supported_devices: list[str] = field(default_factory=list)
    degraded_reason: Optional[str] = None
    generator: ModelLoadState = field(default_factory=lambda: ModelLoadState(path=""))
    denoise: ModelLoadState = field(default_factory=lambda: ModelLoadState(path=""))

    def as_api_dict(self) -> dict:
        return {
            "status": self.status.value if isinstance(self.status, ReadinessStatus) else self.status,
            "is_ready": self.is_ready,
            "configured_device": self.configured_device,
            "effective_device": self.effective_device,
            "supported_devices": list(self.supported_devices),
            "degraded_reason": self.degraded_reason,
            "generator_loaded": self.generator.loaded,
            "denoise_loaded": self.denoise.loaded,
            "generator_model_exists": self.generator.exists,
            "denoise_model_exists": self.denoise.exists,
            "generator_error": self.generator.error,
            "denoise_error": self.denoise.error,
        }


class EnhancerPipeline:
    """
    IMU-assisted audio enhancement pipeline.

    Loads Generator and DenoiseNet models on initialization,
    then processes (wav, acc, gyro) triplets to produce enhanced audio.
    """

    def __init__(
        self,
        cfg: Optional[ServerConfig] = None,
        device_override: Optional[str] = None,
        supported_devices: Optional[list[str]] = None,
    ):
        self.config = cfg or default_config
        self.device_name = device_override or self.config.device
        self.device = torch.device(self.device_name)
        self.generator: Optional[Generator] = None
        self.denoise_net: Optional[AudioDenoiseNetwork] = None
        self._models_loaded = False
        self._amp_enabled = False
        self._amp_dtype = torch.float32
        self.runtime_state = PipelineRuntimeState(
            configured_device=self.config.device,
            effective_device=self.device_name,
            supported_devices=list(supported_devices or detect_supported_devices()),
            generator=ModelLoadState(path=str(self.config.generator_model_path)),
            denoise=ModelLoadState(path=str(self.config.denoise_model_path)),
        )

    def load_models(self) -> None:
        """Load both models into memory. Call once at startup."""
        if self.runtime_state.is_ready:
            return

        self.runtime_state.generator.exists = self.config.generator_model_path.exists()
        self.runtime_state.denoise.exists = self.config.denoise_model_path.exists()
        self.runtime_state.generator.loaded = False
        self.runtime_state.denoise.loaded = False
        self.runtime_state.generator.error = None
        self.runtime_state.denoise.error = None
        self.runtime_state.degraded_reason = None
        self.runtime_state.status = ReadinessStatus.loading
        self.runtime_state.is_ready = False

        logger.info("Loading models (device: %s)...", self.device)

        if not self.runtime_state.generator.exists or not self.runtime_state.denoise.exists:
            self.generator = None
            self.denoise_net = None
            self._models_loaded = False
            self.runtime_state.status = ReadinessStatus.degraded
            self.runtime_state.degraded_reason = "missing-model-files"
            logger.warning(
                "Model files missing (generator=%s, denoise=%s)",
                self.config.generator_model_path,
                self.config.denoise_model_path,
            )
            return

        try:
            generator = Generator().to(self.device)
            generator.load_state_dict(
                torch.load(
                    str(self.config.generator_model_path),
                    map_location=self.device,
                    weights_only=True,
                )
            )
            generator.eval()
            self.generator = generator
            self.runtime_state.generator.loaded = True
            logger.info("Generator loaded from %s", self.config.generator_model_path)
        except Exception as exc:  # pragma: no cover - exercised via contract tests
            self.generator = None
            self.runtime_state.generator.error = str(exc)
            logger.exception("Failed to load generator model")

        try:
            denoise_net = AudioDenoiseNetwork().to(self.device)
            denoise_net.load_state_dict(
                torch.load(
                    str(self.config.denoise_model_path),
                    map_location=self.device,
                    weights_only=True,
                )
            )
            denoise_net.eval()
            self.denoise_net = denoise_net
            self.runtime_state.denoise.loaded = True
            logger.info("DenoiseNet loaded from %s", self.config.denoise_model_path)
        except Exception as exc:  # pragma: no cover - exercised via contract tests
            self.denoise_net = None
            self.runtime_state.denoise.error = str(exc)
            logger.exception("Failed to load denoise model")

        if self.runtime_state.generator.loaded and self.runtime_state.denoise.loaded:
            self._try_compile_models()
            self._setup_amp()
            self._models_loaded = True
            self.runtime_state.status = ReadinessStatus.ready
            self.runtime_state.is_ready = True
            logger.info("All models loaded successfully")
            return

        self._models_loaded = False
        self.runtime_state.status = ReadinessStatus.degraded
        self.runtime_state.degraded_reason = "model-load-failed"
        logger.warning("Backend started in degraded mode due to model load failure")

    def get_runtime_state(self) -> PipelineRuntimeState:
        return self.runtime_state

    def _try_compile_models(self) -> None:
        """Apply torch.compile for 15-25%% inference speedup (PyTorch 2.x+)."""
        if not self.generator or not self.denoise_net:
            return
        if not hasattr(torch, "compile"):
            logger.info("torch.compile not available (PyTorch < 2.0), skipping")
            return
        if self.device.type == "cpu":
            logger.info("Skipping torch.compile on CPU (overhead > benefit for single inference)")
            return
        if self.device.type == "mps":
            # torch.compile on MPS can fail in packaged/runtime contexts due to
            # generated Metal kernels requiring internal headers that are unavailable.
            # Keep MPS inference on eager mode by default for reliability.
            if os.environ.get("ENHANCER_ENABLE_TORCH_COMPILE_MPS", "0").lower() not in {
                "1",
                "true",
                "yes",
                "on",
            }:
                logger.info(
                    "Skipping torch.compile on MPS for stability; set "
                    "ENHANCER_ENABLE_TORCH_COMPILE_MPS=1 to force-enable"
                )
                return
        try:
            self.generator = cast(Generator, torch.compile(self.generator, mode="reduce-overhead"))
            self.denoise_net = cast(
                AudioDenoiseNetwork, torch.compile(self.denoise_net, mode="reduce-overhead")
            )
            logger.info("torch.compile applied successfully (mode=reduce-overhead)")
        except Exception as exc:  # pragma: no cover - compile availability is host-specific
            logger.warning("torch.compile failed, falling back to eager mode: %s", exc)

    def _setup_amp(self) -> None:
        """Enable mixed-precision inference on CUDA for faster GPU inference."""
        if self.device.type == "cuda":
            self._amp_enabled = True
            self._amp_dtype = torch.float16
            logger.info("AMP enabled (dtype=float16) for CUDA inference")
        else:
            self._amp_enabled = False
            self._amp_dtype = torch.float32
            logger.info("AMP disabled for device %s", self.device.type)

    @property
    def is_ready(self) -> bool:
        return self.runtime_state.is_ready

    def _ensure_ready(self) -> None:
        if not self.is_ready:
            reason = self.runtime_state.degraded_reason or "models-not-ready"
            raise RuntimeError(f"Enhancer pipeline is not ready: {reason}")

    def _tensor_to_numpy_float32(self, tensor: torch.Tensor) -> np.ndarray:
        """Convert inference outputs to a NumPy-friendly dtype before leaving PyTorch."""
        return tensor.detach().to(device="cpu", dtype=torch.float32).numpy()

    # ------------------------------------------------------------------
    # Step 1: IMU data preprocessing
    # ------------------------------------------------------------------
    def process_imu_data(self, acc_path: str, gyro_path: str) -> np.ndarray:
        """
        Read acc/gyro txt files → truncate/pad to 125 → interpolate to 150
        → compute magnitude → combine to (150, 2).

        Uses pd.read_csv with auto-separator detection for robustness,
        while keeping output shape and semantics aligned with test_单个.py.
        """
        cfg = self.config

        def load_and_fix(path: str) -> np.ndarray:
            try:
                df = pd.read_csv(path, sep=None, engine="python", header=None)
                if df.shape[1] == 3:
                    data = df.values
                elif df.shape[1] >= 4:
                    data = df.iloc[:, 1:4].values
                else:
                    raise ValueError(f"IMU file has insufficient columns: {path} (cols={df.shape[1]})")
            except Exception as exc:
                raise ValueError(f"Failed to parse IMU file: {path}") from exc

            if len(data) == 0:
                raise ValueError(f"IMU file has no valid rows: {path}")

            if len(data) >= cfg.imu_truncate_len:
                data = data[: cfg.imu_truncate_len]
            else:
                pad = np.zeros((cfg.imu_truncate_len - len(data), 3))
                data = np.vstack([data, pad]) if len(data) > 0 else pad
            return data.astype(np.float64)

        def interpolate(data: np.ndarray) -> np.ndarray:
            orig = np.linspace(0, 5.0, cfg.imu_truncate_len, endpoint=False)
            target = np.linspace(0, 5.0, cfg.imu_interp_len, endpoint=False)
            res = np.empty((cfg.imu_interp_len, 3))
            for i in range(3):
                res[:, i] = np.interp(target, orig, data[:, i])
            return res

        acc = load_and_fix(acc_path)
        gyro = load_and_fix(gyro_path)

        acc_150 = interpolate(acc)
        gyro_150 = interpolate(gyro)

        acc_norm = np.sqrt(np.sum(acc_150**2, axis=1, keepdims=True))
        gyro_norm = np.sqrt(np.sum(gyro_150**2, axis=1, keepdims=True))
        return np.hstack((acc_norm, gyro_norm)).astype(np.float32)

    # ------------------------------------------------------------------
    # Step 2: GAN video displacement generation
    # ------------------------------------------------------------------
    def generate_video_displacement(self, imu_data: np.ndarray) -> np.ndarray:
        """
        IMU magnitude data (150, 2) → GAN → video displacement (150, 40).
        """
        self._ensure_ready()
        cfg = self.config
        assert self.generator is not None
        min_v, max_v = imu_data.min(), imu_data.max()
        if max_v == min_v:
            norm = np.zeros_like(imu_data, dtype=np.uint8)
        else:
            norm = ((imu_data - min_v) / (max_v - min_v) * 255).astype(np.uint8)

        img_pil = Image.fromarray(norm.T, mode="L")
        if img_pil.size[0] > img_pil.size[1]:
            img_pil = img_pil.rotate(90, expand=True)

        imu_np = np.array(img_pil, dtype=np.float32)
        imu_np = (imu_np / 127.5) - 1.0
        imu_tensor = torch.from_numpy(imu_np).unsqueeze(0).unsqueeze(0).to(self.device)

        if imu_tensor.shape[2:] != (cfg.imu_interp_len, 6):
            imu_tensor = F.interpolate(
                imu_tensor, size=(cfg.imu_interp_len, 6), mode="bilinear", align_corners=True
            )

        with torch.inference_mode():
            if self._amp_enabled:
                with torch.autocast(device_type=self.device.type, dtype=self._amp_dtype):
                    gen_tensor = self.generator(imu_tensor)
            else:
                gen_tensor = self.generator(imu_tensor)

        gen_tensor = (gen_tensor + 1) / 2
        gen_tensor = F.interpolate(
            gen_tensor,
            size=(cfg.video_disp_height, cfg.video_disp_width),
            mode="bilinear",
            align_corners=True,
        )
        gen_np = self._tensor_to_numpy_float32(gen_tensor.squeeze())
        gen_img = Image.fromarray((gen_np * 255).astype(np.uint8))

        rotated_img = gen_img.rotate(-90, expand=True)
        gray_image = np.array(rotated_img)
        data_transposed = gray_image.T.astype(np.float32)

        v_range = cfg.video_fixed_max - cfg.video_fixed_min
        recovered_data = ((data_transposed / 255.0) * v_range + cfg.video_fixed_min).astype(
            np.float32
        )

        return recovered_data

    # ------------------------------------------------------------------
    # Step 3: Audio STFT preprocessing
    # ------------------------------------------------------------------
    def process_audio_input(self, wav_path: str) -> tuple[np.ndarray, np.ndarray, int]:
        """
        WAV → STFT → normalized spectrogram (1025, 431) + phase.
        Returns (spec_norm, phase, sample_rate).
        """
        cfg = self.config
        strict_no_fallback = _fallback_forbidden()
        librosa = _try_import_librosa()
        D: np.ndarray
        sr: int

        if librosa is not None:
            try:
                y, sr_loaded = librosa.load(wav_path, sr=None)
                sr = int(sr_loaded)
                D = librosa.stft(y)
                S_db = librosa.amplitude_to_db(np.abs(D), ref=np.max)
            except Exception as exc:
                if strict_no_fallback:
                    raise RuntimeError(
                        "librosa STFT failed in strict mode; fallback is disabled"
                    ) from exc
                logger.warning("librosa STFT failed, falling back to scipy STFT: %s", exc)
                y, sr = sf.read(wav_path, always_2d=False)
                if y.ndim > 1:
                    y = np.mean(y, axis=1)
                y = y.astype(np.float32, copy=False)
                _, _, D = signal.stft(
                    y,
                    fs=sr,
                    window="hann",
                    nperseg=_STFT_WIN_LENGTH,
                    noverlap=_STFT_NOVERLAP,
                    nfft=_STFT_WIN_LENGTH,
                    boundary="zeros",
                    padded=True,
                    return_onesided=True,
                )
                S_db = _amplitude_to_db(np.abs(D))
        else:
            y, sr = sf.read(wav_path, always_2d=False)
            if y.ndim > 1:
                y = np.mean(y, axis=1)
            y = y.astype(np.float32, copy=False)
            _, _, D = signal.stft(
                y,
                fs=sr,
                window="hann",
                nperseg=_STFT_WIN_LENGTH,
                noverlap=_STFT_NOVERLAP,
                nfft=_STFT_WIN_LENGTH,
                boundary="zeros",
                padded=True,
                return_onesided=True,
            )
            S_db = _amplitude_to_db(np.abs(D))

        S_norm = (S_db - S_db.min()) / (S_db.max() - S_db.min() + 1e-9)

        S_norm = S_norm[::-1, :].copy()
        phase = np.angle(D)

        if S_norm.shape != (cfg.spec_freq_bins, cfg.spec_time_steps):
            S_norm = cv2.resize(S_norm, (cfg.spec_time_steps, cfg.spec_freq_bins))

        return S_norm, phase, sr

    # ------------------------------------------------------------------
    # Step 4: Joint denoise model inference
    # ------------------------------------------------------------------
    def run_denoise_model(
        self, audio_spec_norm: np.ndarray, video_data_npy: np.ndarray
    ) -> np.ndarray:
        """
        Audio spectrogram + video displacement → clean spectrogram.
        """
        self._ensure_ready()
        cfg = self.config
        assert self.denoise_net is not None
        audio_in = audio_spec_norm.T.copy()
        audio_tensor = (
            torch.tensor(audio_in, dtype=torch.float32).unsqueeze(0).unsqueeze(0).to(self.device)
        )

        video_norm = (video_data_npy - cfg.video_mean) / cfg.video_std
        video_tensor = torch.tensor(video_norm, dtype=torch.float32).unsqueeze(0).to(self.device)

        with torch.inference_mode():
            if self._amp_enabled:
                with torch.autocast(device_type=self.device.type, dtype=self._amp_dtype):
                    clean_spec = self.denoise_net(audio_tensor, video_tensor)
            else:
                clean_spec = self.denoise_net(audio_tensor, video_tensor)
            clean_spec = torch.clamp(clean_spec, 0.0, 1.0)

        return self._tensor_to_numpy_float32(clean_spec.squeeze())

    # ------------------------------------------------------------------
    # Step 5: Spectrogram post-processing (Pic → NPY)
    # ------------------------------------------------------------------
    def convert_spec_to_npy(self, clean_spec_np: np.ndarray) -> np.ndarray:
        """
        Clean spectrogram → uint8 image → re-normalize → flip.
        """
        img_data = clean_spec_np.T
        img_uint8 = (img_data * 255).astype(np.uint8)
        img_normalized = img_uint8.astype(np.float32) / 255.0
        img_flipped = img_normalized[::-1, :].copy()
        return img_flipped

    # ------------------------------------------------------------------
    # Step 6: ISTFT audio reconstruction
    # ------------------------------------------------------------------
    def reconstruct_audio_istft(
        self, norm_mag: np.ndarray, phase: np.ndarray, output_wav_path: str
    ) -> str:
        """
        Reconstructs audio from cleaned magnitude and original phase.
        Applies peak normalization. Returns output path.
        """
        cfg = self.config
        strict_no_fallback = _fallback_forbidden()
        norm_mag = norm_mag.astype(np.float32)

        if norm_mag.shape != phase.shape:
            target_width = phase.shape[1]
            target_height = phase.shape[0]
            norm_mag = cv2.resize(
                norm_mag, (target_width, target_height), interpolation=cv2.INTER_LINEAR
            )

        if cfg.db_range != _DB_RANGE_FIXED:
            logger.warning(
                "db_range is configured as %s, but reconstruction is locked to %s to match model training.",
                cfg.db_range,
                _DB_RANGE_FIXED,
            )

        S_db = norm_mag * _DB_RANGE_FIXED - _DB_RANGE_FIXED

        librosa = _try_import_librosa()
        if librosa is not None:
            try:
                magnitude = librosa.db_to_amplitude(S_db)
            except Exception as exc:
                if strict_no_fallback:
                    raise RuntimeError(
                        "librosa dB conversion failed in strict mode; fallback is disabled"
                    ) from exc
                logger.warning("librosa dB conversion failed, using numpy fallback: %s", exc)
                magnitude = _db_to_amplitude(S_db)
        else:
            magnitude = _db_to_amplitude(S_db)

        if magnitude.shape != phase.shape:
            magnitude = magnitude[: phase.shape[0], : phase.shape[1]]

        D = magnitude * np.exp(1j * phase)
        if librosa is not None:
            try:
                y_recon = librosa.istft(
                    D,
                    hop_length=_STFT_HOP_LENGTH,
                    win_length=_STFT_WIN_LENGTH,
                    window="hann",
                    center=True,
                )
            except Exception as exc:
                if strict_no_fallback:
                    raise RuntimeError(
                        "librosa ISTFT failed in strict mode; fallback is disabled"
                    ) from exc
                logger.warning("librosa ISTFT failed, falling back to scipy ISTFT: %s", exc)
                _, y_recon = signal.istft(
                    D,
                    fs=cfg.sample_rate,
                    window="hann",
                    nperseg=_STFT_WIN_LENGTH,
                    noverlap=_STFT_NOVERLAP,
                    nfft=_STFT_WIN_LENGTH,
                    input_onesided=True,
                    boundary=True,
                )
        else:
            _, y_recon = signal.istft(
                D,
                fs=cfg.sample_rate,
                window="hann",
                nperseg=_STFT_WIN_LENGTH,
                noverlap=_STFT_NOVERLAP,
                nfft=_STFT_WIN_LENGTH,
                input_onesided=True,
                boundary=True,
            )

        y_recon = np.asarray(y_recon, dtype=np.float32)

        # Peak normalization
        max_amp = np.max(np.abs(y_recon))
        if max_amp > 0:
            scale_factor = cfg.target_peak / max_amp
            y_recon = y_recon * scale_factor

        sf.write(output_wav_path, y_recon, cfg.sample_rate)
        logger.info("Audio saved to %s", output_wav_path)
        return output_wav_path

    # ------------------------------------------------------------------
    # Full pipeline
    # ------------------------------------------------------------------
    def process_single(
        self,
        wav_path: str,
        acc_path: str,
        gyro_path: str,
        output_wav_path: str,
        on_progress: Optional[ProgressCallback] = None,
        should_cancel: Optional[ShouldCancelCallback] = None,
    ) -> dict:
        """
        Run the complete 6-step enhancement pipeline on a single sample.

        Steps 1-2 (IMU → video displacement) and Step 3 (audio STFT) are
        independent and run in parallel to reduce total latency.

        Returns dict with timing info and output path.
        """
        self.load_models()
        self._ensure_ready()

        def _check_cancel() -> None:
            if should_cancel and should_cancel():
                raise InterruptedError("Task cancelled")

        def _progress(step: int, pct: int, msg: str = ""):
            _check_cancel()
            if on_progress:
                on_progress(step, PIPELINE_STEPS[step], pct, msg)

        total_start = time.time()
        step_times: dict[str, float] = {}

        # Steps 1-2 (IMU → video disp) and Step 3 (audio STFT) run in parallel
        _progress(0, 0, "Reading sensor data...")
        _progress(2, 0, "Extracting audio features...")

        def _imu_and_video():
            _check_cancel()
            t0 = time.time()
            imu_data = self.process_imu_data(acc_path, gyro_path)
            t_imu = time.time() - t0
            _check_cancel()
            t1 = time.time()
            video_disp = self.generate_video_displacement(imu_data)
            t_video = time.time() - t1
            return imu_data, video_disp, t_imu, t_video

        def _audio_stft():
            _check_cancel()
            t0 = time.time()
            result = self.process_audio_input(wav_path)
            t_audio = time.time() - t0
            return result, t_audio

        fut_imu = _io_executor.submit(_imu_and_video)
        fut_audio = _io_executor.submit(_audio_stft)

        imu_data, video_disp, t_imu, t_video = fut_imu.result()
        _check_cancel()
        step_times[PIPELINE_STEPS[0]] = round(t_imu, 4)
        step_times[PIPELINE_STEPS[1]] = round(t_video, 4)
        _progress(0, 100, "IMU data processed")
        _progress(1, 100, "Video displacement generated")

        (audio_spec_norm, audio_phase, sr), t_audio = fut_audio.result()
        _check_cancel()
        step_times[PIPELINE_STEPS[2]] = round(t_audio, 4)
        _progress(2, 100, "Audio features extracted")

        # Step 4: Joint denoise
        _progress(3, 0, "Running denoise model...")
        t0 = time.time()
        clean_spec_raw = self.run_denoise_model(audio_spec_norm, video_disp)
        _check_cancel()
        step_times[PIPELINE_STEPS[3]] = round(time.time() - t0, 4)
        _progress(3, 100, "Denoising complete")

        # Step 5: Spectrogram post-processing
        _progress(4, 0, "Post-processing spectrogram...")
        t0 = time.time()
        cleaned_npy = self.convert_spec_to_npy(clean_spec_raw)
        _check_cancel()
        step_times[PIPELINE_STEPS[4]] = round(time.time() - t0, 4)
        _progress(4, 100, "Spectrogram processed")

        # Step 6: ISTFT reconstruction
        _progress(5, 0, "Reconstructing audio...")
        t0 = time.time()
        output_path = self.reconstruct_audio_istft(cleaned_npy, audio_phase, output_wav_path)
        _check_cancel()
        step_times[PIPELINE_STEPS[5]] = round(time.time() - t0, 4)
        _progress(5, 100, "Audio reconstruction complete")

        total_time = time.time() - total_start

        return {
            "output_path": output_path,
            "total_time": round(total_time, 4),
            "step_times": step_times,
            "device": str(self.device),
            "sample_rate": self.config.sample_rate,
        }

    # ------------------------------------------------------------------
    # Batch processing (synced from reference UltraFastPipeline)
    # ------------------------------------------------------------------
    def process_batch(
        self,
        samples: list[dict],
        on_progress: Optional[Callable[[int, int, str], None]] = None,
        should_cancel: Optional[ShouldCancelCallback] = None,
    ) -> list[dict]:
        """
        Process multiple samples with batched GPU inference.

        Each sample dict must have keys: wav_path, acc_path, gyro_path, output_wav_path.
        on_progress callback: (completed_count, total_count, message)

        Returns list of result dicts.
        """
        self.load_models()
        self._ensure_ready()

        total = len(samples)
        results: list[dict] = []

        for i, sample in enumerate(samples):
            if should_cancel and should_cancel():
                raise InterruptedError("Task cancelled")
            if on_progress:
                on_progress(i, total, f"Processing sample {i + 1}/{total}")
            try:
                result = self.process_single(
                    sample["wav_path"],
                    sample["acc_path"],
                    sample["gyro_path"],
                    sample["output_wav_path"],
                    should_cancel=should_cancel,
                )
                results.append({"success": True, **result})
            except InterruptedError:
                raise
            except Exception as exc:
                logger.error("Batch item %d failed: %s", i, exc)
                results.append({"success": False, "error": str(exc)})

        if on_progress:
            on_progress(total, total, "Batch processing complete")

        return results


class PipelineManager:
    """Resolve request devices and cache pipelines per effective runtime device."""

    def __init__(self, cfg: Optional[ServerConfig] = None):
        self.config = cfg or default_config
        self.supported_devices = detect_supported_devices()
        self._pipelines: dict[str, EnhancerPipeline] = {}

    def _pick_best_available_device(self) -> str:
        """Prefer GPU-capable runtimes for auto selection when available."""
        for candidate in (DeviceType.cuda.value, DeviceType.mps.value, DeviceType.cpu.value):
            if candidate in self.supported_devices:
                return candidate
        return self.supported_devices[0] if self.supported_devices else DeviceType.cpu.value

    def resolve_device(self, requested_device: str | DeviceType | None = None) -> str:
        device_value = requested_device.value if isinstance(requested_device, DeviceType) else requested_device
        device_value = (device_value or DeviceType.auto.value).strip().lower()

        if device_value == DeviceType.auto.value:
            configured = str(getattr(self.config, "device", DeviceType.auto.value) or "").strip().lower()
            if configured and configured != DeviceType.auto.value and configured in self.supported_devices:
                return configured
            return self._pick_best_available_device()

        if device_value not in self.supported_devices:
            supported = ", ".join(self.supported_devices) if self.supported_devices else DeviceType.cpu.value
            raise ValueError(
                f"Requested device is not available: {device_value}. Available: {supported}"
            )
        return device_value

    def get_pipeline(
        self, requested_device: str | DeviceType | None = None
    ) -> tuple[EnhancerPipeline, str]:
        effective_device = self.resolve_device(requested_device)
        pipeline = self._pipelines.get(effective_device)
        if pipeline is None:
            pipeline = EnhancerPipeline(
                self.config,
                device_override=effective_device,
                supported_devices=self.supported_devices,
            )
            pipeline.load_models()
            self._pipelines[effective_device] = pipeline
        return pipeline, effective_device

    def initialize(self) -> PipelineRuntimeState:
        pipeline, _ = self.get_pipeline(self.config.device)
        return pipeline.get_runtime_state()

    def get_runtime_state(
        self, requested_device: str | DeviceType | None = None
    ) -> PipelineRuntimeState:
        pipeline, _ = self.get_pipeline(requested_device or self.config.device)
        return pipeline.get_runtime_state()
