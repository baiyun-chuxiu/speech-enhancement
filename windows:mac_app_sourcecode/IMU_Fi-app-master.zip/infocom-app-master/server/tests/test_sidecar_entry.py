import runpy


def test_sidecar_entry_runs_server_cli(monkeypatch):
    called = {"value": False}

    def fake_cli():
        called["value"] = True

    monkeypatch.setattr("server.main._cli", fake_cli)

    runpy.run_module("server.sidecar_entry", run_name="__main__")

    assert called["value"] is True
