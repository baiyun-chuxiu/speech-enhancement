from types import SimpleNamespace

import pytest

from server.pipeline import PipelineManager


def test_resolve_device_auto_prefers_gpu_when_config_is_auto():
    manager = PipelineManager(cfg=SimpleNamespace(device="auto"))
    manager.supported_devices = ["cpu", "cuda"]

    assert manager.resolve_device("auto") == "cuda"


def test_resolve_device_auto_uses_best_available_when_config_is_invalid():
    manager = PipelineManager(cfg=SimpleNamespace(device="unknown"))
    manager.supported_devices = ["cpu", "cuda"]

    assert manager.resolve_device("auto") == "cuda"


def test_resolve_device_error_lists_supported_targets():
    manager = PipelineManager(cfg=SimpleNamespace(device="cpu"))
    manager.supported_devices = ["cpu"]

    with pytest.raises(ValueError, match="Available"):
        manager.resolve_device("cuda")
