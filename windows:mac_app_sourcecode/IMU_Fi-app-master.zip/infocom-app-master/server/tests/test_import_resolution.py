from pathlib import Path

import server


def test_pytest_uses_checkout_server_package():
    repo_root = Path(__file__).resolve().parents[2]
    expected = repo_root / "server" / "__init__.py"

    assert Path(server.__file__).resolve() == expected
