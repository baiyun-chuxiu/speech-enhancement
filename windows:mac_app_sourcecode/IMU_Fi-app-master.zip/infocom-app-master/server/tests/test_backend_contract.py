import asyncio
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

import server.main as main
import server.routes as routes
from server.pipeline import PIPELINE_STEPS
from server.schemas import ProcessingStep, TaskInfo, TaskStatus


class FakePipeline:
    def __init__(self, *, device: str = "cpu", ready: bool = True, should_delay: bool = False):
        self.device = device
        self.is_ready = ready
        self.generator = object() if ready else None
        self.denoise_net = object() if ready else None
        self.runtime_state = {
            "status": "ready" if ready else "degraded",
            "is_ready": ready,
            "configured_device": "cpu",
            "effective_device": device,
            "supported_devices": ["cpu"],
            "degraded_reason": None if ready else "missing-model-files",
            "generator_loaded": ready,
            "denoise_loaded": ready,
            "generator_model_exists": ready,
            "denoise_model_exists": ready,
        }
        self.should_delay = should_delay

    def process_single(self, wav_path, acc_path, gyro_path, output_wav_path, on_progress=None, **kwargs):
        if on_progress:
            on_progress(0, PIPELINE_STEPS[0], 10, "Processing")
        if self.should_delay:
            time.sleep(0.05)

        Path(output_wav_path).write_bytes(b"RIFF")
        return {
            "output_path": output_wav_path,
            "total_time": 0.01,
            "step_times": {PIPELINE_STEPS[0]: 0.01},
            "device": self.device,
            "sample_rate": 44100,
        }

    def process_batch(self, samples, on_progress=None, **kwargs):
        results = []
        total = len(samples)
        for index, sample in enumerate(samples, start=1):
            if on_progress:
                on_progress(index - 1, total, f"Processing sample {index}/{total}")
            Path(sample["output_wav_path"]).write_bytes(b"RIFF")
            results.append(
                {
                    "success": True,
                    "output_path": sample["output_wav_path"],
                    "total_time": 0.01,
                    "device": self.device,
                }
            )
        if on_progress:
            on_progress(total, total, "Batch processing complete")
        return results


class FakePipelineManager:
    def __init__(self, pipeline: FakePipeline):
        self.pipeline = pipeline
        self.runtime_state = pipeline.runtime_state

    def initialize(self):
        return self.runtime_state

    def get_runtime_state(self):
        return self.runtime_state

    def resolve_device(self, requested_device: str):
        supported = self.runtime_state["supported_devices"]
        if requested_device in ("auto", "", None):
            return self.runtime_state["effective_device"]
        if requested_device not in supported:
            raise ValueError(f"Requested device is not available: {requested_device}")
        return requested_device

    def get_pipeline(self, requested_device: str = "auto"):
        return self.pipeline, self.resolve_device(requested_device)


@pytest.fixture(autouse=True)
def reset_route_state(monkeypatch, tmp_path):
    upload_dir = tmp_path / "uploads"
    output_dir = tmp_path / "outputs"
    upload_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    monkeypatch.setattr(routes.config, "upload_dir", upload_dir)
    monkeypatch.setattr(routes.config, "output_dir", output_dir)

    routes.tasks.clear()
    routes.uploaded_files.clear()
    routes.websocket_connections.clear()

    if hasattr(routes, "pipeline"):
        routes.pipeline = None
    if hasattr(routes, "pipeline_manager"):
        routes.pipeline_manager = None


def install_fake_backend(monkeypatch, pipeline: FakePipeline):
    manager = FakePipelineManager(pipeline)

    def fake_init_pipeline():
        if hasattr(routes, "pipeline"):
            routes.pipeline = pipeline
        if hasattr(routes, "pipeline_manager"):
            routes.pipeline_manager = manager

    monkeypatch.setattr(main, "init_pipeline", fake_init_pipeline)
    monkeypatch.setattr(routes, "get_pipeline", lambda *args, **kwargs: pipeline)

    if hasattr(routes, "pipeline_manager"):
        routes.pipeline_manager = manager
    if hasattr(routes, "pipeline"):
        routes.pipeline = pipeline

    return manager


def create_client(monkeypatch, pipeline: FakePipeline) -> TestClient:
    install_fake_backend(monkeypatch, pipeline)
    return TestClient(main.app)


def multipart_files():
    return {
        "audio_file": ("sample.wav", b"RIFFDATA", "audio/wav"),
        "accel_file": ("accel.txt", b"0,0,0\n1,1,1\n", "text/plain"),
        "gyro_file": ("gyro.txt", b"0,0,0\n1,1,1\n", "text/plain"),
    }


def batch_multipart_files():
    return [
        ("audio_files", ("sample.wav", b"RIFFDATA", "audio/wav")),
        ("accel_files", ("accel.txt", b"0,0,0\n1,1,1\n", "text/plain")),
        ("gyro_files", ("gyro.txt", b"0,0,0\n1,1,1\n", "text/plain")),
    ]


def test_liveness_and_readiness_are_reported_separately(monkeypatch):
    pipeline = FakePipeline(ready=False)
    client = create_client(monkeypatch, pipeline)

    with client:
        health = client.get("/health")
        ready = client.get("/ready")

    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    assert ready.status_code == 200
    assert ready.json()["status"] == "degraded"
    assert ready.json()["is_ready"] is False
    assert ready.json()["degraded_reason"] == "missing-model-files"


def test_system_info_reports_truthful_model_diagnostics(monkeypatch):
    pipeline = FakePipeline(ready=False)
    client = create_client(monkeypatch, pipeline)

    with client:
        response = client.get("/api/v1/system/info")

    assert response.status_code == 200
    body = response.json()
    assert body["is_ready"] is False
    assert body["generator_loaded"] is False
    assert body["denoise_loaded"] is False
    assert body["generator_model_exists"] is False
    assert body["denoise_model_exists"] is False
    assert body["supported_devices"] == ["cpu"]
    assert body["degraded_reason"] == "missing-model-files"


def test_enhance_rejects_unsupported_device_before_task_creation(monkeypatch):
    pipeline = FakePipeline(ready=True)
    client = create_client(monkeypatch, pipeline)

    with client:
        response = client.post("/api/v1/enhance?device=cuda", files=multipart_files())

    assert response.status_code == 400
    assert "device" in response.json()["detail"].lower()
    assert routes.tasks == {}


def test_enhancement_task_records_requested_and_effective_device(monkeypatch):
    pipeline = FakePipeline(ready=True, device="cpu")
    client = create_client(monkeypatch, pipeline)

    with client:
        start = client.post("/api/v1/enhance?device=auto", files=multipart_files())
        task_id = start.json()["task_id"]
        task = client.get(f"/api/v1/tasks/{task_id}")

    assert start.status_code == 200
    assert task.status_code == 200
    body = task.json()
    assert body["status"] == "completed"
    assert body["requested_device"] == "auto"
    assert body["effective_device"] == "cpu"
    assert body["result"]["requested_device"] == "auto"
    assert body["result"]["effective_device"] == "cpu"


def test_batch_rejects_unsupported_device_before_task_creation(monkeypatch):
    pipeline = FakePipeline(ready=True)
    client = create_client(monkeypatch, pipeline)

    with client:
        response = client.post("/api/v1/enhance/batch?device=cuda", files=batch_multipart_files())

    assert response.status_code == 400
    assert "device" in response.json()["detail"].lower()
    assert routes.tasks == {}


@pytest.mark.asyncio
async def test_cancelled_task_does_not_flip_back_to_completed(monkeypatch, tmp_path):
    pipeline = FakePipeline(ready=True, should_delay=True)
    install_fake_backend(monkeypatch, pipeline)

    task_id = "task-cancel"
    output_file_id = "output-cancel"
    output_path = str(tmp_path / "outputs" / f"{output_file_id}.wav")
    routes.tasks[task_id] = TaskInfo(
        task_id=task_id,
        status=TaskStatus.pending,
        steps=[ProcessingStep(index=i, name=name) for i, name in enumerate(PIPELINE_STEPS)],
    )

    runner = asyncio.create_task(
        routes._run_enhancement(
            task_id,
            "audio.wav",
            "accel.txt",
            "gyro.txt",
            output_path,
            output_file_id,
            requested_device="cpu",
            effective_device="cpu",
        )
    )
    await asyncio.sleep(0.01)
    routes.tasks[task_id].status = TaskStatus.cancelled
    await runner

    task = routes.tasks[task_id]
    assert task.status == TaskStatus.cancelled
    assert task.result is None
