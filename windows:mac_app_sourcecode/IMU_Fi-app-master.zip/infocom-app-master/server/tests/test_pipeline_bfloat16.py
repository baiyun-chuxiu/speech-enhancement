import numpy as np
import torch

from server.pipeline import EnhancerPipeline
from server.schemas import ReadinessStatus


class BFloat16Generator(torch.nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.ones((x.shape[0], 1, x.shape[2], x.shape[3]), dtype=torch.bfloat16, device=x.device)


class BFloat16Denoise(torch.nn.Module):
    def forward(self, audio: torch.Tensor, video: torch.Tensor) -> torch.Tensor:
        return torch.ones_like(audio, dtype=torch.bfloat16)


def build_ready_pipeline() -> EnhancerPipeline:
    pipeline = EnhancerPipeline(device_override="cpu", supported_devices=["cpu"])
    pipeline.generator = BFloat16Generator()
    pipeline.denoise_net = BFloat16Denoise()
    pipeline.runtime_state.is_ready = True
    pipeline.runtime_state.status = ReadinessStatus.ready
    return pipeline


def test_generate_video_displacement_converts_bfloat16_output_to_numpy() -> None:
    pipeline = build_ready_pipeline()

    video_disp = pipeline.generate_video_displacement(np.ones((150, 2), dtype=np.float32))

    assert video_disp.shape == (150, 40)
    assert video_disp.dtype == np.float32


def test_run_denoise_model_converts_bfloat16_output_to_numpy() -> None:
    pipeline = build_ready_pipeline()

    clean_spec = pipeline.run_denoise_model(
        np.ones((1025, 431), dtype=np.float32),
        np.ones((150, 40), dtype=np.float32),
    )

    assert clean_spec.shape == (431, 1025)
    assert clean_spec.dtype == np.float32
