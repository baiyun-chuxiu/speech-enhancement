from server.config import ServerConfig


def test_default_cors_origins_include_tauri_desktop_hosts():
    config = ServerConfig()

    assert "http://tauri.localhost" in config.cors_origins
    assert "https://tauri.localhost" in config.cors_origins
    assert "tauri://localhost" in config.cors_origins
