from pathlib import Path
from unittest.mock import patch

import pytest

from server.build_sidecar import (
    COLLECT_BINARIES,
    COLLECT_DATA,
    COLLECT_SUBMODULES,
    HIDDEN_IMPORTS,
    REQUIRED_MODEL_FILES,
    build_pyinstaller_command,
    validate_required_models,
    verify_built_sidecar,
)


def test_validate_required_models_rejects_missing_weights(tmp_path: Path):
    models_dir = tmp_path / "models"
    models_dir.mkdir()
    (models_dir / ".gitkeep").write_text("", encoding="utf-8")
    (models_dir / REQUIRED_MODEL_FILES[0]).write_text("stub", encoding="utf-8")

    with pytest.raises(FileNotFoundError, match=REQUIRED_MODEL_FILES[1]):
        validate_required_models(models_dir)


def test_build_pyinstaller_command_includes_models_data_dir(tmp_path: Path):
    project_root = tmp_path / "project"
    script_dir = project_root / "server"
    dist_dir = project_root / "src-tauri" / "binaries"
    models_dir = script_dir / "models"
    sidecar_entry = script_dir / "sidecar_entry.py"

    models_dir.mkdir(parents=True)
    dist_dir.mkdir(parents=True)
    sidecar_entry.write_text("print('sidecar')", encoding="utf-8")

    for filename in REQUIRED_MODEL_FILES:
        (models_dir / filename).write_text("stub", encoding="utf-8")

    command = build_pyinstaller_command(
        python_executable="python",
        triple="x86_64-pc-windows-msvc",
        project_root=project_root,
        script_dir=script_dir,
        dist_path=dist_dir,
        entrypoint=sidecar_entry,
        platform_name="win32",
    )

    add_data_index = command.index("--add-data")
    assert command[add_data_index + 1] == f"{models_dir};models"


def test_build_pyinstaller_command_collects_torch_binaries_for_gpu_runtime(tmp_path: Path):
    project_root = tmp_path / "project"
    script_dir = project_root / "server"
    dist_dir = project_root / "src-tauri" / "binaries"
    models_dir = script_dir / "models"
    sidecar_entry = script_dir / "sidecar_entry.py"

    models_dir.mkdir(parents=True)
    dist_dir.mkdir(parents=True)
    sidecar_entry.write_text("print('sidecar')", encoding="utf-8")

    for filename in REQUIRED_MODEL_FILES:
        (models_dir / filename).write_text("stub", encoding="utf-8")

    command = build_pyinstaller_command(
        python_executable="python",
        triple="x86_64-pc-windows-msvc",
        project_root=project_root,
        script_dir=script_dir,
        dist_path=dist_dir,
        entrypoint=sidecar_entry,
        platform_name="win32",
    )

    assert "--collect-binaries" in command
    collect_binaries_index = command.index("--collect-binaries")
    assert command[collect_binaries_index + 1] == "torch"
    assert "--collect-submodules" in command
    collect_submodules_index = command.index("--collect-submodules")
    assert command[collect_submodules_index + 1] == "torch.cuda"


def test_build_pyinstaller_command_collects_runtime_audio_dependencies(tmp_path: Path):
    project_root = tmp_path / "project"
    script_dir = project_root / "server"
    dist_dir = project_root / "src-tauri" / "binaries"
    models_dir = script_dir / "models"
    sidecar_entry = script_dir / "sidecar_entry.py"

    models_dir.mkdir(parents=True)
    dist_dir.mkdir(parents=True)
    sidecar_entry.write_text("print('sidecar')", encoding="utf-8")

    for filename in REQUIRED_MODEL_FILES:
        (models_dir / filename).write_text("stub", encoding="utf-8")

    command = build_pyinstaller_command(
        python_executable="python",
        triple="x86_64-pc-windows-msvc",
        project_root=project_root,
        script_dir=script_dir,
        dist_path=dist_dir,
        entrypoint=sidecar_entry,
        platform_name="win32",
    )

    command_pairs = [command[i : i + 2] for i in range(len(command) - 1)]

    for package_name in COLLECT_SUBMODULES:
        assert ["--collect-submodules", package_name] in command_pairs

    for package_name in COLLECT_BINARIES:
        assert ["--collect-binaries", package_name] in command_pairs

    for package_name in COLLECT_DATA:
        assert ["--collect-data", package_name] in command_pairs

    assert "librosa" in HIDDEN_IMPORTS
    assert "audioread" in HIDDEN_IMPORTS


def test_verify_built_sidecar_runs_smoke_check(tmp_path: Path):
    project_root = tmp_path / "project"
    server_dir = project_root / "server"
    server_dir.mkdir(parents=True)
    (server_dir / "smoke_check.py").write_text("print('smoke')", encoding="utf-8")
    sidecar_path = project_root / "src-tauri" / "binaries" / "audio-enhancer-server.exe"
    sidecar_path.parent.mkdir(parents=True)
    sidecar_path.write_text("binary", encoding="utf-8")

    with patch("server.build_sidecar.subprocess.run") as mocked_run:
        verify_built_sidecar(
            python_executable="python",
            project_root=project_root,
            sidecar_path=sidecar_path,
        )

    mocked_run.assert_called_once()
    called_command = mocked_run.call_args.args[0]
    assert called_command[:3] == ["python", str(server_dir / "smoke_check.py"), "--command"]
    assert str(sidecar_path) in called_command
    assert "--expect-ready" in called_command
