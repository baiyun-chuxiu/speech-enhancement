import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]

if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

loaded_server = sys.modules.get("server")
if loaded_server is not None:
    loaded_from = Path(getattr(loaded_server, "__file__", "")).resolve()
    if REPO_ROOT not in loaded_from.parents:
        sys.modules.pop("server", None)
