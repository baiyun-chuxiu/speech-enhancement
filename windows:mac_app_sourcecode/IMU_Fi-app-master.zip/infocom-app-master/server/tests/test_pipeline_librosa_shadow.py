import sys

import numpy as np
import soundfile as sf

from server.pipeline import EnhancerPipeline


def test_process_audio_input_ignores_shadow_coverage_namespace(tmp_path, monkeypatch) -> None:
    shadow_root = tmp_path / "shadow-root"
    (shadow_root / "coverage").mkdir(parents=True)

    wav_path = tmp_path / "sample.wav"
    sf.write(wav_path, np.zeros(44100, dtype=np.float32), 44100)

    for name in list(sys.modules):
        if name == "coverage" or name.startswith("numba") or name.startswith("librosa.core."):
            sys.modules.pop(name, None)

    monkeypatch.syspath_prepend(str(shadow_root))

    pipeline = EnhancerPipeline(device_override="cpu", supported_devices=["cpu"])

    spec_norm, phase, sr = pipeline.process_audio_input(str(wav_path))

    assert sr == 44100
    assert spec_norm.shape == (pipeline.config.spec_freq_bins, pipeline.config.spec_time_steps)
    assert phase.ndim == 2


def test_process_audio_input_falls_back_when_librosa_is_broken(monkeypatch, tmp_path) -> None:
    class ExplodingLibrosaModule:
        def __getattr__(self, name: str):
            raise RuntimeError(f"broken librosa module: {name}")

    monkeypatch.setitem(sys.modules, "librosa", ExplodingLibrosaModule())

    wav_path = tmp_path / "sample.wav"
    sf.write(wav_path, np.zeros(44100, dtype=np.float32), 44100)

    pipeline = EnhancerPipeline(device_override="cpu", supported_devices=["cpu"])
    spec_norm, phase, sr = pipeline.process_audio_input(str(wav_path))

    assert sr == 44100
    assert spec_norm.shape == (pipeline.config.spec_freq_bins, pipeline.config.spec_time_steps)
    assert phase.ndim == 2
