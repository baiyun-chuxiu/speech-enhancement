"""
Pydantic request/response schemas for the Audio Enhancement API.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class DeviceType(str, Enum):
    auto = "auto"
    cpu = "cpu"
    cuda = "cuda"
    mps = "mps"


class TaskStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


class ReadinessStatus(str, Enum):
    loading = "loading"
    ready = "ready"
    degraded = "degraded"


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = "1.0.0"
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    readiness_status: ReadinessStatus = ReadinessStatus.loading
    is_ready: bool = False
    degraded_reason: Optional[str] = None


class ReadinessResponse(BaseModel):
    status: ReadinessStatus = ReadinessStatus.loading
    version: str = "1.0.0"
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    is_ready: bool = False
    configured_device: str = "cpu"
    effective_device: str = "cpu"
    supported_devices: list[str] = Field(default_factory=list)
    degraded_reason: Optional[str] = None


class SystemInfo(BaseModel):
    version: str = "1.0.0"
    python_version: str
    platform: str
    cuda_available: bool
    mps_available: bool
    configured_device: str
    device: str
    supported_devices: list[str] = Field(default_factory=list)
    status: ReadinessStatus = ReadinessStatus.loading
    is_ready: bool = False
    degraded_reason: Optional[str] = None
    generator_loaded: bool = False
    denoise_loaded: bool = False
    generator_model_exists: bool = False
    denoise_model_exists: bool = False
    generator_error: Optional[str] = None
    denoise_error: Optional[str] = None
    supported_qualities: list[str] = Field(default_factory=list)
    supported_output_formats: list[str] = Field(default_factory=list)
    default_quality: str = "balanced"
    default_output_format: str = "wav"


class FileUploadResponse(BaseModel):
    success: bool
    file_id: str
    filename: str
    size: int
    content_type: str
    path: str


class EnhanceRequest(BaseModel):
    """Request body for the /enhance endpoint (when files are pre-uploaded)."""

    audio_file_id: str
    accel_file_id: str
    gyro_file_id: str
    device: DeviceType = DeviceType.auto
    quality: str = "balanced"
    output_format: str = "wav"


class ProcessingStep(BaseModel):
    index: int
    name: str
    status: TaskStatus = TaskStatus.pending
    progress: int = 0
    message: str = ""
    duration: Optional[float] = None


class EnhanceResult(BaseModel):
    success: bool
    output_file_id: Optional[str] = None
    output_url: Optional[str] = None
    output_path: Optional[str] = None
    output_file_name: Optional[str] = None
    output_size: Optional[int] = None
    total_time: Optional[float] = None
    step_times: Optional[dict[str, float]] = None
    requested_device: Optional[str] = None
    effective_device: Optional[str] = None
    device: Optional[str] = None
    quality: Optional[str] = None
    output_format: Optional[str] = None
    sample_rate: Optional[int] = None
    error: Optional[str] = None


class TaskInfo(BaseModel):
    task_id: str
    status: TaskStatus = TaskStatus.pending
    progress: int = 0
    message: str = ""
    steps: list[ProcessingStep] = Field(default_factory=list)
    result: Optional[dict[str, Any]] = None
    error: Optional[str] = None
    requested_device: Optional[str] = None
    effective_device: Optional[str] = None
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now().isoformat())


class EnhanceResponse(BaseModel):
    success: bool
    task_id: str
    status: TaskStatus = TaskStatus.pending
    requested_device: Optional[str] = None
    effective_device: Optional[str] = None
    quality: Optional[str] = None
    output_format: Optional[str] = None
    output_file: Optional[str] = None
    output_url: Optional[str] = None


class BatchEnhanceRequest(BaseModel):
    """Request body for the /enhance/batch endpoint."""

    samples: list[dict[str, Any]] = Field(
        ..., description="List of {audio_file_id, accel_file_id, gyro_file_id}"
    )
    device: DeviceType = DeviceType.auto
    quality: str = "balanced"
    output_format: str = "wav"


class BatchEnhanceResponse(BaseModel):
    success: bool
    task_id: str
    status: TaskStatus = TaskStatus.pending
    total_samples: int = 0
    requested_device: Optional[str] = None
    effective_device: Optional[str] = None
    quality: Optional[str] = None
    output_format: Optional[str] = None


class BatchResultItem(BaseModel):
    success: bool
    output_file_id: Optional[str] = None
    output_url: Optional[str] = None
    total_time: Optional[float] = None
    requested_device: Optional[str] = None
    effective_device: Optional[str] = None
    error: Optional[str] = None


class ErrorResponse(BaseModel):
    error: str
    message: str
    path: Optional[str] = None
