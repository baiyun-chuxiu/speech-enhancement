"""
Configuration management for the Audio Enhancement server.

Settings can be overridden via environment variables or .env file.
"""

import os
import sys
import torch
from pathlib import Path
from dataclasses import dataclass, field


def _get_base_dir() -> Path:
    """Get the base directory for bundled resources.

    When running as a PyInstaller one-file executable, resources are
    extracted to a temporary directory accessible via sys._MEIPASS.
    Otherwise, use the directory containing this file.
    """
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        return Path(sys._MEIPASS)
    return Path(__file__).parent


def _detect_device() -> str:
    """Auto-detect the best available compute device."""
    if torch.cuda.is_available():
        return "cuda"
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


@dataclass
class ServerConfig:
    """Server configuration with sensible defaults."""

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    cors_origins: list[str] = field(
        default_factory=lambda: [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://tauri.localhost",
            "https://tauri.localhost",
            "tauri://localhost",
        ]
    )

    # Paths
    base_dir: Path = field(default_factory=_get_base_dir)
    models_dir: Path = field(default_factory=lambda: _get_base_dir() / "models")
    upload_dir: Path = field(default_factory=lambda: Path(__file__).parent / "uploads")
    output_dir: Path = field(default_factory=lambda: Path(__file__).parent / "outputs")

    # Model files
    generator_model_path: Path = field(default_factory=lambda: _get_base_dir() / "models" / "generator_final.pth")
    denoise_model_path: Path = field(default_factory=lambda: _get_base_dir() / "models" / "best_model.pth")

    # Device
    device: str = field(default_factory=_detect_device)

    # Processing parameters
    video_mean: float = 0.0
    video_std: float = 1.0
    db_range: int = 90
    sample_rate: int = 44100
    target_peak: float = 0.95
    default_quality: str = "balanced"
    default_output_format: str = "wav"
    supported_qualities: list[str] = field(default_factory=lambda: ["balanced"])
    supported_output_formats: list[str] = field(default_factory=lambda: ["wav"])

    # IMU parameters
    imu_truncate_len: int = 125
    imu_interp_len: int = 150

    # Spectrogram parameters
    spec_freq_bins: int = 1025
    spec_time_steps: int = 431

    # Video displacement parameters
    video_disp_height: int = 150
    video_disp_width: int = 40
    video_fixed_min: float = -50.0
    video_fixed_max: float = 50.0

    def __post_init__(self):
        """Apply environment variable overrides and ensure directories exist."""
        self.host = os.environ.get("ENHANCER_HOST", self.host)
        self.port = int(os.environ.get("ENHANCER_PORT", str(self.port)))
        self.device = os.environ.get("ENHANCER_DEVICE", self.device)

        env_models_dir = os.environ.get("ENHANCER_MODELS_DIR")
        if env_models_dir:
            self.models_dir = Path(env_models_dir)
            self.generator_model_path = self.models_dir / "generator_final.pth"
            self.denoise_model_path = self.models_dir / "best_model.pth"

        env_gen_path = os.environ.get("ENHANCER_GENERATOR_PATH")
        if env_gen_path:
            self.generator_model_path = Path(env_gen_path)

        env_denoise_path = os.environ.get("ENHANCER_DENOISE_PATH")
        if env_denoise_path:
            self.denoise_model_path = Path(env_denoise_path)

        cors_env = os.environ.get("ENHANCER_CORS_ORIGINS")
        if cors_env:
            self.cors_origins = [o.strip() for o in cors_env.split(",")]

        # Ensure directories exist
        for d in [self.models_dir, self.upload_dir, self.output_dir]:
            d.mkdir(parents=True, exist_ok=True)


# Global config singleton
config = ServerConfig()
