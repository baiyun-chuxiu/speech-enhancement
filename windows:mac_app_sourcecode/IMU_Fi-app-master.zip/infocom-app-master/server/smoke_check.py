"""
Runtime smoke check for the Audio Enhancer backend.

This script boots the supported server entrypoint, validates liveness,
readiness, and system-info responses, then terminates the child process.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


def _read_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=3) as response:
        return json.loads(response.read().decode("utf-8"))


def _wait_for_endpoint(
    url: str, timeout_seconds: int, process: subprocess.Popen[str] | None = None
) -> dict:
    deadline = time.time() + timeout_seconds
    last_error: Exception | None = None
    while time.time() < deadline:
        if process and process.poll() is not None:
            raise RuntimeError(
                f"Backend process exited early with code {process.returncode} while waiting for {url}"
            )
        try:
            return _read_json(url)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = exc
            time.sleep(0.5)
    detail = f"; last error: {last_error}" if last_error else ""
    raise TimeoutError(f"Timed out waiting for {url}{detail}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Smoke test the Audio Enhancer backend")
    parser.add_argument("--port", type=int, default=8765, help="Temporary port for the smoke check")
    parser.add_argument(
        "--command",
        help="Optional executable to launch instead of `python -m server.main`",
    )
    parser.add_argument(
        "--expect-ready",
        action="store_true",
        help="Expect the backend to be ready instead of degraded",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=30,
        help="Seconds to wait for the server to come up",
    )
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent.parent
    env = os.environ.copy()
    env["ENHANCER_HOST"] = "127.0.0.1"
    env["ENHANCER_PORT"] = str(args.port)

    command = [args.command] if args.command else [sys.executable, "-m", "server.main"]
    process = subprocess.Popen(
        command,
        cwd=repo_root,
        env=env,
        stdin=subprocess.PIPE,
        # Inherit stdout/stderr to avoid deadlock when child logs fill PIPE buffers.
        stdout=None,
        stderr=None,
        text=True,
    )

    base_url = f"http://127.0.0.1:{args.port}"

    try:
        health = _wait_for_endpoint(f"{base_url}/health", args.timeout, process)
        readiness = _wait_for_endpoint(f"{base_url}/ready", args.timeout, process)
        system_info = _wait_for_endpoint(f"{base_url}/api/v1/system/info", args.timeout, process)

        if health.get("status") != "ok":
            raise RuntimeError(f"Expected /health status=ok, got: {health}")

        if args.expect_ready:
            if not readiness.get("is_ready"):
                raise RuntimeError(f"Expected ready backend, got: {readiness}")
        else:
            if readiness.get("is_ready"):
                raise RuntimeError(
                    "Smoke check expected degraded startup but backend reported ready"
                )
            if not readiness.get("degraded_reason"):
                raise RuntimeError(
                    "Smoke check expected a degraded reason when backend is not ready"
                )

        if bool(system_info.get("is_ready")) != bool(readiness.get("is_ready")):
            raise RuntimeError(
                f"System info readiness does not match /ready response: {system_info} vs {readiness}"
            )

        print("health:", json.dumps(health, ensure_ascii=True))
        print("ready:", json.dumps(readiness, ensure_ascii=True))
        print("system:", json.dumps(system_info, ensure_ascii=True))
        return 0
    finally:
        if process.stdin:
            try:
                process.stdin.write("sidecar shutdown\n")
                process.stdin.flush()
            except OSError:
                pass
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


if __name__ == "__main__":
    raise SystemExit(main())
