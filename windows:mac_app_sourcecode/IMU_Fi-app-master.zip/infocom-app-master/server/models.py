"""
Neural Network Model Definitions for Audio Enhancement Pipeline.

Models ported from the MobiCom 2026 research codebase.
- Generator: GAN model that converts IMU data to video displacement features
- AudioDenoiseNetwork: Joint audio-video denoising network
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class SpatialAttentionResidualBlock(nn.Module):
    """Residual block with spatial and channel attention mechanisms."""

    def __init__(self, in_channels: int):
        super(SpatialAttentionResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.bn2 = nn.BatchNorm2d(in_channels)
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(in_channels, 1, kernel_size=7, padding=3),
            nn.Sigmoid()
        )
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels // 4, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // 4, in_channels, kernel_size=1),
            nn.Sigmoid()
        )
        self.dropout = nn.Dropout(0.25)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.dropout(out)
        out = self.bn2(self.conv2(out))
        spatial_att = self.spatial_attention(out)
        channel_att = self.channel_attention(out)
        out = out * spatial_att * channel_att
        out += residual
        return F.relu(out)


class Generator(nn.Module):
    """
    GAN Generator: IMU sensor data -> Video displacement features.

    Input shape:  (batch, 1, 150, 6)  - normalized IMU data
    Output shape: (batch, 1, H, W)    - generated video displacement
    """

    def __init__(self):
        super(Generator, self).__init__()
        self.init_conv = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=7, stride=1, padding=3),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.down1 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True)
        )
        self.res1 = SpatialAttentionResidualBlock(256)
        self.res2 = SpatialAttentionResidualBlock(256)
        self.res3 = SpatialAttentionResidualBlock(256)
        self.res4 = SpatialAttentionResidualBlock(256)
        self.res5 = SpatialAttentionResidualBlock(256)
        self.up1 = nn.Sequential(
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )
        self.up2 = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.width_expansion = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 128, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 64, kernel_size=(1, 5), stride=(1, 3), padding=(0, 1)),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(64 + 64, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, kernel_size=7, stride=1, padding=3),
            nn.Tanh()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x0 = self.init_conv(x)
        x1 = self.down1(x0)
        x2 = self.down2(x1)
        x3 = self.res1(x2)
        x4 = self.res2(x3)
        x5 = self.res3(x4)
        x6 = self.res4(x5)
        x7 = self.res5(x6)
        x8 = self.up1(x7)
        x9 = self.up2(x8)
        x10 = self.width_expansion(x9)
        x0_up = F.interpolate(x0, size=x10.shape[2:], mode='bilinear', align_corners=True)
        fused = torch.cat([x10, x0_up], dim=1)
        return self.final_conv(fused)


class FeatureFusionModule(nn.Module):
    """
    Attention-based fusion of audio and video features.

    Combines encoded audio features with video displacement data
    using learned attention weights.
    """

    def __init__(self, audio_channels: int, video_channels: int, fusion_channels: int):
        super(FeatureFusionModule, self).__init__()
        self.audio_proj = nn.Sequential(
            nn.Conv2d(audio_channels, fusion_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(fusion_channels, eps=1e-3),
            nn.ReLU()
        )
        self.video_proj = nn.Sequential(
            nn.Linear(150 * 40, video_channels),
            nn.BatchNorm1d(video_channels, eps=1e-3),
            nn.ReLU(),
            nn.Linear(video_channels, fusion_channels),
            nn.BatchNorm1d(fusion_channels, eps=1e-3),
            nn.ReLU()
        )
        self.attention = nn.Sequential(
            nn.Linear(fusion_channels * 2, fusion_channels),
            nn.ReLU(),
            nn.Linear(fusion_channels, 2),
            nn.Softmax(dim=1)
        )
        self.fusion_refine = nn.Sequential(
            nn.Conv2d(fusion_channels, fusion_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(fusion_channels, eps=1e-3),
            nn.ReLU()
        )

    def forward(self, audio_feat: torch.Tensor, video_feat: torch.Tensor) -> torch.Tensor:
        batch_size = audio_feat.shape[0]
        audio_x = self.audio_proj(audio_feat)
        video_x = video_feat.reshape(batch_size, -1)
        video_x = self.video_proj(video_x)

        audio_global = F.adaptive_avg_pool2d(audio_x, (1, 1)).reshape(batch_size, -1)
        attn_input = torch.cat([audio_global, video_x], dim=1)
        attn_weights = self.attention(attn_input)
        audio_attn, video_attn = attn_weights[:, 0:1], attn_weights[:, 1:2]

        video_x_expanded = video_x.unsqueeze(-1).unsqueeze(-1).expand_as(audio_x)
        fused_feat = (audio_attn.unsqueeze(-1).unsqueeze(-1) * audio_x) + \
                     (video_attn.unsqueeze(-1).unsqueeze(-1) * video_x_expanded)
        return self.fusion_refine(fused_feat)


class ResidualBlock(nn.Module):
    """Standard residual block with optional stride for downsampling."""

    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels, eps=1e-3)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels, eps=1e-3)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels, eps=1e-3)
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(residual)
        return self.relu(out)


class AudioDenoiseNetwork(nn.Module):
    """
    Audio denoising network with video feature fusion.

    Takes noisy audio spectrogram and video displacement features,
    produces a cleaned audio spectrogram.

    Input:
      - audio_noisy: (batch, 1, 431, 1025) - normalized spectrogram
      - video_disp:  (batch, 1, 150, 40)   - video displacement
    Output:
      - clean spectrogram: (batch, 1, 431, 1025)
    """

    def __init__(self, in_channels: int = 1, fusion_channels: int = 32):
        super(AudioDenoiseNetwork, self).__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(16, 16),
            nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(32, 32),
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(64, 64),
        )
        self.feature_fusion = FeatureFusionModule(64, 128, fusion_channels)
        self.self_attention = nn.Sequential(
            nn.Conv2d(fusion_channels, fusion_channels // 2, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(fusion_channels // 2, fusion_channels, kernel_size=1),
            nn.Sigmoid()
        )
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(fusion_channels, 32, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(32, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(32, 32),
            nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(16, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(16, 16),
            nn.Conv2d(16, 8, kernel_size=3, padding=1),
            nn.BatchNorm2d(8, eps=1e-3),
            nn.ReLU(),
            nn.Conv2d(8, in_channels, kernel_size=3, padding=1),
            nn.Upsample(size=(431, 1025), mode='bilinear', align_corners=True),
            nn.Sigmoid()
        )

    def forward(self, audio_noisy: torch.Tensor, video_disp: torch.Tensor) -> torch.Tensor:
        audio_encoded = self.encoder(audio_noisy)
        fused_feat = self.feature_fusion(audio_encoded, video_disp)
        attn_map = self.self_attention(fused_feat)
        fused_feat = fused_feat * attn_map
        return self.decoder(fused_feat)
