import os
import numpy as np
import pandas as pd
import librosa
import librosa.display
import soundfile as sf
import torch
import torch.nn as nn
import torch.nn.functional as F
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import warnings
import time

# 忽略警告
warnings.filterwarnings("ignore")


# ==========================================
# 1. 网络模型定义 (保持不变)
# ==========================================

class SpatialAttentionResidualBlock(nn.Module):
    def __init__(self, in_channels):
        super(SpatialAttentionResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.bn2 = nn.BatchNorm2d(in_channels)
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(in_channels, 1, kernel_size=7, padding=3),
            nn.Sigmoid()
        )
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels // 4, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // 4, in_channels, kernel_size=1),
            nn.Sigmoid()
        )
        self.dropout = nn.Dropout(0.25)

    def forward(self, x):
        residual = x
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.dropout(out)
        out = self.bn2(self.conv2(out))
        spatial_att = self.spatial_attention(out)
        channel_att = self.channel_attention(out)
        out = out * spatial_att * channel_att
        out += residual
        return F.relu(out)


class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.init_conv = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=7, stride=1, padding=3),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.down1 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True)
        )
        self.res1 = SpatialAttentionResidualBlock(256)
        self.res2 = SpatialAttentionResidualBlock(256)
        self.res3 = SpatialAttentionResidualBlock(256)
        self.res4 = SpatialAttentionResidualBlock(256)
        self.res5 = SpatialAttentionResidualBlock(256)
        self.up1 = nn.Sequential(
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )
        self.up2 = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.width_expansion = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 128, kernel_size=(1, 4), stride=(1, 2), padding=(0, 1)),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 64, kernel_size=(1, 5), stride=(1, 3), padding=(0, 1)),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(64 + 64, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, kernel_size=7, stride=1, padding=3),
            nn.Tanh()
        )

    def forward(self, x):
        x0 = self.init_conv(x)
        x1 = self.down1(x0)
        x2 = self.down2(x1)
        x3 = self.res1(x2)
        x4 = self.res2(x3)
        x5 = self.res3(x4)
        x6 = self.res4(x5)
        x7 = self.res5(x6)
        x8 = self.up1(x7)
        x9 = self.up2(x8)
        x10 = self.width_expansion(x9)
        x0_up = F.interpolate(x0, size=x10.shape[2:], mode='bilinear', align_corners=True)
        fused = torch.cat([x10, x0_up], dim=1)
        return self.final_conv(fused)


class FeatureFusionModule(nn.Module):
    def __init__(self, audio_channels, video_channels, fusion_channels):
        super(FeatureFusionModule, self).__init__()
        self.audio_proj = nn.Sequential(
            nn.Conv2d(audio_channels, fusion_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(fusion_channels, eps=1e-3),
            nn.ReLU()
        )
        self.video_proj = nn.Sequential(
            nn.Linear(150 * 40, video_channels),
            nn.BatchNorm1d(video_channels, eps=1e-3),
            nn.ReLU(),
            nn.Linear(video_channels, fusion_channels),
            nn.BatchNorm1d(fusion_channels, eps=1e-3),
            nn.ReLU()
        )
        self.attention = nn.Sequential(
            nn.Linear(fusion_channels * 2, fusion_channels),
            nn.ReLU(),
            nn.Linear(fusion_channels, 2),
            nn.Softmax(dim=1)
        )
        self.fusion_refine = nn.Sequential(
            nn.Conv2d(fusion_channels, fusion_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(fusion_channels, eps=1e-3),
            nn.ReLU()
        )

    def forward(self, audio_feat, video_feat):
        batch_size = audio_feat.shape[0]
        audio_x = self.audio_proj(audio_feat)
        video_x = video_feat.reshape(batch_size, -1)
        video_x = self.video_proj(video_x)

        audio_global = F.adaptive_avg_pool2d(audio_x, (1, 1)).reshape(batch_size, -1)
        attn_input = torch.cat([audio_global, video_x], dim=1)
        attn_weights = self.attention(attn_input)
        audio_attn, video_attn = attn_weights[:, 0:1], attn_weights[:, 1:2]

        video_x_expanded = video_x.unsqueeze(-1).unsqueeze(-1).expand_as(audio_x)
        fused_feat = (audio_attn.unsqueeze(-1).unsqueeze(-1) * audio_x) + \
                     (video_attn.unsqueeze(-1).unsqueeze(-1) * video_x_expanded)
        return self.fusion_refine(fused_feat)


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels, eps=1e-3)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels, eps=1e-3)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels, eps=1e-3)
            )

    def forward(self, x):
        residual = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(residual)
        return self.relu(out)


class AudioDenoiseNetwork(nn.Module):
    def __init__(self, in_channels=1, fusion_channels=32):
        super(AudioDenoiseNetwork, self).__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(16, 16),
            nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(32, 32),
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(64, 64),
        )
        self.feature_fusion = FeatureFusionModule(64, 128, fusion_channels)
        self.self_attention = nn.Sequential(
            nn.Conv2d(fusion_channels, fusion_channels // 2, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(fusion_channels // 2, fusion_channels, kernel_size=1),
            nn.Sigmoid()
        )
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(fusion_channels, 32, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(32, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(32, 32),
            nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(16, eps=1e-3),
            nn.ReLU(),
            ResidualBlock(16, 16),
            nn.Conv2d(16, 8, kernel_size=3, padding=1),
            nn.BatchNorm2d(8, eps=1e-3),
            nn.ReLU(),
            nn.Conv2d(8, in_channels, kernel_size=3, padding=1),
            nn.Upsample(size=(431, 1025), mode='bilinear', align_corners=True),
            nn.Sigmoid()
        )

    def forward(self, audio_noisy, video_disp):
        audio_encoded = self.encoder(audio_noisy)
        fused_feat = self.feature_fusion(audio_encoded, video_disp)
        attn_map = self.self_attention(fused_feat)
        fused_feat = fused_feat * attn_map
        return self.decoder(fused_feat)


# ==========================================
# 2. 完整处理管线类
# ==========================================

class EnhancerPipeline:
    def __init__(self, config):
        self.config = config
        self.device = config['device']
        self._load_models()

    def _load_models(self):
        print(f"正在加载模型 (使用设备: {self.device})...")
        # 1. 加载 GAN 生成器
        self.generator = Generator().to(self.device)
        try:
            self.generator.load_state_dict(
                torch.load(self.config['generator_model_path'], map_location=self.device, weights_only=True))
            self.generator.eval()
            print("GAN Generator 加载成功")
        except Exception as e:
            print(f"GAN Generator 加载失败 (请检查路径): {e}")

        # 2. 加载去噪网络
        self.denoise_net = AudioDenoiseNetwork().to(self.device)
        try:
            self.denoise_net.load_state_dict(
                torch.load(self.config['denoise_model_path'], map_location=self.device, weights_only=True))
            self.denoise_net.eval()
            print("Denoise Network 加载成功")
        except Exception as e:
            print(f"Denoise Network 加载失败 (请检查路径): {e}")

    # -------------------------------------------------------------------------
    # 步骤 1: 预处理 IMU 数据
    # -------------------------------------------------------------------------
    def process_imu_data(self, acc_path, gyro_path):
        """读取 -> 截取125 -> 插值150 -> 计算模长 -> 合并"""

        def load_and_fix(path):
            df = pd.read_csv(path, sep=' ', header=None)
            data = df.iloc[:, :3].values if df.shape[1] == 3 else df.iloc[:, 1:4].values
            if len(data) >= 125:
                data = data[:125]
            else:
                data = np.vstack([data, np.zeros((125 - len(data), 3))])
            return data

        def interpolate(data):
            orig = np.linspace(0, 5.0, 125, endpoint=False)
            target = np.linspace(0, 5.0, 150, endpoint=False)
            res = np.empty((150, 3))
            for i in range(3):
                res[:, i] = np.interp(target, orig, data[:, i])
            return res

        acc = load_and_fix(acc_path)
        gyro = load_and_fix(gyro_path)

        acc_150 = interpolate(acc)
        gyro_150 = interpolate(gyro)

        acc_norm = np.sqrt(np.sum(acc_150 ** 2, axis=1, keepdims=True))
        gyro_norm = np.sqrt(np.sum(gyro_150 ** 2, axis=1, keepdims=True))
        return np.hstack((acc_norm, gyro_norm))

        # -------------------------------------------------------------------------

    # 步骤 2: GAN 生成视频位移
    # -------------------------------------------------------------------------
    def generate_video_displacement(self, imu_data):
        min_v, max_v = imu_data.min(), imu_data.max()
        if max_v == min_v:
            norm = np.zeros_like(imu_data, dtype=np.uint8)
        else:
            norm = ((imu_data - min_v) / (max_v - min_v) * 255).astype(np.uint8)

        img_pil = Image.fromarray(norm.T, mode='L')
        if img_pil.size[0] > img_pil.size[1]:
            img_pil = img_pil.rotate(90, expand=True)

        imu_np = np.array(img_pil, dtype=np.float32)
        imu_np = (imu_np / 127.5) - 1.0
        imu_tensor = torch.from_numpy(imu_np).unsqueeze(0).unsqueeze(0).to(self.device)

        if imu_tensor.shape[2:] != (150, 6):
            imu_tensor = F.interpolate(imu_tensor, size=(150, 6), mode='bilinear', align_corners=True)

        with torch.no_grad():
            gen_tensor = self.generator(imu_tensor)

        gen_tensor = (gen_tensor + 1) / 2
        gen_tensor = F.interpolate(gen_tensor, size=(150, 40), mode='bilinear', align_corners=True)
        gen_np = gen_tensor.squeeze().cpu().numpy()
        gen_img = Image.fromarray((gen_np * 255).astype(np.uint8))

        rotated_img = gen_img.rotate(-90, expand=True)
        gray_image = np.array(rotated_img)
        data_transposed = gray_image.T.astype(np.float32)

        FIXED_MIN, FIXED_MAX = -50.0, 50.0
        RANGE = FIXED_MAX - FIXED_MIN
        recovered_data = (data_transposed / 255.0) * RANGE + FIXED_MIN

        return recovered_data

    # -------------------------------------------------------------------------
    # 步骤 3: 音频预处理
    # -------------------------------------------------------------------------
    def process_audio_input(self, wav_path):
        y, sr = librosa.load(wav_path, sr=None)
        D = librosa.stft(y)
        S_db = librosa.amplitude_to_db(np.abs(D), ref=np.max)
        S_norm = (S_db - S_db.min()) / (S_db.max() - S_db.min() + 1e-9)

        S_norm = S_norm[::-1, :].copy()
        phase = np.angle(D)

        if S_norm.shape != (1025, 431):
            S_norm = cv2.resize(S_norm, (431, 1025))

        return S_norm, phase, sr

    # -------------------------------------------------------------------------
    # 步骤 4: 联合去噪
    # -------------------------------------------------------------------------
    def run_denoise_model(self, audio_spec_norm, video_data_npy):
        audio_in = audio_spec_norm.T.copy()
        audio_tensor = torch.tensor(audio_in, dtype=torch.float32).unsqueeze(0).unsqueeze(0).to(self.device)

        video_norm = (video_data_npy - self.config['video_mean']) / self.config['video_std']
        video_tensor = torch.tensor(video_norm, dtype=torch.float32).unsqueeze(0).to(self.device)

        with torch.no_grad():
            clean_spec = self.denoise_net(audio_tensor, video_tensor)
            clean_spec = torch.clamp(clean_spec, 0.0, 1.0)

        return clean_spec.squeeze().cpu().numpy()

    # -------------------------------------------------------------------------
    # 步骤 5: Pic -> NPY 转换
    # -------------------------------------------------------------------------
    def convert_spec_image_to_npy(self, clean_spec_np, output_img_path):
        img_data = clean_spec_np.T
        img_uint8 = (img_data * 255).astype(np.uint8)
        Image.fromarray(img_uint8, mode='L').save(output_img_path)

        img = Image.open(output_img_path).convert('L')
        img_array = np.array(img, dtype=np.float32)
        img_normalized = img_array / 255.0

        img_flipped = img_normalized[::-1, :].copy()

        return img_flipped

    # -------------------------------------------------------------------------
    # 步骤 6: ISTFT 合成语音 (包含自动音量)
    # -------------------------------------------------------------------------
    def reconstruct_audio_istft(self, norm_mag, phase, output_wav_path, db_range=90):
        print(f"  [ISTFT] 幅度谱形状: {norm_mag.shape}, 相位形状: {phase.shape}")
        start_time = time.time()

        norm_mag = norm_mag.astype(np.float32)
        if norm_mag.shape != phase.shape:
            target_width = phase.shape[1]
            target_height = phase.shape[0]
            norm_mag = cv2.resize(norm_mag, (target_width, target_height), interpolation=cv2.INTER_LINEAR)

        S_db = norm_mag * db_range - db_range
        magnitude = librosa.db_to_amplitude(S_db)

        if magnitude.shape != phase.shape:
            magnitude = magnitude[:phase.shape[0], :phase.shape[1]]

        D = magnitude * np.exp(1j * phase)
        y_recon = librosa.istft(D, hop_length=512, win_length=2048, window='hann', center=True)

        # 自动音量归一化 (Peak Normalization)
        max_amp = np.max(np.abs(y_recon))
        if max_amp > 0:
            scale_factor = 0.95 / max_amp
            y_recon = y_recon * scale_factor
            print(f"  [AutoGain] 峰值归一化 (Max: {max_amp:.5f} -> 0.95)")

        sf.write(output_wav_path, y_recon, 44100)
        cost = time.time() - start_time
        print(f"  [ISTFT] 音频重建耗时: {cost:.4f}s")

        self._plot_results(y_recon, output_wav_path)

    def _plot_results(self, y, path):
        plt.figure(figsize=(10, 4))
        plt.plot(y)
        plt.title("Reconstructed Audio Waveform")
        plt.tight_layout()
        plt.savefig(path + ".png")
        plt.close()

    # ==========================================
    # 主流程函数 (含总耗时统计)
    # ==========================================
    def process_single_sample(self, wav_path, acc_path, gyro_path, output_dir):
        file_id = os.path.splitext(os.path.basename(wav_path))[0]
        os.makedirs(output_dir, exist_ok=True)

        # 记录样本处理开始时间
        sample_start_time = time.time()
        print(f"\n>>> 开始处理样本: {file_id}")

        # Step 1 & 2
        print(">>> [1/4] 生成视频位移特征...")
        imu_data = self.process_imu_data(acc_path, gyro_path)
        video_disp = self.generate_video_displacement(imu_data)

        # Step 3
        print(">>> [2/4] 提取音频特征...")
        audio_spec_norm, audio_phase, sr = self.process_audio_input(wav_path)

        # Step 4
        print(">>> [3/4] 运行去噪模型...")
        clean_spec_raw = self.run_denoise_model(audio_spec_norm, video_disp)

        # Step 5
        spec_img_path = os.path.join(output_dir, f"audiopic_{file_id}.png")
        print(f">>> [4/4] 保存中间结果并重建音频...")
        cleaned_npy = self.convert_spec_image_to_npy(clean_spec_raw, spec_img_path)
        np.save(os.path.join(output_dir, f"audionpy_{file_id}.npy"), cleaned_npy)

        # Step 6
        out_wav_path = os.path.join(output_dir, f"enhanced_{file_id}.wav")
        self.reconstruct_audio_istft(cleaned_npy, audio_phase, out_wav_path, db_range=90)

        # 记录样本处理结束时间
        sample_end_time = time.time()
        total_time = sample_end_time - sample_start_time

        print(f"\n✅ 样本 {file_id} 处理完成!")
        print(f"📁 结果位于: {output_dir}")
        print(f"⏱️ 总耗时: {total_time:.4f} 秒")


# ==========================================
# 3. 运行配置
# ==========================================
if __name__ == "__main__":

    # --- 配置区域 ---

    # 1. 设备选择：优先检查 MPS (Mac M1/M2/M3)，其次检查 CUDA，最后使用 CPU
    if torch.cuda.is_available():
        device_name = "cuda"
    elif torch.backends.mps.is_available():
        device_name = "mps"
    else:
        device_name = "cpu"

    CONFIG = {
        "device": torch.device(device_name),
        "generator_model_path": "/Volumes/戴熠辰/2026.mobicom.code/软件制作所需code/所需要使用的原始code/权重模型/IMU2video/generator_final.pth",
        "denoise_model_path": "/Volumes/戴熠辰/2026.mobicom.code/软件制作所需code/所需要使用的原始code/权重模型/video2audio/best_model.pth",
        # 全局统计参数 (用于去噪模型输入归一化)
        "video_mean": 0.0,
        "video_std": 1.0
    }

    # --- 输入文件路径 ---
    # 请修改为你要测试的具体文件路径
    test_wav = "/Volumes/戴熠辰/2026.mobicom.code/测试数据/单个wavtxt测试数据/audio/segment_1.wav"
    test_acc = "/Volumes/戴熠辰/2026.mobicom.code/测试数据/单个wavtxt测试数据/acc/segment_1.txt"
    test_gyro = "/Volumes/戴熠辰/2026.mobicom.code/测试数据/单个wavtxt测试数据/gyro/segment_1.txt"

    output_folder = "./final_result_test"

    # --- 执行 ---
    pipeline = EnhancerPipeline(CONFIG)

    if os.path.exists(test_wav):
        pipeline.process_single_sample(test_wav, test_acc, test_gyro, output_folder)
    else:
        print("错误: 找不到输入文件，请检查代码底部的路径配置。")