# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Changelog

### 2026-01-21
- Enhanced documentation with Mermaid architecture diagrams
- Added comprehensive module structure visualization
- Added coverage report and testing strategy details
- Documented multi-backend API architecture patterns
- Added module-level documentation links

---

## Project Overview

InfoCom is a dual-deployment React + Tauri application for audio and sensor data analysis with local AI model processing capabilities. Users can upload and process accelerometer, gyroscope, and audio files through a web interface or desktop application, with visualization tools including waveform displays, frequency analyzers, and data charts.

- **Frontend**: Next.js 16 with React 19, TypeScript, and Tailwind CSS v4
- **Desktop Framework**: Tauri 2.9 for cross-platform desktop app capabilities
- **UI Components**: shadcn/ui with Radix UI primitives and Lucide icons
- **State Management**: Custom hooks-based pattern (Zustand installed but unused)
- **Styling**: Tailwind CSS with CSS variables and dark mode support
- **Testing**: Jest for unit tests, Playwright for E2E tests

## Module Structure Diagram

```mermaid
graph TD
    Root["(根) infocom-app<br/>InfoCom Audio & Sensor Platform"]
    Root --> Pages["pages/<br/>Next.js App Router"]
    Root --> Components["components/<br/>React Components"]
    Root --> Hooks["hooks/<br/>Custom Hooks"]
    Root --> Lib["lib/<br/>Utilities & API"]
    Root --> Desktop["desktop/<br/>Tauri Rust Backend"]
    Root --> E2E["e2e/<br/>Playwright Tests"]

    Pages --> PageLayout["layout.tsx"]
    Pages --> PageHome["page.tsx"]
    Pages --> PageUpload["upload/page.tsx"]
    Pages --> PageHelp["help/page.tsx"]
    Pages --> PageSettings["settings/page.tsx"]

    Components --> UIComponents["ui/<br/>shadcn/ui components"]
    Components --> UploadComponents["upload/<br/>Feature components"]

    Hooks --> HookUpload["useFileUpload.ts"]
    Hooks --> HookPlayer["useAudioPlayer.ts"]
    Hooks --> HookModel["useModelApi.ts"]

    Lib --> LibTypes["types.ts"]
    Lib --> LibUtils["utils.ts"]
    Lib --> LibApi["api/<br/>Multi-backend API"]

    Desktop --> DesktopMain["src/main.rs"]
    Desktop --> DesktopLib["src/lib.rs"]
    Desktop --> DesktopCommands["src/commands/<br/>Tauri commands"]

    click Pages "./app/CLAUDE.md" "Pages Module"
    click Components "./components/CLAUDE.md" "Components Module"
    click Hooks "./hooks/CLAUDE.md" "Hooks Module"
    click Lib "./lib/CLAUDE.md" "Library Module"
    click Desktop "./src-tauri/CLAUDE.md" "Desktop Module"
    click E2E "./e2e/CLAUDE.md" "E2E Tests Module"

    style Root fill:#e1f5fe
    style Pages fill:#fff3e0
    style Components fill:#f3e5f5
    style Hooks fill:#e8f5e9
    style Lib fill:#fce4ec
    style Desktop fill:#fff9c4
    style E2E fill:#e0f2f1
```

## Architecture Overview

```mermaid
graph TB
    subgraph Frontend["前端 Frontend (Next.js + React 19)"]
        Pages["App Router Pages"]
        Components["React Components"]
        Hooks["Custom Hooks"]
    end

    subgraph APILayer["API 抽象层 API Abstraction Layer"]
        ModelAPI["ModelApi 统一接口"]
        TauriAPI["TauriModelApi<br/>桌面环境"]
        HTTPAPI["HttpModelApi<br/>HTTP REST"]
        WSAPI["WebSocketModelApi<br/>实时通信"]
        InfocomAPI["InfocomModelApi<br/>INFOCOM 服务"]
        MockAPI["MockModelApi<br/>开发测试"]
    end

    subgraph Backend["后端选项 Backend Options"]
        TauriDesktop["Tauri Desktop<br/>Rust Commands"]
        HTTPServer["HTTP Server<br/>localhost:8080"]
        InfocomServer["INFOCOM Server<br/>localhost:8000"]
        LocalModel["Local AI Models<br/>(预留)"]
    end

    Pages --> ModelAPI
    Components --> Hooks
    Hooks --> ModelAPI

    ModelAPI --> TauriAPI
    ModelAPI --> HTTPAPI
    ModelAPI --> WSAPI
    ModelAPI --> InfocomAPI
    ModelAPI --> MockAPI

    TauriAPI --> TauriDesktop
    HTTPAPI --> HTTPServer
    WSAPI --> HTTPServer
    InfocomAPI --> InfocomServer
    MockAPI --> LocalModel

    style Frontend fill:#e3f2fd
    style APILayer fill:#fff3e0
    style Backend fill:#f1f8e9
    style ModelAPI fill:#ffecb3,stroke:#ff6f00,stroke-width:2px
```

## Development Commands

**Always use pnpm** (lockfile present).

### Frontend Development

```bash
pnpm dev              # Start Next.js dev server at http://localhost:3000
pnpm build            # Build Next.js app for production (outputs to out/)
pnpm start            # Start Next.js production server (after build)
pnpm lint             # Run ESLint (auto-fix: pnpm exec eslint . --fix)
pnpm exec tsc --noEmit # Type check without emitting files
```

### Testing

```bash
# Unit/Integration Tests (Jest + React Testing Library)
pnpm test             # Run all tests
pnpm test:watch       # Run tests in watch mode
pnpm test:coverage    # Run tests with coverage report

# E2E Tests (Playwright)
pnpm test:e2e         # Run all E2E tests (starts dev server automatically)
pnpm test:e2e:ui      # Run Playwright with UI mode
pnpm test:e2e:headed  # Run tests in headed mode (show browser)
pnpm test:e2e:debug   # Debug Playwright tests
pnpm test:e2e:report  # Show HTML test report
pnpm test:e2e:chromium # Run only Chromium tests
pnpm test:e2e:firefox   # Run only Firefox tests
pnpm test:e2e:webkit    # Run only WebKit tests
```

### Tauri Desktop App Development

```bash
pnpm tauri dev        # Start Tauri dev mode (starts frontend + desktop app with hot reload)
pnpm tauri build      # Build production desktop application
pnpm tauri info       # Display Tauri environment information
```

### Adding UI Components

```bash
pnpm dlx shadcn@latest add <component-name>
# Example: pnpm dlx shadcn@latest add card dialog
```

## Module Index

| Module | Path | Language | Description | Documentation |
|--------|------|----------|-------------|---------------|
| **Pages** | `app/` | TypeScript | Next.js App Router pages and layouts | [CLAUDE.md](./app/CLAUDE.md) |
| **Components** | `components/` | TypeScript | React components (UI + Features) | [CLAUDE.md](./components/CLAUDE.md) |
| **Hooks** | `hooks/` | TypeScript | Custom React hooks for state management | [CLAUDE.md](./hooks/CLAUDE.md) |
| **Library** | `lib/` | TypeScript | Utilities, types, and API layer | [CLAUDE.md](./lib/CLAUDE.md) |
| **Desktop** | `src-tauri/` | Rust | Tauri desktop application backend | [CLAUDE.md](./src-tauri/CLAUDE.md) |
| **E2E Tests** | `e2e/` | TypeScript | Playwright end-to-end test suite | [CLAUDE.md](./e2e/CLAUDE.md) |

## Architecture

### Dual Runtime Model

1. **Web mode** (`pnpm dev`): Next.js dev server at http://localhost:3000
2. **Desktop mode** (`pnpm tauri dev`): Tauri wraps the Next.js app in a native window

**Critical**: Tauri builds expect a static export from Next.js (`out/` directory). The `tauri.conf.json` points `frontendDist` to `../out`, and `next.config.ts` is configured with `output: "export"` for proper Tauri production builds.

### Multi-Backend API Architecture

The app supports five different backend implementations for model processing, with automatic backend selection:

```mermaid
graph LR
    Client[Client Code]
    API[modelApi.getApi<br/>自动选择]
    Tauri[TauriModelApi]
    HTTP[HttpModelApi]
    WS[WebSocketModelApi]
    Infocom[InfocomModelApi]
    Mock[MockModelApi<br/>默认]

    Client --> API
    API -->|环境检测| Tauri
    API -->|手动配置| HTTP
    API -->|实时通信| WS
    API -->|INFOCOM| Infocom
    API -->|开发模式| Mock

    style Mock fill:#ffcdd2,stroke:#c62828
```

**API Implementations**:

- **TauriModelApi**: Uses Tauri invoke commands for desktop app (optimal performance)
- **HttpModelApi**: Fetches from HTTP endpoints (localhost:8080)
- **WebSocketModelApi**: Connects via WebSocket for real-time progress updates
- **InfocomModelApi**: Calls INFOCOM REST API endpoints (localhost:8000)
- **MockModelApi**: Returns simulated data with WAV generation (default for development)

API initialization is in `lib/api/model-api.ts` with default mode 'mock'. Components call `modelApi.setMode()` to specify backend, and `getApi()` auto-detects the environment (Tauri vs web).

### State Management Pattern

**Custom hooks-based state management** (no global state libraries):
- Each domain (upload, player, API) gets a dedicated hook
- Hooks accept callback options (`onSuccess`, `onError`, `onComplete`) for parent coordination
- Data flows unidirectionally from hooks through props to UI components
- Component tree is shallow (2-3 levels), making props drilling manageable

Key hooks:
- `hooks/useFileUpload.ts`: Manages file upload state, validation, progress tracking, and file parsing
- `hooks/useAudioPlayer.ts`: Handles audio playback state, AudioContext management, and waveform analysis
- `hooks/useModelApi.ts`: Orchestrates model API processing, step tracking, progress updates, and error handling

### Frontend Structure

- `app/` - Next.js App Router pages and layout
  - `layout.tsx` - Root layout with Geist fonts and global styles
  - `page.tsx` - Main landing page
  - `upload/page.tsx` - Upload/processing page that orchestrates custom hooks
  - `globals.css` - Global Tailwind styles and CSS variables
- `components/` - Reusable React components
  - `ui/` - shadcn/ui components (Button, Dialog, etc.)
  - `upload/` - Feature components for file upload, audio player, visualization
- `hooks/` - Custom React hooks for state management
- `lib/` - Utility functions and configurations
  - `api/` - Multi-backend API implementations
  - `utils.ts` - Tailwind utility function (`cn`) for class merging
  - `types.ts` - Shared type definitions for all state structures
- `components.json` - shadcn/ui configuration with path aliases

### Tauri Integration

- `src-tauri/` - Rust backend for desktop functionality
  - `tauri.conf.json` - Tauri configuration (window settings, build commands)
  - `src/main.rs` - Main Rust application entry point
  - `src/lib.rs` - Rust library code with debug logging setup
  - `src/commands/` - Tauri commands implementing model API interface
  - `Cargo.toml` - Rust dependencies
- **Build Configuration**: Tauri builds the Next.js app to `out/` directory and bundles it
- **Development**: Tauri runs `pnpm dev` for frontend and serves at `http://localhost:3000`

### Key Technologies

- **Next.js 16** with App Router for React 19 applications
- **Tailwind CSS v4** with PostCSS for styling
- **shadcn/ui** component library built on Radix UI primitives
- **Tauri 2.9** for building cross-platform desktop apps
- **TypeScript** throughout the stack
- **Jest + React Testing Library** for unit/integration tests
- **Playwright** for E2E testing across browsers

### Path Aliases (configured in components.json and tsconfig.json)

```typescript
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
```

Available aliases:
- `@/components` → `components/`
- `@/lib` → `lib/`
- `@/hooks` → `hooks/`
- `@/ui` → `components/ui`
- `@/utils` → `lib/utils.ts`

## Development Patterns

### Import Paths
Always use `@/` alias for internal imports (not relative paths).

### Component Composition
Prefer composition patterns with `asChild` for buttons/links:
```tsx
<Button asChild>
  <Link href="/path">Click me</Link>
</Button>
```

### Styling Utilities
- Use `cn()` from `@/lib/utils` to merge Tailwind classes safely
- Example: `cn("base-classes", conditionalClass && "conditional-classes", className)`
- Tailwind v4 with CSS variables for theming (defined in `app/globals.css`)
- Class-based dark mode: apply `.dark` class to parent element

### Testing Patterns
- Unit tests: Co-located with components using `.test.tsx` suffix
- E2E tests: Located in `e2e/` directory
- Playwright automatically starts dev server on `http://localhost:3000`
- Jest configured with path aliases and CSS/image mocks

## Testing Strategy

### Unit Testing (Jest)

**Coverage Configuration**:
- Thresholds: 60% branches, 60% functions, 70% lines, 70% statements
- Provider: v8
- Reporters: JSON, text, lcov, HTML, clover, cobertura

**Test File Pattern**: `**/*.test.tsx` or `**/*.spec.tsx`

**Current Coverage**:
- Pages: 33% (3/9 files tested)
- Components: 25% (7/28 files tested)
- Hooks: 0% (tested indirectly through components)
- Library: 25% (2/8 files tested)

### E2E Testing (Playwright)

**Browser Coverage**: Chromium, Firefox, WebKit (desktop + mobile)
**Test Categories**:
- Upload complete flow
- Upload validation
- API integration
- Navigation
- File drag & drop
- Settings
- Audio player
- Data visualization
- Responsive design
- Accessibility
- Performance
- Edge cases

## Development Notes

- The app uses pnpm as the preferred package manager (see pnpm-lock.yaml)
- Tauri configuration is set to build the frontend to `out/` directory (not `.next`)
- The project supports both web and desktop deployment from the same codebase
- shadcn/ui is configured with "new-york" style and CSS variables for theming
- Coverage thresholds configured (60-70%) in Jest but disabled by default
- Playwright configured for Chromium, Firefox, WebKit (desktop + mobile)
- INFOCOM API client supports both REST and WebSocket connections

## Coverage & Gaps

### What's Well Covered
- Next.js App Router pages and layouts
- shadcn/ui component integration
- Upload feature components with tests
- Multi-backend API architecture
- E2E test suite across browsers

### Known Gaps
- Hook unit tests (tested indirectly through components)
- Rust/Tauri backend tests
- Some UI components lack dedicated test files
- Visual regression tests not implemented

### Recommendations
1. Add dedicated unit tests for custom hooks
2. Implement Rust unit tests for Tauri commands
3. Expand component test coverage
4. Consider adding visual regression tests
5. Improve API mocking utilities for test isolation

## AI Usage Guidelines

When working with this codebase:

1. **Always use `@/` path aliases** for internal imports
2. **Follow the hooks-based state management pattern** - don't introduce global state libraries
3. **Maintain the multi-backend API abstraction** - keep implementations separate
4. **Write tests for new components** using `.test.tsx` suffix
5. **Use the custom hooks** (`useFileUpload`, `useAudioPlayer`, `useModelApi`) instead of duplicating logic
6. **Maintain responsive design** - test on mobile and desktop viewports
7. **Follow the existing component structure** in `components/upload/` for new features

## Troubleshooting

### Port 3000 already in use
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# macOS/Linux
lsof -ti:3000 | xargs kill -9
```

### Tauri build fails
```bash
pnpm tauri info  # Check environment
rustup update    # Update Rust
cd src-tauri && cargo clean  # Clean build cache
```

### Module not found errors
```bash
rm -rf .next node_modules pnpm-lock.yaml
pnpm install
```

## Related Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [Tauri Documentation](https://tauri.app/)
- [shadcn/ui Documentation](https://ui.shadcn.com/)
- [Tailwind CSS v4](https://tailwindcss.com/docs)
- [Radix UI Primitives](https://www.radix-ui.com/)
